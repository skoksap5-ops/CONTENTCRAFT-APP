import React, { useState, useCallback, useEffect, Suspense, lazy } from 'react';
import type { Module, View } from './types';
import Dashboard from './components/Dashboard';
import ModuleView from './components/ModuleView';
import { useDailyUsage } from './hooks/useDailyUsage';
import { processQueue } from './services/offlineService';
import { analytics } from './services/firebase';
import { logEvent } from 'firebase/analytics';
import ProfileView from './components/ProfileView';
import ArrowLeftIcon from './components/icons/ArrowLeftIcon';
import ShareView from './components/ShareView';
import SplashScreen from './components/SplashScreen';
import SettingsView from './components/SettingsView';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';
import { useFeedback } from './hooks/useFeedback';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import AuthView from './components/AuthView';
import HistoryView from './components/HistoryView';
import LanguageSettingsView from './components/LanguageSettingsView';
import FontSizeSettingsView from './components/FontSizeSettingsView';
import HelpView from './components/HelpView';
import { useLanguage } from './hooks/useLanguage';
import UpgradeView from './components/UpgradeView';
import ManageSubscriptionView from './components/ManageSubscriptionView';
import FloatingChatbot from './components/FloatingChatbot';
import EarnWithContentCraftView from './components/EarnWithContentCraftView';
import { MODULES } from './constants';

const BannerAppView = lazy(() => import('./components/BannerAppView'));

const App: React.FC = () => {
  const [showSplashScreen, setShowSplashScreen] = useState(true);
  const [selectedModule, setSelectedModule] = useState<Module | null>(null);
  const [activeView, setActiveView] = useState<View>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { userId, usesLeft, totalUses, addUses, decrementUse, isPremium, isLoadingUser, streakRewardGranted } = useDailyUsage();
  const { playClick } = useFeedback();
  const { t } = useLanguage();
  const [notification, setNotification] = useState<string | null>(null);

  useEffect(() => {
    if (streakRewardGranted) {
        setNotification("🎉 Congratulations! You've earned +1 credit for your 7-day streak!");
        const timer = setTimeout(() => setNotification(null), 5000);
        return () => clearTimeout(timer);
    }
  }, [streakRewardGranted]);

  useEffect(() => {
    const removeTimer = setTimeout(() => {
      setShowSplashScreen(false);
    }, 6000);

    return () => {
      clearTimeout(removeTimer);
    };
  }, []);

  // Set up listener for processing offline queue
  useEffect(() => {
    const handleOnline = () => {
      console.log("Application is back online. Processing offline queue...");
      processQueue(decrementUse);
    };

    window.addEventListener('online', handleOnline);

    if (navigator.onLine) {
       console.log("Application is online. Checking for offline requests...");
       processQueue(decrementUse);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
    };
  }, [decrementUse]);


  const handleModuleSelect = useCallback((module: Module) => {
    if (analytics && userId) {
      logEvent(analytics, 'select_content', {
        content_type: 'module',
        item_id: module.id,
        item_name: module.name,
      });
    }
    setSelectedModule(module);
  }, [userId]);
  
  const handleBackToDashboard = useCallback(() => {
    playClick();
    setSelectedModule(null);
  }, [playClick]);

  if (showSplashScreen) {
    return <SplashScreen />;
  }

  if (isLoadingUser) {
    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-base-100 dark:bg-d-base-100">
        <div className="text-center animate-fade-in-up">
            <svg className="animate-spin mx-auto h-8 w-8 text-brand-primary mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <h1 className="text-2xl sm:text-3xl font-bold text-text-primary dark:text-d-text-primary tracking-tight font-heading">
                {t('initializingSession')}
            </h1>
            <p className="text-text-secondary dark:text-d-text-secondary mt-2">{t('gettingThingsReady')}</p>
        </div>
      </div>
    );
  }

  if (!userId) {
    return <AuthView />;
  }

  if (activeView === 'share') {
    return <ShareView onClose={() => setActiveView('dashboard')} addUses={addUses} />;
  }

  if (activeView === 'privacy') {
    return <PrivacyPolicy onClose={() => setActiveView('profile')} />;
  }

  if (activeView === 'terms') {
    return <TermsOfService onClose={() => setActiveView('profile')} />;
  }
  
  if (activeView === 'helpFromProfile') {
    return <HelpView onClose={() => setActiveView('profile')} />;
  }
  if (activeView === 'helpFromSettings') {
    return <HelpView onClose={() => setActiveView('settings')} />;
  }

  if (activeView === 'language') {
    return <LanguageSettingsView onClose={() => setActiveView('settings')} />;
  }

  if (activeView === 'fontSize') {
    return <FontSizeSettingsView onClose={() => setActiveView('settings')} />;
  }
  
  if (activeView === 'upgrade') {
    return <UpgradeView onClose={() => setActiveView('profile')} />;
  }

  if (activeView === 'subscription') {
    return <ManageSubscriptionView onClose={() => setActiveView('profile')} />;
  }
  
  if (activeView === 'banner') {
    return <Suspense fallback={<div>Loading...</div>}><BannerAppView onClose={() => setActiveView('settings')} /></Suspense>;
  }

  const renderActiveView = () => {
    switch(activeView) {
      case 'profile':
        return <ProfileView usesLeft={usesLeft} totalUses={totalUses} isPremium={isPremium} setView={setActiveView} />;
      case 'settings':
         return <SettingsView setView={setActiveView} />;
      case 'history':
         return <HistoryView userId={userId} />;
      case 'earn':
        const earnModule = MODULES.find(m => m.id === 'earn-with-content-craft-365');
        if (!earnModule) return <div>Error: Earn module not found</div>;
        return <EarnWithContentCraftView module={earnModule} userId={userId} usesLeft={usesLeft} decrementUse={decrementUse} isPremium={isPremium} />;
      case 'dashboard':
      default:
        return <Dashboard onModuleSelect={handleModuleSelect} />;
    }
  };

  return (
    <div className="min-h-screen font-sans bg-base-100 dark:bg-d-base-100">
        {notification && (
            <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fade-in-up">
                {notification}
            </div>
        )}

        {!selectedModule ? (
            <Header onMenuClick={() => setIsSidebarOpen(true)} usesLeft={usesLeft} setView={setActiveView} isPremium={isPremium}/>
        ) : (
            <div className="flex items-center px-4 sm:px-6 lg:px-8 h-16 bg-base-200/80 dark:bg-d-base-200/80 sticky top-0 z-20 backdrop-blur-sm border-b border-base-300 dark:border-d-base-300">
                <button
                    onClick={handleBackToDashboard}
                    className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-300 dark:hover:bg-d-base-300 hover:text-text-primary dark:hover:text-d-text-primary transition-colors mr-2"
                    aria-label={t('backToDashboard')}
                >
                    <ArrowLeftIcon className="h-6 w-6" />
                </button>
                <h1 className="text-xl sm:text-2xl font-bold text-text-primary dark:text-d-text-primary tracking-tight font-heading truncate">
                    {selectedModule.name}
                </h1>
            </div>
        )}

        <Sidebar 
            isOpen={isSidebarOpen && !selectedModule} 
            onClose={() => setIsSidebarOpen(false)} 
            setView={setActiveView} 
            activeView={activeView}
            isPremium={isPremium}
        />

        <main className={`p-4 sm:p-6 lg:p-8 ${!selectedModule ? 'pt-24' : ''}`}>
             {selectedModule ? (
                <Suspense fallback={
                    <div className="flex justify-center items-center p-16">
                        <svg className="animate-spin h-8 w-8 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    </div>
                }>
                    <ModuleView 
                      module={selectedModule}
                      userId={userId}
                      usesLeft={usesLeft} 
                      decrementUse={decrementUse}
                      isPremium={isPremium} 
                    />
                </Suspense>
             ) : (
                renderActiveView()
             )}
        </main>
        
        <FloatingChatbot />
    </div>
  );
};

export default App;