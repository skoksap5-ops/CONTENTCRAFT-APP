export interface Module {
  id: string;
  name: string;
  description: string;
  group: string;
  prompt: (input: string, tones: string[]) => string;
}

export interface Generation {
  id: number;
  moduleName: string;
  inputs: string;
  output: string;
  timestamp: string;
}

export type View = 'dashboard' | 'profile' | 'settings' | 'share' | 'privacy' | 'terms' | 'history' | 'language' | 'fontSize' | 'helpFromProfile' | 'helpFromSettings' | 'upgrade' | 'subscription' | 'earn' | 'banner';