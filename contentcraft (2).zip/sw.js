const CACHE_NAME = 'contentcraft-cache-v2';
const IMMUTABLE_CACHE_NAME = 'contentcraft-immutable-v2';

// URLs for the app shell that should be cached on install.
const APP_SHELL_URLS = [
    '/',
    '/index.html',
    '/manifest.json',
    '/icon.svg'
];

// URLs for immutable assets (libs from CDN). Note: aistudiocdn URLs are wildcard-matched by origin below.
const IMMUTABLE_URL_ORIGINS = [
    'https://aistudiocdn.com',
    'https://www.gstatic.com',
    'https://cdn.tailwindcss.com',
    'https://fonts.googleapis.com',
    'https://fonts.gstatic.com'
];


self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
        return cache.addAll(APP_SHELL_URLS);
    })
  );
});

self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter(name => name !== CACHE_NAME && name !== IMMUTABLE_CACHE_NAME)
          .map(name => {
            console.log('Service Worker: Deleting old cache', name);
            return caches.delete(name);
          })
      );
    })
  );
  return self.clients.claim();
});

self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    // Ignore non-GET requests
    if (request.method !== 'GET') {
        return;
    }

    // For immutable CDN assets, use a cache-first strategy.
    if (IMMUTABLE_URL_ORIGINS.some(origin => url.origin === origin)) {
        event.respondWith(
            caches.open(IMMUTABLE_CACHE_NAME).then(cache => {
                return cache.match(request).then(cachedResponse => {
                    if (cachedResponse) {
                        return cachedResponse;
                    }
                    return fetch(request).then(networkResponse => {
                        cache.put(request, networkResponse.clone());
                        return networkResponse;
                    });
                });
            })
        );
        return;
    }

    // For all other requests (app assets), use a stale-while-revalidate strategy.
    event.respondWith(
        caches.open(CACHE_NAME).then(cache => {
            return cache.match(request).then(cachedResponse => {
                const fetchPromise = fetch(request).then(networkResponse => {
                    // Don't cache firestore requests
                    if (!request.url.includes('firestore.googleapis.com')) {
                       cache.put(request, networkResponse.clone());
                    }
                    return networkResponse;
                }).catch(err => {
                    // If network fails and there's no cache, this will fail.
                    // For navigations, we can provide a fallback.
                    if (request.mode === 'navigate') {
                        return caches.match('/');
                    }
                });

                // Return cached response immediately if available, and update cache in background.
                return cachedResponse || fetchPromise;
            });
        })
    );
});
