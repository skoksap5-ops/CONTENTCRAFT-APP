import type { Module } from './types';
import { MODULES } from './constants/modules';
import { MODULE_GROUPS, MODULE_GROUPS_MAP } from './constants/groups';

export interface Tone {
  name: string;
  description: string;
  example: {
    before: string;
    after: string;
  };
}

export interface ToneCategory {
  name: string;
  tones: Tone[];
  color: {
    bg: string;
    border: string;
    text: string;
    hoverBorder: string;
  }
}

export const TONE_CATEGORIES: ToneCategory[] = [
  {
    name: 'Standard',
    color: {
      bg: 'bg-indigo-500/10',
      border: 'border-indigo-500',
      text: 'text-indigo-400',
      hoverBorder: 'hover:border-indigo-500/50'
    },
    tones: [
      { name: 'Formal', description: 'Professional, following established rules and conventions.', example: { before: "We need to finish this report ASAP.", after: "It is imperative that the report is finalized at your earliest convenience." } },
      { name: 'Assertive', description: 'Confident, direct, and decisive.', example: { before: "I think we could try a different approach.", after: "We must implement a different strategy to achieve our goals." } },
      { name: 'Informative', description: 'Provides clear facts and data.', example: { before: "The new feature is cool.", after: "The new feature increases user efficiency by 35% by automating data entry." } },
      { name: 'Convincing', description: 'Persuasive and able to make someone believe something.', example: { before: "You should buy this product.", after: "Investing in this product will revolutionize your workflow and deliver a significant return on investment." } },
      { name: 'Urgent', description: 'Requires immediate action or attention.', example: { before: "Please look at this when you have a moment.", after: "Immediate attention is required: The system will go offline in one hour for critical updates." } },
    ]
  },
  {
    name: 'Emotional',
    color: {
      bg: 'bg-rose-500/10',
      border: 'border-rose-500',
      text: 'text-rose-400',
      hoverBorder: 'hover:border-rose-500/50'
    },
    tones: [
      { name: 'Appreciative', description: 'Expresses gratitude and thankfulness.', example: { before: "Thanks for the help.", after: "I am incredibly grateful for your invaluable assistance; I couldn't have done it without you." } },
      { name: 'Enthusiastic', description: 'Shows intense excitement and eagerness.', example: { before: "The event went well.", after: "The event was an absolutely spectacular success! The energy was electric!" } },
      { name: 'Awestruck', description: 'Filled with feelings of admiration and wonder.', example: { before: "The new design looks good.", after: "I am absolutely blown away by the new design; it's a true masterpiece of creativity and skill." } },
      { name: 'Joyful', description: 'Expresses great happiness and cheer.', example: { before: "I'm happy about the news.", after: "I'm absolutely thrilled and overjoyed to hear the wonderful news!" } },
      { name: 'Passionate', description: 'Shows strong, intense emotion and belief.', example: { before: "I care about this project.", after: "This project is more than just a task; it's a mission I believe in with every fiber of my being." } },
      { name: 'Humorous', description: 'Amusing, witty, and designed to make people laugh.', example: { before: "Our meeting has been rescheduled.", after: "Hold the phone! Our beloved meeting has been moved. Try to contain your excitement." } },
      { name: 'Thoughtful', description: 'Shows careful consideration for others or a topic.', example: { before: "Here is the document.", after: "I've attached the document, and I also highlighted a few sections I thought would be most relevant to your current focus." } },
      { name: 'Empathetic', description: 'Shows the ability to understand and share the feelings of another.', example: { before: "I'm sorry you missed the deadline.", after: "I understand how challenging it can be to juggle so many priorities, and I'm here to support you in getting back on track." } },
      { name: 'Sympathetic', description: 'Expresses sorrow or pity for someone else\'s misfortune.', example: { before: "That's too bad about the project funding.", after: "I was so sorry to hear the news about the project funding. That must be incredibly disappointing for the whole team." } },
    ]
  },
  {
    name: 'Inspirational',
    color: {
      bg: 'bg-amber-500/10',
      border: 'border-amber-500',
      text: 'text-amber-400',
      hoverBorder: 'hover:border-amber-500/50'
    },
    tones: [
      { name: 'Inspirational', description: 'Uplifting and motivating.', example: { before: "We need to work harder.", after: "Together, we have the power to overcome any obstacle and achieve greatness beyond our wildest dreams." } },
      { name: 'Encouraging', description: 'Gives support, confidence, or hope.', example: { before: "That was a good attempt.", after: "You've made fantastic progress, and I'm confident you'll succeed. Keep up the great work!" } },
      { name: 'Optimistic', description: 'Hopeful and confident about the future.', example: { before: "There are some problems.", after: "While there are challenges ahead, I see incredible opportunities for growth and innovation." } },
      { name: 'Earnest', description: 'Shows sincere and intense conviction.', example: { before: "It is important to follow the guidelines.", after: "I sincerely believe that adhering to these guidelines is fundamental to our shared success and integrity." } },
    ]
  },
  {
    name: 'Neutral',
    color: {
      bg: 'bg-slate-500/10',
      border: 'border-slate-500',
      text: 'text-slate-400',
      hoverBorder: 'hover:border-slate-500/50'
    },
    tones: [
      { name: 'Neutral', description: 'Impartial and without strong emotional color.', example: { before: "The new policy is good, I guess.", after: "The new policy will be implemented on Monday, affecting all departments." } },
      { name: 'Casual', description: 'Relaxed, informal, and conversational.', example: { before: "Please find the attached file for your review.", after: "Hey, just sent over the file. Let me know what you think!" } },
      { name: 'Candid', description: 'Truthful, straightforward, and frank.', example: { before: "There are some areas for improvement in the presentation.", after: "To be frank, the presentation's data section was confusing and needs to be reworked for clarity." } },
      { name: 'Humble', description: 'Shows a modest or low estimate of one\'s own importance.', example: { before: "I led the project to success.", after: "I was fortunate to be part of a talented team that collectively achieved a successful project outcome." } },
    ]
  },
  {
    name: 'Serious',
    color: {
      bg: 'bg-red-500/10',
      border: 'border-red-500',
      text: 'text-red-400',
      hoverBorder: 'hover:border-red-500/50'
    },
    tones: [
      { name: 'Serious', description: 'Sober, thoughtful, and not light-hearted.', example: { before: "We need to discuss the budget issues.", after: "We must convene to address the significant budgetary shortfalls." } },
      { name: 'Compassionate', description: 'Feels or shows sympathy and concern for others.', example: { before: "Don't worry about the mistake.", after: "It's completely understandable that this happened, and we're here to help you work through it." } },
      { name: 'Cautionary', description: 'Serves as a warning of potential danger or problems.', example: { before: "Be careful when deploying the update.", after: "Proceed with extreme caution: Deploying this update without proper backups could result in irreversible data loss." } },
      { name: 'Critical', description: 'Expresses disapproving comments or judgments.', example: { before: "The report has some mistakes.", after: "The report is fundamentally flawed due to numerous factual inaccuracies and a lack of clear analysis." } },
      { name: 'Worried', description: 'Feels anxious or troubled about potential problems.', example: { before: "I hope the launch goes well.", after: "I am deeply concerned about the upcoming launch, given the unresolved bugs in the system." } },
      { name: 'Angry', description: 'Expresses strong annoyance, displeasure, or hostility.', example: { before: "I'm not happy with the quality of this work.", after: "The quality of this work is completely unacceptable and falls far below the standards we demand." } },
      { name: 'Skeptical', description: 'Not easily convinced; having doubts or reservations.', example: { before: "The new plan sounds promising.", after: "I have significant doubts about whether this new plan is truly viable given the logistical hurdles." } },
    ]
  },
  {
    name: 'Professional',
    color: {
      bg: 'bg-gray-600/10',
      border: 'border-gray-500',
      text: 'text-gray-400',
      hoverBorder: 'hover:border-gray-500/50'
    },
    tones: [
      { name: 'Professional', description: 'Exhibits competence and a business-like manner.', example: { before: "Gimme the files when u can.", after: "Please provide the necessary files at your earliest convenience." } },
      { name: 'Authoritative', description: 'Commanding, knowledgeable, and reliable.', example: { before: "Maybe we should do it this way.", after: "The standard operating procedure requires that we execute this task as follows." } },
      { name: 'Collaborative', description: 'Encourages teamwork and cooperation.', example: { before: "I'll do this part, you do that part.", after: "Let's work together on this. How about I handle the research, and you can focus on the initial draft?" } },
    ]
  }
];

export const ALL_TONES: Tone[] = TONE_CATEGORIES.flatMap(category => category.tones);
export const ALL_TONE_NAMES: string[] = ALL_TONES.map(tone => tone.name);

export { MODULE_GROUPS_MAP, MODULE_GROUPS };

export { MODULES };
