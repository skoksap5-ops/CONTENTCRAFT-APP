import { useState, useCallback } from 'react';
import { Type } from "@google/genai";
import { generateContent } from '../services/geminiService';
import { saveGeneration } from '../services/historyService';
import type { QuizConfig, QuizData, QuizQuestion } from '../components/ai-quiz-creator/types';

const quizSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING },
        questions: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    id: { type: Type.NUMBER },
                    type: { type: Type.STRING, enum: ['multiple-choice'] },
                    question: { type: Type.STRING },
                    options: { type: Type.ARRAY, items: { type: Type.STRING } },
                    correctAnswers: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                    explanation: { type: Type.STRING }
                },
                required: ['id', 'type', 'question', 'options', 'correctAnswers', 'explanation']
            }
        }
    },
    required: ['title', 'questions']
};

const generateQuizContent = async (config: QuizConfig): Promise<Omit<QuizData, 'results' | 'config'>> => {
    const prompt = `You are an expert quiz designer and instructional designer. Create a high-quality quiz based on the following specifications.

    **SPECIFICATIONS:**
    - Title: "${config.title}"
    - Topic: "${config.topic}"
    - Quiz Type: ${config.type}
    - Difficulty: ${config.difficulty}
    - Number of Questions: ${config.questionCount}
    - Target Audience: ${config.audience}
    - Primary Purpose: ${config.purpose}

    **INSTRUCTIONS:**
    1. Generate exactly ${config.questionCount} questions.
    2. For each question, provide 4 distinct options.
    3. For 'knowledge' or 'assessment' types, provide the index of the correct answer (e.g., [0] for the first option). For 'personality' quizzes, you can leave correctAnswers as an empty array [] as there's no single right answer.
    4. Provide a brief, helpful explanation for each question.
    5. Ensure the questions and options align with the specified difficulty and audience.
    6. Your response must be a valid JSON object conforming to the provided schema. The 'id' for each question should be a unique number (you can just use the index, 1, 2, 3...).
    `;

    const responseText = await generateContent(prompt, {
        responseMimeType: "application/json",
        responseSchema: quizSchema as any,
    });

    try {
        const parsed = JSON.parse(responseText);
        // Ensure IDs are unique if the AI doesn't do it correctly
        if (parsed.questions && Array.isArray(parsed.questions)) {
            parsed.questions.forEach((q: any, i: number) => q.id = Date.now() + i);
        }
        return parsed as Omit<QuizData, 'results' | 'config'>;
    } catch (e) {
        console.error("Failed to parse quiz JSON:", responseText, e);
        throw new Error("The AI returned an unexpected format for the quiz.");
    }
};

export const quizService = {
    generateQuizContent,
};


export const useQuizAI = (
    userId: string | null,
    moduleId: string,
    moduleName: string,
    usesLeft: number | 'Unlimited',
    decrementUse: () => void
) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateQuiz = async (config: QuizConfig): Promise<QuizData | null> => {
    if (usesLeft !== 'Unlimited' && usesLeft <= 0) {
      setError("You have no uses left for today.");
      return null;
    }
    setIsLoading(true);
    setError(null);
    try {
      const quizContent = await quizService.generateQuizContent(config);
      const fullQuizData: QuizData = {
          ...quizContent,
          results: [], // Initialize empty results
          config: config
      };

      if (userId) {
          saveGeneration(userId, {
              moduleId,
              moduleName,
              inputs: `Topic: ${config.topic}, Questions: ${config.questionCount}`,
              output: `Generated Quiz: ${quizContent.title}`
          });
      }

      if (usesLeft !== 'Unlimited') {
          decrementUse();
      }
      return fullQuizData;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An unknown error occurred during quiz generation.";
      setError(errorMessage);
      console.error('Quiz generation error:', err);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // optimizeQuestions can be a future feature, for now it does nothing
  const optimizeQuestions = async (questions: QuizQuestion[], config: QuizConfig): Promise<QuizQuestion[]> => {
    // This is a placeholder for a future AI call
    return Promise.resolve(questions);
  };

  return {
    generateQuiz,
    optimizeQuestions,
    isLoading,
    error,
  };
};
