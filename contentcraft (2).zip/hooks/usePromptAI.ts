import { useState } from 'react';
import { generateContent } from '../services/geminiService';
import { saveGeneration } from '../services/historyService';
import { Type } from "@google/genai";

// Define the structure of the analysis response from the AI
export interface PromptAnalysis {
  clarityScore: number;
  specificityScore: number;
  expectedResultsScore: number;
  suggestions: string[];
}

export interface PromptRequestData {
    goal: string;
    context: string;
    desiredOutput: string;
    tone: string;
    length: string;
    includeExamples: boolean;
}

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        clarityScore: { type: Type.NUMBER, description: "Score from 0-10 for prompt clarity." },
        specificityScore: { type: Type.NUMBER, description: "Score from 0-10 for prompt specificity." },
        expectedResultsScore: { type: Type.NUMBER, description: "Score from 0-10 for how well it defines expected results." },
        suggestions: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of 3-5 specific suggestions for improvement." }
    },
    required: ['clarityScore', 'specificityScore', 'expectedResultsScore', 'suggestions']
};

export const usePromptAI = (
    userId: string | null,
    moduleId: string,
    moduleName: string,
    usesLeft: number | 'Unlimited',
    decrementUse: () => void
) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generatePrompt = async (promptRequest: PromptRequestData, selectedAI: string): Promise<{ prompt: string; optimizedVersion: string } | null> => {
    if (usesLeft !== 'Unlimited' && usesLeft <= 0) {
      setError("You have no uses left for today.");
      return null;
    }
    setIsLoading(true);
    setError(null);
    try {
      const metaPrompt = `You are a prompt engineering expert for ${selectedAI}. Your task is to generate a powerful and detailed prompt based on the user's request.
      
      User Request:
      - Goal: ${promptRequest.goal}
      - Context: ${promptRequest.context}
      - Desired Output: ${promptRequest.desiredOutput}
      - Tone: ${promptRequest.tone}
      - Length: ${promptRequest.length}
      - Include Examples: ${promptRequest.includeExamples ? 'Yes' : 'No'}

      Generate two versions:
      1. A direct, well-structured prompt that fulfills the user's request.
      2. An 'optimized' version that is more advanced, perhaps using a framework like R.O.L.E. or C.O.S.T. to get even better results from the AI.

      Structure your response as:
      ---PROMPT START---
      [Direct Prompt Here]
      ---PROMPT END---
      ---OPTIMIZED START---
      [Optimized Prompt Here]
      ---OPTIMIZED END---
      `;
      
      const result = await generateContent(metaPrompt);
      const prompt = result.split('---PROMPT START---')[1]?.split('---PROMPT END---')[0]?.trim() || '';
      const optimizedVersion = result.split('---OPTIMIZED START---')[1]?.split('---OPTIMIZED END---')[0]?.trim() || '';

      if (userId) {
        saveGeneration(userId, {
            moduleId,
            moduleName: `${moduleName} - Generate`,
            inputs: `Goal: ${promptRequest.goal}`,
            output: `---PROMPT---\n${prompt}\n\n---OPTIMIZED---\n${optimizedVersion}`
        });
      }
      if (usesLeft !== 'Unlimited') decrementUse();

      return { prompt, optimizedVersion };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const optimizePrompt = async (prompt: string, selectedAI: string): Promise<string | null> => {
    if (usesLeft !== 'Unlimited' && usesLeft <= 0) {
      setError("You have no uses left for today.");
      return null;
    }
    setIsLoading(true);
    setError(null);
    try {
       const metaPrompt = `You are a prompt optimization expert for ${selectedAI}. Your task is to analyze the following user-provided prompt and rewrite it for maximum clarity, specificity, and effectiveness. Explain the key changes you made.

      User Prompt:
      "${prompt}"

      Rewrite the prompt to be more powerful. Add context, constraints, examples, or specific formatting instructions as needed.
      
      Structure your response as:
      ---OPTIMIZED PROMPT START---
      [Your rewritten, optimized prompt here]
      ---OPTIMIZED PROMPT END---
      ---CHANGES START---
      - Change 1: [Explanation]
      - Change 2: [Explanation]
      ---CHANGES END---
      `;

      const result = await generateContent(metaPrompt);
      const optimized = result.split('---OPTIMIZED PROMPT START---')[1]?.split('---OPTIMIZED PROMPT END---')[0]?.trim() || result;
      
      if (userId) {
        saveGeneration(userId, {
            moduleId,
            moduleName: `${moduleName} - Optimize`,
            inputs: `Original: ${prompt.substring(0, 150)}...`,
            output: optimized,
        });
      }
      if (usesLeft !== 'Unlimited') decrementUse();
      
      return optimized;

    } catch (err) {
       const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const analyzePrompt = async (prompt: string, selectedAI: string): Promise<PromptAnalysis | null> => {
    if (usesLeft !== 'Unlimited' && usesLeft <= 0) {
      setError("You have no uses left for today.");
      return null;
    }
    setIsLoading(true);
    setError(null);
    try {
      const metaPrompt = `You are a prompt analysis expert for ${selectedAI}. Analyze the following prompt and provide a score (from 0 to 10) for clarity, specificity, and how well it defines expected results. Also, provide a list of 3-5 specific suggestions for improvement.

      User Prompt: "${prompt}"

      Your response must be a valid JSON object conforming to the provided schema.`;

      const result = await generateContent(metaPrompt, {
        responseMimeType: "application/json",
        responseSchema: analysisSchema
      });

      const parsedResult: PromptAnalysis = JSON.parse(result);

      if (userId) {
        saveGeneration(userId, {
            moduleId,
            moduleName: `${moduleName} - Analyze`,
            inputs: `Prompt: ${prompt.substring(0, 150)}...`,
            output: `Analysis Scores:\nClarity: ${parsedResult.clarityScore}/10\nSpecificity: ${parsedResult.specificityScore}/10`,
        });
      }
      if (usesLeft !== 'Unlimited') decrementUse();

      return parsedResult;
    } catch (err) {
       const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };


  return { generatePrompt, optimizePrompt, analyzePrompt, isLoading, error };
};
