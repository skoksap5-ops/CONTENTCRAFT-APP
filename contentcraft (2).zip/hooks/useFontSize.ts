import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';

export type FontSize = 'sm' | 'md' | 'lg';

interface FontSizeContextType {
  fontSize: FontSize;
  setFontSize: (size: FontSize) => void;
}

const FontSizeContext = createContext<FontSizeContextType | undefined>(undefined);

const FONT_SCALES: Record<FontSize, string> = {
  sm: '0.9',
  md: '1.0',
  lg: '1.15',
};

export const FontSizeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [fontSize, setFontSizeState] = useState<FontSize>(() => {
    try {
      if (typeof window === 'undefined') return 'md';
      const savedSize = localStorage.getItem('fontSize') as FontSize | null;
      return savedSize && FONT_SCALES[savedSize] ? savedSize : 'md';
    } catch {
      return 'md';
    }
  });

  useEffect(() => {
    const scale = FONT_SCALES[fontSize];
    document.documentElement.style.setProperty('--font-scale', scale);
    try {
      localStorage.setItem('fontSize', fontSize);
    } catch (e) {
      console.error('Failed to save font size to localStorage', e);
    }
  }, [fontSize]);
  
  const setFontSize = useCallback((size: FontSize) => {
    if (FONT_SCALES[size]) {
      setFontSizeState(size);
    }
  }, []);

  const value = useMemo(() => ({ fontSize, setFontSize }), [fontSize, setFontSize]);

  return React.createElement(FontSizeContext.Provider, { value }, children);
};

export const useFontSize = (): FontSizeContextType => {
  const context = useContext(FontSizeContext);
  if (context === undefined) {
    throw new Error('useFontSize must be used within a FontSizeProvider');
  }
  return context;
};
