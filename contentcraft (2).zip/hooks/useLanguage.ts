import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import { LANGUAGES, Language } from '../constants/languages';
import { translations } from '../utils/translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (languageCode: string) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      if (typeof window === 'undefined') return LANGUAGES[0];
      const savedLangCode = localStorage.getItem('language');
      const foundLang = LANGUAGES.find(l => l.code === savedLangCode);
      return foundLang || LANGUAGES[0]; // Default to English
    } catch {
      return LANGUAGES[0];
    }
  });

  const setLanguage = useCallback((languageCode: string) => {
    const newLang = LANGUAGES.find(l => l.code === languageCode) || LANGUAGES[0];
    setLanguageState(newLang);
    try {
      localStorage.setItem('language', languageCode);
    } catch (e) {
      console.error("Failed to save language to localStorage", e);
    }
  }, []);

  const t = useCallback((key: string): string => {
    return translations[language.code]?.[key] || translations['en']?.[key] || key;
  }, [language.code]);

  const value = useMemo(() => ({ language, setLanguage, t }), [language, setLanguage, t]);

  return React.createElement(LanguageContext.Provider, { value }, children);
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};