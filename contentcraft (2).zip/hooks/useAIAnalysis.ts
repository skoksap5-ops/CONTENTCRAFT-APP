import { useState } from 'react';
import { aiTemplateService } from '../services/aiTemplateService';
import { saveGeneration } from '../services/historyService';
import type { PurposeData, TemplateData, AIAnalysisData, GenerationResponse } from '../components/ai-template-builder/types';

export const useAIAnalysis = (
    userId: string | null,
    moduleId: string,
    moduleName: string,
    usesLeft: number | 'Unlimited',
    decrementUse: () => void
) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const analyze = async (purposeData: PurposeData): Promise<AIAnalysisData | null> => {
    if (usesLeft !== 'Unlimited' && usesLeft <= 0) {
      setError("You have no uses left for today.");
      return null;
    }
    setIsLoading(true);
    setError(null);
    try {
      const analysis = await aiTemplateService.analyzePurpose(purposeData);
      if (userId) {
          saveGeneration(userId, {
              moduleId,
              moduleName: `${moduleName} - Analysis`,
              inputs: JSON.stringify(purposeData, null, 2),
              output: JSON.stringify(analysis, null, 2)
          });
      }
      if (usesLeft !== 'Unlimited') decrementUse();
      return analysis;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during analysis.');
      console.error('Analysis error:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const generate = async (userInput: {purpose: PurposeData, analysis: AIAnalysisData}): Promise<GenerationResponse | null> => {
    if (usesLeft !== 'Unlimited' && usesLeft <= 0) {
      setError("You have no uses left for today.");
      return null;
    }
    setIsLoading(true);
    setError(null);
    try {
      const templateResponse = await aiTemplateService.generateTemplate(userInput);
      if (userId) {
          saveGeneration(userId, {
              moduleId,
              moduleName: `${moduleName} - Generation`,
              inputs: `Goal: ${userInput.purpose.primaryGoal}`,
              output: `Generated ${templateResponse.variations.length} template variations.`
          });
      }
      if (usesLeft !== 'Unlimited') decrementUse();
      return templateResponse;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during generation.');
      console.error('Generation error:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const optimize = async (template: TemplateData, optimizationGoals: { length: string; tone: string; }): Promise<TemplateData | null> => {
    if (usesLeft !== 'Unlimited' && usesLeft <= 0) {
      setError("You have no uses left for today.");
      return null;
    }
    setIsLoading(true);
    setError(null);
    try {
      const optimized = await aiTemplateService.optimizeTemplate(template, optimizationGoals);
       if (userId) {
          saveGeneration(userId, {
              moduleId,
              moduleName: `${moduleName} - Optimization`,
              inputs: `Optimizing template: ${template.name}`,
              output: `New optimized template created: ${optimized.name}`
          });
      }
      if (usesLeft !== 'Unlimited') decrementUse();
      return optimized;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred during optimization.');
      console.error('Optimization error:', err);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };
  
  const personalize = async (template: TemplateData, userInput: { persona: string }): Promise<TemplateData | null> => {
    if (usesLeft !== 'Unlimited' && usesLeft <= 0) {
      setError("You have no uses left for today.");
      return null;
    }
    setIsLoading(true);
    setError(null);
    try {
      const personalized = await aiTemplateService.personalizeTemplate(template, userInput);
      if (userId) {
          saveGeneration(userId, {
              moduleId,
              moduleName: `${moduleName} - Personalization`,
              inputs: `Personalizing for: ${userInput.persona || 'Default'}`,
              output: `New personalized template created: ${personalized.name}`
          });
      }
      if (usesLeft !== 'Unlimited') decrementUse();
      return personalized;
    } catch (err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred during personalization.');
        console.error('Personalization error:', err);
        throw err;
    } finally {
        setIsLoading(false);
    }
  };

  return { analyze, generate, optimize, personalize, isLoading, error };
};
