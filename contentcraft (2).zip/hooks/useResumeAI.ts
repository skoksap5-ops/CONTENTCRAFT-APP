import { useState, useCallback } from 'react';
import { generateContent } from '../services/geminiService';
import { saveGeneration } from '../services/historyService';
import { Type } from "@google/genai";
import type { ResumeData } from '../components/resume-generator/types';

interface EnhancedResume {
    summary: string;
    experience: {
        id: number;
        description: string;
    }[];
}

const resumeEnhancementSchema = {
    type: Type.OBJECT,
    properties: {
        summary: { type: Type.STRING, description: "An enhanced, professional summary." },
        experience: {
            type: Type.ARRAY,
            description: "An array of enhanced experience descriptions, one for each experience item provided.",
            items: {
                type: Type.OBJECT,
                properties: {
                    id: { type: Type.NUMBER, description: "The original ID of the experience item." },
                    description: { type: Type.STRING, description: "The rewritten, impactful description using action verbs and quantifiable results." }
                },
                required: ['id', 'description']
            }
        }
    },
    required: ['summary', 'experience']
};

export const useResumeAI = (
    userId: string | null,
    moduleId: string,
    moduleName: string,
    usesLeft: number | 'Unlimited',
    decrementUse: () => void
) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const enhanceResume = useCallback(async (resumeData: ResumeData): Promise<EnhancedResume | null> => {
    if (usesLeft !== 'Unlimited' && usesLeft <= 0) {
      setError("You have no uses left for today.");
      return null;
    }
    setIsLoading(true);
    setError(null);
    try {
        const experienceToEnhance = resumeData.experience.map(exp => ({
            id: exp.id,
            title: exp.title,
            description: exp.description
        }));
      
        const prompt = `You are an expert resume writer and career coach. Your task is to enhance the provided resume content for maximum impact.

        **RESUME DATA:**
        - Professional Summary: "${resumeData.summary}"
        - Experience: ${JSON.stringify(experienceToEnhance)}

        **INSTRUCTIONS:**
        1.  Rewrite the **Professional Summary** to be more compelling and concise, highlighting key strengths.
        2.  For each **Experience** item, rewrite the description. Focus on turning responsibilities into achievements. Use the STAR method (Situation, Task, Action, Result) where possible, start bullet points with strong action verbs, and quantify results with metrics (even if you have to invent realistic numbers based on the context).
        3.  Return the enhanced content as a valid JSON object conforming to the provided schema. Ensure you return an object in the 'experience' array for every experience item provided, using the original ID.
        `;
      
      const result = await generateContent(prompt, {
        responseMimeType: "application/json",
        responseSchema: resumeEnhancementSchema,
      });

      const parsed: EnhancedResume = JSON.parse(result);

      if (userId) {
        saveGeneration(userId, {
            moduleId,
            moduleName: `${moduleName} - AI Enhance`,
            inputs: `Original Summary: ${resumeData.summary.substring(0, 100)}...`,
            output: `Enhanced Summary: ${parsed.summary.substring(0, 100)}...`
        });
      }
      if (usesLeft !== 'Unlimited') decrementUse();

      return parsed;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(errorMessage);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [userId, moduleId, moduleName, usesLeft, decrementUse]);

  return { enhanceResume, isLoading, error };
};
