import { useCallback, useMemo } from 'react';

export const useFeedback = () => {
    const triggerHaptic = useCallback(() => {
        if (typeof navigator.vibrate === 'function') {
            navigator.vibrate(50); // A short vibration
        }
    }, []);

    const playClick = useCallback(() => {
        triggerHaptic();
    }, [triggerHaptic]);
    
    const playSuccess = useCallback(() => {
        triggerHaptic();
    }, [triggerHaptic]);

    // useMemo helps to prevent re-creating the object on every render
    return useMemo(() => ({ playClick, playSuccess }), [playClick, playSuccess]);
};
