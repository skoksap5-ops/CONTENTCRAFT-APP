import { useState, useCallback } from 'react';
import { calendarService } from '../services/calendarService';
import { saveGeneration } from '../services/historyService';
import type { CampaignDay, CampaignConfig, StrategyData } from '../components/social-campaign-planner/types';

export const useCalendarAI = (
    userId: string | null,
    moduleId: string,
    moduleName: string,
    usesLeft: number | 'Unlimited',
    decrementUse: () => void
) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateCalendar = useCallback(async (config: CampaignConfig & StrategyData): Promise<CampaignDay[] | null> => {
    setIsLoading(true);
    setError(null);
    try {
      const calendar = await calendarService.generateContentCalendar(config);
      if (userId) {
          const outputToSave = calendar.map((day: CampaignDay) => `Day ${day.day}: ${day.theme}\n` + day.posts.map(p => `${p.platform}: ${p.postContent}`).join('\n')).join('\n\n');
          saveGeneration(userId, {
              moduleId,
              moduleName,
              inputs: `Campaign: ${config.campaignName}, Platforms: ${config.platforms.join(', ')}`,
              output: outputToSave,
          });
      }
      if (usesLeft !== 'Unlimited') {
          decrementUse();
      }
      return calendar;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred during calendar generation.';
      console.error('Calendar generation error:', err);
      setError(errorMessage);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [userId, moduleId, moduleName, usesLeft, decrementUse]);

  const optimizeSchedule = useCallback(async (calendar: CampaignDay[], config: any): Promise<CampaignDay[] | null> => {
    setIsLoading(true);
    setError(null);
    try {
      const optimized = await calendarService.optimizePostingSchedule(calendar, config);
      return optimized;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred during schedule optimization.';
      console.error('Schedule optimization error:', err);
      setError(errorMessage);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    generateCalendar,
    optimizeSchedule,
    isLoading,
    error
  };
};
