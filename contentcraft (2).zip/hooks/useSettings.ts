import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';

export interface AppSettings {
    pushNotifications: boolean;
    emailUpdates: boolean;
    marketingEmails: boolean;
    compactMode: boolean;
    analytics: boolean;
    crashReporting: boolean;
    autoOptimize: boolean;
    keywordSuggestions: boolean;
    developerMode: boolean;
    betaFeatures: boolean;
}

interface SettingsContextType {
  settings: AppSettings;
  updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const defaultSettings: AppSettings = {
    pushNotifications: true,
    emailUpdates: false,
    marketingEmails: false,
    compactMode: false,
    analytics: true,
    crashReporting: true,
    autoOptimize: false,
    keywordSuggestions: true,
    developerMode: false,
    betaFeatures: false,
};

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const savedSettings = localStorage.getItem('appSettings');
      if (savedSettings) {
        // Merge saved settings with defaults to ensure all keys are present
        return { ...defaultSettings, ...JSON.parse(savedSettings) };
      }
    } catch (e) {
      console.error('Failed to parse settings from localStorage', e);
    }
    return defaultSettings;
  });

  useEffect(() => {
    try {
      localStorage.setItem('appSettings', JSON.stringify(settings));
    } catch(e) {
      console.error('Failed to save settings to localStorage', e);
    }
  }, [settings]);

  const updateSetting = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const value = useMemo(() => ({ settings, updateSetting }), [settings]);

  return React.createElement(SettingsContext.Provider, { value }, children);
};

export const useSettings = (): SettingsContextType => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};