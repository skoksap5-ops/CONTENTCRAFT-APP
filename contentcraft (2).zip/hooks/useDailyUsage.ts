import { useState, useEffect, useCallback } from 'react';
import { db, onAuthUserChanged, firebaseInitialized } from '../services/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';

const DAILY_LIMIT = 5;

interface UsageData {
  usesLeft: number | 'Unlimited';
  lastReset: string; // YYYY-MM-DD
  isPremium: boolean;
}

// Firestore only stores numbers, so the DB type is different from the state type
interface UsageDataInDb {
    usesLeft: number;
    lastReset: string;
    isPremium: boolean;
    createdAt?: any;
    streak?: number;
    lastLoginDate?: string;
}


export const useDailyUsage = () => {
    const [usage, setUsage] = useState<UsageData>({ usesLeft: 0, lastReset: '', isPremium: false });
    const [userId, setUserId] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [streakRewardGranted, setStreakRewardGranted] = useState(false);

    useEffect(() => {
        if (!firebaseInitialized) {
            console.warn("Firebase not initialized. App is running in offline demo mode with unlimited uses.");
            setUserId('demo-user'); // Set a mock user ID for demo purposes
            setUsage({ usesLeft: 'Unlimited', lastReset: '', isPremium: true }); // Provide unlimited uses for demo mode
            setIsLoading(false);
            return; // Skip the rest of the Firebase logic
        }

        const unsubscribe = onAuthUserChanged((user) => {
            if (user) {
                setUserId(user.uid);
            } else {
                setUserId(null);
                setUsage({ usesLeft: 0, lastReset: '', isPremium: false }); // Reset usage on sign out
            }
            setIsLoading(false); // Auth state is resolved
        });

        return () => unsubscribe();
    }, []);

    const fetchUsageData = useCallback(async (uid: string) => {
        if (!db) {
            setIsLoading(false);
            return;
        }

        setIsLoading(true);
        const userDocRef = doc(db, 'users', uid);
        const userDocSnap = await getDoc(userDocRef);
        const today = new Date().toISOString().split('T')[0];

        if (userDocSnap.exists()) {
            const data = userDocSnap.data() as UsageDataInDb;
            let newUsageData: UsageDataInDb = { ...data };
            let shouldUpdateDb = false;
            
            // Reset daily uses if it's a new day for a non-premium user
            if (data.lastReset !== today && !data.isPremium) {
                newUsageData = { ...newUsageData, usesLeft: DAILY_LIMIT, lastReset: today };
                shouldUpdateDb = true;
            }

            // Daily Streak logic
            if (data.lastLoginDate !== today) {
                const yesterday = new Date();
                yesterday.setDate(yesterday.getDate() - 1);
                const yesterdayStr = yesterday.toISOString().split('T')[0];
                
                let currentStreak = data.streak || 0;
                
                if (data.lastLoginDate === yesterdayStr) {
                    currentStreak++; // It's a consecutive day
                } else {
                    currentStreak = 1; // Streak is broken, reset to 1
                }

                if (currentStreak >= 7) {
                    if (typeof newUsageData.usesLeft === 'number') {
                        newUsageData.usesLeft++;
                        setStreakRewardGranted(true); // Signal reward
                    }
                    currentStreak = 0; // Reset streak after reward
                }
                
                newUsageData = { ...newUsageData, streak: currentStreak, lastLoginDate: today };
                shouldUpdateDb = true;
            }

            if (shouldUpdateDb) {
                 await setDoc(userDocRef, newUsageData, { merge: true });
            }
            
            setUsage({ 
                ...newUsageData, 
                usesLeft: newUsageData.isPremium ? 'Unlimited' : newUsageData.usesLeft 
            });
        } else {
            // Create a new document for a new user
            const newUsageData: UsageDataInDb & { createdAt: any } = { 
                usesLeft: DAILY_LIMIT, 
                lastReset: today, 
                isPremium: false, 
                createdAt: serverTimestamp(),
                streak: 1, // Start streak at 1 on first login
                lastLoginDate: today
            };
            await setDoc(userDocRef, newUsageData);
            setUsage({ ...newUsageData, usesLeft: DAILY_LIMIT });
        }
        setIsLoading(false);
    }, []);

    useEffect(() => {
        if (userId && userId !== 'demo-user') {
            fetchUsageData(userId);
        } else {
            // When user logs out or is in demo mode, we still need to set loading to false.
            setIsLoading(false);
        }
    }, [userId, fetchUsageData]);


    const updateUsageInDb = useCallback(async (newUsageData: Partial<UsageDataInDb>) => {
        if (!userId || !db) return;
        const userDocRef = doc(db, 'users', userId);
        await setDoc(userDocRef, newUsageData, { merge: true });
    }, [userId]);

    const addUses = useCallback(async (amount: number) => {
        if (usage.isPremium || !userId || typeof usage.usesLeft !== 'number') return;
        const newUses = usage.usesLeft + amount;
        setUsage(prev => ({ ...prev, usesLeft: newUses }));
        await updateUsageInDb({ usesLeft: newUses });
    }, [usage.isPremium, usage.usesLeft, userId, updateUsageInDb]);

    const decrementUse = useCallback(async () => {
        if (usage.isPremium || !userId || typeof usage.usesLeft !== 'number') return;
        const newUses = Math.max(0, usage.usesLeft - 1);
        setUsage(prev => ({ ...prev, usesLeft: newUses }));
        await updateUsageInDb({ usesLeft: newUses });
    }, [usage.isPremium, usage.usesLeft, userId, updateUsageInDb]);
    
    return { 
        userId,
        isLoadingUser: isLoading,
        usesLeft: usage.usesLeft, 
        totalUses: usage.isPremium ? 'Unlimited' : (isLoading ? '...' : DAILY_LIMIT), 
        addUses, 
        decrementUse, 
        isPremium: usage.isPremium,
        streakRewardGranted,
    };
};
