import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ToneSelector from './ToneSelector';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type AdObjective = 'Clicks' | 'Conversions' | 'Leads' | 'Sales';
type BudgetLevel = 'Starter' | 'Moderate' | 'Advanced' | 'Enterprise';

const GOOGLE_AD_PROMPT = `
You are a Google Ads expert and PPC strategist. Create high-converting, keyword-optimized Google Search Ads that dominate SERP positions, drive qualified traffic, and maximize ROI.

**INPUT:**
- Product/Service: {PRODUCT_SERVICE}
- Target Keywords: {TARGET_KEYWORDS}
- Landing Page: {LANDING_PAGE_URL}
- Unique Selling Proposition: {USP}
- Ad Objective: {AD_OBJECTIVE}
- Budget Level: {BUDGET_LEVEL}
- Tone: {SELECTED_TONES}

**TASK:**
Based on the input, generate two complete ad groups. The output MUST follow this structure exactly:

🎯 **AD GROUP 1: [Creative Ad Group Name]**
**KEYWORDS:**
- **Exact:** [keyword1], [keyword2]
- **Phrase:** "keyword phrase 1", "keyword phrase 2"
- **Broad:** +keyword1 +keyword2
**RESPONSIVE SEARCH AD:**
**HEADLINES:**
1. [Headline 1]
2. [Headline 2]
3. [Headline 3]
4. [Headline 4]
5. [Headline 5]
**DESCRIPTIONS:**
1. [Description 1]
2. [Description 2]
**SITELINK EXTENSIONS:**
- [Sitelink 1] → /page1
- [Sitelink 2] → /page2
**STRUCTURED SNIPPETS:**
- **Services:** [Service 1, Service 2]

🎯 **AD GROUP 2: [Another Creative Ad Group Name]**
(Repeat the structure above)

📊 **TARGETING RECOMMENDATIONS:**
**CORE AUDIENCES:**
1. [Audience 1 Details]
**CUSTOM AUDIENCES:**
- [List of custom audiences]
**LOOKALIKE AUDIENCES:**
- [List of lookalike audiences]

💰 **BUDGET & BIDDING:**
- **Strategy:** [e.g., Target CPA @ $25/conversion]
- **Budget Allocation:** [e.g., 60% Ad Group 1, 40% Ad Group 2]

📈 **PERFORMANCE PREDICTION:**
- **Estimated CTR:** [X]%
- **Quality Score:** [Y]/10
- **Cost Per Click:** [$Z.ZZ]
- **Conversion Rate:** [W]%
- **Expected CPA:** [$A.AA]
`;

interface AdSet {
    title: string;
    keywords: string;
    headlines: string[];
    descriptions: string[];
    sitelinks: string;
    structuredSnippets: string;
}
interface ParsedOutput {
    adSets: AdSet[];
    targetingRecommendations: string;
    budgetAndBidding: string;
    performancePrediction: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const GoogleAdView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [productService, setProductService] = useState('');
    const [targetKeywords, setTargetKeywords] = useState('');
    const [landingPageUrl, setLandingPageUrl] = useState('');
    const [usp, setUsp] = useState('');
    const [adObjective, setAdObjective] = useState<AdObjective>('Conversions');
    const [budgetLevel, setBudgetLevel] = useState<BudgetLevel>('Moderate');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && productService.trim() && targetKeywords.trim();
    
    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string, source = text) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = source.match(regex);
                return match ? match[1].trim() : '';
            };

            const adSetSections = text.split(/🎯 \*\*AD GROUP \d+:/).slice(1);
            const adSets = adSetSections.map((section, index) => {
                const titleMatch = text.match(new RegExp(`🎯 \\*\\*AD GROUP ${index + 1}:(.*?)\\*\\*`, 'i'));
                return {
                    title: titleMatch ? titleMatch[1].trim() : `Ad Group ${index + 1}`,
                    keywords: getSection('\\*\\*KEYWORDS:\\*\\*', '\\*\\*RESPONSIVE SEARCH AD:\\*\\*', section),
                    headlines: getSection('\\*\\*HEADLINES:\\*\\*', '\\*\\*DESCRIPTIONS:\\*\\*', section).split('\n').map(s => s.replace(/^\d+\.\s*/, '').trim()).filter(Boolean),
                    descriptions: getSection('\\*\\*DESCRIPTIONS:\\*\\*', '\\*\\*SITELINK EXTENSIONS:\\*\\*', section).split('\n').map(s => s.replace(/^\d+\.\s*/, '').trim()).filter(Boolean),
                    sitelinks: getSection('\\*\\*SITELINK EXTENSIONS:\\*\\*', '\\*\\*STRUCTURED SNIPPETS:\\*\\*', section),
                    structuredSnippets: getSection('\\*\\*STRUCTURED SNIPPETS:\\*\\*', '$', section),
                };
            });

            const targetingRecommendations = getSection('📊 \\*\\*TARGETING RECOMMENDATIONS:\\*\\*', '💰 \\*\\*BUDGET & BIDDING:\\*\\*');
            const budgetAndBidding = getSection('💰 \\*\\*BUDGET & BIDDING:\\*\\*', '📈 \\*\\*PERFORMANCE PREDICTION:\\*\\*');
            const performancePrediction = getSection('📈 \\*\\*PERFORMANCE PREDICTION:\\*\\*', '$');

            return { adSets, targetingRecommendations, budgetAndBidding, performancePrediction };
        } catch (e) {
            console.error("Failed to parse Google Ad output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return GOOGLE_AD_PROMPT
            .replace('{PRODUCT_SERVICE}', productService)
            .replace('{TARGET_KEYWORDS}', targetKeywords)
            .replace('{LANDING_PAGE_URL}', landingPageUrl)
            .replace('{USP}', usp)
            .replace('{AD_OBJECTIVE}', adObjective)
            .replace('{BUDGET_LEVEL}', budgetLevel)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [productService, targetKeywords, landingPageUrl, usp, adObjective, budgetLevel, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };
    
    const AdGroupCard: React.FC<{ adSet: AdSet }> = ({ adSet }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            const copyText = `Headlines:\n${adSet.headlines.join('\n')}\n\nDescriptions:\n${adSet.descriptions.join('\n')}`;
            navigator.clipboard.writeText(copyText).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!adSet.headlines || adSet.headlines.length === 0) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative space-y-4">
                <div className="flex justify-between items-start">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary flex items-center gap-2">
                        <span className="text-xl">🎯</span> Ad Group: {adSet.title}
                    </h4>
                     <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${adSet.title}`}>
                        {copySuccess ? 'Copied!' : <CopyIcon className="h-5 w-5" />}
                    </button>
                </div>
                
                <div className="text-sm space-y-3">
                    <div><strong className="block text-text-secondary dark:text-d-text-secondary text-xs uppercase tracking-wider">Headlines</strong><ul className="mt-1 list-disc list-inside space-y-1">{adSet.headlines.map((h, i) => <li key={i}>{h}</li>)}</ul></div>
                    <div><strong className="block text-text-secondary dark:text-d-text-secondary text-xs uppercase tracking-wider">Descriptions</strong><ul className="mt-1 list-disc list-inside space-y-1">{adSet.descriptions.map((d, i) => <li key={i}>{d}</li>)}</ul></div>
                    <Accordion title={<>🔑 <span className="ml-2">Keywords & Extensions</span></>}>
                        <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(`**KEYWORDS:**\n${adSet.keywords}\n\n**SITELINK EXTENSIONS:**\n${adSet.sitelinks}\n\n**STRUCTURED SNIPPETS:**\n${adSet.structuredSnippets}`)} />
                    </Accordion>
                </div>
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[120px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={productService} onChange={e => setProductService(e.target.value)} placeholder="Product/Service Description..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Ad Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Target Keywords</label>
                                <input value={targetKeywords} onChange={e => setTargetKeywords(e.target.value)} placeholder="e.g., ai content tool, seo writer" className={commonInputClasses} />
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Landing Page URL</label>
                                <input value={landingPageUrl} onChange={e => setLandingPageUrl(e.target.value)} placeholder="e.g., https://example.com/offer" className={commonInputClasses} />
                            </div>
                            <div className="md:col-span-2">
                                <label className={commonLabelClasses}>Unique Selling Proposition (USP)</label>
                                <input value={usp} onChange={e => setUsp(e.target.value)} placeholder="e.g., The only AI that..." className={commonInputClasses} />
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Ad Objective</label>
                                <select value={adObjective} onChange={e => setAdObjective(e.target.value as AdObjective)} className={commonInputClasses}>
                                    <option>Conversions</option><option>Clicks</option><option>Leads</option><option>Sales</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Budget Level</label>
                                <select value={budgetLevel} onChange={e => setBudgetLevel(e.target.value as BudgetLevel)} className={commonInputClasses}>
                                    <option>Moderate</option><option>Starter</option><option>Advanced</option><option>Enterprise</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Creating Ads...' : (isQueued ? 'Request Queued' : 'Create Google Ad')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && (productService.trim() || targetKeywords.trim()) && <p className="text-center text-yellow-500 text-sm mt-2">Please fill in all required fields.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Building your ad campaign...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your comprehensive ad campaign will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-6">
                             <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Ad Creative Suite</h3>
                                {parsedOutput.adSets.map((adSet, index) => <AdGroupCard key={index} adSet={adSet} />)}
                            </div>
                            <div className="space-y-2 pt-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Strategy & Performance</h3>
                                <Accordion title={<>📊 <span className="ml-2">Targeting Recommendations</span></>} defaultOpen={true}><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.targetingRecommendations)}/></Accordion>
                                <Accordion title={<>💰 <span className="ml-2">Budget & Bidding</span></>}><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.budgetAndBidding)}/></Accordion>
                                <Accordion title={<>📈 <span className="ml-2">Performance Prediction</span></>}><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.performancePrediction)}/></Accordion>
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default GoogleAdView;