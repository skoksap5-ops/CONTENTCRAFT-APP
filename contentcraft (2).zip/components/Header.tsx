import React from 'react';
import HamburgerIcon from './icons/HamburgerIcon';
import ThemeSwitcher from './ThemeSwitcher';
import { useLanguage } from '../hooks/useLanguage';
import { useFeedback } from '../hooks/useFeedback';
import type { View } from '../types';
import HeaderCubeIcon from './icons/HeaderCubeIcon';

interface HeaderProps {
  onMenuClick: () => void;
  usesLeft: number | 'Unlimited';
  isPremium: boolean;
  setView: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuClick, usesLeft, isPremium, setView }) => {
  const { t } = useLanguage();
  const { playClick } = useFeedback();

  const handleUpgradeClick = () => {
    playClick();
    setView('upgrade');
  };

  return (
    <header className="fixed top-0 left-0 right-0 bg-base-200/80 dark:bg-d-base-200/80 z-20 backdrop-blur-sm border-b border-base-300 dark:border-d-base-300">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <button
              onClick={onMenuClick}
              className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-300 dark:hover:bg-d-base-300 hover:text-text-primary dark:hover:text-d-text-primary transition-colors mr-2"
              aria-label="Open menu"
            >
              <HamburgerIcon className="h-6 w-6" />
            </button>
            <h1 className="text-xl sm:text-2xl font-bold text-text-primary dark:text-d-text-primary tracking-tight font-heading">
              Content<span className="text-brand-primary">Craft</span>
            </h1>
          </div>
          <div className="flex items-center space-x-2 sm:space-x-4">
            <ThemeSwitcher />
            {isPremium ? (
               <button
                onClick={handleUpgradeClick}
                className="text-sm font-medium bg-brand-secondary/20 text-brand-secondary px-3 py-1.5 rounded-full transition-colors hover:bg-brand-secondary/30 flex items-center gap-1.5"
                aria-label="View Pro benefits"
              >
                <HeaderCubeIcon />
                {t('craftPro')}
              </button>
            ) : (
               <button
                onClick={handleUpgradeClick}
                className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary transition-colors hover:bg-base-300/80 dark:hover:bg-d-base-300/80"
                aria-label={t('upgradeToPro')}
              >
                <span className="font-bold text-text-primary dark:text-d-text-primary">{usesLeft}</span> {t('usesLeft')}
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;