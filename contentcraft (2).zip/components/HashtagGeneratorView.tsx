import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type Platform = 'Instagram' | 'TikTok' | 'Twitter' | 'LinkedIn' | 'Facebook' | 'YouTube';
type Strategy = 'Balanced Mix' | 'High Reach' | 'Niche & Targeted';

interface HashtagSet {
    title: string;
    hashtags: string[];
}

interface ParsedOutput {
    hashtagSets: {
        balancedMix: string[];
        highReach: string[];
        nicheTargeted: string[];
    };
    strategyAnalysis: {
        overallStrategy: string;
        setBreakdown: string;
    };
    performancePrediction: {
        reachPotential: number;
        engagementPotential: number;
        relevanceScore: number;
    };
    hashtagTiers: {
        tag: string;
        tier: string;
    }[];
}

const HASHTAG_GENERATOR_PROMPT = `
You are an expert social media strategist specializing in hashtag optimization. Your task is to generate strategic hashtag sets for a given topic and platform, and provide a comprehensive analysis.

**CONSTRAINTS:**
- Your response MUST be a valid JSON object conforming to the provided schema.
- Adhere to platform-specific hashtag best practices (e.g., Instagram 5-15, TikTok 3-5, etc.).

**INPUT:**
- Core Topic/Post Content: {POST_TOPIC}
- Social Media Platform: {PLATFORM}
- Desired Hashtag Strategy: {STRATEGY}
- Custom/Branded Hashtags (optional): {BRANDED_HASHTAGS}
- Desired Tone: {TONES}

**TASK & JSON Fields Instructions:**
Generate a complete, valid JSON object that conforms to the provided schema.

1.  **hashtagSets**: Generate three distinct sets of hashtags.
    *   **balancedMix**: A combination of broad, niche, and targeted tags.
    *   **highReach**: Focus on popular and trending tags to maximize visibility.
    *   **nicheTargeted**: Focus on specific, niche tags to attract a highly relevant audience.
    *   Each set should be an array of hashtag strings (e.g., ["#marketing", "#digitalstrategy"]).

2.  **strategyAnalysis**:
    *   **overallStrategy**: Explain the approach taken based on the user's input.
    *   **setBreakdown**: Briefly explain the purpose of each of the three generated sets.

3.  **performancePrediction**: Score the potential of the *balancedMix* set on a scale of 1-10.
    *   **reachPotential**: The potential to reach a large audience.
    *   **engagementPotential**: The potential to drive likes, comments, and shares.
    *   **relevanceScore**: How relevant the hashtags are to the topic.

4.  **hashtagTiers**: For the *balancedMix* set, classify each hashtag into one of four tiers: Broad, Niche, Targeted, or Branded.
`;

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        hashtagSets: {
            type: Type.OBJECT,
            properties: {
                balancedMix: { type: Type.ARRAY, items: { type: Type.STRING } },
                highReach: { type: Type.ARRAY, items: { type: Type.STRING } },
                nicheTargeted: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['balancedMix', 'highReach', 'nicheTargeted']
        },
        strategyAnalysis: {
            type: Type.OBJECT,
            properties: {
                overallStrategy: { type: Type.STRING },
                setBreakdown: { type: Type.STRING, description: "Explain the purpose of Balanced Mix, High Reach, and Niche Targeted sets." }
            },
            required: ['overallStrategy', 'setBreakdown']
        },
        performancePrediction: {
            type: Type.OBJECT,
            properties: {
                reachPotential: { type: Type.NUMBER, description: "Score 1-10 for potential audience reach." },
                engagementPotential: { type: Type.NUMBER, description: "Score 1-10 for potential engagement." },
                relevanceScore: { type: Type.NUMBER, description: "Score 1-10 for relevance to the topic." }
            },
            required: ['reachPotential', 'engagementPotential', 'relevanceScore']
        },
        hashtagTiers: {
            type: Type.ARRAY,
            description: "Classification of each hashtag in the balancedMix set.",
            items: {
                type: Type.OBJECT,
                properties: {
                    tag: { type: Type.STRING },
                    tier: { type: Type.STRING, description: "Broad, Niche, Targeted, or Branded" }
                },
                required: ['tag', 'tier']
            }
        }
    },
    required: ['hashtagSets', 'strategyAnalysis', 'performancePrediction', 'hashtagTiers']
};

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};

const ScoreBar: React.FC<{ score: number; label: string }> = ({ score, label }) => (
  <div>
    <div className="flex justify-between items-center mb-1">
      <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">{label}</span>
      <span className="text-sm font-bold text-text-primary dark:text-d-text-primary">{score}/10</span>
    </div>
    <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2">
      <div className="bg-brand-primary h-2 rounded-full transition-all duration-500" style={{ width: `${score * 10}%` }}></div>
    </div>
  </div>
);

const HashtagGeneratorView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [platform, setPlatform] = useState<Platform>('Instagram');
    const [strategy, setStrategy] = useState<Strategy>('Balanced Mix');
    const [brandedHashtags, setBrandedHashtags] = useState('');
    const [tones, setTones] = useState<string[]>([]);
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();
    
    const getPrompt = useCallback(() => {
        return HASHTAG_GENERATOR_PROMPT
            .replace('{POST_TOPIC}', input)
            .replace('{PLATFORM}', platform)
            .replace('{STRATEGY}', strategy)
            .replace('{BRANDED_HASHTAGS}', brandedHashtags)
            .replace('{TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [input, platform, strategy, brandedHashtags, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId && parsed.hashtagSets?.balancedMix) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: parsed.hashtagSets.balancedMix.join(' '),
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse hashtags: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);

    const HashtagSetCard: React.FC<HashtagSet> = ({ title, hashtags }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            navigator.clipboard.writeText(hashtags.join(' ')).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        return (
            <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg shadow-sm relative">
                <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary mb-2">{title}</h4>
                <div className="flex flex-wrap gap-2">
                    {hashtags.map((tag, index) => (
                        <span key={index} className="bg-base-200 dark:bg-d-base-200 px-2 py-1 rounded text-sm text-brand-primary font-semibold">{tag}</span>
                    ))}
                </div>
                 <button onClick={handleCopy} className="absolute top-3 right-3 p-2 rounded-lg bg-base-200 dark:bg-d-base-200 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${title} hashtags`}>
                    <CopyIcon className="h-5 w-5" />
                </button>
                {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        )
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter your post topic or keywords..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Hashtag Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Platform</label>
                                <select value={platform} onChange={e => setPlatform(e.target.value as Platform)} className={commonInputClasses}>
                                    <option>Instagram</option><option>TikTok</option><option>Twitter</option><option>LinkedIn</option><option>Facebook</option><option>YouTube</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Strategy</label>
                                <select value={strategy} onChange={e => setStrategy(e.target.value as Strategy)} className={commonInputClasses}>
                                    <option>Balanced Mix</option><option>High Reach</option><option>Niche & Targeted</option>
                                </select>
                            </div>
                       </div>
                        <div>
                            <label className={commonLabelClasses}>Custom/Branded Hashtags (optional)</label>
                            <input value={brandedHashtags} onChange={e => setBrandedHashtags(e.target.value)} placeholder="e.g., #MyBrand, #ContentCraftAI" className={commonInputClasses} />
                        </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Generating...' : (isQueued ? 'Request Queued' : 'Generate Hashtags')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please enter a topic to generate hashtags.</p>}
                </div>

                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Finding the best hashtags...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your strategic hashtag sets and analysis will appear here.</p>}
                    {parsedOutput && (
                        <div className="space-y-6">
                             <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Generated Hashtag Sets</h3>
                                <HashtagSetCard title="Balanced Mix" hashtags={parsedOutput.hashtagSets.balancedMix} />
                                <HashtagSetCard title="High Reach" hashtags={parsedOutput.hashtagSets.highReach} />
                                <HashtagSetCard title="Niche & Targeted" hashtags={parsedOutput.hashtagSets.nicheTargeted} />
                            </div>
                            
                            <div className="space-y-2">
                                <Accordion title="📊 Performance Prediction" defaultOpen={true}>
                                    <div className="space-y-4 p-2">
                                        <ScoreBar score={parsedOutput.performancePrediction.reachPotential} label="Reach Potential" />
                                        <ScoreBar score={parsedOutput.performancePrediction.engagementPotential} label="Engagement Potential" />
                                        <ScoreBar score={parsedOutput.performancePrediction.relevanceScore} label="Relevance Score" />
                                    </div>
                                </Accordion>
                                <Accordion title="🚀 Strategy Analysis" defaultOpen={true}>
                                    <div className="space-y-3 p-2 text-sm">
                                        <div>
                                            <h4 className="font-semibold text-text-primary dark:text-d-text-primary">Overall Strategy</h4>
                                            <p className="text-xs mt-1">{parsedOutput.strategyAnalysis.overallStrategy}</p>
                                        </div>
                                         <div>
                                            <h4 className="font-semibold text-text-primary dark:text-d-text-primary">Set Breakdown</h4>
                                            <p className="text-xs mt-1">{parsedOutput.strategyAnalysis.setBreakdown}</p>
                                        </div>
                                    </div>
                                </Accordion>
                                <Accordion title="🏷️ Hashtag Tiers (Balanced Mix)">
                                     <div className="flex flex-wrap gap-2 p-2">
                                        {parsedOutput.hashtagTiers.map((h, i) => (
                                            <div key={i} className="bg-base-300 dark:bg-d-base-300 px-2 py-1 rounded-md text-xs">
                                                <span className="font-semibold text-text-primary dark:text-d-text-primary">{h.tag}</span>
                                                <span className="text-text-secondary dark:text-d-text-secondary ml-1.5">({h.tier})</span>
                                            </div>
                                        ))}
                                    </div>
                                </Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default HashtagGeneratorView;