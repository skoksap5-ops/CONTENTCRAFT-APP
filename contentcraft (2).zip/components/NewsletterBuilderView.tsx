import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ToneSelector from './ToneSelector';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type Audience = 'Subscribers' | 'Customers' | 'Leads' | 'Partners' | 'Internal';
type Purpose = 'Educate' | 'Promote' | 'Engage' | 'Retain' | 'Convert' | 'Nurture';
type BrandVoice = 'Professional' | 'Casual' | 'Authoritative' | 'Friendly' | 'Inspirational';
type PrimaryGoal = 'Clicks' | 'Sales' | 'Engagement' | 'Education' | 'Retention';

const NEWSLETTER_BUILDER_PROMPT = `
You are an expert email marketing strategist and newsletter specialist. Create engaging, conversion-focused newsletters that build audience relationships, drive action, and deliver consistent value.

**INPUT:**
- Main Topic/Theme: {MAIN_TOPIC}
- Target Audience: {TARGET_AUDIENCE}
- Newsletter Purpose: {NEWSLETTER_PURPOSE}
- Brand Voice: {BRAND_VOICE}
- Primary Goal: {PRIMARY_GOAL}
- Tone: {SELECTED_TONES}

**TASK:**
Based on the input, generate a complete newsletter. The output MUST follow this structure exactly:

**SUBJECT LINE OPTIONS:**
1. [Option 1]
2. [Option 2]
3. [Option 3]

**PREVIEW TEXT:**
[Your preview text here]

**NEWSLETTER CONTENT:**
[Full newsletter body text, using markdown for formatting like **bold text**, • for bullet points, and [CTA TEXT] for calls to action]

**PERFORMANCE PREDICTION:**
- Estimated Open Rate: [X]%
- Expected CTR: [Y]%
- Conversion Probability: [Z]%
- Subscriber Retention: [W]%
`;

interface ParsedOutput {
    subjectLines: string[];
    previewText: string;
    newsletterContent: string;
    performance: {
        openRate?: string;
        ctr?: string;
        conversion?: string;
        retention?: string;
    }
}

const NewsletterBuilderView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [mainTopic, setMainTopic] = useState('');
    const [targetAudience, setTargetAudience] = useState<Audience>('Subscribers');
    const [newsletterPurpose, setNewsletterPurpose] = useState<Purpose>('Educate');
    const [brandVoice, setBrandVoice] = useState<BrandVoice>('Friendly');
    const [primaryGoal, setPrimaryGoal] = useState<PrimaryGoal>('Engagement');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && mainTopic.trim();

    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = text.match(regex);
                return match ? match[1].trim() : '';
            };

            const subjectLinesText = getSection('\\*\\*SUBJECT LINE OPTIONS:\\*\\*', '\\*\\*PREVIEW TEXT:\\*\\*');
            const performanceText = getSection('\\*\\*PERFORMANCE PREDICTION:\\*\\*', '$');

            const performance: ParsedOutput['performance'] = {};
            performance.openRate = performanceText.match(/- Estimated Open Rate: (.*?)(?:\n|$)/i)?.[1].trim();
            performance.ctr = performanceText.match(/- Expected CTR: (.*?)(?:\n|$)/i)?.[1].trim();
            performance.conversion = performanceText.match(/- Conversion Probability: (.*?)(?:\n|$)/i)?.[1].trim();
            performance.retention = performanceText.match(/- Subscriber Retention: (.*?)(?:\n|$)/i)?.[1].trim();

            return {
                subjectLines: subjectLinesText.split('\n').map(s => s.replace(/^\d+\.\s*/, '').trim()).filter(Boolean),
                previewText: getSection('\\*\\*PREVIEW TEXT:\\*\\*', '\\*\\*NEWSLETTER CONTENT:\\*\\*'),
                newsletterContent: getSection('\\*\\*NEWSLETTER CONTENT:\\*\\*', '\\*\\*PERFORMANCE PREDICTION:\\*\\*'),
                performance,
            };
        } catch (e) {
            console.error("Failed to parse Newsletter output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return NEWSLETTER_BUILDER_PROMPT
            .replace('{MAIN_TOPIC}', mainTopic)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{NEWSLETTER_PURPOSE}', newsletterPurpose)
            .replace('{BRAND_VOICE}', brandVoice)
            .replace('{PRIMARY_GOAL}', primaryGoal)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [mainTopic, targetAudience, newsletterPurpose, brandVoice, primaryGoal, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\[(.*?)\]/g, '<span class="bg-brand-primary/20 text-brand-primary px-2 py-1 rounded-md font-semibold text-sm">$1</span>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={mainTopic} onChange={e => setMainTopic(e.target.value)} placeholder="Enter main topic or key points..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Newsletter Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Target Audience</label>
                                <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as Audience)} className={commonInputClasses}>
                                    <option>Subscribers</option><option>Customers</option><option>Leads</option><option>Partners</option><option>Internal</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Newsletter Purpose</label>
                                <select value={newsletterPurpose} onChange={e => setNewsletterPurpose(e.target.value as Purpose)} className={commonInputClasses}>
                                    <option>Educate</option><option>Promote</option><option>Engage</option><option>Retain</option><option>Convert</option><option>Nurture</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Brand Voice</label>
                                <select value={brandVoice} onChange={e => setBrandVoice(e.target.value as BrandVoice)} className={commonInputClasses}>
                                    <option>Friendly</option><option>Professional</option><option>Casual</option><option>Authoritative</option><option>Inspirational</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Primary Goal</label>
                                <select value={primaryGoal} onChange={e => setPrimaryGoal(e.target.value as PrimaryGoal)} className={commonInputClasses}>
                                    <option>Engagement</option><option>Clicks</option><option>Sales</option><option>Education</option><option>Retention</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Building Newsletter...' : (isQueued ? 'Request Queued' : 'Build Newsletter')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && mainTopic.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                </div>
                <div className="bg-base-100 dark:bg-d-base-100 rounded-lg p-4 min-h-[500px] shadow-inner">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Building your expert newsletter...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your professionally crafted newsletter will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-6">
                           <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300">
                                <h3 className="font-bold text-lg text-text-primary dark:text-d-text-primary mb-2">Subject Line Options</h3>
                                <ul className="space-y-2">
                                    {parsedOutput.subjectLines.map((line, index) => (
                                        <li key={index} className="flex items-center justify-between text-sm p-2 rounded-md bg-base-100 dark:bg-d-base-100">
                                            <span className="text-text-secondary dark:text-d-text-secondary">{line}</span>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div className="bg-base-200/50 dark:bg-d-base-200/50 p-6 rounded-lg shadow-md">
                                <div className="border-b border-base-300 dark:border-d-base-300 pb-4 mb-4">
                                    <p className="text-sm text-text-secondary dark:text-d-text-secondary"><strong className="text-text-primary dark:text-d-text-primary">Subject:</strong> {parsedOutput.subjectLines[0] || 'Your Subject Here'}</p>
                                    <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1"><strong className="text-text-primary dark:text-d-text-primary">Preview:</strong> {parsedOutput.previewText}</p>
                                </div>
                                <div className="prose prose-sm dark:prose-invert max-w-none text-text-primary dark:text-d-text-primary" dangerouslySetInnerHTML={formatContent(parsedOutput.newsletterContent)} />
                            </div>
                            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300">
                                <h3 className="font-bold text-lg text-text-primary dark:text-d-text-primary mb-3">Performance Prediction</h3>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                                    <div><p className="text-2xl font-bold text-brand-primary">{parsedOutput.performance.openRate || 'N/A'}</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Open Rate</p></div>
                                    <div><p className="text-2xl font-bold text-brand-primary">{parsedOutput.performance.ctr || 'N/A'}</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Click Rate</p></div>
                                    <div><p className="text-2xl font-bold text-brand-secondary">{parsedOutput.performance.conversion || 'N/A'}</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Conversion</p></div>
                                    <div><p className="text-2xl font-bold text-brand-secondary">{parsedOutput.performance.retention || 'N/A'}</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Retention</p></div>
                                </div>
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default NewsletterBuilderView;
