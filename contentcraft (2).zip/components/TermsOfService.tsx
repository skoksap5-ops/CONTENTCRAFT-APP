import React from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';

interface TermsOfServiceProps {
  onClose: () => void;
}

const TermsOfService: React.FC<TermsOfServiceProps> = ({ onClose }) => {
  const H3: React.FC<{children: React.ReactNode}> = ({ children }) => <h3 className="text-xl font-bold font-heading mt-5 mb-2 text-text-primary dark:text-d-text-primary">{children}</h3>;
  const P: React.FC<{children: React.ReactNode}> = ({ children }) => <p className="mb-4 leading-relaxed text-text-secondary dark:text-d-text-secondary">{children}</p>;
  const LI: React.FC<{children: React.ReactNode}> = ({ children }) => <li className="mb-2 ml-4 list-disc">{children}</li>;
  
  return (
    <div className="fixed inset-0 bg-base-100 dark:bg-d-base-100 z-50 animate-fade-in-up overflow-y-auto" role="dialog" aria-modal="true">
      <header className="sticky top-0 bg-base-100/80 dark:bg-d-base-100/80 backdrop-blur-sm z-10 border-b border-base-300 dark:border-d-base-300">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-16 gap-4">
          <button
            onClick={onClose}
            className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-200"
            aria-label="Back to profile"
          >
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Terms of Service</h1>
        </div>
      </header>
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-2xl font-bold font-heading mt-6 mb-3 text-text-primary dark:text-d-text-primary">Terms of Service</h2>
        <P><em>Last updated: December 2024</em></P>
        <P>
            You can also view these terms on our website: 
            <a href="http://contentcraft.free.nf/terms.html" target="_blank" rel="noopener noreferrer" className="text-brand-primary hover:underline ml-1">
                contentcraft.free.nf/terms.html
            </a>
        </P>

        <H3>Agreement to Terms</H3>
        <P>By accessing and using ContentCraft ("the Service"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, please do not use our Service.</P>
        
        <H3>Description of Service</H3>
        <P>ContentCraft is an AI-powered content creation platform featuring 53 specialized modules across multiple categories including:</P>
        <ul>
            <LI>AI Power Suite (11 modules: AI Prompt Generator, SEO Opportunity Finder, Content Repurposing Engine, etc.)</LI>
            <LI>Core Modules (15 modules: SEO Optimizer, Human Warmth, Corporate Polish, etc.)</LI>
            <LI>Social Suite (11 modules: LinkedIn Styler, Instagram Styler, Hashtag Generator, etc.)</LI>
            <LI>Professional & Content (10 modules: Startup Pitch, Email Craft, Case Study Creator, etc.)</LI>
            <LI>Marketing & Conversion (5 modules: Headline Generator, Google Ads, Landing Page Copy, etc.)</LI>
            <LI>Module Explanation Assistant - AI chatbot for module guidance</LI>
        </ul>

        <H3>User Accounts</H3>
        <ul>
            <LI>You are responsible for maintaining the confidentiality of your account</LI>
            <LI>You must provide accurate and complete information</LI>
            <LI>You are responsible for all activities under your account</LI>
            <LI>You must notify us immediately of any unauthorized use</LI>
            <LI>We reserve the right to suspend or terminate accounts that violate these Terms</LI>
        </ul>

        <H3>Acceptable Use Policy</H3>
        <P>You agree not to use the Service to:</P>
        <ul>
            <LI>Generate content that is illegal, harmful, or violates others' rights</LI>
            <LI>Create spam, malware, or other malicious content</LI>
            <LI>Infringe on intellectual property rights</LI>
            <LI>Generate content for deceptive or fraudulent purposes</LI>
            <LI>Violate any applicable laws or regulations</LI>
            <LI>Attempt to reverse engineer or hack the Service</LI>
            <LI>Use any of the 53 modules for unlawful or unethical purposes</LI>
        </ul>

        <H3>Subscription and Payment</H3>
        <ul>
            <LI>Subscriptions are billed in advance on a monthly or annual basis</LI>
            <LI>All fees are non-refundable except as required by law</LI>
            <LI>Prices may change with 30 days notice</LI>
            <LI>You can cancel your subscription at any time</LI>
            <LI>Cancellation takes effect at the end of the current billing period</LI>
            <LI>Free tier usage is subject to daily limits and module access restrictions</LI>
        </ul>

        <H3>Intellectual Property</H3>
        <ul>
            <LI>You retain ownership of content you input into the Service</LI>
            <LI>You own the content generated by the Service based on your inputs</LI>
            <LI>ContentCraft retains ownership of the Service, software, technology, and all 53 modules</LI>
            <LI>You grant us a limited license to process your content to provide the Service</LI>
            <LI>We may use anonymized usage data to improve our Service</LI>
        </ul>
        
        <H3>Content Guidelines</H3>
        <P>Generated content should be:</P>
        <ul>
            <LI>Used responsibly and ethically across all 53 modules</LI>
            <LI>Reviewed and edited as appropriate</LI>
            <LI>Attributed properly when required</LI>
            <LI>Compliant with applicable laws and platform policies</LI>
        </ul>
        <P>We are not responsible for the accuracy or appropriateness of generated content from any module.</P>

        <H3>Privacy</H3>
        <P>Your privacy is important to us. Please review our Privacy Policy (updated December 2024), which also governs your use of the Service, to understand our practices regarding data collection and AI model training.</P>

        <H3>Disclaimers</H3>
        <ul>
            <LI>The Service is provided "as is" without warranties</LI>
            <LI>We do not guarantee the accuracy of generated content from any module</LI>
            <LI>AI-generated content may contain errors or biases</LI>
            <LI>Service availability and module performance are not guaranteed</LI>
            <LI>We are not liable for any damages arising from use of the Service</LI>
        </ul>

        <H3>Limitation of Liability</H3>
        <P>To the maximum extent permitted by law, ContentCraft shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues arising from use of any of the 53 modules.</P>

        <H3>Termination</H3>
        <ul>
            <LI>Either party may terminate this agreement at any time</LI>
            <LI>We may suspend or terminate your access for violations</LI>
            <LI>Upon termination, your right to use the Service and all modules ceases</LI>
            <LI>Certain provisions will survive termination</LI>
        </ul>

        <H3>Changes to Terms</H3>
        <P>We reserve the right to modify these Terms at any time. We will notify users of significant changes. Continued use of the Service after changes constitutes acceptance of the new Terms.</P>

        <H3>Governing Law</H3>
        <P>These Terms are governed by and construed in accordance with applicable laws. Any disputes will be resolved through binding arbitration.</P>

        <H3>Contact Us</H3>
        <P>If you have any questions about these Terms of Service, please contact us:</P>
        <ul>
            <LI>Email: <a href="mailto:Contentcraft.free.nf@gmail.com" className="text-brand-primary hover:underline">Contentcraft.free.nf@gmail.com</a></LI>
        </ul>
      </main>
    </div>
  );
};

export default TermsOfService;