import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type ConsistencyLevel = 'Subtle Adjustment' | 'Moderate Refinement' | 'Complete Transformation';
type Context = 'Business' | 'Personal' | 'Academic' | 'Creative' | 'Technical';
type TargetAudience = 'Executives' | 'Colleagues' | 'Customers' | 'General Public';

const toneSchema = {
    type: Type.OBJECT,
    properties: {
        versions: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "A creative title for the version." },
                    content: { type: Type.STRING, description: "The full transformed text for this version." },
                    analysis: { type: Type.STRING, description: "Markdown-formatted analysis of key changes and tone shift." }
                },
                required: ['title', 'content', 'analysis']
            }
        },
        report: { type: Type.STRING, description: "A concise, markdown-formatted tone transformation report." }
    },
    required: ['versions', 'report']
};


const TONE_HARMONIZER_PROMPT = `
You are a master linguistic stylist and tone adaptation expert. Transform any text to perfectly match desired emotional tones while preserving core meaning.

**INPUT:**
- Original Text: {ORIGINAL_TEXT}
- Target Tones: {TARGET_TONES}
- Consistency Level: {CONSISTENCY}
- Context: {CONTEXT}
- Audience: {TARGET_AUDIENCE}

**INSTRUCTIONS:**
Your response MUST be a valid JSON object conforming to the provided schema.
- Create 3 distinct versions of the text, each harmonized to the target tones but with a different stylistic focus.
- The 'content' field for each version MUST contain the full, rewritten text. This is the most important part.
- The 'report' field should contain a brief, high-level analysis of the transformation strategy.
`;

interface Version {
    title: string;
    content: string;
    analysis: string;
}

interface ParsedOutput {
    versions: Version[];
    report: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const ToneHarmonizerView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const [targetTones, setTargetTones] = useState<string[]>([]);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    const [consistency, setConsistency] = useState<ConsistencyLevel>('Moderate Refinement');
    const [context, setContext] = useState<Context>('Business');
    const [audience, setAudience] = useState<TargetAudience>('General Public');

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim() && targetTones.length > 0;

    const getPrompt = useCallback(() => {
        return TONE_HARMONIZER_PROMPT
            .replace('{ORIGINAL_TEXT}', input)
            .replace('{TARGET_TONES}', targetTones.join(', '))
            .replace('{CONSISTENCY}', consistency)
            .replace('{CONTEXT}', context)
            .replace('{TARGET_AUDIENCE}', audience);
    }, [input, targetTones, consistency, context, audience]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: toneSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
             if (!parsed.versions || parsed.versions.length === 0) {
                setError("The AI returned an incomplete response. Please try again.");
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };
    
    const VersionCard: React.FC<{ version: Version }> = ({ version }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!version.content) return;
            navigator.clipboard.writeText(version.content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!version.content) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative space-y-4">
                <div className="flex justify-between items-start">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{version.title}</h4>
                     <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${version.title}`}>
                        {copySuccess ? 'Copied!' : <CopyIcon className="h-5 w-5" />}
                    </button>
                </div>
                <p className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed">{version.content}</p>
                <Accordion title={<>💡 <span className="ml-2">Analysis</span></>}>
                    <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(version.analysis)} />
                </Accordion>
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[250px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter text to harmonize..." className={commonTextareaClasses} />
                    
                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Target Tones</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{targetTones.length}</span> / 3</div></div>
                        <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-2">{targetTones.length > 0 ? targetTones.join(', ') : 'Tap to select one or more target tones.'}</p>
                    </button>
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Consistency</label>
                                <select value={consistency} onChange={e => setConsistency(e.target.value as ConsistencyLevel)} className={commonInputClasses}>
                                    <option>Subtle Adjustment</option><option>Moderate Refinement</option><option>Complete Transformation</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Context</label>
                                <select value={context} onChange={e => setContext(e.target.value as Context)} className={commonInputClasses}>
                                    <option>Business</option><option>Personal</option><option>Academic</option><option>Creative</option><option>Technical</option>
                                </select>
                            </div>
                             <div>
                                <label className={commonLabelClasses}>Audience</label>
                                <select value={audience} onChange={e => setAudience(e.target.value as TargetAudience)} className={commonInputClasses}>
                                    <option>General Public</option><option>Executives</option><option>Colleagues</option><option>Customers</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Harmonizing...' : (isQueued ? 'Request Queued' : 'Harmonize Tone')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && <p className="text-center text-yellow-500 text-sm mt-2">Please provide text and at least one target tone.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Harmonizing your text...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your tone-harmonized versions and analysis will appear here.</p>}
                    {error && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">An Error Occurred</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">{error}</p></div>}
                    {parsedOutput && (
                        <div className="space-y-6">
                             <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Tone-Harmonized Versions</h3>
                                {parsedOutput.versions.map((version, index) => <VersionCard key={index} version={version} />)}
                            </div>
                            <div className="pt-4">
                                <Accordion title={<>📊 <span className="ml-2">Tone Transformation Report</span></>}>
                                    <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.report)}/>
                                </Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={targetTones} onTonesChange={setTargetTones} />
        </>
    );
};

export default ToneHarmonizerView;