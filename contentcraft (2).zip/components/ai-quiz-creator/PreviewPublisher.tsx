import React from 'react';

const PreviewPublisher = ({ onBack, quiz }: { onBack: () => void; quiz: any; }) => {
    return (
        <div className="text-center p-8 animate-fade-in">
            <h2 className="text-2xl font-bold font-heading">🚀 Publish (Coming Soon)</h2>
            <p className="text-text-secondary dark:text-d-text-secondary mt-2">Preview your quiz and get the code to embed it on your site.</p>
            <div className="bg-base-100 dark:bg-d-base-100 p-4 my-6 rounded-md text-left shadow-inner max-w-md mx-auto">
                <p className="text-sm text-text-secondary dark:text-d-text-secondary">Your Quiz:</p>
                <p className="font-bold text-text-primary dark:text-d-text-primary"><strong>{quiz?.title}</strong></p>
            </div>
             <div className="flex justify-between items-center mt-8 max-w-sm mx-auto">
                <button onClick={onBack} className="px-4 py-2 font-semibold text-sm rounded-lg hover:bg-base-200 dark:hover:bg-d-base-200">← Back</button>
                <button className="px-6 py-3 font-semibold rounded-xl bg-brand-secondary text-white hover:bg-green-500" onClick={() => alert('Publishing feature coming soon!')}>Publish Quiz</button>
            </div>
        </div>
    );
};

export default PreviewPublisher;
