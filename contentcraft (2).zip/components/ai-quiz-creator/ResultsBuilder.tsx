import React, { useState } from 'react';
import type { QuizData, QuizResult } from './types';

interface ResultsBuilderProps {
    quiz: QuizData;
    onUpdate: (results: QuizResult[]) => void;
    onBack: () => void;
}

const ResultsBuilder: React.FC<ResultsBuilderProps> = ({ quiz, onUpdate, onBack }) => {
  const [results, setResults] = useState<QuizResult[]>(quiz.results.length > 0 ? quiz.results : []);

  const addNewResult = () => {
    const newResult: QuizResult = {
      id: Date.now(),
      title: `Result ${results.length + 1}`,
      description: '',
      minScore: 0,
      maxScore: 100,
      recommendations: []
    };
    setResults(prev => [...prev, newResult]);
  };

  const updateResult = (resultId: number, updates: Partial<QuizResult>) => {
    setResults(prev => prev.map(r => 
      r.id === resultId ? { ...r, ...updates } : r
    ));
  };

  const handleSaveAndContinue = () => {
    onUpdate(results);
  };
  
  const commonInputClasses = "w-full p-2 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";

  return (
    <div className="animate-fade-in">
        <div className="text-center mb-6">
            <h2 className="text-2xl font-bold font-heading">📊 Build Your Results</h2>
            <p className="text-text-secondary dark:text-d-text-secondary text-sm">Create meaningful outcomes for your quiz takers.</p>
        </div>

        <div className="space-y-4">
            {results.map((result, index) => (
                <div key={result.id} className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg border border-base-300 dark:border-d-base-300 space-y-3">
                    <input type="text" value={result.title} onChange={(e) => updateResult(result.id, { title: e.target.value })} className={`${commonInputClasses} font-bold text-lg`} />
                    <textarea value={result.description} onChange={(e) => updateResult(result.id, { description: e.target.value })} placeholder="Describe this result..." className={`${commonInputClasses} min-h-[60px]`} />
                </div>
            ))}
            <button onClick={addNewResult} className="w-full p-3 text-sm font-semibold border-2 border-dashed border-base-300 dark:border-d-base-300 rounded-lg hover:border-brand-primary hover:text-brand-primary transition-colors">
                + Add Result Type
            </button>
        </div>

        <div className="flex justify-between items-center mt-8">
            <button onClick={onBack} className="px-4 py-2 font-semibold text-sm rounded-lg hover:bg-base-200 dark:hover:bg-d-base-200">← Back</button>
            <button onClick={handleSaveAndContinue} className="px-6 py-3 font-semibold rounded-xl bg-brand-primary text-white hover:bg-brand-primary/90">
              Set Up Lead Capture →
            </button>
        </div>
    </div>
  );
};

export default ResultsBuilder;
