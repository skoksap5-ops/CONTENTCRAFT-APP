import React, { useState } from 'react';
import type { QuizConfig } from './types';

interface QuizSetupProps {
  onSubmit: (data: QuizConfig) => void;
  isLoading: boolean;
}

const QuizSetup: React.FC<QuizSetupProps> = ({ onSubmit, isLoading }) => {
  const [setupData, setSetupData] = useState({
    title: '',
    type: 'personality' as QuizConfig['type'],
    topic: '',
    difficulty: 'beginner' as QuizConfig['difficulty'],
    questionCount: 5,
    purpose: 'lead-generation',
    audience: ''
  });

  const quizTypes = [
    { id: 'personality', name: 'Personality Quiz', icon: '🌟', description: 'Discover personality types or traits' },
    { id: 'knowledge', name: 'Knowledge Test', icon: '🧠', description: 'Test expertise on a specific topic' },
    { id: 'assessment', name: 'Skills Assessment', icon: '📊', description: 'Evaluate skills or capabilities' }
  ];

  const handleInputChange = (field: keyof typeof setupData, value: string | number) => {
    setSetupData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (setupData.title && setupData.topic) {
      onSubmit(setupData as QuizConfig);
    }
  };
  
  const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
  const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2";

  return (
    <div className="animate-fade-in">
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="form-section">
          <h3 className="text-xl font-bold font-heading mb-4">🎯 Quiz Basics</h3>
          <div className="space-y-4">
            <div>
              <label htmlFor="title" className={commonLabelClasses}>Quiz Title</label>
              <input id="title" type="text" value={setupData.title} onChange={(e) => handleInputChange('title', e.target.value)} placeholder="e.g., What's Your Marketing Superpower?" required className={commonInputClasses} />
            </div>
            <div>
              <label htmlFor="topic" className={commonLabelClasses}>Topic/Industry</label>
              <input id="topic" type="text" value={setupData.topic} onChange={(e) => handleInputChange('topic', e.target.value)} placeholder="e.g., Digital Marketing, Productivity" required className={commonInputClasses} />
            </div>
          </div>
        </div>

        <div className="form-section">
          <h3 className="text-xl font-bold font-heading mb-4">🎪 Quiz Type</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {quizTypes.map(type => (
              <button type="button" key={type.id} className={`p-4 rounded-lg border-2 text-left transition-colors ${setupData.type === type.id ? 'border-brand-primary bg-brand-primary/10' : 'bg-base-100 dark:bg-d-base-100 border-base-300 dark:border-d-base-300'}`} onClick={() => handleInputChange('type', type.id)}>
                <div className="text-2xl mb-2">{type.icon}</div>
                <div className="font-semibold">{type.name}</div>
                <div className="text-xs text-text-secondary dark:text-d-text-secondary">{type.description}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="form-section">
          <h3 className="text-xl font-bold font-heading mb-4">⚙️ Configuration</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="questionCount" className={commonLabelClasses}>Number of Questions ({setupData.questionCount})</label>
              <input id="questionCount" type="range" min="3" max="15" step="1" value={setupData.questionCount} onChange={(e) => handleInputChange('questionCount', parseInt(e.target.value))} className="w-full h-2 bg-base-300 dark:bg-d-base-300 rounded-lg appearance-none cursor-pointer" />
            </div>
            <div>
              <label htmlFor="difficulty" className={commonLabelClasses}>Difficulty</label>
              <select id="difficulty" value={setupData.difficulty} onChange={(e) => handleInputChange('difficulty', e.target.value)} className={commonInputClasses}>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </div>
          </div>
        </div>

        <button type="submit" className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 transition-all" disabled={isLoading || !setupData.title || !setupData.topic}>
          {isLoading ? 'Generating Quiz...' : 'Create Quiz Questions →'}
        </button>
      </form>
    </div>
  );
};

export default QuizSetup;
