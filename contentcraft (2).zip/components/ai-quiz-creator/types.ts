export interface QuizConfig {
    title: string;
    type: 'personality' | 'knowledge' | 'assessment';
    topic: string;
    audience: string;
    difficulty: 'beginner' | 'intermediate' | 'advanced';
    questionCount: number;
    purpose: string;
    description?: string;
}

export interface QuizQuestion {
    id: number;
    type: 'multiple-choice';
    question: string;
    options: string[];
    correctAnswers: number[];
    explanation: string;
}

export interface QuizResult {
    id: number;
    title: string;
    description: string;
    minScore: number;
    maxScore: number;
    recommendations: string[];
}

export interface QuizData {
    title: string;
    questions: QuizQuestion[];
    results: QuizResult[];
    config: QuizConfig;
    leadCapture?: any;
}