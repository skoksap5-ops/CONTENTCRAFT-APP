import React, { useState } from 'react';
import type { QuizData, QuizQuestion } from './types';

interface QuestionDesignerProps {
    quiz: QuizData;
    onUpdate: (questions: QuizQuestion[]) => void;
    onBack: () => void;
}

const QuestionDesigner: React.FC<QuestionDesignerProps> = ({ quiz, onUpdate, onBack }) => {
  const [questions, setQuestions] = useState<QuizQuestion[]>(quiz.questions || []);
  const [editingQuestionId, setEditingQuestionId] = useState<number | null>(questions.length > 0 ? questions[0].id : null);
  
  const editingQuestion = questions.find(q => q.id === editingQuestionId);

  const addNewQuestion = () => {
    const newQuestion: QuizQuestion = {
      id: Date.now(),
      type: 'multiple-choice',
      question: '',
      options: ['', '', '', ''],
      correctAnswers: [],
      explanation: ''
    };
    setQuestions(prev => [...prev, newQuestion]);
    setEditingQuestionId(newQuestion.id);
  };

  const updateQuestion = (questionId: number, updates: Partial<QuizQuestion>) => {
    setQuestions(prev => prev.map(q => 
      q.id === questionId ? { ...q, ...updates } : q
    ));
  };
  
  const handleSaveAndContinue = () => {
    onUpdate(questions);
  };

  const commonInputClasses = "w-full p-2 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";

  return (
    <div className="animate-fade-in">
        <div className="text-center mb-6">
            <h2 className="text-2xl font-bold font-heading">❓ Design Your Questions</h2>
            <p className="text-text-secondary dark:text-d-text-secondary text-sm">Review, edit, and add questions for your quiz.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 bg-base-100 dark:bg-d-base-100 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold">Questions ({questions.length})</h3>
                    <button onClick={addNewQuestion} className="px-3 py-1 text-sm font-semibold bg-brand-primary text-white rounded-md">+</button>
                </div>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                    {questions.map((q, i) => (
                        <button key={q.id} onClick={() => setEditingQuestionId(q.id)} className={`w-full text-left p-3 rounded-md transition-colors ${editingQuestionId === q.id ? 'bg-brand-primary/10' : 'hover:bg-base-200 dark:hover:bg-d-base-200'}`}>
                            <p className="font-semibold text-sm truncate"><span className="text-text-secondary dark:text-d-text-secondary">Q{i+1}:</span> {q.question || 'New Question'}</p>
                        </button>
                    ))}
                </div>
            </div>

            <div className="lg:col-span-2 bg-base-100 dark:bg-d-base-100 p-4 rounded-lg">
                {editingQuestion ? (
                    <div className="space-y-4">
                        <div>
                            <label className="text-sm font-medium">Question Text</label>
                            <textarea value={editingQuestion.question} onChange={e => updateQuestion(editingQuestion.id, { question: e.target.value })} className={`${commonInputClasses} min-h-[80px] mt-1`} />
                        </div>
                        <div>
                            <label className="text-sm font-medium">Options</label>
                            <div className="space-y-2 mt-1">
                                {editingQuestion.options.map((opt, i) => (
                                    <input key={i} value={opt} onChange={e => {
                                        const newOptions = [...editingQuestion.options];
                                        newOptions[i] = e.target.value;
                                        updateQuestion(editingQuestion.id, { options: newOptions });
                                    }} placeholder={`Option ${i+1}`} className={commonInputClasses} />
                                ))}
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="flex items-center justify-center h-full text-center text-text-secondary dark:text-d-text-secondary">
                        <p>Select a question to edit or add a new one.</p>
                    </div>
                )}
            </div>
        </div>

        <div className="flex justify-between items-center mt-8">
            <button onClick={onBack} className="px-4 py-2 font-semibold text-sm rounded-lg hover:bg-base-200 dark:hover:bg-d-base-200">← Back</button>
            <button onClick={handleSaveAndContinue} className="px-6 py-3 font-semibold rounded-xl bg-brand-primary text-white hover:bg-brand-primary/90">Build Results Page →</button>
        </div>
    </div>
  );
};

export default QuestionDesigner;
