import React from 'react';
import { useLanguage } from '../hooks/useLanguage';
import { LANGUAGES } from '../constants/languages';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import LanguageIcon from './icons/LanguageIcon';
import CheckIcon from './icons/CheckIcon';
import InfoIcon from './icons/InfoIcon';

interface LanguageSettingsViewProps {
  onClose: () => void;
}

const LanguageSettingsView: React.FC<LanguageSettingsViewProps> = ({ onClose }) => {
  const { language, setLanguage } = useLanguage();

  const handleLanguageSelect = (code: string) => {
    setLanguage(code);
  };

  return (
    <div className="fixed inset-0 bg-base-100 dark:bg-d-base-100 z-50 animate-fade-in-up flex flex-col" role="dialog" aria-modal="true">
      <header className="sticky top-0 bg-brand-primary/95 backdrop-blur-sm z-10 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-16 gap-4">
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10"
            aria-label="Back to settings"
          >
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold">Language Settings</h1>
        </div>
      </header>
      
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="text-center mb-8">
                <div className="w-20 h-20 mx-auto bg-brand-primary/10 rounded-full flex items-center justify-center mb-4">
                    <LanguageIcon className="h-10 w-10 text-brand-primary" />
                </div>
                <h2 className="text-3xl font-bold font-heading text-text-primary dark:text-d-text-primary">Language</h2>
                <p className="mt-2 text-text-secondary dark:text-d-text-secondary">
                    Choose your preferred language. This will affect the app interface and content generation.
                </p>
            </div>

            <div className="mb-8">
                <h3 className="text-sm font-semibold text-text-secondary dark:text-d-text-secondary uppercase tracking-wider mb-2">Current Language</h3>
                <div className="bg-base-200 dark:bg-d-base-200 rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center">
                        <span className="text-3xl mr-4">{language.flag}</span>
                        <div>
                            <p className="font-bold text-lg text-text-primary dark:text-d-text-primary">{language.name}</p>
                            <p className="text-sm text-text-secondary dark:text-d-text-secondary">{language.country}</p>
                        </div>
                    </div>
                     <GlobeAltIcon className="h-6 w-6 text-brand-primary" />
                </div>
            </div>

            <div>
                <h3 className="text-sm font-semibold text-text-secondary dark:text-d-text-secondary uppercase tracking-wider mb-2">Available Languages</h3>
                <div className="space-y-3">
                    {LANGUAGES.map(lang => {
                        const isSelected = language.code === lang.code;
                        return (
                             <button 
                                key={lang.code}
                                onClick={() => handleLanguageSelect(lang.code)}
                                className={`w-full text-left bg-base-200 dark:bg-d-base-200 rounded-xl p-4 flex items-center justify-between border-2 transition-all duration-200 ${isSelected ? 'border-brand-primary' : 'border-transparent hover:border-brand-primary/50'}`}
                            >
                                <div className="flex items-center">
                                    <span className="text-3xl mr-4">{lang.flag}</span>
                                    <div>
                                        <p className="font-bold text-lg text-text-primary dark:text-d-text-primary">{lang.name}</p>
                                        <p className="text-sm text-text-secondary dark:text-d-text-secondary">{lang.country}</p>
                                    </div>
                                </div>
                                <div className="flex items-center">
                                    <span className="text-sm text-text-secondary dark:text-d-text-secondary mr-4 hidden sm:inline">{lang.nativeName}</span>
                                    {isSelected && (
                                        <div className="w-6 h-6 bg-brand-primary rounded-full flex items-center justify-center text-white">
                                            <CheckIcon className="h-4 w-4" />
                                        </div>
                                    )}
                                </div>
                            </button>
                        )
                    })}
                </div>
            </div>

            <div className="mt-8 bg-blue-500/10 dark:bg-blue-500/20 p-4 rounded-xl flex items-start text-blue-800 dark:text-blue-300">
                 <InfoIcon className="h-5 w-5 flex-shrink-0 mt-0.5 mr-3" />
                 <div className="text-sm">
                    <h4 className="font-bold mb-1">Language Support</h4>
                    <ul className="list-disc list-inside space-y-1">
                        <li>Interface language affects menus and buttons.</li>
                        <li>Content generation will use the selected language.</li>
                        <li>Some features may have limited translation.</li>
                        <li>You can change the language anytime in settings.</li>
                    </ul>
                 </div>
            </div>
        </div>
      </main>
    </div>
  );
};

// A new icon needed for the header
const GlobeAltIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21V3m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m0 18c1.657 0 3-4.03 3-9s-1.343-9-3-9M3.28 9a11.96 11.96 0 0117.44 0" />
  </svg>
);


export default LanguageSettingsView;