import React from 'react';
import CloseIcon from './icons/CloseIcon';
import HomeIcon from './icons/HomeIcon';
import UserIcon from './icons/UserIcon';
import SettingsIcon from './icons/SettingsIcon';
import HistoryIcon from './icons/HistoryIcon';
import { useFeedback } from '../hooks/useFeedback';
import { useLanguage } from '../hooks/useLanguage';
import type { View } from '../types';
import EarnIcon from './icons/EarnIcon';
import { MODULE_GROUPS_MAP } from '../constants'; 

// New icon imports for groups
import SparklesIcon from './icons/settings/SparklesIcon';
import GridIcon from './icons/GridIcon';
import ShareIcon from './icons/ShareIcon';
import BriefcaseIcon from './icons/professional/BriefcaseIcon';
import BarChartIcon from './icons/BarChartIcon';
import CrownIcon from './icons/CrownIcon';


interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  setView: (view: View) => void;
  activeView: View;
  isPremium: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, setView, activeView, isPremium }) => {
    const { playClick } = useFeedback();
    const { t } = useLanguage();

    const handleSetView = (view: View) => {
        playClick();
        setView(view);
        onClose();
    }
    
    const handleGroupClick = (groupId: string) => {
        playClick();
        setView('dashboard'); // Switch to dashboard view
        onClose();
        // Use a timeout to allow the dashboard to render before scrolling
        setTimeout(() => {
            const element = document.getElementById(groupId);
            if (element) {
                // Adjust for fixed header height
                const headerOffset = 64; // h-16
                const elementPosition = element.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset - 16; // extra 1rem padding

                window.scrollTo({
                    top: offsetPosition,
                    behavior: "smooth"
                });
            }
        }, 150); // A bit more delay to be safe
    }


    const appViews = [
        { id: 'dashboard', name: t('home'), icon: <HomeIcon className="h-6 w-6" /> },
        { id: 'earn', name: t('earn'), icon: <EarnIcon className="h-6 w-6" /> },
        { id: 'history', name: t('history'), icon: <HistoryIcon className="h-6 w-6" /> },
        { id: 'profile', name: t('profile'), icon: <UserIcon className="h-6 w-6" /> },
        { id: 'settings', name: t('settings'), icon: <SettingsIcon className="h-6 w-6" /> },
    ];

    const moduleGroups = Object.values(MODULE_GROUPS_MAP);
    
    const getGroupIcon = (nameKey: string) => {
        const className = "h-5 w-5 opacity-80"; // Smaller icons for groups
        switch (nameKey) {
            case 'group_ai_power': return <SparklesIcon className={className} />;
            case 'group_core': return <GridIcon className={className} />;
            case 'group_social': return <ShareIcon className={className} />;
            case 'group_professional': return <BriefcaseIcon className={className} />;
            case 'group_marketing': return <BarChartIcon className={className} />;
            default: return <div className={className} />;
        }
    };

    return (
        <>
            <div 
                className={`fixed inset-0 bg-black/60 z-30 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
                onClick={onClose}
                aria-hidden="true"
            />
            <aside className={`fixed top-0 left-0 h-full w-72 bg-base-200 dark:bg-d-base-200 shadow-xl z-40 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                <div className="flex justify-between items-center p-4 border-b border-base-300 dark:border-d-base-300">
                     <h2 className="text-xl font-bold font-heading text-text-primary dark:text-d-text-primary">Content<span className="text-brand-primary">Craft</span></h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-base-300 dark:hover:bg-d-base-300">
                        <CloseIcon className="h-6 w-6" />
                    </button>
                </div>
                <nav className="p-4 flex flex-col h-[calc(100%-65px)]">
                    <div className="flex-1 overflow-y-auto space-y-6">
                        <div>
                            <h3 className="px-2 text-sm font-semibold text-text-secondary dark:text-d-text-secondary uppercase tracking-wider mb-2">{t('menu')}</h3>
                            <div className="space-y-1">
                                {appViews.map(view => (
                                    <button key={view.id} onClick={() => handleSetView(view.id as View)} className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-left font-medium transition-colors ${activeView === view.id ? 'bg-brand-primary/10 text-brand-primary' : 'text-text-primary dark:text-d-text-primary hover:bg-base-300 dark:hover:bg-d-base-300'}`}>
                                        {view.icon}
                                        {view.name}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div>
                            <h3 className="px-2 text-sm font-semibold text-text-secondary dark:text-d-text-secondary uppercase tracking-wider mb-2 mt-6">{t('modules')}</h3>
                            <div className="space-y-1">
                                {moduleGroups.map(group => (
                                    <button key={group.id} onClick={() => handleGroupClick(group.id)} className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-left font-medium transition-colors text-text-secondary dark:text-d-text-secondary hover:bg-base-300 dark:hover:bg-d-base-300 hover:text-text-primary dark:hover:text-d-text-primary`}>
                                        {getGroupIcon(group.nameKey)}
                                        <span className="flex-1">{t(group.nameKey)}</span>
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                    
                    <div className="mt-auto pt-4 border-t border-base-300 dark:border-d-base-300">
                        {isPremium ? (
                            <div className="px-4 py-3 bg-brand-secondary/10 dark:bg-brand-secondary/20 rounded-lg text-center mx-2">
                                <div className="flex items-center justify-center gap-2">
                                    <div className="sidebar-cube-container">
                                        <div className="sidebar-cube">
                                            <div className="sidebar-cube-face face-front">
                                                <span className="sidebar-cube-face-text">CONTENT<br/>CRAFT</span>
                                            </div>
                                            <div className="sidebar-cube-face face-right"></div>
                                            <div className="sidebar-cube-face face-top"></div>
                                        </div>
                                    </div>
                                    <p className="font-semibold text-brand-secondary">Craft Pro</p>
                                </div>
                                <p className="text-xs text-brand-secondary/80 dark:text-brand-secondary/90 mt-1">You have unlimited access!</p>
                            </div>
                        ) : (
                            <div className="px-4 py-3 bg-brand-primary/10 dark:bg-brand-primary/20 rounded-lg text-center mx-2 cursor-pointer hover:bg-brand-primary/20 dark:hover:bg-brand-primary/30" onClick={() => handleSetView('upgrade')}>
                            <div className="flex items-center justify-center gap-2">
                                <CrownIcon className="h-5 w-5 text-brand-primary" />
                                <p className="font-semibold text-brand-primary">Upgrade to Pro</p>
                            </div>
                            <p className="text-xs text-brand-primary/80 dark:text-brand-primary/90 mt-1">Unlock unlimited access!</p>
                            </div>
                        )}
                    </div>
                </nav>
            </aside>
        </>
    );
};
export default Sidebar;