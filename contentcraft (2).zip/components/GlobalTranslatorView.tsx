import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type ContentType = 'Formal' | 'Business' | 'Casual' | 'Technical' | 'Creative';
type TonePreservation = 'Adapt' | 'Preserve' | 'Ignore';

const GLOBAL_TRANSLATOR_PROMPT = `
You are a master linguist and cultural adaptation specialist. Provide accurate, context-aware translations that preserve meaning, adapt to regional dialects, and maintain appropriate cultural nuances across languages.

**INPUT:**
- Source Text: {SOURCE_TEXT}
- Source Language: {SOURCE_LANGUAGE}
- Target Language: {TARGET_LANGUAGE}
- Regional Dialect: {REGIONAL_DIALECT}
- Content Type: {CONTENT_TYPE}
- Cultural Context: {CULTURAL_CONTEXT}
- Tone Preservation: {TONE_PRESERVATION}

**TASK:**
Generate a comprehensive translation report. The output MUST follow this structure exactly:

---TRANSLATION START---

🌍 **TRANSLATION RESULTS:**

## 🎯 **STANDARD TRANSLATION**
"[Translation]"
**Translation Analysis:**
- **Accuracy**: [Score]/10
- **Cultural Appropriateness**: [Score]/10
- **Tone Match**: [Comment]
- **Regional Adaptation**: [Comment]
**Key Adaptations:**
• "[Change 1]" → "[New Phrase]" ([Reason])
• "[Change 2]" → "[New Phrase]" ([Reason])

## 💼 **FORMAL VERSION**
"[Translation]"
**Translation Analysis:**
- **Accuracy**: [Score]/10
- **Cultural Appropriateness**: [Score]/10
- **Tone Match**: [Comment]
- **Regional Adaptation**: [Comment]
**Key Adaptations:**
• "[Change 1]" → "[New Phrase]" ([Reason])
• "[Change 2]" → "[New Phrase]" ([Reason])

## 🤝 **CASUAL/COLLOQUIAL VERSION**
"[Translation]"
**Translation Analysis:**
- **Accuracy**: [Score]/10
- **Cultural Appropriateness**: [Score]/10
- **Tone Match**: [Comment]
- **Regional Adaptation**: [Comment]
**Key Adaptations:**
• "[Change 1]" → "[New Phrase]" ([Reason])
• "[Change 2]" → "[New Phrase]" ([Reason])

---

📊 **TRANSLATION QUALITY METRICS:**
**Overall Quality Score: [Score]/10**
- **Meaning Preservation**: [Score]/10
- **Cultural Adaptation**: [Score]/10
- **Tone & Style**: [Score]/10
- **Readability & Flow**: [Score]/10

---

🔍 **CULTURAL ADAPTATION NOTES:**
- **Business Culture Considerations:** [List of considerations]
- **Regional Language Nuances:** [List of nuances]
- **Idiom Adaptation Analysis:** [Analysis of idiom translations]

---

🌐 **ALTERNATIVE REGIONAL VARIATIONS:**
- **[Region 1]:** "[Translation]"
- **[Region 2]:** "[Translation]"
- **Key Regional Differences:** [Explanation]

---TRANSLATION END---
`;

interface TranslationVersion {
    title: string;
    content: string;
    analysis: string;
    adaptations: string;
}

interface ParsedOutput {
    versions: TranslationVersion[];
    qualityMetrics: string;
    culturalNotes: string;
    regionalVariations: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const GlobalTranslatorView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
  const [input, setInput] = useState('');
  const [targetLanguage, setTargetLanguage] = useState('Serbian (Cyrillic)');
  const [output, setOutput] = useState('');
  const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isQueued, setIsQueued] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Advanced options
  const [sourceLanguage, setSourceLanguage] = useState('Auto-detect');
  const [regionalDialect, setRegionalDialect] = useState('');
  const [contentType, setContentType] = useState<ContentType>('Business');
  const [culturalContext, setCulturalContext] = useState('');
  const [tonePreservation, setTonePreservation] = useState<TonePreservation>('Adapt');

  const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim() && targetLanguage.trim();

  const parseOutput = useCallback((text: string): ParsedOutput | null => {
    try {
        const getSection = (start: string, end: string, source = text) => {
            const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
            const match = source.match(regex);
            return match ? match[1].trim() : '';
        };

        const resultsText = getSection('🌍 \\*\\*TRANSLATION RESULTS:\\*\\*', '---', text);
        if (!resultsText) return null;

        const metricsText = getSection('📊 \\*\\*TRANSLATION QUALITY METRICS:\\*\\*', '---', text);
        const notesText = getSection('🔍 \\*\\*CULTURAL ADAPTATION NOTES:\\*\\*', '---', text);
        const variationsText = getSection('🌐 \\*\\*ALTERNATIVE REGIONAL VARIATIONS:\\*\\*', '---TRANSLATION END---', text);

        const versionBlocks = resultsText.split(/## /).slice(1);
        const versions: TranslationVersion[] = versionBlocks.map(block => {
            const titleMatch = block.match(/🎯|💼|🤝\s*\*\*(.*?)\*\*/);
            const title = titleMatch ? titleMatch[1].trim() : 'Translated Version';
            
            const contentMatch = block.match(/"([\s\S]*?)"/);
            const content = contentMatch ? contentMatch[1] : '';
            
            const analysis = getSection('\\*\\*Translation Analysis:\\*\\*', '\\*\\*Key Adaptations:\\*\\*', block);
            const adaptations = getSection('\\*\\*Key Adaptations:\\*\\*', '$', block);
            
            return { title, content, analysis, adaptations };
        });

        if (versions.length === 0) return null;

        return {
            versions,
            qualityMetrics: metricsText,
            culturalNotes: notesText,
            regionalVariations: variationsText
        };
    } catch (e) {
        console.error("Failed to parse Global Translator output:", e);
        return null;
    }
  }, []);

  const getPrompt = useCallback(() => {
    return GLOBAL_TRANSLATOR_PROMPT
        .replace('{SOURCE_TEXT}', input)
        .replace('{SOURCE_LANGUAGE}', sourceLanguage || 'Auto-detect')
        .replace('{TARGET_LANGUAGE}', targetLanguage)
        .replace('{REGIONAL_DIALECT}', regionalDialect || 'Not specified')
        .replace('{CONTENT_TYPE}', contentType)
        .replace('{CULTURAL_CONTEXT}', culturalContext || 'Not specified')
        .replace('{TONE_PRESERVATION}', tonePreservation);
  }, [input, sourceLanguage, targetLanguage, regionalDialect, contentType, culturalContext, tonePreservation]);

  const handleGenerate = useCallback(async () => {
    if (!canGenerate) return;

    setIsLoading(true);
    setError(null);
    setOutput('');
    setParsedOutput(null);
    setIsQueued(false);
    
    const prompt = getPrompt();
    
    if (!navigator.onLine) {
        try {
            if (Notification.permission !== 'granted') await Notification.requestPermission();
            await addToQueue({ prompt, moduleName: module.name });
            setIsQueued(true);
        } catch (queueError) {
            setError("Could not save request for offline processing.");
        } finally {
            setIsLoading(false);
        }
        return;
    }

    try {
      const result = await generateContent(prompt);
      setOutput(result);
      const parsed = parseOutput(result);
      setParsedOutput(parsed);
      if (usesLeft !== 'Unlimited') decrementUse();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

  const formatContent = (text: string): { __html: string } => {
    if (!text) return { __html: '' };
    return { __html: text
        .replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
        .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
        .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
        .replace(/\n/g, '<br />')
        .replace(/<br \/>\s*<li/g, '<li')
    };
  };
    
  const VersionCard: React.FC<{ version: TranslationVersion }> = ({ version }) => {
    const [copySuccess, setCopySuccess] = useState(false);
    const handleCopy = () => {
        if (!version.content) return;
        navigator.clipboard.writeText(version.content).then(() => {
            setCopySuccess(true);
            setTimeout(() => setCopySuccess(false), 2000);
        });
    };

    if (!version.content) return null;
    return (
        <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative space-y-4">
            <div className="flex justify-between items-start">
                <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{version.title}</h4>
                 <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${version.title}`}>
                    {copySuccess ? 'Copied!' : <CopyIcon className="h-5 w-5" />}
                </button>
            </div>
            <p className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed">{version.content}</p>
            <Accordion title="Analysis & Adaptations">
                <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(`**Translation Analysis:**\n${version.analysis}\n\n**Key Adaptations:**\n${version.adaptations}`)} />
            </Accordion>
        </div>
    );
  };

  const commonTextareaClasses = "w-full min-h-[200px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
  const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
  const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

  return (
      <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
          <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          <div className="space-y-4">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Enter text to translate..."
              className={commonTextareaClasses}
            />
            
            <div>
              <label htmlFor="targetLanguage" className={commonLabelClasses}>Target Language</label>
              <input 
                id="targetLanguage"
                type="text" 
                value={targetLanguage} 
                onChange={e => setTargetLanguage(e.target.value)} 
                placeholder="e.g., Brazilian Portuguese" 
                className={commonInputClasses} />
            </div>

            <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                <button onClick={() => setShowAdvanced(!showAdvanced)} className="w-full flex justify-between items-center" aria-expanded={showAdvanced}>
                    <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Advanced Options</h3>
                    <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
                </button>
                {showAdvanced && (
                    <div className="pt-4 border-t border-base-300 dark:border-d-base-300 space-y-4 animate-fade-in">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="sourceLang" className={commonLabelClasses}>Source Language</label>
                                <input id="sourceLang" type="text" value={sourceLanguage} onChange={e => setSourceLanguage(e.target.value)} className={commonInputClasses} />
                            </div>
                            <div>
                                <label htmlFor="dialect" className={commonLabelClasses}>Regional Dialect (optional)</label>
                                <input id="dialect" type="text" value={regionalDialect} onChange={e => setRegionalDialect(e.target.value)} placeholder="e.g., Mexican, Québécois" className={commonInputClasses} />
                            </div>
                            <div>
                                <label htmlFor="contentType" className={commonLabelClasses}>Content Type</label>
                                <select id="contentType" value={contentType} onChange={e => setContentType(e.target.value as ContentType)} className={commonInputClasses}>
                                    <option>Business</option><option>Formal</option><option>Casual</option><option>Technical</option><option>Creative</option>
                                </select>
                            </div>
                             <div>
                                <label htmlFor="tonePreservation" className={commonLabelClasses}>Tone Handling</label>
                                <select id="tonePreservation" value={tonePreservation} onChange={e => setTonePreservation(e.target.value as TonePreservation)} className={commonInputClasses}>
                                    <option>Adapt</option><option>Preserve</option><option>Ignore</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label htmlFor="culturalContext" className={commonLabelClasses}>Cultural Context (optional)</label>
                            <input id="culturalContext" type="text" value={culturalContext} onChange={e => setCulturalContext(e.target.value)} placeholder="e.g., Addressing a senior executive" className={commonInputClasses} />
                        </div>
                    </div>
                )}
            </div>
            
            <button
              onClick={handleGenerate}
              disabled={isLoading || !canGenerate}
              className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300"
            >
              {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
              {isLoading ? 'Translating...' : (isQueued ? 'Request Queued' : 'Translate')}
            </button>
            {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
            {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please provide text to translate.</p>}
          </div>

          <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
            {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Generating expert translation...</p>}
            {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your translation report will appear here.</p>}
            {parsedOutput ? (
                <div className="space-y-6">
                    <div className="space-y-4">
                        <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Translation Results</h3>
                        {parsedOutput.versions.map((version, index) => <VersionCard key={index} version={version} />)}
                    </div>
                    <div className="space-y-2 pt-4">
                        <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Analysis & Insights</h3>
                        <Accordion title={<>📊 <span className="ml-2">Quality Metrics</span></>} defaultOpen={true}>
                            <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.qualityMetrics)}/>
                        </Accordion>
                        <Accordion title={<>🔍 <span className="ml-2">Cultural Notes</span></>}>
                            <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.culturalNotes)}/>
                        </Accordion>
                        <Accordion title={<>🌐 <span className="ml-2">Regional Variations</span></>}>
                            <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.regionalVariations)}/>
                        </Accordion>
                    </div>
                </div>
            ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
          </div>
        </div>
        {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
      </div>
  );
};

export default GlobalTranslatorView;