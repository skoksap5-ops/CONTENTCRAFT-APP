import React from 'react';
import { signOut, firebaseInitialized } from '../services/firebase';
import { useLanguage } from '../hooks/useLanguage';
import type { View } from '../types';

// Icons
import StarOutlineIcon from './icons/StarOutlineIcon';
import ShareIcon from './icons/ShareIcon';
import HelpIcon from './icons/HelpIcon';
import ArrowLeftOnRectangleIcon from './icons/ArrowLeftOnRectangleIcon';
import UserCircleIcon from './icons/UserCircleIcon';
import CrownIcon from './icons/CrownIcon';
import CreditCardIcon from './icons/CreditCardIcon';
import LanguageIcon from './icons/LanguageIcon';
import PaintBrushIcon from './icons/PaintBrushIcon';
import CharacterSpacingIcon from './icons/CharacterSpacingIcon';
import ShieldIcon from './icons/ShieldIcon';
import DocumentTextIcon from './icons/DocumentTextIcon';
import SparklesIcon from './icons/settings/SparklesIcon';


interface ProfileViewProps {
  usesLeft: number | 'Unlimited';
  totalUses: number | 'Unlimited';
  isPremium: boolean;
  setView: (view: View) => void;
}

const ProfileSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <section>
        <h2 className="text-sm font-semibold text-text-secondary dark:text-d-text-secondary uppercase tracking-wider mb-3 px-1">{title}</h2>
        <div className="bg-base-200 dark:bg-d-base-200 rounded-xl shadow-sm divide-y divide-base-300 dark:divide-d-base-300">
            {children}
        </div>
    </section>
);

const ProfileItem: React.FC<{ icon: React.ReactNode; title: string; subtitle?: string; onClick?: () => void; action?: 'navigate' | 'action'; }> = ({ icon, title, subtitle, onClick, action = 'navigate' }) => (
    <button onClick={onClick} className="w-full flex items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors first:rounded-t-xl last:rounded-b-xl focus:outline-none focus:ring-2 focus:ring-inset focus:ring-brand-primary">
        <div className="mr-4 text-text-secondary dark:text-d-text-secondary">{icon}</div>
        <div className="flex-grow">
            <h3 className="font-semibold text-text-primary dark:text-d-text-primary">{title}</h3>
            {subtitle && <p className="text-sm text-text-secondary dark:text-d-text-secondary">{subtitle}</p>}
        </div>
         {action === 'navigate' && (<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5 text-base-300 dark:text-d-base-300">
            <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
        </svg>)}
    </button>
);


const ProfileView: React.FC<ProfileViewProps> = ({ usesLeft, isPremium, setView }) => {
    const { t } = useLanguage();
    
    const handleSignOut = async () => {
        if (!firebaseInitialized) {
            alert("Sign out is disabled because the application is not connected to a user database (Firebase is not configured).");
            return;
        }
        try {
            await signOut();
        } catch (error) {
            console.error("Error signing out:", error);
            alert("Failed to sign out. Please try again.");
        }
    };
    
    return (
        <div className="max-w-4xl mx-auto flex flex-col gap-8 animate-fade-in -mt-24">
            <header className="p-4 sm:p-6 lg:p-8 bg-gradient-to-br from-brand-primary to-accent text-white rounded-3xl shadow-lg">
                <div className="flex items-center pt-16 pb-8">
                    <UserCircleIcon className="h-20 w-20 text-white/80" />
                    <div className="ml-4">
                        <h1 className="text-2xl font-bold font-heading">Saša Petrić</h1>
                        <p className="opacity-90">Mycologist and mushroom grower</p>
                    </div>
                </div>
            </header>

            <div className="px-4 sm:px-6 lg:px-8 space-y-10 -mt-16">
                 <section>
                     <h2 className="text-sm font-semibold text-text-secondary dark:text-d-text-secondary uppercase tracking-wider mb-3 px-1">{t('yourStats')}</h2>
                     <div className="grid grid-cols-2 gap-4">
                         <div className="bg-base-200 dark:bg-d-base-200 p-5 rounded-xl text-center shadow-sm border border-base-300 dark:border-d-base-300">
                             <p className="text-4xl font-bold text-indigo-400">Unlimited</p>
                             <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1">{t('totalGenerations')}</p>
                         </div>
                         <div className="bg-base-200 dark:bg-d-base-200 p-5 rounded-xl text-center shadow-sm border border-base-300 dark:border-d-base-300">
                             <p className="text-4xl font-bold text-green-400">{usesLeft}</p>
                             <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1">{t('usesRemaining')}</p>
                         </div>
                     </div>
                 </section>

                <ProfileSection title="Account">
                    {isPremium ? (
                        <ProfileItem icon={<CreditCardIcon className="h-6 w-6"/>} title="Manage Subscription" subtitle="View your Craft Pro plan" onClick={() => setView('subscription')} />
                    ) : (
                        <ProfileItem icon={<CrownIcon className="h-6 w-6 text-yellow-500"/>} title={t('upgradePro')} subtitle={t('upgradeProSub')} onClick={() => setView('upgrade')} />
                    )}
                    <ProfileItem 
                        icon={<ArrowLeftOnRectangleIcon className="h-6 w-6"/>} 
                        title={t('signOut')}
                        subtitle={t('signOutSub')}
                        onClick={handleSignOut}
                        action="action"
                    />
                </ProfileSection>

                <ProfileSection title="Preferences">
                    <ProfileItem icon={<LanguageIcon className="h-6 w-6"/>} title={t('language')} subtitle="Set your preferred language" onClick={() => setView('language')} />
                    <ProfileItem icon={<PaintBrushIcon className="h-6 w-6"/>} title="Appearance" subtitle="Customize theme and appearance" onClick={() => setView('settings')} />
                    <ProfileItem icon={<CharacterSpacingIcon className="h-6 w-6"/>} title={t('fontSize')} subtitle="Adjust text size for readability" onClick={() => setView('fontSize')} />
                </ProfileSection>

                <ProfileSection title="Support & Legal">
                    <ProfileItem icon={<HelpIcon className="h-6 w-6" />} title={t('helpFaq')} subtitle={t('helpFaqSub')} onClick={() => setView('helpFromProfile')} />
                    <ProfileItem icon={<ShieldIcon className="h-6 w-6"/>} title={t('privacyPolicy')} subtitle="Read our privacy policy" onClick={() => setView('privacy')} />
                    <ProfileItem icon={<DocumentTextIcon className="h-6 w-6"/>} title={t('termsOfService')} subtitle="Review our terms of service" onClick={() => setView('terms')} />
                </ProfileSection>
                
                <ProfileSection title="Share & Earn">
                    <ProfileItem icon={<StarOutlineIcon className="h-6 w-6" />} title={t('rateApp')} subtitle={t('rateAppSub')} onClick={() => window.open('https://play.google.com/store/apps/details?id=com.novasky.contentcraft', '_blank', 'noopener,noreferrer')} />
                    <ProfileItem icon={<ShareIcon className="h-6 w-6" />} title={t('shareApp')} subtitle="Earn free credits by sharing" onClick={() => setView('share')} />
                </ProfileSection>

                <footer className="text-center text-xs text-text-secondary dark:text-d-text-secondary pb-8">
                    <p>ContentCraft v3.0</p>
                </footer>
            </div>
        </div>
    );
};
export default ProfileView;