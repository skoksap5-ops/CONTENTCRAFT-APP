import React, { useState } from 'react';
import { useAIAnalysis } from '../hooks/useAIAnalysis';
import type { PurposeData, TemplateData, AIAnalysisData, GenerationResponse } from './ai-template-builder/types';
import PurposeDefinition from './ai-template-builder/PurposeDefinition';
import AIAnalysis from './ai-template-builder/AIAnalysis';
import TemplateGenerator from './ai-template-builder/TemplateGenerator';
import { TemplateOptimizer } from './ai-template-builder/TemplateOptimizer';
import { PersonalizationEngine } from './ai-template-builder/PersonalizationEngine';
import type { Module } from '../types';


interface AITemplateBuilderViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

const AITemplateBuilderView: React.FC<AITemplateBuilderViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [userInput, setUserInput] = useState<{purpose?: PurposeData, analysis?: AIAnalysisData}>({});
  const [generatedTemplatesResponse, setGeneratedTemplatesResponse] = useState<GenerationResponse | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<TemplateData | null>(null);

  const { analyze, generate, optimize, personalize, isLoading, error } = useAIAnalysis(userId, module.id, module.name, usesLeft, decrementUse);

  const steps = [
    { id: 1, title: 'Define Purpose' },
    { id: 2, title: 'AI Analysis' },
    { id: 3, title: 'Generate' },
    { id: 4, title: 'Optimize' },
    { id: 5, title: 'Personalize' }
  ];

  const handlePurposeSubmit = async (purposeData: PurposeData) => {
    const newUserInput = { ...userInput, purpose: purposeData };
    setUserInput(newUserInput);
    setCurrentStep(2);
    try {
        const analysis = await analyze(purposeData);
        if (analysis) {
            setUserInput((prev: any) => ({ ...prev, analysis }));
        } else if (usesLeft !== 'Unlimited' && usesLeft <=0) {
             setCurrentStep(1); // Go back if no uses left
        }
    } catch (e) {
        console.error(e);
        setCurrentStep(1); // Go back if analysis fails
    }
  };

  const handleGenerateTemplate = async () => {
    if (!userInput.purpose || !userInput.analysis) return;
    setCurrentStep(3);
    try {
        const templateResponse = await generate({purpose: userInput.purpose, analysis: userInput.analysis});
        if(templateResponse) {
            setGeneratedTemplatesResponse(templateResponse);
        } else if (usesLeft !== 'Unlimited' && usesLeft <=0) {
             setCurrentStep(2); 
        }
    } catch (e) {
        console.error(e);
        setCurrentStep(2); // Go back if generation fails
    }
  };

  const handleSelectTemplateAndProceed = (template: TemplateData) => {
    setSelectedTemplate(template);
    setCurrentStep(4);
  };
  
  const handleOptimizeTemplate = async (optimizationGoals: { length: string; tone: string; }) => {
    if (!selectedTemplate) return;
    try {
        const optimized = await optimize(selectedTemplate, optimizationGoals);
        if(optimized) {
            setSelectedTemplate(optimized);
            setCurrentStep(5);
        }
    } catch (e) {
        console.error(e);
        // stay on step 4 if optimization fails
    }
  };

  const handlePersonalizeTemplate = async (persona: string) => {
     if (!selectedTemplate) return;
     try {
        const personalized = await personalize(selectedTemplate, { persona });
        if(personalized) {
            setSelectedTemplate(personalized);
        }
     } catch (e) {
        console.error(e);
        // stay on step 5 if personalization fails
     }
  };

  const renderContent = () => {
    switch (currentStep) {
        case 1:
            return <PurposeDefinition onSubmit={handlePurposeSubmit} isLoading={isLoading} />;
        case 2:
            return <AIAnalysis analysis={userInput.analysis} onGenerate={handleGenerateTemplate} isLoading={isLoading && !userInput.analysis} />;
        case 3:
            return <TemplateGenerator 
                        generationResponse={generatedTemplatesResponse} 
                        onSelectTemplate={handleSelectTemplateAndProceed} 
                        isLoading={isLoading && !generatedTemplatesResponse} 
                    />;
        case 4:
            return <TemplateOptimizer template={selectedTemplate} onOptimize={handleOptimizeTemplate} isLoading={isLoading} />;
        case 5:
            return <PersonalizationEngine template={selectedTemplate} onPersonalize={handlePersonalizeTemplate} isLoading={isLoading} />;
        default:
            return null;
    }
  }


  return (
    <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
        <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
      </div>
      
      {/* Progress Stepper */}
      <div className="w-full px-4 sm:px-0">
          <div className="flex items-center">
              {steps.map((step, index) => (
                  <React.Fragment key={step.id}>
                      <div className="flex flex-col items-center">
                          <button
                            onClick={() => { if (step.id < currentStep && !isLoading) setCurrentStep(step.id) }}
                            className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors duration-300 ${currentStep >= step.id ? 'bg-brand-primary text-white' : 'bg-base-300 dark:bg-d-base-300 text-text-secondary dark:text-d-text-secondary'} ${step.id < currentStep && !isLoading ? 'cursor-pointer' : 'cursor-default'}`}
                            disabled={step.id >= currentStep || isLoading}
                          >
                              {step.id}
                          </button>
                          <p className={`mt-2 text-xs text-center font-semibold ${currentStep >= step.id ? 'text-text-primary dark:text-d-text-primary' : 'text-text-secondary dark:text-d-text-secondary'}`}>{step.title}</p>
                      </div>
                      {index < steps.length - 1 && (
                          <div className={`flex-1 h-1 transition-colors duration-300 -mt-6 mx-2 ${currentStep > step.id ? 'bg-brand-primary' : 'bg-base-300 dark:bg-d-base-300'}`}></div>
                      )}
                  </React.Fragment>
              ))}
          </div>
      </div>
      
      <div className="bg-base-200/50 dark:bg-d-base-200/50 p-6 rounded-xl border border-base-300 dark:border-d-base-300 min-h-[300px]">
        {renderContent()}
      </div>

       {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}

    </div>
  );
};

export default AITemplateBuilderView;
