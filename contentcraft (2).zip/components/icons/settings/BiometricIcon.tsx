import React from 'react';

const BiometricIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.864 4.243A7.5 7.5 0 0119.5 10.5c0 2.92-.556 5.709-1.588 8.26l-1.42 1.42-1.42-1.42A6.75 6.75 0 0018 10.5a6.75 6.75 0 00-6.75-6.75c-1.78 0-3.418.67-4.66 1.76l-1.42 1.42-1.42-1.42A7.5 7.5 0 017.864 4.243z" />
  </svg>
);

export default BiometricIcon;