import React from 'react';

const NarrativeSoftenerIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 4.5a.75.75 0 01.75-.75h4.5a.75.75 0 010 1.5h-4.5a.75.75 0 01-.75-.75z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9a.75.75 0 01.75-.75h12.5a.75.75 0 010 1.5H4.5a.75.75 0 01-.75-.75z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5a.75.75 0 01.75-.75h15.5a.75.75 0 010 1.5H4.5a.75.75 0 01-.75-.75z" />
         <path strokeLinecap="round" strokeLinejoin="round" d="M3 19.5c6.333-3 12.667-3 19 0" />
    </svg>
);

export default NarrativeSoftenerIcon;
