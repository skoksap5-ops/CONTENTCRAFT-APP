import React from 'react';

const BroomIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-3.375m0 0V3.375M13.5 17.625c-3.15 0-6 .75-6 2.25s2.85 2.25 6 2.25c3.15 0 6-.75 6-2.25s-2.85-2.25-6-2.25z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 3.375L6 10.5" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 3.375v3.375" />
    </svg>
);

export default BroomIcon;
