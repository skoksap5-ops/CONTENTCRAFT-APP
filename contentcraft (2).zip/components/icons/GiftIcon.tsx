import React from 'react';

const GiftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.25v8.25a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 19.5v-8.25M12 4.875A3.75 3.75 0 006.75 8.625H17.25A3.75 3.75 0 0012 4.875z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 12.75c-2.485 0-4.5-2.015-4.5-4.5s2.015-4.5 4.5-4.5 4.5 2.015 4.5 4.5-2.015 4.5-4.5 4.5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 11.25h16.5" />
  </svg>
);

export default GiftIcon;