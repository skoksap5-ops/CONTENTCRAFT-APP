import React from 'react';

const AiContentPerformanceIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 009-9H3a9 9 0 009 9z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v1.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M18.364 5.636l-1.06 1.06" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 12h-1.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M5.636 5.636l1.06 1.06" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 12h1.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 15.75L14.25 12" />
  </svg>
);

export default AiContentPerformanceIcon;
