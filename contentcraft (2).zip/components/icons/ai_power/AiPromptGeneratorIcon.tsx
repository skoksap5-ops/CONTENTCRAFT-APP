import React from 'react';

const AiPromptGeneratorIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 15L12 18.75 15.75 15m-7.5-6L12 5.25 15.75 9" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193l-3.721.465c-.934.117-1.859.435-2.673.931l-4.218 2.812c-.75.501-1.771-.217-1.771-1.124V14.25M3.75 14.25v-4.526c0-.97.606-1.826 1.5-2.181l3.72-1.468c.934-.368 1.859-.552 2.673-.552l4.218 0" />
  </svg>
);

export default AiPromptGeneratorIcon;
