import React from 'react';

const TikTokIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 28.3 28.3" fill="white" xmlns="http://www.w3.org/2000/svg" {...props}>
        <path d="M17.4 5.3v10.1c0 3-1.6 4.7-4.4 4.7-2.8 0-4.3-1.7-4.3-4.5 0-2.8 2.5-4.5 5.5-4.5h.3V5.1c-3 .1-5.7 2-5.7 5.8 0 4.1 2.7 6.3 6.3 6.3 3.6 0 6.1-2.2 6.1-6.1V5.3c1.4-1.6 2.8-1.7 3.3-1.7V0c-.3 0-1.8.2-3.4 1.8z" />
    </svg>
);

export default TikTokIcon;
