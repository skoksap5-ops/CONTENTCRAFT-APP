import React from 'react';

const MicrosoftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path fill="#f25022" d="M11.4 11.4H2.5V2.5h8.9v8.9z"/>
    <path fill="#7fba00" d="M21.5 11.4h-8.9V2.5h8.9v8.9z"/>
    <path fill="#00a4ef" d="M11.4 21.5H2.5v-8.9h8.9v8.9z"/>
    <path fill="#ffb900" d="M21.5 21.5h-8.9v-8.9h8.9v8.9z"/>
  </svg>
);

export default MicrosoftIcon;