import React from 'react';

const BufferIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M22.5,8.5h-7V0h-7v8.5H1.5V15h7v8.5h7V15h7V8.5z M14.5,22.5h-5V15h5V22.5z M14.5,7.5h-5V1h5V7.5z"/>
  </svg>
);

export default BufferIcon;