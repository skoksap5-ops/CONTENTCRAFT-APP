import React from 'react';

const TumblrIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M16.2,22c-3.4,0-6.2-2.8-6.2-6.2V9.8h4.4v5.3c0,1,0.8,1.8,1.8,1.8s1.8-0.8,1.8-1.8v-9h4.4v9 C22.4,19.2,19.6,22,16.2,22z M7.8,9.8H3.4V6.1c0-1.1,0.9-2,2-2s2,0.9,2,2V9.8z"/>
  </svg>
);

export default TumblrIcon;