import React from 'react';

const MediumIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" {...props}>
    <path d="M7.4 6.3c0-1.7 1.3-3 3-3h3.5c1.6 0 3 1.3 3 3v11.5c0 1.6-1.4 3-3 3h-3.5c-1.7 0-3-1.4-3-3V6.3z" />
    <path d="M17.3 6.3c0-1.1.9-2 2-2h.8c1.1 0 2 .9 2 2v10.5c0 1.1-.9 2-2 2h-.8c-1.1 0-2-.9-2-2V6.3zM4.5 7.2c0-.5.4-1 .9-1h.8c.5 0 .9.4.9 1v8.7c0 .5-.4 1-.9 1h-.8c-.5 0-.9-.4-.9-1V7.2z" />
  </svg>
);

export default MediumIcon;