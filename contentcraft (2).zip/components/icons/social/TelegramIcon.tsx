import React from 'react';

const TelegramIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M22,3.2l-2.7,12.9c-0.2,0.9-0.7,1.1-1.5,0.7L12,13.1l-1.9,1.8c-0.2,0.2-0.4,0.4-0.8,0.4l0.3-2.9l5.8-5.3 C16,6.6,15.5,6.4,15,6.7l-7.2,4.5l-2.8-0.9C4.1,10.1,3.9,9.4,5,9.2l15.3-5.9C21.4,2.9,22.2,3.1,22,3.2z"/>
  </svg>
);

export default TelegramIcon;