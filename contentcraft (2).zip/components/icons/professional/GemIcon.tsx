import React from 'react';

const GemIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.33l-5.87-3.41L12 3.67l5.87 11.25L12 18.33zM12 21l-7-4.07v-8.14L12 2l7 6.79v8.14L12 21z" />
  </svg>
);

export default GemIcon;
