import React from 'react';

const GamepadIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 12c0-3.313-2.687-6-6-6H10.5c-3.313 0-6 2.687-6 6v3c0 3.313 2.687 6 6 6h3c3.313 0 6-2.687 6-6v-3z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 10.5h-3m3 3h-3m3-1.5v3" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 12.75a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
    </svg>
);

export default GamepadIcon;
