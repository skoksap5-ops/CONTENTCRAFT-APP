import React from 'react';

const BriefcaseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 14.15v4.075c0 1.3-1.05 2.325-2.325 2.325H6.075A2.25 2.25 0 013.75 18.225v-4.075m16.5 0v-3.75a2.25 2.25 0 00-2.25-2.25h-1.5a2.25 2.25 0 00-2.25 2.25v3.75m-1.5-1.5h-6a1.5 1.5 0 00-1.5 1.5v3.75a1.5 1.5 0 001.5 1.5h6a1.5 1.5 0 001.5-1.5v-3.75a1.5 1.5 0 00-1.5-1.5zM12 6.75v.75m0 0a1.5 1.5 0 00-1.5 1.5v3.75a1.5 1.5 0 001.5 1.5h.008a1.5 1.5 0 001.5-1.5v-3.75a1.5 1.5 0 00-1.5-1.5H12z" />
  </svg>
);

export default BriefcaseIcon;