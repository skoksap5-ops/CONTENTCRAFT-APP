import React from 'react';

const HeaderCubeIcon: React.FC = () => (
  <div className="header-cube-container">
    <div className="header-cube">
      <div className="header-cube-face header-face-front">
        <span className="header-cube-face-text">CONTENT<br/>CRAFT</span>
      </div>
      <div className="header-cube-face header-face-right"></div>
      <div className="header-cube-face header-face-top"></div>
    </div>
  </div>
);

export default HeaderCubeIcon;
