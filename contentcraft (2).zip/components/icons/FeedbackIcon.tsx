import React from 'react';

const FeedbackIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193l-3.721.465c-.934.117-1.859.435-2.673.931l-4.218 2.812c-.75.501-1.771-.217-1.771-1.124V14.25M17.25 7.5a4.5 4.5 0 01-9 0 4.5 4.5 0 019 0zm-4.5 3.75a.75.75 0 000-1.5m-3 1.5a.75.75 0 01.75-.75h3a.75.75 0 010 1.5h-3a.75.75 0 01-.75-.75z" />
  </svg>
);

export default FeedbackIcon;
