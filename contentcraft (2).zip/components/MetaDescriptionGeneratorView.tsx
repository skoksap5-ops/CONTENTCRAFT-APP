import React, { useState, useCallback, useEffect } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { saveGeneration } from '../services/historyService';
import { addToQueue } from '../services/offlineService';
import { useFeedback } from '../hooks/useFeedback';
import { Type } from '@google/genai';

// Icons
import SearchIcon from './icons/SearchIcon';
import EyeIcon from './icons/settings/EyeIcon';
import SparklesIcon from './icons/settings/SparklesIcon';
import CopyIcon from './icons/CopyIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type DescriptionStyle = 'persuasive' | 'informative' | 'question' | 'benefit-driven';

interface GeneratedDescription {
    style: string;
    content: string;
    character_count: number;
}

interface ParsedOutput {
    variations: GeneratedDescription[];
}

const metaDescriptionsSchema = {
  type: Type.OBJECT,
  properties: {
    variations: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          style: { type: Type.STRING, description: "The style of the description (e.g., 'Persuasive', 'Informative')." },
          content: { type: Type.STRING, description: "The meta description text, optimized for 155-160 characters." },
          character_count: { type: Type.NUMBER },
        },
        required: ['style', 'content', 'character_count']
      }
    }
  },
  required: ['variations']
};

const MetaDescriptionGeneratorView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const { playClick, playSuccess } = useFeedback();

    // Form state
    const [pageTitle, setPageTitle] = useState('');
    const [pageContent, setPageContent] = useState('');
    const [targetKeywords, setTargetKeywords] = useState('');
    const [descriptionStyle, setDescriptionStyle] = useState<DescriptionStyle>('persuasive');
    const [descriptionTone, setDescriptionTone] = useState('professional');
    const [includeCta, setIncludeCta] = useState(true);

    // Output state
    const [generatedDescriptions, setGeneratedDescriptions] = useState<GeneratedDescription[]>([]);
    const [previewDescription, setPreviewDescription] = useState('Your meta description will appear here. A well-crafted description improves click-through rates and tells users what your page is about.');
    const [previewTitle, setPreviewTitle] = useState('Your Page Title Will Appear Here');

    // API state
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [copySuccess, setCopySuccess] = useState<string | null>(null);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && pageTitle.trim() && pageContent.trim();

    useEffect(() => {
        setPreviewTitle(pageTitle || 'Your Page Title Will Appear Here');
    }, [pageTitle]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        playClick();
        setIsLoading(true);
        setError(null);
        setGeneratedDescriptions([]);
        setIsQueued(false);

        const prompt = `You are an expert SEO copywriter specializing in creating high-CTR meta descriptions. Based on the user's input, generate a set of 4 distinct meta descriptions.

        **INPUT:**
        - Page Title: ${pageTitle}
        - Page Content Summary: ${pageContent}
        - Target Keywords: ${targetKeywords}
        - Tone of Voice: ${descriptionTone}
        - Include Call-to-Action: ${includeCta}

        **INSTRUCTIONS:**
        1.  Generate 4 meta description variations, one for each of the following styles: 'Persuasive', 'Informative', 'Question-Based', and 'Benefit-Driven'.
        2.  Adhere to all the user's requirements (tone, CTA, keywords).
        3.  Optimize each description to be between 155 and 160 characters.
        4.  Ensure each description is compelling and encourages clicks.
        5.  Your response MUST be a valid JSON object conforming to the provided schema.`;

        if (!navigator.onLine) {
            try {
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: 'application/json',
                responseSchema: metaDescriptionsSchema as any,
            });
            const parsed: ParsedOutput = JSON.parse(result);
            setGeneratedDescriptions(parsed.variations);
            setPreviewDescription(parsed.variations[0]?.content || 'No description generated.');
            playSuccess();

            if (userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt.split('**INSTRUCTIONS**')[0], // Save only the input part
                    output: parsed.variations.map(v => v.content).join('\n---\n'),
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();

        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, pageTitle, pageContent, targetKeywords, descriptionTone, includeCta, playClick, playSuccess, module.id, module.name, userId, usesLeft, decrementUse]);

    const getCharCounterClass = () => {
        const len = previewDescription.length;
        if (len >= 150 && len <= 160) return 'optimal';
        if (len > 160 && len <= 180) return 'warning';
        if (len > 180) return 'danger';
        return '';
    };

    const styleOptions: { id: DescriptionStyle; name: string; icon: string; desc: string }[] = [
        { id: 'persuasive', name: 'Persuasive', icon: '🎯', desc: 'CTR focused' },
        { id: 'informative', name: 'Informative', icon: 'ℹ️', desc: 'Content summary' },
        { id: 'question', name: 'Question', icon: '❓', desc: 'Engage users' },
        { id: 'benefit-driven', name: 'Benefit-driven', icon: '⭐', desc: 'Value focused' },
    ];
    
    return (
        <div className="meta-desc-module max-w-7xl mx-auto flex flex-col gap-8">
            <header className="text-center">
                <h1 className="text-3xl font-bold font-heading">{module.name}</h1>
                <p className="subtitle text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <section className="creation-section bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-4">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-seo-green to-brand-secondary rounded-xl flex items-center justify-center text-white text-2xl">
                            <SearchIcon className="h-6 w-6" />
                        </div>
                        <h2 className="text-2xl font-bold font-heading">Generate Descriptions</h2>
                    </div>

                    <div className="form-group space-y-4">
                         <input type="text" value={pageTitle} onChange={(e) => setPageTitle(e.target.value)} placeholder="Enter your page title..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                         <textarea value={pageContent} onChange={(e) => setPageContent(e.target.value)} placeholder="Paste your page content or describe what the page is about..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[120px] resize-y"></textarea>
                         <input type="text" value={targetKeywords} onChange={(e) => setTargetKeywords(e.target.value)} placeholder="Target Keywords (comma separated)..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                    </div>

                    <div className="form-group">
                        <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">Description Style</label>
                        <div className="grid grid-cols-2 gap-2">
                            {styleOptions.map(opt => (
                                <button key={opt.id} onClick={() => setDescriptionStyle(opt.id)} className={`option-card p-3 rounded-lg border-2 text-center transition-all duration-200 bg-base-100 dark:bg-d-base-100 ${descriptionStyle === opt.id ? 'selected' : 'border-transparent'}`}>
                                    <div className="option-icon text-xl">{opt.icon}</div>
                                    <div className="option-name text-sm font-semibold">{opt.name}</div>
                                    <div className="option-desc text-xs">{opt.desc}</div>
                                </button>
                            ))}
                        </div>
                    </div>
                     <div className="form-group">
                        <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">Tone of Voice</label>
                        <select value={descriptionTone} onChange={e => setDescriptionTone(e.target.value)} className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100">
                             <option value="professional">Professional</option>
                             <option value="friendly">Friendly & Casual</option>
                             <option value="authoritative">Authoritative</option>
                             <option value="enthusiastic">Enthusiastic</option>
                             <option value="urgent">Urgent</option>
                        </select>
                    </div>

                    <div className="form-group flex items-center gap-4">
                        <label className="flex items-center gap-2 text-sm">
                            <input type="checkbox" checked={includeCta} onChange={e => setIncludeCta(e.target.checked)} className="rounded"/> Include CTA
                        </label>
                    </div>

                     <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="btn btn-primary btn-block w-full p-4 rounded-xl text-white font-bold text-lg flex items-center justify-center gap-2">
                        {isLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/50 border-t-white rounded-full"></span> : <SparklesIcon className="h-6 w-6" />}
                        {isLoading ? 'Generating...' : 'Generate Descriptions'}
                    </button>
                    {error && <div className="text-center bg-error/20 text-error p-2 rounded-lg text-sm">{error}</div>}
                </section>
                 <section className="preview-section bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-4">
                     <div className="flex items-center gap-3 mb-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-seo-green to-brand-secondary rounded-xl flex items-center justify-center text-white text-2xl">
                           <EyeIcon className="h-6 w-6"/>
                        </div>
                        <h2 className="text-2xl font-bold font-heading">Search Result Preview</h2>
                    </div>

                    <div className="preview-container bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg p-4">
                         <div className="search-preview bg-base-200 dark:bg-d-base-200 rounded p-4">
                             <div className="search-result">
                                <div className="search-url text-sm truncate">https://www.example.com › ...</div>
                                <div className="search-title text-xl font-medium truncate">{previewTitle}</div>
                                <div className="search-description text-sm mt-1">{previewDescription}</div>
                            </div>
                        </div>
                         <div className={`char-counter text-sm font-medium mt-2 text-right ${getCharCounterClass()}`}>
                            <span>{previewDescription.length}</span>/160 characters
                        </div>
                    </div>
                    
                    <div className="results-grid space-y-3">
                         {generatedDescriptions.map((desc, index) => (
                             <div key={index} className="result-card bg-base-100 dark:bg-d-base-100 p-4 rounded-lg border border-base-300 dark:border-d-base-300">
                                 <div className="flex justify-between items-start mb-2">
                                     <div className="result-type text-xs font-bold uppercase text-white px-2 py-0.5 rounded-full">{desc.style}</div>
                                     <button onClick={() => setPreviewDescription(desc.content)} className="btn-sm px-3 py-1 text-xs font-semibold bg-brand-primary text-white rounded-md">Use This</button>
                                 </div>
                                 <p className="result-content text-sm">{desc.content}</p>
                                 <div className="result-stats text-xs text-text-secondary dark:text-d-text-secondary">{desc.character_count} characters</div>
                             </div>
                         ))}
                    </div>
                </section>
            </div>
        </div>
    );
};

export default MetaDescriptionGeneratorView;
