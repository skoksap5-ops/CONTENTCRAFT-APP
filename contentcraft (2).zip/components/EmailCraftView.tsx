import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ToneSelector from './ToneSelector';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type EmailPurpose = 'Sales' | 'Networking' | 'Customer Service' | 'Follow-up' | 'Thank You' | 'Appointment' | 'Proposal' | 'Introduction';
type TargetAudience = 'Client' | 'Colleague' | 'Investor' | 'Recruiter' | 'Customer' | 'Partner';
type Relationship = 'First Contact' | 'Existing Relationship' | 'Close Colleague' | 'Formal';
type DesiredOutcome = 'Response' | 'Meeting' | 'Sale' | 'Information' | 'Approval';
type Urgency = 'Low' | 'Medium' | 'High' | 'Emergency';

const emailSchema = {
    type: Type.OBJECT,
    properties: {
        strategyAnalysis: { type: Type.STRING, description: "Markdown-formatted analysis of the email strategy." },
        versions: {
            type: Type.OBJECT,
            properties: {
                concise: { type: Type.STRING, description: "The full text of the concise email version, including subject line." },
                standard: { type: Type.STRING, description: "The full text of the standard email version, including subject line." },
                comprehensive: { type: Type.STRING, description: "The full text of the comprehensive email version, including subject line." }
            },
            required: ['concise', 'standard', 'comprehensive']
        },
        subjectLines: { type: Type.ARRAY, items: { type: Type.STRING }, description: "An array of 3-5 alternative subject line options." },
        strategicBreakdown: { type: Type.STRING, description: "A combined markdown string covering body copy, CTA, closing, and follow-up strategies." }
    },
    required: ['strategyAnalysis', 'versions', 'subjectLines', 'strategicBreakdown']
};

const EMAIL_CRAFT_PROMPT = `
You are an expert email communication strategist. Your primary task is to generate multiple complete and effective email drafts and provide a strategic analysis.

**INPUT:**
- Key Points/Core Message: {KEY_POINTS}
- Email Purpose: {EMAIL_PURPOSE}
- Target Audience: {TARGET_AUDIENCE}
- Relationship Level: {RELATIONSHIP}
- Desired Outcome: {DESIRED_OUTCOME}
- Urgency Level: {URGENCY}
- Tone: {SELECTED_TONES}

**INSTRUCTIONS:**
Your response MUST be a valid JSON object conforming to the provided schema.
- The 'versions' object MUST contain the complete, ready-to-use email drafts, including a subject line for each (e.g., "Subject: Your Subject Here\\n\\nDear..."). This is the most important part.
- Populate the markdown string fields ('strategyAnalysis', 'strategicBreakdown') with rich, formatted content.
- Provide 3-5 distinct options for the 'subjectLines' array.
`;

interface ParsedOutput {
    strategyAnalysis: string;
    versions: {
        concise: string;
        standard: string;
        comprehensive: string;
    };
    subjectLines: string[];
    strategicBreakdown: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const EmailCraftView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [keyPoints, setKeyPoints] = useState('');
    const [emailPurpose, setEmailPurpose] = useState<EmailPurpose>('Sales');
    const [targetAudience, setTargetAudience] = useState<TargetAudience>('Client');
    const [relationship, setRelationship] = useState<Relationship>('First Contact');
    const [desiredOutcome, setDesiredOutcome] = useState<DesiredOutcome>('Response');
    const [urgency, setUrgency] = useState<Urgency>('Medium');
    const [tones, setTones] = useState<string[]>([]);
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && keyPoints.trim();

    const getPrompt = useCallback(() => {
        return EMAIL_CRAFT_PROMPT
            .replace('{KEY_POINTS}', keyPoints)
            .replace('{EMAIL_PURPOSE}', emailPurpose)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{RELATIONSHIP}', relationship)
            .replace('{DESIRED_OUTCOME}', desiredOutcome)
            .replace('{URGENCY}', urgency)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [keyPoints, emailPurpose, targetAudience, relationship, desiredOutcome, urgency, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: emailSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
             if (!parsed.versions?.concise) {
                setError("The AI returned an incomplete response. Please try again.");
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/^###\s*(.*)/gm, '<h4 class="text-md font-semibold text-text-primary dark:text-d-text-primary mt-4 mb-2">$1</h4>')
            .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };
    
    const VersionCard: React.FC<{ title: string; content: string }> = ({ title, content }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!content) return;
            navigator.clipboard.writeText(content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!content) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative">
                <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{title}</h4>
                     <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${title}`}>
                        <CopyIcon className="h-5 w-5" />
                    </button>
                </div>
                <pre className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed whitespace-pre-wrap font-sans">{content}</pre>
                 {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={keyPoints} onChange={e => setKeyPoints(e.target.value)} placeholder="Enter key points or your core message..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Email Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Email Purpose</label>
                                <select value={emailPurpose} onChange={e => setEmailPurpose(e.target.value as EmailPurpose)} className={commonInputClasses}>
                                    <option>Sales</option><option>Networking</option><option>Customer Service</option><option>Follow-up</option><option>Thank You</option><option>Appointment</option><option>Proposal</option><option>Introduction</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Target Audience</label>
                                <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as TargetAudience)} className={commonInputClasses}>
                                    <option>Client</option><option>Colleague</option><option>Investor</option><option>Recruiter</option><option>Customer</option><option>Partner</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Relationship Level</label>
                                <select value={relationship} onChange={e => setRelationship(e.target.value as Relationship)} className={commonInputClasses}>
                                    <option>First Contact</option><option>Existing Relationship</option><option>Close Colleague</option><option>Formal</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Desired Outcome</label>
                                <select value={desiredOutcome} onChange={e => setDesiredOutcome(e.target.value as DesiredOutcome)} className={commonInputClasses}>
                                    <option>Response</option><option>Meeting</option><option>Sale</option><option>Information</option><option>Approval</option>
                                </select>
                            </div>
                            <div className="md:col-span-2">
                                <label className={commonLabelClasses}>Urgency</label>
                                <select value={urgency} onChange={e => setUrgency(e.target.value as Urgency)} className={commonInputClasses}>
                                    <option>Low</option><option>Medium</option><option>High</option><option>Emergency</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Crafting Email...' : (isQueued ? 'Request Queued' : 'Craft Email')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please provide the key points for your email.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Crafting your email suite...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your professionally crafted emails will appear here.</p>}
                    {error && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">An Error Occurred</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">{error}</p></div>}
                    {parsedOutput && (
                        <div className="space-y-6">
                            <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Multi-Format Email Versions</h3>
                                <VersionCard title="Concise Version" content={parsedOutput.versions.concise} />
                                <VersionCard title="Standard Version" content={parsedOutput.versions.standard} />
                                <VersionCard title="Comprehensive Version" content={parsedOutput.versions.comprehensive} />
                            </div>
                            <div className="space-y-2 pt-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Strategy & Insights</h3>
                                <Accordion title="📊 Email Strategy Analysis" defaultOpen={true}><div dangerouslySetInnerHTML={formatContent(parsedOutput.strategyAnalysis)}/></Accordion>
                                <Accordion title="💡 Subject Line Mastery"><ul className="list-disc list-inside p-2">{parsedOutput.subjectLines.map((s, i) => <li key={i}>{s}</li>)}</ul></Accordion>
                                <Accordion title="✍️ Strategic Breakdown"><div dangerouslySetInnerHTML={formatContent(parsedOutput.strategicBreakdown)}/></Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default EmailCraftView;