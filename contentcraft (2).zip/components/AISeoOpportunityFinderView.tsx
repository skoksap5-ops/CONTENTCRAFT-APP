import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import { Type } from '@google/genai';
import CloseIcon from './icons/CloseIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface KeywordOpportunity {
    term: string;
    search_volume: string;
    difficulty: 'low' | 'medium' | 'high';
    opportunity_score: number;
    cpc: number;
    competition: number;
    competitor_ranking?: string[];
}
interface CompetitorAnalysis {
    domain: string;
    domain_authority: number;
    keyword_count: number;
    content_gaps: { topic: string; volume: string }[];
}
interface ContentGap {
    topic: string;
    description: string;
    intent: 'informational' | 'commercial' | 'navigational' | 'transactional';
    priority: 'high' | 'medium' | 'low';
    search_volume: string;
    difficulty: number;
    competitor_count: number;
    top_competitors: string[];
    content_ideas?: string[];
}
interface OverallMetrics {
    total_opportunities: number;
    high_opportunity: number;
    estimated_traffic_value: string;
    opportunity_score: number;
    estimated_monthly_traffic: string;
    gap_keywords: number;
    content_opportunities: number;
}
interface AnalysisResult {
    keyword_opportunities: KeywordOpportunity[];
    competitor_analysis: CompetitorAnalysis[];
    content_gaps: ContentGap[];
    overall_metrics: OverallMetrics;
}

const seoOpportunitySchema = {
    type: Type.OBJECT,
    properties: {
        keyword_opportunities: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    term: { type: Type.STRING },
                    search_volume: { type: Type.STRING },
                    difficulty: { type: Type.STRING, enum: ['low', 'medium', 'high'] },
                    opportunity_score: { type: Type.NUMBER },
                    cpc: { type: Type.NUMBER },
                    competition: { type: Type.NUMBER },
                    competitor_ranking: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ['term', 'search_volume', 'difficulty', 'opportunity_score', 'cpc', 'competition']
            }
        },
        competitor_analysis: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    domain: { type: Type.STRING },
                    domain_authority: { type: Type.NUMBER },
                    keyword_count: { type: Type.NUMBER },
                    content_gaps: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                topic: { type: Type.STRING },
                                volume: { type: Type.STRING }
                            },
                            required: ['topic', 'volume']
                        }
                    }
                },
                required: ['domain', 'domain_authority', 'keyword_count', 'content_gaps']
            }
        },
        content_gaps: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    topic: { type: Type.STRING },
                    description: { type: Type.STRING },
                    intent: { type: Type.STRING, enum: ['informational', 'commercial', 'navigational', 'transactional'] },
                    priority: { type: Type.STRING, enum: ['high', 'medium', 'low'] },
                    search_volume: { type: Type.STRING },
                    difficulty: { type: Type.NUMBER },
                    competitor_count: { type: Type.NUMBER },
                    top_competitors: { type: Type.ARRAY, items: { type: Type.STRING } },
                    content_ideas: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ['topic', 'description', 'intent', 'priority', 'search_volume', 'difficulty', 'competitor_count', 'top_competitors']
            }
        },
        overall_metrics: {
            type: Type.OBJECT,
            properties: {
                total_opportunities: { type: Type.NUMBER },
                high_opportunity: { type: Type.NUMBER },
                estimated_traffic_value: { type: Type.STRING },
                opportunity_score: { type: Type.NUMBER },
                estimated_monthly_traffic: { type: Type.STRING },
                gap_keywords: { type: Type.NUMBER },
                content_opportunities: { type: Type.NUMBER }
            },
            required: ['total_opportunities', 'high_opportunity', 'estimated_traffic_value', 'opportunity_score', 'estimated_monthly_traffic', 'gap_keywords', 'content_opportunities']
        }
    },
    required: ['keyword_opportunities', 'competitor_analysis', 'content_gaps', 'overall_metrics']
};


const AISeoOpportunityFinderView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [topic, setTopic] = useState('');
    const [industry, setIndustry] = useState('');
    const [competitors, setCompetitors] = useState<string[]>([]);
    const [competitorInput, setCompetitorInput] = useState('');
    const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && topic.trim();

    const handleAddCompetitor = () => {
        if (competitorInput.trim() && !competitors.includes(competitorInput.trim())) {
            setCompetitors(prev => [...prev, competitorInput.trim()]);
            setCompetitorInput('');
        }
    };

    const handleRemoveCompetitor = (competitorToRemove: string) => {
        setCompetitors(prev => prev.filter(c => c !== competitorToRemove));
    };

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);
        setIsQueued(false);

        const prompt = `You are an expert SEO analyst. Perform a comprehensive SEO opportunity analysis based on the user's topic and their competitors.
        - Topic: ${topic}
        - Competitor Domains: ${competitors.join(', ')}
        - Industry: ${industry || 'Not specified'}
        Generate realistic but illustrative data for all fields. Your response must be a valid JSON object conforming to the provided schema.`;


        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: seoOpportunitySchema as any,
            });
            const parsed: AnalysisResult = JSON.parse(result);
            setAnalysisResult(parsed);

            if (userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: JSON.stringify(parsed, null, 2),
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Analysis failed. The AI may not support the complex JSON structure required for this module yet. Error: ${err.message}`: 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, topic, industry, competitors, module, userId, usesLeft, decrementUse]);

    const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    const renderInputForm = () => (
         <div className="space-y-6">
            <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="topic" className={commonLabelClasses}>Topic or Keyword</label>
                        <input id="topic" value={topic} onChange={e => setTopic(e.target.value)} placeholder="e.g., AI in marketing" className={commonInputClasses} />
                    </div>
                    <div>
                        <label htmlFor="industry" className={commonLabelClasses}>Industry (Optional)</label>
                        <input id="industry" value={industry} onChange={e => setIndustry(e.target.value)} placeholder="e.g., Technology, Healthcare" className={commonInputClasses} />
                    </div>
                </div>
                 <div>
                    <label htmlFor="competitor" className={commonLabelClasses}>Competitors (Optional)</label>
                     <div className="flex gap-2">
                         <input id="competitor" value={competitorInput} onChange={e => setCompetitorInput(e.target.value)} placeholder="competitor.com" className="flex-grow p-2 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg"/>
                         <button onClick={handleAddCompetitor} className="px-4 py-2 bg-base-300 dark:bg-d-base-300 font-semibold rounded-lg hover:bg-base-300/80 dark:hover:bg-d-base-300/80">Add</button>
                     </div>
                     <div className="flex flex-wrap gap-2 mt-3">
                         {competitors.map(c => (
                             <span key={c} className="flex items-center bg-base-300 dark:bg-d-base-300 text-sm font-medium px-3 py-1 rounded-full">
                                 {c}
                                 <button onClick={() => handleRemoveCompetitor(c)} className="ml-2 text-text-secondary dark:text-d-text-secondary hover:text-error">
                                    <CloseIcon className="h-4 w-4" />
                                </button>
                             </span>
                         ))}
                     </div>
                 </div>
            </div>
             <button
                onClick={handleGenerate}
                disabled={isLoading || !canGenerate}
                className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed transition-all"
            >
                {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : '📈 Analyze Trends'}
            </button>
        </div>
    );
    
    // In a real implementation, the renderResults function would be much more complex
    // This is a simplified version to demonstrate the structure
    const renderResults = () => (
         <div className="space-y-6 animate-fade-in">
            <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl">
                <h3 className="text-2xl font-bold font-heading mb-2">Analysis for "{topic}"</h3>
                <p className="text-text-secondary dark:text-d-text-secondary">{analysisResult?.summary || "Here's what we found."}</p>
                <button onClick={() => setAnalysisResult(null)} className="text-sm font-semibold text-brand-primary mt-4">New Analysis</button>
            </div>
            {/* A full tabbed interface would go here */}
            <div>
                <h3 className="text-xl font-bold font-heading mb-4">💎 Top Keyword Opportunity</h3>
                <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg">
                    <p className="font-bold text-lg">{analysisResult?.keyword_opportunities[0]?.term}</p>
                    <p className="text-sm">Score: <span className="font-bold text-brand-secondary">{analysisResult?.keyword_opportunities[0]?.opportunity_score}/100</span></p>
                </div>
            </div>
             <div>
                <h3 className="text-xl font-bold font-heading mb-4">📊 Top Content Gap</h3>
                <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg">
                    <p className="font-bold text-lg">{analysisResult?.content_gaps[0]?.topic}</p>
                     <p className="text-sm">Priority: <span className="font-bold text-error">{analysisResult?.content_gaps[0]?.priority.toUpperCase()}</span></p>
                </div>
            </div>
         </div>
    );

    return (
        <div className="max-w-4xl mx-auto flex flex-col gap-8">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            
            {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
            {isQueued && <p className="text-center text-accent">Request queued for when you're back online.</p>}

            {isLoading && (
                 <div className="text-center p-8">
                     <svg className="animate-spin mx-auto h-12 w-12 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                    <h3 className="text-xl font-bold font-heading mt-4">Analyzing trends...</h3>
                    <p className="text-text-secondary dark:text-d-text-secondary mt-2">Gathering insights from across the web.</p>
                </div>
            )}
            
            {!isLoading && !error && (
                analysisResult ? renderResults() : renderInputForm()
            )}
        </div>
    );
};

export default AISeoOpportunityFinderView;