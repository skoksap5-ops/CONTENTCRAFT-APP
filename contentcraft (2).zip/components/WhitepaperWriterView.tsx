import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ToneSelector from './ToneSelector';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type Audience = 'Executives' | 'Technical' | 'Investors' | 'Academic' | 'General';
type Purpose = 'Thought Leadership' | 'Lead Generation' | 'Problem Solving' | 'Industry Analysis';
type Length = 'Short 10-15pp' | 'Standard 20-30pp' | 'Comprehensive 40-50pp';
type ResearchDepth = 'Introductory' | 'Intermediate' | 'Advanced' | 'Expert';

const WHITEPAPER_WRITER_PROMPT = `
You are an expert research analyst and technical writer specializing in creating authoritative, data-driven whitepapers that establish thought leadership and drive business outcomes.

**INPUT:**
- Research Topic: {RESEARCH_TOPIC}
- Target Audience: {TARGET_AUDIENCE}
- Whitepaper Purpose: {PURPOSE}
- Length Requirement: {LENGTH}
- Research Depth: {RESEARCH_DEPTH}
- Tone: {SELECTED_TONES}

**COMPREHENSIVE WHITEPAPER CREATION:**

## 1. WHITEPAPER STRATEGY FRAMEWORK
(Your detailed analysis of the research methodology and thesis development will go here)

## 2. PROFESSIONAL WHITEPAPER STRUCTURE
(Your detailed breakdown of each section of the whitepaper from Cover Page to References will go here)

## 3. CONTENT DEVELOPMENT FRAMEWORK
(Your strategy for data visualization, technical content adaptation, and persuasive argument building will go here)

## 4. WHITEPAPER TYPES & TEMPLATES
(Your analysis and recommendation of a whitepaper type - e.g., Problem-Solution - will go here)

## 5. RESEARCH & DATA INTEGRATION
(Your plan for primary/secondary research and statistical analysis will go here)

## 6. PROFESSIONAL FORMATTING
(Your recommendations for academic standards and brand alignment will go here)
`;


interface ParsedOutput {
    strategyFramework: string;
    professionalStructure: string;
    contentDevelopment: string;
    typesAndTemplates: string;
    researchAndData: string;
    professionalFormatting: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const WhitepaperWriterView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [researchTopic, setResearchTopic] = useState('');
    const [targetAudience, setTargetAudience] = useState<Audience>('Executives');
    const [purpose, setPurpose] = useState<Purpose>('Thought Leadership');
    const [length, setLength] = useState<Length>('Standard 20-30pp');
    const [researchDepth, setResearchDepth] = useState<ResearchDepth>('Intermediate');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && researchTopic.trim();
    
    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = text.match(regex);
                return match ? match[1].trim() : 'Could not parse this section.';
            };
            
            return {
                strategyFramework: getSection('## 1. WHITEPAPER STRATEGY FRAMEWORK', '## 2. PROFESSIONAL WHITEPAPER STRUCTURE'),
                professionalStructure: getSection('## 2. PROFESSIONAL WHITEPAPER STRUCTURE', '## 3. CONTENT DEVELOPMENT FRAMEWORK'),
                contentDevelopment: getSection('## 3. CONTENT DEVELOPMENT FRAMEWORK', '## 4. WHITEPAPER TYPES & TEMPLATES'),
                typesAndTemplates: getSection('## 4. WHITEPAPER TYPES & TEMPLATES', '## 5. RESEARCH & DATA INTEGRATION'),
                researchAndData: getSection('## 5. RESEARCH & DATA INTEGRATION', '## 6. PROFESSIONAL FORMATTING'),
                professionalFormatting: getSection('## 6. PROFESSIONAL FORMATTING', '$'),
            };
        } catch (e) {
            console.error("Failed to parse Whitepaper Writer output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return WHITEPAPER_WRITER_PROMPT
            .replace('{RESEARCH_TOPIC}', researchTopic)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{PURPOSE}', purpose)
            .replace('{LENGTH}', length)
            .replace('{RESEARCH_DEPTH}', researchDepth)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [researchTopic, targetAudience, purpose, length, researchDepth, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/^###\s*[A-Z]\.\s*(.*)/gm, '<h4 class="text-md font-semibold text-text-primary dark:text-d-text-primary mt-4 mb-2">$1</h4>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };
    
    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={researchTopic} onChange={e => setResearchTopic(e.target.value)} placeholder="Describe the research topic, core argument, and key data points..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Whitepaper Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Target Audience</label>
                                <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as Audience)} className={commonInputClasses}>
                                    <option>Executives</option><option>Technical</option><option>Investors</option><option>Academic</option><option>General</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Purpose</label>
                                <select value={purpose} onChange={e => setPurpose(e.target.value as Purpose)} className={commonInputClasses}>
                                    <option>Thought Leadership</option><option>Lead Generation</option><option>Problem Solving</option><option>Industry Analysis</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Length Requirement</label>
                                <select value={length} onChange={e => setLength(e.target.value as Length)} className={commonInputClasses}>
                                    <option>Short 10-15pp</option><option>Standard 20-30pp</option><option>Comprehensive 40-50pp</option>
                                </select>
                            </div>
                             <div>
                                <label className={commonLabelClasses}>Research Depth</label>
                                <select value={researchDepth} onChange={e => setResearchDepth(e.target.value as ResearchDepth)} className={commonInputClasses}>
                                    <option>Introductory</option><option>Intermediate</option><option>Advanced</option><option>Expert</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Generating Whitepaper...' : (isQueued ? 'Request Queued' : 'Generate Whitepaper')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && researchTopic.trim() && <p className="text-center text-yellow-500 text-sm mt-2">Please provide a research topic.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Building your authoritative whitepaper...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your comprehensive whitepaper outline and strategy will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-2">
                           <Accordion title={<>📊 <span className="ml-2">Strategy Framework</span></>} defaultOpen={true}>
                             <div className="prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={formatContent(parsedOutput.strategyFramework)} />
                           </Accordion>
                           <Accordion title={<>📑 <span className="ml-2">Professional Structure</span></>} defaultOpen={true}>
                             <div className="prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={formatContent(parsedOutput.professionalStructure)} />
                           </Accordion>
                           <Accordion title={<>✍️ <span className="ml-2">Content Development</span></>}>
                             <div className="prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={formatContent(parsedOutput.contentDevelopment)} />
                           </Accordion>
                           <Accordion title={<>📋 <span className="ml-2">Types & Templates</span></>}>
                             <div className="prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={formatContent(parsedOutput.typesAndTemplates)} />
                           </Accordion>
                           <Accordion title={<>🔬 <span className="ml-2">Research & Data</span></>}>
                             <div className="prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={formatContent(parsedOutput.researchAndData)} />
                           </Accordion>
                           <Accordion title={<>🎨 <span className="ml-2">Professional Formatting</span></>}>
                             <div className="prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={formatContent(parsedOutput.professionalFormatting)} />
                           </Accordion>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default WhitepaperWriterView;