import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ToneSelector from './ToneSelector';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type Industry = 'Tech/SaaS' | 'Healthcare' | 'Finance' | 'Retail' | 'Manufacturing' | 'Other';
type TargetAudience = 'Prospects' | 'Investors' | 'Partners' | 'Internal';
type Purpose = 'Sales' | 'Marketing' | 'Investor' | 'Internal Training';

const CASE_STUDY_CREATOR_PROMPT = `
You are an expert case study strategist and storytelling specialist. Create compelling, results-driven case studies that demonstrate value, build credibility, and drive conversions through powerful storytelling and data-driven results.

**INPUT:**
- Client Company: {CLIENT_COMPANY}
- Industry: {INDUSTRY}
- Challenge: {MAIN_CHALLENGE}
- Solution: {SOLUTION_PROVIDED}
- Results: {KEY_RESULTS}
- Target Audience: {TARGET_AUDIENCE}
- Case Study Purpose: {PURPOSE}
- Tone: {SELECTED_TONES}

**COMPREHENSIVE CASE STUDY CREATION:**

## 1. CASE STUDY STRATEGY FRAMEWORK
(Your detailed analysis of storytelling, persuasion, and client needs will go here)

## 2. PROFESSIONAL CASE STUDY STRUCTURE
### A. COVER & HERO SECTION
### B. EXECUTIVE SUMMARY
### C. CLIENT BACKGROUND
### D. THE CHALLENGE
### E. SOLUTION SELECTION
### F. IMPLEMENTATION JOURNEY
### G. THE SOLUTION IN ACTION
### H. RESULTS & ROI
### I. CLIENT TESTIMONIAL
### J. FUTURE OUTLOOK
### K. CALL TO ACTION

## 3. CASE STUDY TYPES & TEMPLATES
(Your analysis and recommendation of a case study type will go here)

## 4. DATA VISUALIZATION STRATEGY
(Your recommendations for charts, graphs, and visual elements will go here)

## 5. PERSUASIVE ELEMENTS INTEGRATION
(Your analysis of social proof, emotional connection, and risk mitigation will go here)
`;

interface ParsedCaseStudySection {
    hero: string;
    executiveSummary: string;
    clientBackground: string;
    challenge: string;
    solutionSelection: string;
    implementation: string;
    solutionInAction: string;
    results: string;
    testimonial: string;
    future: string;
    cta: string;
}

interface ParsedOutput {
    caseStudy: ParsedCaseStudySection;
    strategyFramework: string;
    typesAndTemplates: string;
    dataVisualization: string;
    persuasiveElements: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const CaseStudyCreatorView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [clientCompany, setClientCompany] = useState('');
    const [industry, setIndustry] = useState<Industry>('Tech/SaaS');
    const [mainChallenge, setMainChallenge] = useState('');
    const [solutionProvided, setSolutionProvided] = useState('');
    const [keyResults, setKeyResults] = useState('');
    const [targetAudience, setTargetAudience] = useState<TargetAudience>('Prospects');
    const [purpose, setPurpose] = useState<Purpose>('Sales');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && clientCompany.trim() && mainChallenge.trim() && solutionProvided.trim() && keyResults.trim();
    
    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string, source = text) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = source.match(regex);
                return match ? match[1].trim() : 'Could not parse this section.';
            };
            
            const caseStudyStructure = getSection('## 2. PROFESSIONAL CASE STUDY STRUCTURE', '## 3. CASE STUDY TYPES & TEMPLATES');

            return {
                strategyFramework: getSection('## 1. CASE STUDY STRATEGY FRAMEWORK', '## 2. PROFESSIONAL CASE STUDY STRUCTURE'),
                caseStudy: {
                    hero: getSection('### A. COVER & HERO SECTION', '### B. EXECUTIVE SUMMARY', caseStudyStructure),
                    executiveSummary: getSection('### B. EXECUTIVE SUMMARY', '### C. CLIENT BACKGROUND', caseStudyStructure),
                    clientBackground: getSection('### C. CLIENT BACKGROUND', '### D. THE CHALLENGE', caseStudyStructure),
                    challenge: getSection('### D. THE CHALLENGE', '### E. SOLUTION SELECTION', caseStudyStructure),
                    solutionSelection: getSection('### E. SOLUTION SELECTION', '### F. IMPLEMENTATION JOURNEY', caseStudyStructure),
                    implementation: getSection('### F. IMPLEMENTATION JOURNEY', '### G. THE SOLUTION IN ACTION', caseStudyStructure),
                    solutionInAction: getSection('### G. THE SOLUTION IN ACTION', '### H. RESULTS & ROI', caseStudyStructure),
                    results: getSection('### H. RESULTS & ROI', '### I. CLIENT TESTIMONIAL', caseStudyStructure),
                    testimonial: getSection('### I. CLIENT TESTIMONIAL', '### J. FUTURE OUTLOOK', caseStudyStructure),
                    future: getSection('### J. FUTURE OUTLOOK', '### K. CALL TO ACTION', caseStudyStructure),
                    cta: getSection('### K. CALL TO ACTION', '$', caseStudyStructure),
                },
                typesAndTemplates: getSection('## 3. CASE STUDY TYPES & TEMPLATES', '## 4. DATA VISUALIZATION STRATEGY'),
                dataVisualization: getSection('## 4. DATA VISUALIZATION STRATEGY', '## 5. PERSUASIVE ELEMENTS INTEGRATION'),
                persuasiveElements: getSection('## 5. PERSUASIVE ELEMENTS INTEGRATION', '$'),
            };
        } catch (e) {
            console.error("Failed to parse Case Study output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return CASE_STUDY_CREATOR_PROMPT
            .replace('{CLIENT_COMPANY}', clientCompany)
            .replace('{INDUSTRY}', industry)
            .replace('{MAIN_CHALLENGE}', mainChallenge)
            .replace('{SOLUTION_PROVIDED}', solutionProvided)
            .replace('{KEY_RESULTS}', keyResults)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{PURPOSE}', purpose)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [clientCompany, industry, mainChallenge, solutionProvided, keyResults, targetAudience, purpose, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/^###\s*[A-Z]\.\s*(.*)/gm, '<h4 class="text-lg font-semibold text-text-primary dark:text-d-text-primary mt-6 mb-3 font-heading border-l-4 border-brand-primary pl-3">$1</h4>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };
    
    const CaseStudySection: React.FC<{ title: string; content: string; icon: string }> = ({ title, icon, content }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!content) return;
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = content.replace(/<br \/>/g, '\n');
            navigator.clipboard.writeText(tempDiv.textContent || "").then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!content || content.toLowerCase().includes('could not parse')) return null;
        return (
            <div className="relative group">
                <button onClick={handleCopy} className="absolute top-4 right-4 p-2 rounded-lg bg-base-300/50 dark:bg-d-base-300/50 opacity-0 group-hover:opacity-100 transition-opacity" aria-label={`Copy ${title}`}>
                    {copySuccess ? 'Copied!' : <CopyIcon className="h-5 w-5" />}
                </button>
                <div dangerouslySetInnerHTML={formatContent(`### A. ${title}\n${content}`)} />
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[120px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className={commonLabelClasses}>Client/Company Name</label>
                            <input value={clientCompany} onChange={e => setClientCompany(e.target.value)} placeholder="e.g., GlobalTech Inc." className={commonInputClasses} />
                        </div>
                        <div>
                            <label className={commonLabelClasses}>Industry</label>
                            <select value={industry} onChange={e => setIndustry(e.target.value as Industry)} className={commonInputClasses}>
                                <option>Tech/SaaS</option><option>Healthcare</option><option>Finance</option><option>Retail</option><option>Manufacturing</option><option>Other</option>
                            </select>
                        </div>
                    </div>
                    <textarea value={mainChallenge} onChange={e => setMainChallenge(e.target.value)} placeholder="Describe the client's main challenge..." className={commonTextareaClasses} />
                    <textarea value={solutionProvided} onChange={e => setSolutionProvided(e.target.value)} placeholder="Describe the solution you provided..." className={commonTextareaClasses} />
                    <textarea value={keyResults} onChange={e => setKeyResults(e.target.value)} placeholder="List the key quantifiable results (e.g., 45% cost reduction, 2x revenue)..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Target Audience</label>
                                <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as TargetAudience)} className={commonInputClasses}>
                                    <option>Prospects</option><option>Investors</option><option>Partners</option><option>Internal</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Case Study Purpose</label>
                                <select value={purpose} onChange={e => setPurpose(e.target.value as Purpose)} className={commonInputClasses}>
                                    <option>Sales</option><option>Marketing</option><option>Investor</option><option>Internal Training</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Generating Case Study...' : (isQueued ? 'Request Queued' : 'Generate Case Study')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please fill in all required fields.</p>}
                </div>
                <div className="bg-base-100 dark:bg-d-base-100 rounded-lg p-6 min-h-[500px] overflow-y-auto shadow-inner prose prose-sm dark:prose-invert max-w-none">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Building your persuasive case study...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your comprehensive case study will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-8">
                            <div>
                                <h2 className="text-2xl font-bold font-heading">CASE STUDY</h2>
                                <p className="lead">For: {clientCompany}</p>
                            </div>
                            <CaseStudySection title="Hero Section" icon="🏆" content={parsedOutput.caseStudy.hero} />
                            <CaseStudySection title="Executive Summary" icon="📑" content={parsedOutput.caseStudy.executiveSummary} />
                            <CaseStudySection title="Client Background" icon="🏢" content={parsedOutput.caseStudy.clientBackground} />
                            <CaseStudySection title="The Challenge" icon="🚨" content={parsedOutput.caseStudy.challenge} />
                            <CaseStudySection title="Solution Selection" icon="💡" content={parsedOutput.caseStudy.solutionSelection} />
                            <CaseStudySection title="Implementation Journey" icon="🛠️" content={parsedOutput.caseStudy.implementation} />
                            <CaseStudySection title="The Solution in Action" icon="⚙️" content={parsedOutput.caseStudy.solutionInAction} />
                            <CaseStudySection title="Results & ROI" icon="📈" content={parsedOutput.caseStudy.results} />
                            <CaseStudySection title="Client Testimonial" icon="💬" content={parsedOutput.caseStudy.testimonial} />
                            <CaseStudySection title="Future Outlook" icon="🔮" content={parsedOutput.caseStudy.future} />
                            <CaseStudySection title="Call to Action" icon="📞" content={parsedOutput.caseStudy.cta} />
                            
                            <div className="space-y-2 pt-8">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-4">Strategy & Analysis</h3>
                                <Accordion title={<>📊 <span className="ml-2">Strategy Framework</span></>} defaultOpen={true}><div dangerouslySetInnerHTML={formatContent(parsedOutput.strategyFramework)}/></Accordion>
                                <Accordion title={<>✨ <span className="ml-2">Persuasive Elements</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.persuasiveElements)}/></Accordion>
                                <Accordion title={<>📋 <span className="ml-2">Types & Templates</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.typesAndTemplates)}/></Accordion>
                                <Accordion title={<>🖼️ <span className="ml-2">Data Visualization</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.dataVisualization)}/></Accordion>
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default CaseStudyCreatorView;
