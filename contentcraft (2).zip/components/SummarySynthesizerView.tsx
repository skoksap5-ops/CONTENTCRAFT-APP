import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type Audience = 'General' | 'Technical' | 'Professional' | 'Casual';

const SUMMARY_SYNTHESIZER_PROMPT = `
You are an expert text summarization specialist. Analyze the provided text and generate a JSON object containing three different length summaries and a detailed analysis.

**INPUT:**
- Original Text: {USER_TEXT}
- Target Audience: {TARGET_AUDIENCE}
- Key Focus Areas: {KEY_POINTS}
- Tone: {SELECTED_TONES}

Your response must be a valid JSON object that conforms to the provided schema. Generate the content for each field as described in the schema. For the string fields that will be displayed directly ('analysis', 'keyInfo'), use markdown-like formatting (e.g., "**- Word Count:** [X] words\\n**- Main Topics:** [List]") where appropriate.
`;

const summaryResponseSchema = {
  type: Type.OBJECT,
  properties: {
    analysis: { type: Type.STRING, description: "Analysis of the original text: word count, main topics, primary purpose. Formatted for display using markdown-like syntax (e.g., '**- Word Count:** ...')." },
    summaries: {
      type: Type.OBJECT,
      properties: {
        micro: { type: Type.STRING, description: "1-2 sentence summary." },
        executive: { type: Type.STRING, description: "3-5 sentence summary." },
        comprehensive: { type: Type.STRING, description: "1-2 paragraph summary." }
      },
      required: ['micro', 'executive', 'comprehensive']
    },
    keyInfo: { type: Type.STRING, description: "Key information extracted: main conclusion, supporting evidence, actionable insights. Formatted for display using markdown-like syntax." },
  },
  required: ['analysis', 'summaries', 'keyInfo']
};


interface ParsedOutput {
    analysis: string;
    summaries: {
        micro: string;
        executive: string;
        comprehensive: string;
    };
    keyInfo: string;
    recommendations: string;
}

const SummarySynthesizerView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    // Specific inputs
    const [audience, setAudience] = useState<Audience>('General');
    const [keyPoints, setKeyPoints] = useState('');

    // Tone selector state
    const [tones, setTones] = useState<string[]>([]);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const [originalWordCount, setOriginalWordCount] = useState(0);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();
    
    const getPrompt = useCallback(() => {
        return SUMMARY_SYNTHESIZER_PROMPT
            .replace('{USER_TEXT}', input)
            .replace('{TARGET_AUDIENCE}', audience)
            .replace('{KEY_POINTS}', keyPoints || 'Not specified')
            .replace('{SELECTED_TONES}', tones.length ? tones.join(', ') : 'neutral');
    }, [input, audience, keyPoints, tones]);


    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;

        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);
        setOriginalWordCount(input.trim().split(/\s+/).length);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: summaryResponseSchema,
            });
            setOutput(result);
            try {
                const parsed = JSON.parse(result);
                setParsedOutput(parsed);
            } catch (e) {
                console.error("Failed to parse JSON response:", e, result);
                setError("The AI returned a response in an unexpected format. Displaying raw output.");
                setParsedOutput(null);
            }

            if (usesLeft !== 'Unlimited') {
                decrementUse();
            }
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, input]);
    
    const formatSection = (text: string) => {
        if (!text) return { __html: '' };
        const html = text
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/• (.*)/g, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />');
        return { __html: html };
    };

    const SummaryCard: React.FC<{title: string; content: string; usage: string}> = ({ title, content, usage }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        
        const handleCopy = () => {
            navigator.clipboard.writeText(content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        const summaryWordCount = content.trim().split(/\s+/).length;
        const reduction = originalWordCount > 0 ? Math.round((1 - (summaryWordCount / originalWordCount)) * 100) : 0;
        const timeSaved = originalWordCount > 0 ? Math.max(Math.round(((originalWordCount - summaryWordCount) / 200)), 0) : 0; // 200 wpm reading speed
        
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative">
                <div className="flex justify-between items-start">
                    <div>
                        <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{title}</h4>
                        <p className="text-xs text-text-secondary dark:text-d-text-secondary mb-2">{usage}</p>
                    </div>
                     <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${title}`}>
                        {copySuccess ? 'Copied!' : <CopyIcon className="h-5 w-5" />}
                    </button>
                </div>
                <p className="text-text-primary dark:text-d-text-primary mt-2">{content}</p>
                {originalWordCount > 0 && content.length > 1 && (
                    <div className="flex items-center space-x-4 mt-4 pt-3 border-t border-base-300 dark:border-d-base-300 text-xs text-text-secondary dark:text-d-text-secondary">
                        <span><strong className="text-brand-secondary">{reduction}%</strong> Less Words</span>
                        <span><strong className="text-brand-secondary">~{timeSaved} min</strong> Time Saved</span>
                    </div>
                )}
            </div>
        );
    };

    const commonTextareaClasses = "w-full p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        placeholder="Enter the text to summarize here..."
                        className={commonTextareaClasses}
                        style={{minHeight: '250px'}}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="audience" className={commonLabelClasses}>Target Audience</label>
                            <select id="audience" value={audience} onChange={e => setAudience(e.target.value as Audience)} className={commonInputClasses}>
                                <option>General</option>
                                <option>Technical</option>
                                <option>Professional</option>
                                <option>Casual</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="keyPoints" className={commonLabelClasses}>Key Focus Areas (optional)</label>
                            <input id="keyPoints" type="text" value={keyPoints} onChange={e => setKeyPoints(e.target.value)} placeholder="e.g. results, methodology" className={commonInputClasses} />
                        </div>
                    </div>

                    <button 
                        onClick={() => setIsToneSelectorOpen(true)}
                        className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors"
                    >
                        <div className="flex justify-between items-center">
                            <div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div>
                            <div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div>
                        </div>
                    </button>
                    
                    <button
                        onClick={handleGenerate}
                        disabled={isLoading || !canGenerate}
                        className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300"
                    >
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Synthesizing...' : (isQueued ? 'Request Queued' : 'Synthesize Summaries')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && input.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                </div>

                <div className={`${commonTextareaClasses} bg-base-200/50 dark:bg-d-base-200/50 min-h-[500px] overflow-y-auto leading-relaxed`}>
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Generating report...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your AI-crafted summaries will appear here...</p>}
                    {parsedOutput && (
                        <div className="space-y-6 p-2">
                             <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">🎯 Summaries</h3>
                             <SummaryCard title="Micro Summary" content={parsedOutput.summaries.micro} usage="Perfect for quick sharing" />
                             <SummaryCard title="Executive Summary" content={parsedOutput.summaries.executive} usage="Ideal for business use" />
                             <SummaryCard title="Comprehensive Summary" content={parsedOutput.summaries.comprehensive} usage="For detailed understanding" />
                           
                            <div>
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mt-8 mb-4">📊 Original Text Analysis</h3>
                                <div className="text-sm text-text-primary dark:text-d-text-primary bg-base-200 dark:bg-d-base-200 p-4 rounded-lg" dangerouslySetInnerHTML={formatSection(parsedOutput.analysis)} />
                            </div>
                             <div>
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mt-8 mb-4">📈 Key Information Extracted</h3>
                                <div className="text-sm text-text-primary dark:text-d-text-primary bg-base-200 dark:bg-d-base-200 p-4 rounded-lg" dangerouslySetInnerHTML={formatSection(parsedOutput.keyInfo)} />
                            </div>
                        </div>
                    )}
                     {output && !parsedOutput && !isLoading && (
                         <div className="p-2">
                             <h3 className="text-lg font-semibold text-error mb-2">Could not parse the AI response.</h3>
                             <p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p>
                             <pre className="whitespace-pre-wrap text-xs">{output}</pre>
                         </div>
                     )}
                </div>
            </div>
             {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector 
            isOpen={isToneSelectorOpen}
            onClose={() => setIsToneSelectorOpen(false)}
            selectedTones={tones}
            onTonesChange={setTones}
        />
        </>
    );
};

export default SummarySynthesizerView;