import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ToneSelector from './ToneSelector';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type AdObjective = 'Awareness' | 'Consideration' | 'Conversion';
type BudgetLevel = 'Starter' | 'Moderate' | 'Advanced' | 'Enterprise';

const FACEBOOK_AD_PROMPT = `
You are a Facebook Ads expert and social media marketing strategist. Create high-converting, platform-optimized Facebook and Instagram ads that capture attention, drive engagement, and generate results.

**INPUT:**
- Product/Service: {PRODUCT_SERVICE}
- Target Audience: {TARGET_AUDIENCE} (Demographics, interests, behaviors)
- Ad Objective: {AD_OBJECTIVE} (Awareness/Consideration/Conversion)
- Primary Offer: {PRIMARY_OFFER} (Discount/Free Trial/Content/Event)
- Budget Level: {BUDGET_LEVEL} (Starter/Moderate/Advanced/Enterprise)
- Tone: {SELECTED_TONES}

**COMPREHENSIVE FACEBOOK AD CREATION:**

## 1. AD STRATEGY FRAMEWORK
(Your analysis of objective alignment and audience targeting strategy will go here internally)

## 2. AD CREATIVE COMPONENTS
(Your analysis of primary text, headline, and description will go here internally)

## 3. VISUAL CONTENT STRATEGY
(Your analysis of image/video recommendations will go here internally)

## 4. CALL-TO-ACTION OPTIMIZATION
(Your analysis of CTA selection and landing page alignment will go here internally)

**TASK:**
Based on the input and your expert analysis, generate multiple complete ad sets with targeting, budget, and performance predictions. The output MUST follow this structure exactly:

🎯 **AD SET 1: [Strategy Focus Name]**
**PRIMARY TEXT:**
[Your primary text here]
**HEADLINE:**
[Your headline here]
**DESCRIPTION:**
[Your description here]
**CTA BUTTON:**
[Your CTA button suggestion here]
**VISUAL RECOMMENDATION:**
- **Format**: [e.g., Animated video (15 seconds)]
- **Content**: [e.g., Before/after workflow comparison]
- **Text Overlay**: [e.g., "Tired of social media chaos?"]
- **Aspect Ratio**: [e.g., 4:5 (mobile-optimized)]

🎯 **AD SET 2: [Strategy Focus Name]**
**PRIMARY TEXT:**
[Your primary text here]
**HEADLINE:**
[Your headline here]
**DESCRIPTION:**
[Your description here]
**CTA BUTTON:**
[Your CTA button suggestion here]
**VISUAL RECOMMENDATION:**
- **Format**: [e.g., Carousel ad (3 cards)]
- **Content**: [e.g., Card 1: Dashboard, Card 2: Analytics, Card 3: Testimonial]
- **Text Overlay**: [e.g., "Real results from real businesses"]
- **Aspect Ratio**: [e.g., 1:1 (square)]

🎯 **AD SET 3: [Strategy Focus Name]**
**PRIMARY TEXT:**
[Your primary text here]
**HEADLINE:**
[Your headline here]
**DESCRIPTION:**
[Your description here]
**CTA BUTTON:**
[Your CTA button suggestion here]
**VISUAL RECOMMENDATION:**
- **Format**: [e.g., User-generated content collage]
- **Content**: [e.g., Customer screenshot montage]
- **Text Overlay**: [e.g., "See what our users are saying!"]
- **Aspect Ratio**: [e.g., 9:16 (Stories-optimized)]

📊 **TARGETING RECOMMENDATIONS:**
**CORE AUDIENCES:**
1. [Audience 1 Details]
2. [Audience 2 Details]
**CUSTOM AUDIENCES:**
- [List of custom audiences]
**LOOKALIKE AUDIENCES:**
- [List of lookalike audiences]

💰 **BUDGET ALLOCATION:**
- **Ad Set 1**: [$/day or %] ([Focus])
- **Ad Set 2**: [$/day or %] ([Focus])
- **Ad Set 3**: [$/day or %] ([Focus])

📈 **PERFORMANCE PREDICTION:**
- **Estimated CTR**: [X]%
- **Cost Per Result**: [e.g., $X.XX per install/lead]
- **Conversion Rate**: [Y]%
- **Quality Score**: [Z]/10
`;


interface AdSet {
    title: string;
    primaryText: string;
    headline: string;
    description: string;
    ctaButton: string;
    visualRecommendation: string;
}
interface ParsedOutput {
    adSets: AdSet[];
    targetingRecommendations: string;
    budgetAllocation: string;
    performancePrediction: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const FacebookAdView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [productService, setProductService] = useState('');
    const [targetAudience, setTargetAudience] = useState('');
    const [adObjective, setAdObjective] = useState<AdObjective>('Consideration');
    const [primaryOffer, setPrimaryOffer] = useState('');
    const [budgetLevel, setBudgetLevel] = useState<BudgetLevel>('Moderate');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && productService.trim();
    
    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string, source = text) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = source.match(regex);
                return match ? match[1].trim() : '';
            };

            const adSetSections = text.split(/🎯 \*\*AD SET \d+:/).slice(1);
            const adSets = adSetSections.map((section, index) => {
                const titleMatch = text.match(new RegExp(`🎯 \\*\\*AD SET ${index + 1}:(.*?)\\*\\*`, 'i'));
                return {
                    title: titleMatch ? titleMatch[1].trim() : `Ad Set ${index + 1}`,
                    primaryText: getSection('\\*\\*PRIMARY TEXT:\\*\\*', '\\*\\*HEADLINE:\\*\\*', section),
                    headline: getSection('\\*\\*HEADLINE:\\*\\*', '\\*\\*DESCRIPTION:\\*\\*', section),
                    description: getSection('\\*\\*DESCRIPTION:\\*\\*', '\\*\\*CTA BUTTON:\\*\\*', section),
                    ctaButton: getSection('\\*\\*CTA BUTTON:\\*\\*', '\\*\\*VISUAL RECOMMENDATION:\\*\\*', section),
                    visualRecommendation: getSection('\\*\\*VISUAL RECOMMENDATION:\\*\\*', '$', section),
                };
            });

            const targetingRecommendations = getSection('📊 \\*\\*TARGETING RECOMMENDATIONS:\\*\\*', '💰 \\*\\*BUDGET ALLOCATION:\\*\\*');
            const budgetAllocation = getSection('💰 \\*\\*BUDGET ALLOCATION:\\*\\*', '📈 \\*\\*PERFORMANCE PREDICTION:\\*\\*');
            const performancePrediction = getSection('📈 \\*\\*PERFORMANCE PREDICTION:\\*\\*', '$');

            return { adSets, targetingRecommendations, budgetAllocation, performancePrediction };
        } catch (e) {
            console.error("Failed to parse Facebook Ad output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return FACEBOOK_AD_PROMPT
            .replace('{PRODUCT_SERVICE}', productService)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{AD_OBJECTIVE}', adObjective)
            .replace('{PRIMARY_OFFER}', primaryOffer)
            .replace('{BUDGET_LEVEL}', budgetLevel)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [productService, targetAudience, adObjective, primaryOffer, budgetLevel, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };
    
    const AdSetCard: React.FC<{ adSet: AdSet }> = ({ adSet }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            const copyText = `Primary Text:\n${adSet.primaryText}\n\nHeadline:\n${adSet.headline}\n\nDescription:\n${adSet.description}`;
            navigator.clipboard.writeText(copyText).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!adSet.primaryText) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative space-y-4">
                <div className="flex justify-between items-start">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary flex items-center gap-2">
                        <span className="text-xl">🎯</span> Ad Set: {adSet.title}
                    </h4>
                     <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${adSet.title}`}>
                        {copySuccess ? 'Copied!' : <CopyIcon className="h-5 w-5" />}
                    </button>
                </div>
                
                <div className="text-sm space-y-3">
                    <div><strong className="block text-text-secondary dark:text-d-text-secondary text-xs uppercase tracking-wider">Primary Text</strong><p className="mt-1 whitespace-pre-wrap">{adSet.primaryText}</p></div>
                    <div><strong className="block text-text-secondary dark:text-d-text-secondary text-xs uppercase tracking-wider">Headline</strong><p className="mt-1">{adSet.headline}</p></div>
                    <div><strong className="block text-text-secondary dark:text-d-text-secondary text-xs uppercase tracking-wider">Description</strong><p className="mt-1">{adSet.description}</p></div>
                    <div><strong className="block text-text-secondary dark:text-d-text-secondary text-xs uppercase tracking-wider">CTA Button</strong><p className="mt-1 bg-brand-primary/20 text-brand-primary px-2 py-0.5 rounded-md inline-block font-semibold">{adSet.ctaButton}</p></div>
                    <Accordion title={<>🖼️ <span className="ml-2">Visual Recommendation</span></>}>
                        <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(adSet.visualRecommendation)} />
                    </Accordion>
                </div>
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[120px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={productService} onChange={e => setProductService(e.target.value)} placeholder="Product/Service Description..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Ad Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Target Audience</label>
                                <input value={targetAudience} onChange={e => setTargetAudience(e.target.value)} placeholder="e.g., small business owners" className={commonInputClasses} />
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Primary Offer</label>
                                <input value={primaryOffer} onChange={e => setPrimaryOffer(e.target.value)} placeholder="e.g., 14-day free trial" className={commonInputClasses} />
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Ad Objective</label>
                                <select value={adObjective} onChange={e => setAdObjective(e.target.value as AdObjective)} className={commonInputClasses}>
                                    <option>Consideration</option><option>Awareness</option><option>Conversion</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Budget Level</label>
                                <select value={budgetLevel} onChange={e => setBudgetLevel(e.target.value as BudgetLevel)} className={commonInputClasses}>
                                    <option>Moderate</option><option>Starter</option><option>Advanced</option><option>Enterprise</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Creating Ads...' : (isQueued ? 'Request Queued' : 'Create Facebook Ad')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && productService.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Building your ad campaign...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your comprehensive ad campaign will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-6">
                             <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Ad Creative Suite</h3>
                                {parsedOutput.adSets.map((adSet, index) => <AdSetCard key={index} adSet={adSet} />)}
                            </div>
                            <div className="space-y-2 pt-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Strategy & Performance</h3>
                                <Accordion title={<>📊 <span className="ml-2">Targeting Recommendations</span></>} defaultOpen={true}><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.targetingRecommendations)}/></Accordion>
                                <Accordion title={<>💰 <span className="ml-2">Budget Allocation</span></>}><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.budgetAllocation)}/></Accordion>
                                <Accordion title={<>📈 <span className="ml-2">Performance Prediction</span></>}><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.performancePrediction)}/></Accordion>
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default FacebookAdView;