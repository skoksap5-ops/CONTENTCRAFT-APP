import React, { useState, useEffect, useCallback, useMemo } from 'react';
import type { Generation } from '../types';
import { getGenerationsForUser, deleteGeneration, clearAllGenerationsForUser } from '../services/historyService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import TrashIcon from './icons/TrashIcon';
import SearchIcon from './icons/SearchIcon';
import { useLanguage } from '../hooks/useLanguage';

interface HistoryViewProps {
  userId: string | null;
}

const HistoryView: React.FC<HistoryViewProps> = ({ userId }) => {
  const [generations, setGenerations] = useState<Generation[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [notification, setNotification] = useState<{message: string, type: 'success' | 'error'} | null>(null);
  const { t } = useLanguage();

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 3000);
  };

  const fetchHistory = useCallback(() => {
    setIsLoading(true);
    getGenerationsForUser(userId)
      .then(data => {
        setGenerations(data);
        setError(null);
      })
      .catch(() => setError("Failed to load generation history."))
      .finally(() => setIsLoading(false));
  }, [userId]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);
  
  const handleToggleExpand = (id: number) => {
    setExpandedId(prevId => (prevId === id ? null : id));
  };

  const handleDelete = async (generationId: number) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
        try {
            await deleteGeneration(generationId);
            setGenerations(prev => prev.filter(gen => gen.id !== generationId));
            showNotification('Item deleted from history');
        } catch (e) {
            setError('Failed to delete item.');
        }
    }
  };

  const handleClearAll = async () => {
    if (window.confirm('Are you sure you want to delete all history? This action cannot be undone.')) {
        try {
            await clearAllGenerationsForUser(userId);
            setGenerations([]);
            showNotification('History cleared successfully');
        } catch (e) {
            setError('Failed to clear history.');
        }
    }
  };
  
  const filteredGenerations = useMemo(() => {
    if (!searchTerm) return generations;
    const lowercasedFilter = searchTerm.toLowerCase();
    return generations.filter(gen =>
      gen.moduleName.toLowerCase().includes(lowercasedFilter) ||
      gen.output.toLowerCase().includes(lowercasedFilter) ||
      gen.inputs.toLowerCase().includes(lowercasedFilter)
    );
  }, [generations, searchTerm]);

  return (
    <div className="max-w-4xl mx-auto flex flex-col gap-4 animate-fade-in">
      <div className="text-left mb-4">
        <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{t('generationHistory')}</h2>
        <p className="text-md text-text-secondary dark:text-d-text-secondary mt-1">{t('historyDescription')}</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="relative flex-grow">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <SearchIcon className="h-5 w-5 text-text-secondary dark:text-d-text-secondary" />
              </span>
              <input 
                  type="text"
                  placeholder={t('searchHistory')}
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary"
              />
          </div>
          <button 
            onClick={handleClearAll}
            disabled={generations.length === 0}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-error/20 text-error font-semibold rounded-lg hover:bg-error/30 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
              <TrashIcon className="h-5 w-5" />
              {t('clearAll')} (<span id="historyCount">{generations.length}/30</span>)
          </button>
      </div>

      {isLoading ? (
        <div className="text-center text-text-secondary dark:text-d-text-secondary p-8">
            <svg className="animate-spin mx-auto h-8 w-8 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
            <p className="mt-2">{t('loadingHistory')}</p>
        </div>
      ) : error ? (
        <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>
      ) : filteredGenerations.length === 0 ? (
        <div className="text-center text-text-secondary dark:text-d-text-secondary py-16 bg-base-200 dark:bg-d-base-200 rounded-lg">
            <h3 className="text-lg font-semibold">{searchTerm ? t('noResultsSearch') : t('noResults')}</h3>
            {searchTerm && <p>Try adjusting your search term.</p>}
        </div>
      ) : (
          filteredGenerations.map(gen => (
            <HistoryItem 
              key={gen.id} 
              generation={gen} 
              isExpanded={expandedId === gen.id}
              onToggleExpand={() => handleToggleExpand(gen.id)}
              onDelete={() => handleDelete(gen.id)}
              showNotification={showNotification}
            />
          ))
      )}

      {notification && (
        <div className={`notification ${notification.type}`}>
            {notification.message}
        </div>
      )}
    </div>
  );
};

const HistoryItem: React.FC<{
  generation: Generation;
  isExpanded: boolean;
  onToggleExpand: () => void;
  onDelete: () => void;
  showNotification: (message: string, type?: 'success' | 'error') => void;
}> = ({ generation, isExpanded, onToggleExpand, onDelete, showNotification }) => {
    
    const handleCopy = useCallback((e: React.MouseEvent, text: string) => {
        e.stopPropagation();
        navigator.clipboard.writeText(text).then(() => {
            showNotification('Copied to clipboard!');
        }).catch(() => {
            showNotification('Failed to copy text.', 'error');
        });
    }, [showNotification]);
    
    const handleDeleteClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        onDelete();
    };

    return (
        <div className={`history-item ${isExpanded ? 'expanded' : ''} bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 border-l-4 border-brand-primary`}>
            <div className="p-4 cursor-pointer" onClick={onToggleExpand}>
                <div className="flex justify-between items-start">
                    <div>
                        <span className="module-badge">{generation.moduleName}</span>
                        <p className="text-xs text-text-secondary dark:text-d-text-secondary mt-2">{generation.timestamp}</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <button onClick={(e) => handleCopy(e, generation.output)} className="p-2 rounded-full hover:bg-base-300 dark:hover:bg-d-base-300 transition-colors"><CopyIcon className="h-5 w-5"/></button>
                        <button onClick={handleDeleteClick} className="p-2 rounded-full hover:bg-error/20 text-error transition-colors"><TrashIcon className="h-5 w-5"/></button>
                    </div>
                </div>
                <div className="history-content mt-2 text-sm text-text-primary dark:text-d-text-primary">{generation.output}</div>
            </div>
            {isExpanded && (
                <div className="border-t border-base-300 dark:border-d-base-300 p-4 animate-fade-in">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-text-secondary dark:text-d-text-secondary mb-2">Prompt Sent to AI</h4>
                    <pre className="text-xs bg-base-100 dark:bg-d-base-100 p-3 rounded-md whitespace-pre-wrap font-mono">{generation.inputs}</pre>
                </div>
            )}
        </div>
    )
}


export default HistoryView;