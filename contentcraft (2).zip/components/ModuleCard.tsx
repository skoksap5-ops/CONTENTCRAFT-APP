import React from 'react';
import type { Module } from '../types';
import ModuleIcon from './ModuleIcon';
import { useFeedback } from '../hooks/useFeedback';

interface ModuleCardProps {
  module: Module;
  onSelect: () => void;
}

const ModuleCard: React.FC<ModuleCardProps> = ({ module, onSelect }) => {
  const { playClick } = useFeedback();

  const handleSelect = () => {
    playClick();
    onSelect();
  };
  
  return (
    <button
      onClick={handleSelect}
      className="group bg-base-200 dark:bg-d-base-200 p-6 rounded-lg text-center h-full flex flex-col justify-center items-center hover:bg-base-300/70 dark:hover:bg-d-base-300/70 border border-base-300 dark:border-d-base-300 hover:border-brand-primary focus:outline-none focus:ring-2 focus:ring-brand-primary focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 transition-all duration-200 ease-in-out transform hover:-translate-y-1"
    >
      <ModuleIcon moduleId={module.id} />
      <div className="mt-6 text-center">
        <h3 className="text-lg font-semibold text-text-primary dark:text-d-text-primary mb-2 font-heading">{module.name}</h3>
        <p className="text-sm text-text-secondary dark:text-d-text-secondary">{module.description}</p>
      </div>
    </button>
  );
};

export default ModuleCard;
