import React, { useState } from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import EmailIcon from './icons/social/EmailIcon';
import { useLanguage } from '../hooks/useLanguage';

interface HelpViewProps {
  onClose: () => void;
}

const FAQItem: React.FC<{ question: string; children: React.ReactNode }> = ({ question, children }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="border-b border-base-300 dark:border-d-base-300 last:border-b-0">
            <button
                className="w-full flex justify-between items-center text-left p-4 hover:bg-base-300/20 dark:hover:bg-d-base-300/20"
                onClick={() => setIsOpen(!isOpen)}
                aria-expanded={isOpen}
            >
                <h4 className="font-semibold text-text-primary dark:text-d-text-primary">{question}</h4>
                <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && (
                <div className="p-4 pt-0 text-text-secondary dark:text-d-text-secondary animate-fade-in leading-relaxed">
                    {children}
                </div>
            )}
        </div>
    );
};

const HelpView: React.FC<HelpViewProps> = ({ onClose }) => {
    const { t } = useLanguage();
  return (
    <div className="fixed inset-0 bg-base-100 dark:bg-d-base-100 z-50 animate-fade-in-up overflow-y-auto" role="dialog" aria-modal="true">
      <header className="sticky top-0 bg-base-100/80 dark:bg-d-base-100/80 backdrop-blur-sm z-10 border-b border-base-300 dark:border-d-base-300">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-16 gap-4">
          <button
            onClick={onClose}
            className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-200"
            aria-label="Back to previous page"
          >
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">{t('helpSupport')}</h1>
        </div>
      </header>
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-3xl font-bold font-heading mb-6 text-text-primary dark:text-d-text-primary">{t('helpFaq')}</h2>
        
        <div className="bg-base-200 dark:bg-d-base-200 rounded-xl shadow-sm">
            <FAQItem question="How do I get more daily uses?">
                <p>You can earn free credits in a couple of ways:</p>
                <ul className="list-disc list-inside space-y-2 my-2">
                    <li><strong>Daily Streak:</strong> Open the app for 7 consecutive days to automatically receive <strong>+1 free credit</strong>.</li>
                    <li><strong>Sharing:</strong> Go to your profile and tap on "Share App". You can earn up to <strong>2 free credits each day</strong> for sharing on social media (+1 credit per share).</li>
                </ul>
                <p>For unlimited uses, you can upgrade to Craft Pro. Look for the "Upgrade to Craft Pro" banner on your profile page.</p>
            </FAQItem>
            <FAQItem question="Is my data safe?">
                <p>Yes, we take your privacy seriously. The content you generate is processed in real-time and is not permanently stored on our servers linked to your identity. Your generation history is stored locally on your device's browser. For more details, please read our Privacy Policy.</p>
            </FAQItem>
            <FAQItem question="What is 'Human Warmth' or 'Corporate Polish'?">
                <p>These are Core Modules designed to refine your text's tone. 'Human Warmth' adds a natural, friendly touch, while 'Corporate Polish' refines text to meet high professional standards. You can combine these with our detailed Tone Selector for even more control.</p>
            </FAQItem>
            <FAQItem question="The app is not working offline. What should I do?">
                <p>ContentCraft supports offline functionality. If you generate content while offline, your request is automatically queued. When you reconnect to the internet, the queue will be processed, and you'll receive a notification when your content is ready. Make sure you have granted notification permissions for this to work best.</p>
            </FAQItem>
             <FAQItem question="How do I use the AI Prompt Generator?">
                <p>The AI Prompt Generator is a powerful tool to help you get the best results from AI models like ChatGPT or Midjourney.</p>
                <ol className="list-decimal list-inside space-y-1 mt-2">
                    <li>Go to the "Create Prompt" tab.</li>
                    <li>Describe your goal, add any important context, and specify the desired output format.</li>
                    <li>The AI will generate a detailed, effective prompt for you, including an advanced 'optimized' version.</li>
                    <li>You can then copy this prompt and use it in your chosen AI tool.</li>
                </ol>
            </FAQItem>
        </div>

        <div className="mt-12 text-center">
            <h3 className="text-xl font-bold font-heading text-text-primary dark:text-d-text-primary">{t('stillNeedHelp')}</h3>
            <p className="text-text-secondary dark:text-d-text-secondary mt-2 mb-4">{t('supportTeamReady')}</p>
            <a 
                href="mailto:Contentcraft.free.nf@gmail.com" 
                className="inline-flex items-center gap-2 px-6 py-3 bg-brand-primary text-white font-semibold rounded-xl shadow-md hover:bg-brand-primary/90 transition-colors"
            >
                <EmailIcon className="h-5 w-5" />
                {t('contactSupport')}
            </a>
        </div>
      </main>
    </div>
  );
};

export default HelpView;