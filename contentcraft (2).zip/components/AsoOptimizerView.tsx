import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import Rating from './Rating';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

const AppleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}><title>Apple</title><path d="M12.152 6.896c-.948 0-2.415-1.078-3.96-1.04-2.04.027-3.91 1.183-4.961 3.014-1.293 2.235-.433 5.474 1.058 7.526 1.013 1.393 2.143 2.943 3.633 2.916 1.44-.026 1.93-1.04 3.842-1.04 1.884 0 2.335 1.04 3.841 1.04 1.52 0 2.573-1.42 3.585-2.888 1.18-1.703 1.315-3.36.108-4.98-1.522-2.02-3.43-3.22-5.32-3.25-1.88-.027-3.32 1.077-3.841 1.077zM13.648 3.687c.728-.888 1.324-2.124 1.162-3.334-.99.053-2.336.68-3.138 1.54-.74.803-1.41 2.067-1.259 3.25.99.106 2.275-.568 3.235-1.456z"/></svg>
);

const AndroidIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="currentColor" {...props}><title>Android</title><path d="M17.424 6.06l1.837-1.838a.494.494 0 00-.7-.7L16.724 5.36a10.02 10.02 0 00-9.45 0L5.438 3.522a.494.494 0 00-.7.7L6.576 6.06A10.035 10.035 0 004 13.5v.5h16v-.5a10.035 10.035 0 00-2.576-7.44zM8.5 15.5a1 1 0 110-2 1 1 0 010 2zm7 0a1 1 0 110-2 1 1 0 010 2z"/></svg>
);


type AsoTask = 'appName' | 'subtitle' | 'longDesc' | 'keywords' | 'visuals' | 'releaseNotes' | 'reviews' | 'unified';

const ASO_TASK_OPTIONS: { value: AsoTask; label: string }[] = [
    { value: 'appName', label: 'App Name & Title Optimizer' },
    { value: 'subtitle', label: 'Subtitle & Short Description' },
    { value: 'longDesc', label: 'Long Description Optimizer' },
    { value: 'keywords', label: 'Keyword Research & Strategy' },
    { value: 'visuals', label: 'Screenshot & Visuals Copy' },
    { value: 'releaseNotes', label: 'Release Notes Optimizer' },
    { value: 'reviews', label: 'Rating & Review Responses' },
    { value: 'unified', label: 'Unified ASO Report (All-in-One)' },
];

const LONG_DESCRIPTION_PROMPT = `You are a master ASO copywriter. Create engaging, keyword-rich long descriptions that convert visitors into users.\n\n**INPUT:**\n- App Features: {APP_FEATURES}\n- Target Keywords: {PRIMARY_SECONDARY_KEYWORDS}\n- User Benefits: {USER_BENEFITS}\n- Competitor Analysis: {COMPETITOR_INSIGHTS}\n- Character Limits: 4000 chars optimal\n- Tone: {SELECTED_TONES}\n\n**OUTPUT FORMAT:**\n**GOOGLE PLAY & APP STORE LONG DESCRIPTION:**\n\n[Emoji] **Catchy Headline with Primary Keyword**\n\n✨ **Key Benefit 1:** [Description with secondary keyword]\n🚀 **Key Benefit 2:** [Description with secondary keyword]\n🎯 **Key Benefit 3:** [Description with secondary keyword]\n\n📱 **Main Features:**\n• [Feature 1] - [Benefit explanation]\n• [Feature 2] - [Benefit explanation]\n• [Feature 3] - [Benefit explanation]\n\n⭐ **Why Users Love Us:**\n[Social proof elements]\n\n**Download Now and [Main Benefit]!**`;
const ASO_KEYWORD_PROMPT = `You are an ASO keyword research expert. Analyze and recommend the best keywords for app store optimization.\n\n**INPUT:**\n- App Category: {APP_CATEGORY}\n- Core Functionality: {APP_FUNCTION}\n- Target Audience: {TARGET_AUDIENCE}\n- Competitor Apps: {COMPETITOR_APPS}\n- Current Keywords: {CURRENT_KEYWORDS}\n\n**OUTPUT FORMAT:**\n**PRIMARY KEYWORD RECOMMENDATIONS:**\n1. [Keyword 1] - Volume: [High/Med/Low], Difficulty: [Score], Intent: [Informational/Transactional]\n2. [Keyword 2] - Volume: [High/Med/Low], Difficulty: [Score], Intent: [Informational/Transactional]\n3. [Keyword 3] - Volume: [High/Med/Low], Difficulty: [Score], Intent: [Informational/Transactional]\n\n**SECONDARY KEYWORD SUGGESTIONS:**\n- Feature-based: [List]\n- Benefit-based: [List]\n\n**COMPETITOR KEYWORD ANALYSIS:**\n- [Competitor 1]: [Key keywords used]\n- Gaps Identified: [Opportunities]`;
const SCREENSHOT_COPY_PROMPT = `You are an ASO visual optimization expert. Create compelling copy for app screenshots and visual assets.\n\n**INPUT:**\n- App Screenshots (Descriptions): {SCREENSHOT_DESCRIPTIONS}\n- Key Features: {KEY_FEATURES}\n- User Benefits: {USER_BENEFITS}\n- Tone: {SELECTED_TONES}\n\n**OUTPUT FORMAT:**\n**SCREENSHOT CAPTIONS (8-10 options):**\n1. **Screenshot 1 - [Feature]:** [Caption 1] - [Benefit focus]\n2. **Screenshot 2 - [Feature]:** [Caption 2] - [Benefit focus]\n3. **Screenshot 3 - [Feature]:** [Caption 3] - [Benefit focus]\n\n**SOCIAL PROOF ELEMENTS:**\n- "Join [X]+ satisfied users"\n- "Rated [X] stars by [Y] users"\n\n**CALL-TO-ACTION VARIATIONS:**\n- "Get Started Free"\n- "Download Now"`;
const RELEASE_NOTES_PROMPT = `Create compelling app update descriptions that drive re-engagement and positive reviews.\n\n**INPUT:**\n- Update Features: {NEW_FEATURES}\n- Bug Fixes: {BUG_FIXES}\n- Improvements: {IMPROVEMENTS}\n- Tone: {SELECTED_TONES}\n\n**OUTPUT:**\n- User-focused benefit descriptions\n- Emotional engagement triggers\n- Clear value propositions\n- Call-to-action for updates`;
const REVIEW_RESPONSE_PROMPT = `Generate professional, brand-appropriate responses to app store reviews.\n\n**INPUT:**\n- Review Content: {REVIEW_TEXT}\n- Review Rating: {RATING}\n- App Context: {APP_CONTEXT}\n- Tone: {SELECTED_TONES}\n\n**OUTPUT:**\n- Positive review responses (encourage more reviews)\n- Negative review responses (damage control & solutions)`;

const AsoOptimizerView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [task, setTask] = useState<AsoTask>('appName');
    const [platform, setPlatform] = useState<'app-store' | 'google-play'>('app-store');
    const [output, setOutput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [copySuccess, setCopySuccess] = useState(false);
    const [isQueued, setIsQueued] = useState(false);
    
    // Inputs
    const [mainInput, setMainInput] = useState('');
    const [keywords, setKeywords] = useState('');
    const [secondaryInput, setSecondaryInput] = useState('');
    const [tertiaryInput, setTertiaryInput] = useState('');
    const [reviewRating, setReviewRating] = useState(5);

    // Tone selector state
    const [tones, setTones] = useState<string[]>([]);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && mainInput.trim();

    const getPrompt = useCallback(() => {
        const platformName = platform === 'app-store' ? 'Apple App Store' : 'Google Play Store';
        const appNameLimit = platform === 'app-store' ? 30 : 50;
        const subtitleName = platform === 'app-store' ? 'Subtitle' : 'Short Description';
        const subtitleLimit = platform === 'app-store' ? 30 : 80;

        const DYNAMIC_APP_NAME_PROMPT = `You are an expert ASO (App Store Optimization) specialist. Generate 3-5 compelling and optimized app names/titles for the ${platformName}.\n\n**INPUT:**\n- App Core Function: {APP_FUNCTION}\n- Primary Keywords: {PRIMARY_KEYWORDS}\n- Target Audience: {TARGET_AUDIENCE}\n- Brand Name: {BRAND_NAME}\n- Character Limit: ${appNameLimit} characters\n- Tone: {SELECTED_TONES}\n\n**OUTPUT FORMAT:**\n**${platformName.toUpperCase()} OPTIONS (${appNameLimit} chars max):**\n1. [Option 1 - X characters] - [Key benefit/strategy]\n2. [Option 2 - X characters] - [Key benefit/strategy]\n3. [Option 3 - X characters] - [Key benefit/strategy]\n\n**KEYWORD ANALYSIS:**\n- Primary Keyword Placement: [Analysis]\n- Search Volume Potential: [High/Medium/Low]\n\n**RECOMMENDATIONS:**\n- Best Overall: [Option X] - [Reason]`;
        
        const DYNAMIC_APP_SUBTITLE_PROMPT = `You are an ASO conversion expert. Create 3 compelling ${subtitleName}s that drive installs for the ${platformName}.\n\n**INPUT:**\n- App Core Value: {APP_VALUE}\n- Target Keywords: {TARGET_KEYWORDS}\n- Unique Selling Points: {USP}\n- Character Limit: ${subtitleLimit} chars\n- Tone: {SELECTED_TONES}\n\n**OUTPUT FORMAT:**\n**${platformName.toUpperCase()} ${subtitleName.toUpperCase()} OPTIONS (${subtitleLimit} chars max):**\n1. [Option 1 - X characters] - [Conversion strategy]\n2. [Option 2 - X characters] - [Conversion strategy]\n3. [Option 3 - X characters] - [Conversion strategy]\n\n**KEYWORD INTEGRATION:**\n- Keywords Included: [List]\n- Conversion Potential: [High/Medium/Low]`;
        
        const DYNAMIC_UNIFIED_PROMPT = `You are ContentCraft's complete ASO optimization engine. Provide a comprehensive App Store Optimization in one integrated response tailored for the ${platformName}.\n\n**INPUT:**\n- App Name/Function: {APP_FUNCTION}\n- Primary Keywords: {PRIMARY_KEYWORDS}\n- Target Audience: {TARGET_AUDIENCE}\n- Key Features: {APP_FEATURES}\n- User Benefits: {USER_BENEFITS}\n- Competitor Insights: {COMPETITOR_INSIGHTS}\n- Tone: {SELECTED_TONES}\n\n**DELIVERABLES:**\n1. **APP NAME/TITLE**\n2. **SUBTITLE/SHORT DESC**\n3. **LONG DESCRIPTION**\n4. **KEYWORD STRATEGY**\n5. **VISUAL COPY**\n\n**OUTPUT FORMAT:**\n[Follow the specific formats from each individual prompt above, combined into one comprehensive ASO report]`;
        
        const PROMPTS: Record<AsoTask, string> = {
            appName: DYNAMIC_APP_NAME_PROMPT,
            subtitle: DYNAMIC_APP_SUBTITLE_PROMPT,
            longDesc: LONG_DESCRIPTION_PROMPT,
            keywords: ASO_KEYWORD_PROMPT,
            visuals: SCREENSHOT_COPY_PROMPT,
            releaseNotes: RELEASE_NOTES_PROMPT,
            reviews: REVIEW_RESPONSE_PROMPT,
            unified: DYNAMIC_UNIFIED_PROMPT,
        };

        let prompt = PROMPTS[task];

        return prompt
            .replace(/{SELECTED_TONES}/g, tones.length ? tones.join(', ') : 'neutral')
            .replace(/{APP_FUNCTION}/g, mainInput)
            .replace(/{PRIMARY_KEYWORDS}/g, keywords)
            .replace(/{TARGET_AUDIENCE}/g, secondaryInput)
            .replace(/{BRAND_NAME}/g, tertiaryInput)
            .replace(/{APP_VALUE}/g, mainInput)
            .replace(/{TARGET_KEYWORDS}/g, keywords)
            .replace(/{USP}/g, secondaryInput)
            .replace(/{APP_FEATURES}/g, mainInput)
            .replace(/{PRIMARY_SECONDARY_KEYWORDS}/g, keywords)
            .replace(/{USER_BENEFITS}/g, secondaryInput)
            .replace(/{COMPETITOR_INSIGHTS}/g, tertiaryInput)
            .replace(/{APP_CATEGORY}/g, mainInput)
            .replace(/{COMPETITOR_APPS}/g, secondaryInput)
            .replace(/{CURRENT_KEYWORDS}/g, keywords)
            .replace(/{SCREENSHOT_DESCRIPTIONS}/g, mainInput)
            .replace(/{KEY_FEATURES}/g, secondaryInput)
            .replace(/{NEW_FEATURES}/g, mainInput)
            .replace(/{BUG_FIXES}/g, secondaryInput)
            .replace(/{IMPROVEMENTS}/g, tertiaryInput)
            .replace(/{REVIEW_TEXT}/g, mainInput)
            .replace(/{RATING}/g, `${reviewRating} star(s)`)
            .replace(/{APP_CONTEXT}/g, secondaryInput);
    }, [mainInput, keywords, secondaryInput, tertiaryInput, reviewRating, task, tones, platform]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setIsQueued(false);

        const prompt = getPrompt();

        // Offline logic
        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') {
                    const permission = await Notification.requestPermission();
                    if (permission !== 'granted') {
                        setError("Notification permission is required to queue offline requests.");
                        setIsLoading(false);
                        return;
                    }
                }
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        // Online logic
        try {
            const result = await generateContent(prompt);
            setOutput(result);
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name]);

    const handleCopy = () => {
        if (!output) return;
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = output.replace(/<br\s*\/?>/gi, '\n');
        navigator.clipboard.writeText(tempDiv.textContent || "").then(() => {
            setCopySuccess(true);
            setTimeout(() => setCopySuccess(false), 2000);
        });
    };
    
    const formatOutput = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        const sanitized = text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
        return { __html: sanitized
            .replace(/\*\*(.*?)\*\*/g, '<strong class="text-brand-primary">$1</strong>')
            .replace(/(\✅|✨|🚀|🎯|⭐|💡)/g, '<span class="mr-2">$1</span>')
            .replace(/^(GOOGLE PLAY OPTIONS|APP STORE OPTIONS|KEYWORD ANALYSIS|RECOMMENDATIONS|APP STORE SUBTITLE OPTIONS|GOOGLE PLAY SHORT DESCRIPTION|KEYWORD INTEGRATION|PERFORMANCE TIPS|GOOGLE PLAY & APP STORE LONG DESCRIPTION|PRIMARY KEYWORD RECOMMENDATIONS|SECONDARY KEYWORD SUGGESTIONS|COMPETITOR KEYWORD ANALYSIS|STRATEGIC RECOMMENDATIONS|SCREENSHOT CAPTIONS|SOCIAL PROOF ELEMENTS|CALL-TO-ACTION VARIATIONS)/gm, '<h4 class="text-lg font-semibold text-text-primary dark:text-d-text-primary mt-4 mb-2">$1</h4>')
            .replace(/\n/g, '<br />')
        };
    };

    const commonTextareaClasses = "w-full p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    const getInputConfig = () => {
        switch(task) {
            case 'appName': return { main: 'App Core Function', kw: 'Primary Keywords', sec: 'Target Audience', tert: 'Brand Name (optional)' };
            case 'subtitle': return { main: 'App Core Value', kw: 'Target Keywords', sec: 'Unique Selling Points', tert: null };
            case 'longDesc': return { main: 'App Features (list)', kw: 'Target Keywords', sec: 'User Benefits (list)', tert: 'Competitor Insights (optional)' };
            case 'keywords': return { main: 'App Category', kw: 'Current Keywords (optional)', sec: 'Competitor Apps (comma-separated)', tert: null, mainOverride: 'Core Functionality' };
            case 'visuals': return { main: 'Screenshot Descriptions (list)', kw: null, sec: 'Key Features', tert: 'User Benefits' };
            case 'releaseNotes': return { main: 'New Features', kw: null, sec: 'Bug Fixes', tert: 'Other Improvements' };
            case 'reviews': return { main: 'Review Content', kw: null, sec: 'App Context (optional)', tert: null, showRating: true };
            case 'unified': return { main: 'App Core Function', kw: 'Primary Keywords', sec: 'Key Features & Benefits', tert: 'Competitor Insights' };
            default: return { main: 'Input', kw: null, sec: null, tert: null };
        }
    }
    const { main, kw, sec, tert, showRating, mainOverride } = getInputConfig();

    return (
        <>
            <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
                <div className="text-center">
                    <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                    <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="asoTask" className={commonLabelClasses}>Select ASO Task</label>
                            <select id="asoTask" value={task} onChange={e => setTask(e.target.value as AsoTask)} className={commonInputClasses}>
                               {ASO_TASK_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                            </select>
                        </div>

                        <div>
                            <label className={commonLabelClasses}>Target Store</label>
                            <div className="grid grid-cols-2 gap-2 bg-base-100 dark:bg-d-base-100 p-1 rounded-lg border border-base-300 dark:border-d-base-300">
                                <button type="button" onClick={() => setPlatform('app-store')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${platform === 'app-store' ? 'bg-brand-primary text-white shadow' : 'text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-200'}`}>
                                    <AppleIcon className="h-5 w-5" /> App Store
                                </button>
                                <button type="button" onClick={() => setPlatform('google-play')} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${platform === 'google-play' ? 'bg-brand-primary text-white shadow' : 'text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-200'}`}>
                                    <AndroidIcon className="h-5 w-5" /> Google Play
                                </button>
                            </div>
                        </div>

                        <textarea value={mainInput} onChange={e => setMainInput(e.target.value)} placeholder={`Enter ${main}...`} className={commonTextareaClasses} style={{minHeight: '150px'}}/>
                        
                        <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                           {mainOverride && (<div><label className={commonLabelClasses}>{mainOverride}</label><input type="text" value={secondaryInput} onChange={e => setSecondaryInput(e.target.value)} placeholder={`Enter ${mainOverride}...`} className={commonInputClasses} /></div>)}
                           {kw && (<div><label className={commonLabelClasses}>{kw}</label><input type="text" value={keywords} onChange={e => setKeywords(e.target.value)} placeholder="e.g. photo editor, filters" className={commonInputClasses} /></div>)}
                           {sec && !mainOverride && (<div><label className={commonLabelClasses}>{sec}</label><input type="text" value={secondaryInput} onChange={e => setSecondaryInput(e.target.value)} placeholder={`Enter ${sec}...`} className={commonInputClasses} /></div>)}
                           {tert && (<div><label className={commonLabelClasses}>{tert}</label><input type="text" value={tertiaryInput} onChange={e => setTertiaryInput(e.target.value)} placeholder={`Enter ${tert}...`} className={commonInputClasses} /></div>)}
                           {showRating && (<div><label className={commonLabelClasses}>Review Rating</label><Rating rating={reviewRating} onRatingChange={setReviewRating} /></div>)}
                        </div>

                        <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                            <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                        </button>
                        
                        <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                            {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                            {isLoading ? 'Generating...' : (isQueued ? 'Request Queued' : 'Run ASO Task')}
                        </button>
                        {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                        {!canGenerate && !isQueued && mainInput.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                    </div>
                    <div className="relative">
                        <div className={`${commonTextareaClasses} bg-base-200/50 dark:bg-d-base-200/50 min-h-[500px] overflow-y-auto leading-relaxed`}>
                            {isLoading && <p className="text-text-secondary dark:text-d-text-secondary">Generating report...</p>}
                            {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary">Your AI-crafted ASO report will appear here...</p>}
                            {output && <div dangerouslySetInnerHTML={formatOutput(output)} />}
                        </div>
                        {output && !isLoading && <button onClick={handleCopy} className="absolute top-3 right-3 p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label="Copy to clipboard"><CopyIcon className="h-5 w-5" /></button>}
                        {copySuccess && <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-success text-white text-xs px-3 py-1 rounded-full animate-fade-in">Copied!</div>}
                    </div>
                </div>
                {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
            </div>
            <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default AsoOptimizerView;