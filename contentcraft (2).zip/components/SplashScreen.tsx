import React, { useState, useEffect } from 'react';

const Fireworks: React.FC = () => {
  const particles = [];
  const numExplosions = 8; // Reduced for performance
  const particlesPerExplosion = 35; // Reduced for performance

  for (let i = 0; i < numExplosions; i++) {
    const explosionTop = `${10 + Math.random() * 80}%`;
    const explosionLeft = `${10 + Math.random() * 80}%`;
    const hue = Math.random() * 360;
    const animationDelayBase = Math.random() * 5; // Spread out explosions

    for (let j = 0; j < particlesPerExplosion; j++) {
      const angle = Math.random() * 360;
      const radius = 60 + Math.random() * 180;
      const x = Math.cos(angle * Math.PI / 180) * radius;
      const y = Math.sin(angle * Math.PI / 180) * radius;
      const size = 2 + Math.random() * 3;
      
      particles.push(
        <div
          key={`${i}-${j}`}
          className="particle"
          style={{
            top: explosionTop,
            left: explosionLeft,
            '--x': `${x}px`,
            '--y': `${y}px`,
            width: `${size}px`,
            height: `${size}px`,
            backgroundColor: `hsl(${hue}, 100%, 70%)`,
            // boxShadow removed for performance optimization
            animationDelay: `${animationDelayBase + Math.random() * 0.5}s`,
            animationDuration: `${0.9 + Math.random() * 0.5}s`
          } as React.CSSProperties}
        />
      );
    }
  }
  return <div className="fireworks" aria-hidden="true">{particles}</div>;
};

const SplashScreen: React.FC = () => {
  const [isFadingOut, setIsFadingOut] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsFadingOut(true);
    }, 5500); // Start fade-out 500ms before it disappears

    return () => clearTimeout(timer);
  }, []);

  const cubeFaceClasses = "absolute w-48 h-48 bg-base-200 dark:bg-d-base-200 border-2 border-brand-primary/50 flex items-center justify-center shadow-2xl shadow-brand-primary/20";
  const cubeTextClasses = "font-heading text-2xl font-bold text-text-primary dark:text-d-text-primary tracking-wider text-center";


  return (
    <div className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-base-100 dark:bg-d-base-100 transition-opacity duration-500 ${isFadingOut ? 'animate-fade-out' : 'opacity-100'}`}>
      <Fireworks />
      <div className="perspective-1000">
        <div className="relative w-48 h-48 animate-rotate-3d" style={{ transformStyle: 'preserve-3d', willChange: 'transform' }}>
          {/* Cube Faces */}
          <div className={cubeFaceClasses} style={{ transform: 'rotateY(0deg) translateZ(96px)'}}>
            <h2 className={cubeTextClasses}>CONTENT<br/>CRAFT</h2>
          </div>
          <div className={cubeFaceClasses} style={{ transform: 'rotateY(90deg) translateZ(96px)'}}>
             {/* Intentionally blank */}
          </div>
          <div className={cubeFaceClasses} style={{ transform: 'rotateY(180deg) translateZ(96px)'}}>
            <h2 className={cubeTextClasses}>CONTENT<br/>CRAFT</h2>
          </div>
          <div className={cubeFaceClasses} style={{ transform: 'rotateY(-90deg) translateZ(96px)'}}>
             {/* Intentionally blank */}
          </div>
          <div className={cubeFaceClasses} style={{ transform: 'rotateX(90deg) translateZ(96px)' }}></div>
          <div className={cubeFaceClasses} style={{ transform: 'rotateX(-90deg) translateZ(96px)' }}></div>
        </div>
      </div>
      <div className="mt-16 text-center animate-fade-in-up" style={{ animationDelay: '0.5s', opacity: 0 }}>
        <h1 className="text-4xl sm:text-5xl font-bold text-text-primary dark:text-d-text-primary tracking-tight font-heading">
          CONTENT<span className="text-brand-primary">CRAFT</span>
        </h1>
        <p className="text-text-secondary dark:text-d-text-secondary mt-2">Powered by NOVA SKY</p>
      </div>
    </div>
  );
};

export default SplashScreen;
