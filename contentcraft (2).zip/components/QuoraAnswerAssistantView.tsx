import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface AnswerVariation {
    title: string;
    content: string;
    analysis: string;
}

interface ParsedOutput {
    answerVariations: AnswerVariation[];
    performanceAnalysis: {
        helpfulness: number;
        authority: number;
        engagement: number;
    };
    authorityStrategy: string;
    engagementStrategy: string;
}

const QUORA_ANSWER_PROMPT = `
You are an expert Quora contributor and authority builder. Your task is to transform a user's expertise into a comprehensive, high-performing Quora answer package.

**INPUT:**
- Question to Answer: {QUESTION}
- Your Expertise/Role: {EXPERTISE}
- Key Points to Include: {KEY_POINTS}
- Primary Goal for the Answer: {ANSWER_GOAL}
- Desired Tones: {TONES}

**INSTRUCTIONS:**
1.  Generate 3 distinct answer variations (e.g., 'Direct & Practical', 'Story-Driven', 'Framework-Based').
2.  For each answer, include a brief analysis of its strategic approach.
3.  Provide a detailed performance analysis with scores for Helpfulness, Authority, and Engagement.
4.  Suggest strategies for building authority and optimizing for the Quora algorithm based on this answer.
5.  Generate a complete, valid JSON object that conforms to the provided schema. The \`content\` fields should use markdown for formatting (\\n for line breaks, ** for bold, • for lists).
`;

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        answerVariations: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    content: { type: Type.STRING },
                    analysis: { type: Type.STRING }
                },
                required: ['title', 'content', 'analysis']
            }
        },
        performanceAnalysis: {
            type: Type.OBJECT,
            properties: {
                helpfulness: { type: Type.NUMBER },
                authority: { type: Type.NUMBER },
                engagement: { type: Type.NUMBER }
            },
            required: ['helpfulness', 'authority', 'engagement']
        },
        authorityStrategy: {
            type: Type.STRING,
            description: "Actionable tips on how to build authority with this answer."
        },
        engagementStrategy: {
            type: Type.STRING,
            description: "Tips on how to optimize this answer for Quora's algorithm and community engagement."
        }
    },
    required: ['answerVariations', 'performanceAnalysis', 'authorityStrategy', 'engagementStrategy']
};


const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};

const ScoreBar: React.FC<{ score: number; label: string }> = ({ score, label }) => (
  <div>
    <div className="flex justify-between items-center mb-1">
      <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">{label}</span>
      <span className="text-sm font-bold text-text-primary dark:text-d-text-primary">{score}/10</span>
    </div>
    <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2">
      <div className="bg-brand-primary h-2 rounded-full transition-all duration-500" style={{ width: `${score * 10}%` }}></div>
    </div>
  </div>
);

const QuoraAnswerAssistantView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [question, setQuestion] = useState('');
    const [expertise, setExpertise] = useState('');
    const [keyPoints, setKeyPoints] = useState('');
    const [answerGoal, setAnswerGoal] = useState('');
    const [tones, setTones] = useState<string[]>([]);
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && question.trim() && expertise.trim();
    
    const getPrompt = useCallback(() => {
        return QUORA_ANSWER_PROMPT
            .replace('{QUESTION}', question)
            .replace('{EXPERTISE}', expertise)
            .replace('{KEY_POINTS}', keyPoints || 'Not specified')
            .replace('{ANSWER_GOAL}', answerGoal || 'Not specified')
            .replace('{TONES}', tones.length > 0 ? tones.join(', ') : 'Authoritative, Helpful');
    }, [question, expertise, keyPoints, answerGoal, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId && parsed.answerVariations?.[0]?.content) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: parsed.answerVariations[0].content,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse content: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);
    
    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };

    const AnswerCard: React.FC<{variation: AnswerVariation}> = ({ variation }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            navigator.clipboard.writeText(variation.content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        return (
            <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg shadow-sm relative">
                <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{variation.title}</h4>
                <p className="text-xs text-text-secondary dark:text-d-text-secondary mb-3">{variation.analysis}</p>
                <pre className="text-text-primary dark:text-d-text-primary whitespace-pre-wrap font-sans text-sm leading-relaxed">{variation.content}</pre>
                <button onClick={handleCopy} className="absolute top-3 right-3 p-2 rounded-lg bg-base-200 dark:bg-d-base-200 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label="Copy post content">
                    <CopyIcon className="h-5 w-5" />
                </button>
                {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        )
    };

    const commonTextareaClasses = "w-full min-h-[100px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={question} onChange={e => setQuestion(e.target.value)} placeholder="What is the Quora question you want to answer?" className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Answer Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Your Expertise/Role</label>
                                <input value={expertise} onChange={e => setExpertise(e.target.value)} placeholder="e.g., Remote work consultant" className={commonInputClasses} />
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Primary Goal for Answer</label>
                                <input value={answerGoal} onChange={e => setAnswerGoal(e.target.value)} placeholder="e.g., Provide practical solutions" className={commonInputClasses} />
                            </div>
                       </div>
                       <div>
                            <label className={commonLabelClasses}>Key Points to Include (optional)</label>
                            <input value={keyPoints} onChange={e => setKeyPoints(e.target.value)} placeholder="e.g., Time blocking, digital hygiene" className={commonInputClasses} />
                        </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Drafting Answer...' : (isQueued ? 'Request Queued' : 'Generate Quora Answer')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please enter a question and your expertise.</p>}
                </div>

                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Drafting your authoritative answer...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your expert-crafted Quora answer and analysis will appear here.</p>}
                    {parsedOutput && (
                        <div className="space-y-6">
                             <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Answer Variations</h3>
                                {parsedOutput.answerVariations.map((v, i) => <AnswerCard key={i} variation={v} />)}
                            </div>
                            
                            <div className="space-y-2">
                                <Accordion title="📊 Performance Analysis" defaultOpen={true}>
                                    <div className="space-y-4 p-2">
                                        <ScoreBar score={parsedOutput.performanceAnalysis.helpfulness} label="Helpfulness" />
                                        <ScoreBar score={parsedOutput.performanceAnalysis.authority} label="Authority" />
                                        <ScoreBar score={parsedOutput.performanceAnalysis.engagement} label="Engagement" />
                                    </div>
                                </Accordion>
                                <Accordion title="🚀 Authority Building Strategy">
                                    <div className="p-2" dangerouslySetInnerHTML={formatContent(parsedOutput.authorityStrategy)} />
                                </Accordion>
                                <Accordion title="📈 Engagement & Algorithm Strategy">
                                    <div className="p-2" dangerouslySetInnerHTML={formatContent(parsedOutput.engagementStrategy)} />
                                </Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default QuoraAnswerAssistantView;