import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import { useFeedback } from '../hooks/useFeedback';
import { Type } from '@google/genai';

// Icons
import CopyIcon from './icons/CopyIcon';
import SparklesIcon from './icons/settings/SparklesIcon';
import BroomIcon from './icons/core/BroomIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface CleanedAnalysis {
    ai_probability: number;
    pattern_score: number;
    watermark_score: number;
    human_likeness: number;
    detected_markers: string[];
}

interface ParsedOutput {
    analysis: CleanedAnalysis;
    cleaned_content: string;
}

const cleanPasteSchema = {
    type: Type.OBJECT,
    properties: {
        analysis: {
            type: Type.OBJECT,
            properties: {
                ai_probability: { type: Type.NUMBER },
                pattern_score: { type: Type.NUMBER },
                watermark_score: { type: Type.NUMBER },
                human_likeness: { type: Type.NUMBER },
                detected_markers: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ['ai_probability', 'pattern_score', 'watermark_score', 'human_likeness', 'detected_markers']
        },
        cleaned_content: { type: Type.STRING }
    },
    required: ['analysis', 'cleaned_content']
};

const CleanPasteView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const { playClick, playSuccess } = useFeedback();

    const [inputText, setInputText] = useState('');
    const [selectedLevel, setSelectedLevel] = useState('standard');
    const [selectedProcessing, setSelectedProcessing] = useState(['rewrite', 'metadata', 'patterns', 'variation']);
    const [contentType, setContentType] = useState('general');
    const [activeTab, setActiveTab] = useState('analysis');
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && inputText.trim();

    const handleClean = useCallback(async () => {
        if (!canGenerate) return;
        playClick();
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);

        const prompt = `You are an expert in AI text detection and humanization. Your task is to analyze a piece of AI-generated text, clean it to sound more human, and provide a report.

        **USER INPUT:**
        - Original Text: ${inputText}
        - Desired Cleaning Level: ${selectedLevel}
        - Processing Options: ${selectedProcessing.join(', ')}
        - Content Type: ${contentType}

        **INSTRUCTIONS:**
        1.  **Analyze the Original Text:** Based on the provided text, simulate an "AI Detection Analysis". Provide percentage scores for AI Probability, AI Patterns, Watermarks, and Human Likeness. Also, list 5 specific AI writing markers you "detected".
        2.  **Clean the Content:** Rewrite the original text to make it sound human-written, applying the user's specified cleaning level and processing options.
        3.  **Return a JSON object:** Your response MUST be a single, valid JSON object that conforms to the provided schema. Do not include any text outside of the JSON object.`;

        try {
            const result = await generateContent(prompt, {
                responseMimeType: 'application/json',
                responseSchema: cleanPasteSchema as any,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            setActiveTab('analysis');
            playSuccess();
            
            if (userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: `Cleaned content with level: ${selectedLevel}`,
                    output: parsed.cleaned_content,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();

        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, inputText, selectedLevel, selectedProcessing, contentType, playClick, playSuccess, module, userId, usesLeft, decrementUse]);

    const detectionLevels = [
        { id: 'standard', name: 'Standard Clean', icon: '🛡️', desc: 'Remove basic AI patterns' },
        { id: 'advanced', name: 'Advanced Purge', icon: '👻', desc: 'Deep AI signature removal' },
        { id: 'stealth', name: 'Stealth Mode', icon: '🕵️', desc: 'Maximum humanization' },
    ];
    
    const ResultCard: React.FC<{ value: number; label: string; }> = ({ value, label }) => {
        const colorClass = value >= 70 ? 'high' : value >= 40 ? 'medium' : 'low';
        return (
            <div className="result-card bg-base-100 dark:bg-d-base-100 p-4 rounded-lg text-center">
                <div className={`result-value text-2xl font-bold ${colorClass}`}>{value}%</div>
                <div className="result-label text-xs mt-1 text-text-secondary dark:text-d-text-secondary">{label}</div>
            </div>
        );
    };

    return (
        <div className="clean-paste-module max-w-7xl mx-auto flex flex-col gap-8">
            <header className="text-center">
                <h1 className="text-3xl font-bold font-heading">{module.name}</h1>
                <p className="subtitle text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </header>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <section className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-6">
                    <div className="section-title flex items-center gap-4">
                        <div className="section-icon w-12 h-12 flex items-center justify-center rounded-xl text-white"><BroomIcon className="h-6 w-6"/></div>
                        <h2 className="text-2xl font-bold font-heading">Clean Your Content</h2>
                    </div>
                    <textarea value={inputText} onChange={e => setInputText(e.target.value)} placeholder="Paste your AI-generated content here..." className="w-full min-h-[200px] p-4 rounded-lg bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300"></textarea>
                     <div>
                        <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">AI Detection Level</label>
                        <div className="grid grid-cols-3 gap-2">
                            {detectionLevels.map(level => (
                                <button key={level.id} onClick={() => setSelectedLevel(level.id)} className={`option-card p-3 rounded-lg border-2 text-center transition-all duration-200 bg-base-100 dark:bg-d-base-100 ${selectedLevel === level.id ? 'selected' : 'border-transparent'}`}>
                                    <div className="option-icon text-2xl mx-auto">{level.icon}</div>
                                    <div className="text-sm font-semibold">{level.name}</div>
                                </button>
                            ))}
                        </div>
                    </div>
                    <button onClick={handleClean} disabled={isLoading || !canGenerate} className="w-full btn-primary flex items-center justify-center p-4 rounded-xl text-white font-bold text-lg gap-2">
                         {isLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/50 border-t-white rounded-full"></span> : <SparklesIcon className="h-6 w-6" />}
                         {isLoading ? 'Cleaning...' : 'Clean & Humanize'}
                    </button>
                    {error && <div className="text-center bg-error/20 text-error p-2 rounded-lg text-sm">{error}</div>}
                </section>
                <section className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl flex flex-col">
                    <div className="section-title flex items-center gap-4">
                        <div className="section-icon w-12 h-12 flex items-center justify-center rounded-xl text-white"><i className="fas fa-eye"></i></div>
                        <h2 className="text-2xl font-bold font-heading">Cleaned Results</h2>
                    </div>
                    <div className="flex-1 flex flex-col mt-4">
                        <div className="preview-tabs flex border-b border-base-300 dark:border-d-base-300">
                            <button className={`tab px-4 py-2 ${activeTab === 'analysis' && 'active'}`} onClick={() => setActiveTab('analysis')}>Analysis</button>
                            <button className={`tab px-4 py-2 ${activeTab === 'cleaned' && 'active'}`} onClick={() => setActiveTab('cleaned')}>Cleaned Content</button>
                            <button className={`tab px-4 py-2 ${activeTab === 'compare' && 'active'}`} onClick={() => setActiveTab('compare')}>Before/After</button>
                        </div>
                        <div className="flex-1 pt-4 overflow-y-auto">
                            {activeTab === 'analysis' && (
                                <div className="space-y-4">
                                    <h4 className="font-semibold text-lg">AI Content Analysis</h4>
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                        <ResultCard value={parsedOutput?.analysis.ai_probability ?? 0} label="AI Probability" />
                                        <ResultCard value={parsedOutput?.analysis.pattern_score ?? 0} label="AI Patterns" />
                                        <ResultCard value={parsedOutput?.analysis.watermark_score ?? 0} label="Watermarks" />
                                        <ResultCard value={parsedOutput?.analysis.human_likeness ?? 0} label="Human Likeness" />
                                    </div>
                                    <div>
                                        <h4 className="font-semibold text-lg mt-4">Detected AI Markers</h4>
                                        <ul className="list-disc list-inside mt-2 text-sm space-y-1">
                                            {parsedOutput?.analysis.detected_markers.map((marker, i) => <li key={i}>{marker}</li>) ?? <li>Run analysis to see results.</li>}
                                        </ul>
                                    </div>
                                </div>
                            )}
                            {activeTab === 'cleaned' && (
                                <div>
                                    <pre className="w-full min-h-[300px] p-4 bg-base-100 dark:bg-d-base-100 rounded-lg whitespace-pre-wrap font-sans">{parsedOutput?.cleaned_content || "Your cleaned content will appear here..."}</pre>
                                    <button onClick={() => navigator.clipboard.writeText(parsedOutput?.cleaned_content || '')} disabled={!parsedOutput} className="w-full mt-4 p-3 bg-brand-secondary text-white font-semibold rounded-lg flex items-center justify-center gap-2 disabled:bg-gray-400">
                                        <CopyIcon className="h-5 w-5"/> Copy Cleaned Text
                                    </button>
                                </div>
                            )}
                            {activeTab === 'compare' && (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <div className="comparison-title">Original (AI-Generated)</div>
                                        <pre className="original-content mt-2 p-3 rounded-lg text-sm h-80 overflow-y-auto whitespace-pre-wrap font-sans">{inputText || "Your original text..."}</pre>
                                    </div>
                                     <div>
                                        <div className="comparison-title">Cleaned (Human-Like)</div>
                                        <pre className="cleaned-content-compare mt-2 p-3 rounded-lg text-sm h-80 overflow-y-auto whitespace-pre-wrap font-sans">{parsedOutput?.cleaned_content || "Your cleaned content..."}</pre>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
};

export default CleanPasteView;
