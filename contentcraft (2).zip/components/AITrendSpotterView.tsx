import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import { Type } from '@google/genai';
import CloseIcon from './icons/CloseIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface TrendAnalysis {
    summary: string;
    keyMetrics: {
        trendScore: number;
        trendDirection: 'Growing' | 'Stable' | 'Declining';
        searchVolume: 'High' | 'Medium' | 'Low';
        competition: 'High' | 'Medium' | 'Low';
    };
    emergingTrends: {
        topic: string;
        growth: string;
    }[];
    topKeywords: {
        term: string;
        volume: 'High' | 'Medium' | 'Low';
    }[];
    contentOpportunities: {
        title: string;
        angle: string;
    }[];
    competitorInsights?: {
        domain: string;
        strength: string;
    }[];
}

const trendResponseSchema = {
    type: Type.OBJECT,
    properties: {
        summary: { type: Type.STRING, description: "A 1-2 sentence executive summary of the trend analysis." },
        keyMetrics: {
            type: Type.OBJECT,
            properties: {
                trendScore: { type: Type.NUMBER, description: "Overall trend score (0-100)." },
                trendDirection: { type: Type.STRING, description: "Growing, Stable, or Declining." },
                searchVolume: { type: Type.STRING, description: "High, Medium, or Low." },
                competition: { type: Type.STRING, description: "High, Medium, or Low." }
            },
            required: ['trendScore', 'trendDirection', 'searchVolume', 'competition']
        },
        emergingTrends: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    topic: { type: Type.STRING },
                    growth: { type: Type.STRING, description: "Growth percentage as a string, e.g., '150%'." }
                },
                required: ['topic', 'growth']
            }
        },
        topKeywords: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    term: { type: Type.STRING },
                    volume: { type: Type.STRING, description: "High, Medium, or Low." }
                },
                required: ['term', 'volume']
            }
        },
        contentOpportunities: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "A catchy title for a content piece." },
                    angle: { type: Type.STRING, description: "The strategic angle or description of the content idea." }
                },
                required: ['title', 'angle']
            }
        },
        competitorInsights: {
            type: Type.ARRAY,
            description: "Analysis of how competitors are performing on this topic.",
            items: {
                type: Type.OBJECT,
                properties: {
                    domain: { type: Type.STRING },
                    strength: { type: Type.STRING, description: "A key strength or content angle for this competitor related to the topic." }
                },
                required: ['domain', 'strength']
            }
        }
    },
    required: ['summary', 'keyMetrics', 'emergingTrends', 'topKeywords', 'contentOpportunities']
};

const AITrendSpotterView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [topic, setTopic] = useState('');
    const [industry, setIndustry] = useState('');
    const [competitors, setCompetitors] = useState<string[]>([]);
    const [competitorInput, setCompetitorInput] = useState('');
    const [analysisResult, setAnalysisResult] = useState<TrendAnalysis | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && topic.trim();

    const handleAddCompetitor = () => {
        if (competitorInput.trim() && !competitors.includes(competitorInput.trim())) {
            setCompetitors(prev => [...prev, competitorInput.trim()]);
            setCompetitorInput('');
        }
    };

    const handleRemoveCompetitor = (competitorToRemove: string) => {
        setCompetitors(prev => prev.filter(c => c !== competitorToRemove));
    };

    const getPrompt = useCallback(() => {
        return `You are a world-class market trend analyst and content strategist. Your task is to analyze a given topic and its competitive landscape to generate a comprehensive trend report.

        **INPUT:**
        - Topic: ${topic}
        - Industry: ${industry || 'Not specified'}
        - Competitors: ${competitors.length > 0 ? competitors.join(', ') : 'Not specified'}
        
        **INSTRUCTIONS:**
        Your response must be a valid JSON object conforming to the provided schema. Analyze the topic to identify emerging trends, related keywords, new content opportunities, and competitor insights.`;
    }, [topic, industry, competitors]);


    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: trendResponseSchema,
            });
            const parsed = JSON.parse(result);
            setAnalysisResult(parsed);

            if(userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: `Topic: ${topic}, Industry: ${industry}, Competitors: ${competitors.join(', ')}`,
                    output: JSON.stringify(parsed, null, 2),
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, topic, industry, competitors, module, userId, usesLeft, decrementUse]);

    const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    const renderInputForm = () => (
         <div className="space-y-6">
            <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="topic" className={commonLabelClasses}>Topic or Keyword</label>
                        <input id="topic" value={topic} onChange={e => setTopic(e.target.value)} placeholder="e.g., AI in marketing" className={commonInputClasses} />
                    </div>
                    <div>
                        <label htmlFor="industry" className={commonLabelClasses}>Industry (Optional)</label>
                        <input id="industry" value={industry} onChange={e => setIndustry(e.target.value)} placeholder="e.g., Technology, Healthcare" className={commonInputClasses} />
                    </div>
                </div>
                 <div>
                    <label htmlFor="competitor" className={commonLabelClasses}>Competitors (Optional)</label>
                     <div className="flex gap-2">
                         <input id="competitor" value={competitorInput} onChange={e => setCompetitorInput(e.target.value)} placeholder="competitor.com" className="flex-grow p-2 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg"/>
                         <button onClick={handleAddCompetitor} className="px-4 py-2 bg-base-300 dark:bg-d-base-300 font-semibold rounded-lg hover:bg-base-300/80 dark:hover:bg-d-base-300/80">Add</button>
                     </div>
                     <div className="flex flex-wrap gap-2 mt-3">
                         {competitors.map(c => (
                             <span key={c} className="flex items-center bg-base-300 dark:bg-d-base-300 text-sm font-medium px-3 py-1 rounded-full">
                                 {c}
                                 <button onClick={() => handleRemoveCompetitor(c)} className="ml-2 text-text-secondary dark:text-d-text-secondary hover:text-error">
                                    <CloseIcon className="h-4 w-4" />
                                </button>
                             </span>
                         ))}
                     </div>
                 </div>
            </div>
             <button
                onClick={handleGenerate}
                disabled={isLoading || !canGenerate}
                className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed transition-all"
            >
                {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : '📈 Analyze Trends'}
            </button>
        </div>
    );
    
    const renderResults = () => (
         <div className="space-y-8 animate-fade-in">
            <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl">
                <h3 className="text-2xl font-bold font-heading mb-4">Analysis for "{topic}"</h3>
                <p className="text-text-secondary dark:text-d-text-secondary">{analysisResult.summary}</p>
                 <button onClick={() => setAnalysisResult(null)} className="text-sm font-semibold text-brand-primary mt-4 hover:underline">New Analysis</button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-xl text-center"><p className="text-3xl font-bold text-brand-primary">{analysisResult.keyMetrics.trendScore}<span className="text-xl">/100</span></p><p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1">Trend Score</p></div>
                <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-xl text-center"><p className="text-3xl font-bold text-brand-primary">{analysisResult.keyMetrics.trendDirection}</p><p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1">Direction</p></div>
                <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-xl text-center"><p className="text-3xl font-bold text-brand-primary">{analysisResult.keyMetrics.searchVolume}</p><p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1">Search Volume</p></div>
                <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-xl text-center"><p className="text-3xl font-bold text-brand-primary">{analysisResult.keyMetrics.competition}</p><p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1">Competition</p></div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                    <h3 className="text-xl font-bold font-heading mb-4">🔥 Emerging Trends</h3>
                    <div className="space-y-3">
                        {analysisResult.emergingTrends.map((trend, i) => (
                            <div key={i} className="bg-base-200 dark:bg-d-base-200 p-3 rounded-lg flex justify-between items-center">
                                <span className="font-semibold text-text-primary dark:text-d-text-primary">{trend.topic}</span>
                                <span className="text-sm font-bold text-green-500 bg-green-500/10 px-2 py-0.5 rounded-full">+{trend.growth}</span>
                            </div>
                        ))}
                    </div>
                </div>
                <div>
                    <h3 className="text-xl font-bold font-heading mb-4">🔑 Top Keywords</h3>
                     <div className="space-y-3">
                        {analysisResult.topKeywords.map((kw, i) => (
                            <div key={i} className="bg-base-200 dark:bg-d-base-200 p-3 rounded-lg flex justify-between items-center">
                                <span className="font-semibold text-text-primary dark:text-d-text-primary">{kw.term}</span>
                                <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">{kw.volume} Volume</span>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            
             {analysisResult.competitorInsights && analysisResult.competitorInsights.length > 0 && (
                <div>
                    <h3 className="text-xl font-bold font-heading mb-4">👥 Competitor Insights</h3>
                    <div className="space-y-3">
                        {analysisResult.competitorInsights.map((insight, i) => (
                            <div key={i} className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg">
                                <p className="font-bold text-text-primary dark:text-d-text-primary">{insight.domain}</p>
                                <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1">{insight.strength}</p>
                            </div>
                        ))}
                    </div>
                </div>
            )}

             <div>
                <h3 className="text-xl font-bold font-heading mb-4">💡 Content Opportunities</h3>
                <div className="space-y-4">
                    {analysisResult.contentOpportunities.map((opp, i) => (
                        <div key={i} className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg">
                            <h4 className="font-bold text-text-primary dark:text-d-text-primary">{opp.title}</h4>
                            <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1">{opp.angle}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );

    return (
        <div className="max-w-4xl mx-auto flex flex-col gap-8">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            
            {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
            {isQueued && <p className="text-center text-accent">Request queued for when you're back online.</p>}

            {isLoading && (
                 <div className="text-center p-8">
                     <svg className="animate-spin mx-auto h-12 w-12 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                    <h3 className="text-xl font-bold font-heading mt-4">Analyzing trends...</h3>
                    <p className="text-text-secondary dark:text-d-text-secondary mt-2">Gathering insights from across the web.</p>
                </div>
            )}
            
            {!isLoading && !error && (
                analysisResult ? renderResults() : renderInputForm()
            )}
        </div>
    );
};

export default AITrendSpotterView;
