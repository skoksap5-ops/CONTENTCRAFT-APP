import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

const CLARITY_ENHANCER_PROMPT = `
You are a master of clear communication and simplicity expert. Transform complex, jargon-heavy, or confusing text into crystal-clear, accessible language that anyone can understand while preserving the original meaning and intent.

**INPUT:**
- Original Text: {ORIGINAL_TEXT}
- Complexity Level: {COMPLEXITY_LEVEL}
- Target Audience: {TARGET_AUDIENCE}
- Simplification Level: {SIMPLIFICATION_LEVEL}
- Purpose: {PURPOSE}
- Reading Level: {READING_LEVEL}

**TASK:**
Based on the input, generate a comprehensive clarity enhancement report following the specified sample output structure.

**SAMPLE OUTPUT STRUCTURE TO FOLLOW:**

**COMPLEXITY ANALYSIS:**
- Reading Level: [e.g., College Graduate (16+)]
- Jargon Density: [e.g., 85% (Very High)]
- Sentence Complexity: [e.g., 9.2/10]
- Clarity Score: [e.g., 2.5/10]

💎 **CLARITY-ENHANCED VERSIONS:**
---
## 🎯 **MODERATE SIMPLIFICATION (Professional)**
"[Simplified text for a professional audience]"

**Clarity Analysis:**
- Reading Level: [New Level] → [Change]
- Jargon Density: [New Density] → [Change]
- Sentence Complexity: [New Score] → [Change]
- Clarity Score: [New Score] → [Change]

**Key Simplifications:**
• "[Original Phrase]" → "[Simplified Phrase]"
• "[Original Phrase]" → "[Simplified Phrase]"
---
## 🌟 **SUBSTANTIAL SIMPLIFICATION (General Public)**
"[Simplified text for the general public]"

**Clarity Analysis:**
(Same structure as above)
**Key Simplifications:**
(Same structure as above)
---
## 🎓 **EDUCATIONAL VERSION (Students)**
"[Simplified text for students]"

**Clarity Analysis:**
(Same structure as above)
**Key Simplifications:**
(Same structure as above)
---
## 👵 **SENIOR-FRIENDLY VERSION**
"[Simplified text for seniors]"

**Clarity Analysis:**
(Same structure as above)
**Key Simplifications:**
(Same structure as above)
---

📊 **CLARITY EFFECTIVENESS METRICS:**
**Overall Success Score: [Score]/10**
- **Readability Improvement**: [Score]/10
- **Jargon Elimination**: [Score]/10
- **Meaning Preservation**: [Score]/10
- **Audience Alignment**: [Score]/10

🔍 **COGNITIVE LOAD ANALYSIS:**
**Original Text Cognitive Load:**
- Working Memory Demand: [Level]
- Processing Speed Required: [Level]
- Prior Knowledge Assumed: [Level]
- Mental Effort Required: [Level]
**Enhanced Text Cognitive Load:**
- Working Memory Demand: [Level]
- Processing Speed Required: [Level]
- Prior Knowledge Assumed: [Level]
- Mental Effort Required: [Level]

🎨 **SIMPLIFICATION TECHNIQUES APPLIED:**
• [Technique 1]: [Explanation]
• [Technique 2]: [Explanation]
• [Technique 3]: [Explanation]

🔧 **ADVANCED FEATURES DEMONSTRATION:**
**Technical Concept Simplification Example:**
**Original:** "[Complex technical text]"
**Simplified:** "[Simple technical text]"
**Key Techniques:**
- "[Technique 1]"
`;

type ComplexityLevel = 'Slightly Complex' | 'Moderately Complex' | 'Very Complex' | 'Extremely Technical';
type TargetAudience = 'General Public' | 'Students' | 'Professionals' | 'Experts' | 'Seniors' | 'Children';
type SimplificationLevel = 'Light' | 'Moderate' | 'Substantial' | 'Maximum';
type Purpose = 'Explain' | 'Inform' | 'Persuade' | 'Educate' | 'Guide';
type ReadingLevel = 'Elementary' | 'Middle School' | 'High School' | 'College' | 'Professional';

interface Version {
  title: string;
  content: string;
  analysis: string;
  simplifications: string;
}

interface ParsedOutput {
  complexityAnalysis: string;
  versions: Version[];
  effectivenessMetrics: string;
  cognitiveLoadAnalysis: string;
  techniques: string;
  advancedDemo: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const ClarityEnhancerView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);

    const [complexityLevel, setComplexityLevel] = useState<ComplexityLevel>('Moderately Complex');
    const [targetAudience, setTargetAudience] = useState<TargetAudience>('General Public');
    const [simplificationLevel, setSimplificationLevel] = useState<SimplificationLevel>('Moderate');
    const [purpose, setPurpose] = useState<Purpose>('Explain');
    const [readingLevel, setReadingLevel] = useState<ReadingLevel>('High School');
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();

    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string, source = text) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = source.match(regex);
                return match ? match[1].trim() : '';
            };

            const versionsText = getSection('💎 \\*\\*CLARITY-ENHANCED VERSIONS:\\*\\*', '📊 \\*\\*CLARITY EFFECTIVENESS METRICS:\\*\\*');
            const versionBlocks = versionsText.split('---').map(b => b.trim()).filter(Boolean);

            const versions: Version[] = versionBlocks.map(block => {
                const titleMatch = block.match(/## (.*?)\n/);
                const title = titleMatch ? titleMatch[1].replace(/[🎯🌟🎓👵*]/g, '').trim() : 'Simplified Version';
                const contentMatch = block.match(/"([\s\S]*?)"/);
                const content = contentMatch ? contentMatch[1] : '';
                const analysis = getSection('\\*\\*Clarity Analysis:\\*\\*', '\\*\\*Key Simplifications:\\*\\*', block);
                const simplifications = getSection('\\*\\*Key Simplifications:\\*\\*', '$', block);
                return { title, content, analysis, simplifications };
            });

            return {
                complexityAnalysis: getSection('\\*\\*COMPLEXITY ANALYSIS:\\*\\*', '💎 \\*\\*CLARITY-ENHANCED VERSIONS:\\*\\*'),
                versions,
                effectivenessMetrics: getSection('📊 \\*\\*CLARITY EFFECTIVENESS METRICS:\\*\\*', '🔍 \\*\\*COGNITIVE LOAD ANALYSIS:\\*\\*'),
                cognitiveLoadAnalysis: getSection('🔍 \\*\\*COGNITIVE LOAD ANALYSIS:\\*\\*', '🎨 \\*\\*SIMPLIFICATION TECHNIQUES APPLIED:\\*\\*'),
                techniques: getSection('🎨 \\*\\*SIMPLIFICATION TECHNIQUES APPLIED:\\*\\*', '🔧 \\*\\*ADVANCED FEATURES DEMONSTRATION:\\*\\*'),
                advancedDemo: getSection('🔧 \\*\\*ADVANCED FEATURES DEMONSTRATION:\\*\\*', '$'),
            };
        } catch (e) {
            console.error("Failed to parse Clarity Enhancer output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return CLARITY_ENHANCER_PROMPT
            .replace('{ORIGINAL_TEXT}', input)
            .replace('{COMPLEXITY_LEVEL}', complexityLevel)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{SIMPLIFICATION_LEVEL}', simplificationLevel)
            .replace('{PURPOSE}', purpose)
            .replace('{READING_LEVEL}', readingLevel);
    }, [input, complexityLevel, targetAudience, simplificationLevel, purpose, readingLevel]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };

    const VersionCard: React.FC<{ version: Version }> = ({ version }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!version.content) return;
            navigator.clipboard.writeText(version.content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!version.content) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative space-y-4">
                <div className="flex justify-between items-start">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{version.title}</h4>
                    <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${version.title}`}>
                        {copySuccess ? 'Copied!' : <CopyIcon className="h-5 w-5" />}
                    </button>
                </div>
                <p className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed">{version.content}</p>
                <Accordion title="Analysis & Simplifications">
                    <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(`**Clarity Analysis:**\n${version.analysis}\n\n**Key Simplifications:**\n${version.simplifications}`)} />
                </Accordion>
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[250px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
            <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
                <div className="text-center">
                    <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                    <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                    <div className="space-y-4">
                        <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter the complex text to simplify..." className={commonTextareaClasses} />
                        
                        <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                            <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Clarity Parameters</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className={commonLabelClasses}>Complexity Level</label>
                                    <select value={complexityLevel} onChange={e => setComplexityLevel(e.target.value as ComplexityLevel)} className={commonInputClasses}>
                                        <option>Slightly Complex</option><option>Moderately Complex</option><option>Very Complex</option><option>Extremely Technical</option>
                                    </select>
                                </div>
                                 <div>
                                    <label className={commonLabelClasses}>Target Audience</label>
                                    <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as TargetAudience)} className={commonInputClasses}>
                                        <option>General Public</option><option>Students</option><option>Professionals</option><option>Experts</option><option>Seniors</option><option>Children</option>
                                    </select>
                                </div>
                                <div>
                                    <label className={commonLabelClasses}>Simplification Level</label>
                                    <select value={simplificationLevel} onChange={e => setSimplificationLevel(e.target.value as SimplificationLevel)} className={commonInputClasses}>
                                        <option>Light</option><option>Moderate</option><option>Substantial</option><option>Maximum</option>
                                    </select>
                                </div>
                                <div>
                                    <label className={commonLabelClasses}>Purpose</label>
                                    <select value={purpose} onChange={e => setPurpose(e.target.value as Purpose)} className={commonInputClasses}>
                                        <option>Explain</option><option>Inform</option><option>Persuade</option><option>Educate</option><option>Guide</option>
                                    </select>
                                </div>
                                 <div className="md:col-span-2">
                                    <label className={commonLabelClasses}>Target Reading Level</label>
                                    <select value={readingLevel} onChange={e => setReadingLevel(e.target.value as ReadingLevel)} className={commonInputClasses}>
                                        <option>Elementary</option><option>Middle School</option><option>High School</option><option>College</option><option>Professional</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                            {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                            {isLoading ? 'Enhancing Clarity...' : (isQueued ? 'Request Queued' : 'Enhance Clarity')}
                        </button>
                        {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                        {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please provide text to simplify.</p>}
                    </div>
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                        {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Simplifying your text...</p>}
                        {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your simplified versions and analysis will appear here.</p>}
                        {parsedOutput ? (
                            <div className="space-y-6">
                                <div className="space-y-4">
                                    <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Clarity-Enhanced Versions</h3>
                                    {parsedOutput.versions.map((version, index) => <VersionCard key={index} version={version} />)}
                                </div>
                                <div className="space-y-2 pt-4">
                                    <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Analysis & Insights</h3>
                                    <Accordion title="Complexity Analysis" defaultOpen={true}><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.complexityAnalysis)}/></Accordion>
                                    <Accordion title="Effectiveness Metrics"><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.effectivenessMetrics)}/></Accordion>
                                    <Accordion title="Cognitive Load Analysis"><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.cognitiveLoadAnalysis)}/></Accordion>
                                    <Accordion title="Techniques Applied"><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.techniques)}/></Accordion>
                                    <Accordion title="Advanced Features Demo"><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.advancedDemo)}/></Accordion>
                                </div>
                            </div>
                        ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                    </div>
                </div>
                {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
            </div>
        </>
    );
};

export default ClarityEnhancerView;
