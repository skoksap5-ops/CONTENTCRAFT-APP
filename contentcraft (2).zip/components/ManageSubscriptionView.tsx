import React from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import CrownIcon from './icons/CrownIcon';
import CheckIcon from './icons/CheckIcon';
import { useLanguage } from '../hooks/useLanguage';

interface ManageSubscriptionViewProps {
  onClose: () => void;
}

const ManageSubscriptionView: React.FC<ManageSubscriptionViewProps> = ({ onClose }) => {
  const { t } = useLanguage();

  const benefits = [
    'Unlimited Generations',
    'Access to All 60+ Modules',
    'Ad-Free Experience',
    'Priority Processing Queue',
    'Early Access to New Features',
    'Priority Customer Support',
    'Lifetime Updates (for Lifetime plan)',
  ];
  
  const handleManage = () => {
      // In a real app, this would deeplink to the App Store / Google Play subscription management page.
      alert("This is a lifetime plan and does not require management.");
  };

  return (
    <div className="fixed inset-0 bg-base-100 dark:bg-d-base-100 z-50 animate-fade-in-up overflow-y-auto" role="dialog" aria-modal="true">
      <header className="sticky top-0 bg-base-100/80 dark:bg-d-base-100/80 backdrop-blur-sm z-10 border-b border-base-300 dark:border-d-base-300">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-16 gap-4">
          <button
            onClick={onClose}
            className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-200"
            aria-label="Back to profile"
          >
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Manage Subscription</h1>
        </div>
      </header>
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
            <div className="h-32 flex items-center justify-center mb-4">
                <div className="perspective-1000">
                    <div className="relative w-20 h-20 animate-rotate-3d" style={{ transformStyle: 'preserve-3d', willChange: 'transform' }}>
                        {/* Cube Faces */}
                        <div className="absolute w-20 h-20 bg-base-200 dark:bg-d-base-200 border-2 border-brand-primary/50 flex items-center justify-center shadow-lg" style={{ transform: 'rotateY(0deg) translateZ(40px)'}}>
                            <h2 className="font-heading text-[10px] font-bold text-text-primary dark:text-d-text-primary tracking-wider text-center">CONTENT<br/>CRAFT</h2>
                        </div>
                        <div className="absolute w-20 h-20 bg-base-200 dark:bg-d-base-200 border-2 border-brand-primary/50 flex items-center justify-center shadow-lg" style={{ transform: 'rotateY(90deg) translateZ(40px)'}}></div>
                        <div className="absolute w-20 h-20 bg-base-200 dark:bg-d-base-200 border-2 border-brand-primary/50 flex items-center justify-center shadow-lg" style={{ transform: 'rotateY(180deg) translateZ(40px)'}}>
                            <h2 className="font-heading text-[10px] font-bold text-text-primary dark:text-d-text-primary tracking-wider text-center">CONTENT<br/>CRAFT</h2>
                        </div>
                        <div className="absolute w-20 h-20 bg-base-200 dark:bg-d-base-200 border-2 border-brand-primary/50 flex items-center justify-center shadow-lg" style={{ transform: 'rotateY(-90deg) translateZ(40px)'}}></div>
                        <div className="absolute w-20 h-20 bg-base-200 dark:bg-d-base-200 border-2 border-brand-primary/50 flex items-center justify-center shadow-lg" style={{ transform: 'rotateX(90deg) translateZ(40px)'}}></div>
                        <div className="absolute w-20 h-20 bg-base-200 dark:bg-d-base-200 border-2 border-brand-primary/50 flex items-center justify-center shadow-lg" style={{ transform: 'rotateX(-90deg) translateZ(40px)'}}></div>
                    </div>
                </div>
            </div>
            <h2 className="text-3xl font-bold font-heading text-text-primary dark:text-d-text-primary">You are a Craft Pro Member!</h2>
            <p className="mt-2 text-text-secondary dark:text-d-text-secondary">
                Thank you for supporting ContentCraft. You have unlimited access.
            </p>
        </div>
        
        <div className="bg-base-200 dark:bg-d-base-200 rounded-xl shadow-sm p-6 space-y-4">
            <div className="flex justify-between items-center">
                <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Current Plan</h3>
                <span className="font-bold text-lg text-brand-secondary">Craft Pro (Lifetime)</span>
            </div>
             <div className="flex justify-between items-center">
                <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Status</h3>
                <span className="text-green-500 font-semibold text-sm bg-green-500/10 px-2 py-1 rounded-full">Active</span>
            </div>
             <div className="flex justify-between items-center">
                <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Billing</h3>
                <span className="text-text-secondary dark:text-d-text-secondary">One-time payment</span>
            </div>
             <div className="flex justify-between items-center">
                <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Price</h3>
                <span className="text-text-secondary dark:text-d-text-secondary">$299.99</span>
            </div>
        </div>

        <div className="mt-8">
            <h3 className="text-lg font-bold font-heading mb-4 text-text-primary dark:text-d-text-primary">Your Pro Benefits</h3>
            <ul className="space-y-3">
                {benefits.map((benefit, index) => (
                    <li key={index} className="flex items-center text-text-primary dark:text-d-text-primary">
                        <CheckIcon className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                        <span>{benefit}</span>
                    </li>
                ))}
            </ul>
        </div>
        
        <div className="mt-10">
            <button 
                onClick={handleManage}
                className="w-full p-4 rounded-xl bg-base-300 dark:bg-d-base-300 font-bold text-text-primary dark:text-d-text-primary hover:bg-base-300/80 dark:hover:bg-d-base-300/80 transition-colors"
            >
                Manage Subscription
            </button>
             <p className="text-xs text-center text-text-secondary dark:text-d-text-secondary mt-4">
                This is a lifetime plan and does not renew.
            </p>
        </div>
      </main>
    </div>
  );
};

export default ManageSubscriptionView;