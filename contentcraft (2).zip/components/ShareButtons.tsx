import React from 'react';
import FacebookIcon from './icons/social/FacebookIcon';
import TwitterIcon from './icons/social/TwitterIcon';
import LinkedInIcon from './icons/social/LinkedInIcon';
import TikTokIcon from './icons/social/TikTokIcon';
import InstagramIcon from './icons/social/InstagramIcon';
import CloseIcon from './icons/CloseIcon';
import DiscordIcon from './icons/social/DiscordIcon';

interface ShareButtonsProps {
  content: string;
  hashtags?: string[];
  onClose: () => void;
  showNotification: (message: string) => void;
}

// --- Helper Functions ---

const copyAndNotify = (text: string, platformName: string, showNotification: (message: string) => void) => {
    navigator.clipboard.writeText(text).then(() => {
        showNotification(`Copied for ${platformName}! Paste it in your new post.`);
    }).catch(() => {
        showNotification(`Could not copy text. Please copy it manually.`);
    });
};

const shareToTikTok = (content: string, hashtags: string[], showNotification: (message: string) => void) => {
    const fullText = `${content}\n\n${hashtags.join(' ')}`;

    if (navigator.share) {
        navigator.share({ title: 'Content Craft Post', text: fullText }).catch(err => {
            if (err.name !== 'AbortError') console.warn('Web Share failed', err);
        });
    } else {
        copyAndNotify(fullText, 'TikTok', showNotification);
        // Try to open TikTok app, with fallback to upload page
        window.location.href = 'tiktok://';
        setTimeout(() => {
            window.open('https://www.tiktok.com/upload', '_blank', 'noopener,noreferrer');
        }, 500);
    }
};

const shareToDiscord = (content: string, hashtags: string[], showNotification: (message: string) => void) => {
    const fullText = `${content}\n\n${hashtags.join(' ')}`;
    copyAndNotify(fullText, 'Discord', showNotification);
    setTimeout(() => {
        window.open('https://discord.com/channels/@me', '_blank');
    }, 500);
};

const shareToInstagram = (content: string, hashtags: string[], showNotification: (message: string) => void) => {
    const fullText = `${content}\n\n${hashtags.join(' ')}`;
    copyAndNotify(fullText, 'Instagram', showNotification);
    // There's no reliable web intent to open Instagram with pre-filled text.
    // We just notify the user that text is copied and they can switch apps.
};


const ShareButtons: React.FC<ShareButtonsProps> = ({ content, hashtags = [], onClose, showNotification }) => {
    
    const SHARE_URL = typeof window !== 'undefined' ? window.location.origin : 'https://contentcraft.ai';
    const fullContentWithHashtags = `${content}\n\n${hashtags.join(' ')}`;

    const platforms = [
        {
            name: 'TikTok',
            icon: <TikTokIcon className="h-6 w-6" />,
            color: 'bg-black',
            onClick: () => shareToTikTok(content, hashtags, showNotification)
        },
        {
            name: 'Instagram',
            icon: <InstagramIcon className="h-5 w-5" strokeWidth={2.5}/>,
            color: 'bg-gradient-to-br from-[#833ab4] via-[#fd1d1d] to-[#fcb045]',
            onClick: () => shareToInstagram(content, hashtags, showNotification)
        },
        {
            name: 'X (Twitter)',
            icon: <TwitterIcon className="h-5 w-5" />,
            color: 'bg-[#1DA1F2]',
            onClick: () => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(fullContentWithHashtags)}`, '_blank')
        },
        {
            name: 'Facebook',
            icon: <FacebookIcon className="h-6 w-6" />,
            color: 'bg-[#1877F2]',
            onClick: () => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(SHARE_URL)}&quote=${encodeURIComponent(fullContentWithHashtags)}`, '_blank')
        },
        {
            name: 'LinkedIn',
            icon: <LinkedInIcon className="h-5 w-5" />,
            color: 'bg-[#0077b5]',
            onClick: () => window.open(`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(SHARE_URL)}&title=Check%20out%20this%20post&summary=${encodeURIComponent(fullContentWithHashtags)}`, '_blank')
        },
        {
            name: 'Discord',
            icon: <DiscordIcon className="h-5 w-5" />,
            color: 'bg-[#5865F2]',
            onClick: () => shareToDiscord(content, hashtags, showNotification)
        },
    ];

    return (
        <div className="absolute right-0 bottom-12 z-10 w-48 bg-base-100 dark:bg-d-base-100 rounded-lg shadow-2xl border border-base-300 dark:border-d-base-300 p-2 animate-fade-in">
             <div className="flex justify-between items-center mb-2 px-2">
                <p className="text-xs font-semibold text-text-secondary dark:text-d-text-secondary">Share Post</p>
                <button onClick={onClose} className="p-1 rounded-full hover:bg-base-200 dark:hover:bg-d-base-200">
                    <CloseIcon className="h-3 w-3" />
                </button>
            </div>
            <div className="space-y-1">
                {platforms.map(p => (
                    <button
                        key={p.name}
                        onClick={p.onClick}
                        className={`w-full flex items-center p-2 rounded-md text-sm font-medium transition-colors text-white hover:opacity-90 ${p.color}`}
                    >
                        {p.icon}
                        <span className="ml-2">{p.name}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};

export default ShareButtons;