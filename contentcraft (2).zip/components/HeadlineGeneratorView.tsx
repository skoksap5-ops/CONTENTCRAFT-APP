import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type ContentType = 'Blog Post' | 'Article' | 'Video' | 'Email' | 'Ad' | 'Social Media';
type TargetAudience = 'General' | 'Experts' | 'Beginners' | 'Professionals';
type Platform = 'Google' | 'Facebook' | 'YouTube' | 'Email' | 'Instagram' | 'Twitter';
type DesiredAction = 'Click' | 'Share' | 'Subscribe' | 'Buy' | 'Learn';

const HEADLINE_GENERATOR_PROMPT = `
You are a master headline writer and click-through rate optimization expert. Create compelling, click-worthy headlines that capture attention, drive traffic, and maximize engagement across all platforms.

**INPUT:**
- Main Topic: {MAIN_TOPIC}
- Content Type: {CONTENT_TYPE}
- Target Audience: {TARGET_AUDIENCE}
- Platform: {PLATFORM}
- Desired Action: {DESIRED_ACTION}
- Tone: {SELECTED_TONES}

**TASK:**
Generate a comprehensive headline report. The output MUST follow this structure exactly:

🎯 **HIGH-PERFORMING HEADLINE OPTIONS:**

**1. CURIOSITY-DRIVEN HEADLINES:**
• [Headline 1]
• [Headline 2]
• [Headline 3]

**2. BENEFIT-FOCUSED HEADLINES:**
• [Headline 1]
• [Headline 2]
• [Headline 3]

**3. NUMBER-DRIVEN HEADLINES:**
• [Headline 1]
• [Headline 2]
• [Headline 3]

**4. QUESTION-BASED HEADLINES:**
• [Headline 1]
• [Headline 2]
• [Headline 3]

📱 **PLATFORM-SPECIFIC ADAPTATIONS:**

**GOOGLE SEARCH OPTIMIZED (50-60 chars):**
• [Headline 1]
• [Headline 2]

**FACEBOOK/LINKEDIN (40-50 chars):**
• [Headline 1]
• [Headline 2]

**TWITTER (70-90 chars):**
• [Headline 1]
• [Headline 2]

**EMAIL SUBJECT LINES (28-39 chars):**
• [Headline 1]
• [Headline 2]

📊 **PERFORMANCE PREDICTIONS:**

**TOP 3 PREDICTED PERFORMERS:**
1. "[Headline]"
   - CTR Prediction: [X]%
   - Social Share Probability: [Y]%
   - Emotional Impact: [Z]/10
2. "[Headline]"
   - CTR Prediction: [X]%
   - Social Share Probability: [Y]%
   - Emotional Impact: [Z]/10
3. "[Headline]"
   - CTR Prediction: [X]%
   - Social Share Probability: [Y]%
   - Emotional Impact: [Z]/10

🎨 **A/B TESTING RECOMMENDATIONS:**
• [Recommendation 1]
• [Recommendation 2]

**PSYCHOLOGICAL TRIGGERS IDENTIFIED:**
• [Trigger 1]: [Explanation]
• [Trigger 2]: [Explanation]
`;

interface HeadlineCategory {
    title: string;
    headlines: string[];
}
interface PlatformAdaptation {
    platform: string;
    headlines: string[];
}
interface PerformancePrediction {
    headline: string;
    ctr?: string;
    shareProbability?: string;
    impact?: string;
}
interface ParsedOutput {
    headlineCategories: HeadlineCategory[];
    platformAdaptations: PlatformAdaptation[];
    performancePredictions: PerformancePrediction[];
    abTesting: string;
    psychologicalTriggers: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const HeadlineGeneratorView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [mainTopic, setMainTopic] = useState('');
    const [contentType, setContentType] = useState<ContentType>('Blog Post');
    const [targetAudience, setTargetAudience] = useState<TargetAudience>('General');
    const [platform, setPlatform] = useState<Platform>('Google');
    const [desiredAction, setDesiredAction] = useState<DesiredAction>('Click');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && mainTopic.trim();
    
    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = text.match(regex);
                return match ? match[1].trim() : '';
            };

            const optionsText = getSection('🎯 \\*\\*HIGH-PERFORMING HEADLINE OPTIONS:\\*\\*', '📱 \\*\\*PLATFORM-SPECIFIC ADAPTATIONS:\\*\\*');
            const adaptationsText = getSection('📱 \\*\\*PLATFORM-SPECIFIC ADAPTATIONS:\\*\\*', '📊 \\*\\*PERFORMANCE PREDICTIONS:\\*\\*');
            const predictionsText = getSection('📊 \\*\\*PERFORMANCE PREDICTIONS:\\*\\*', '🎨 \\*\\*A/B TESTING RECOMMENDATIONS:\\*\\*');
            const abText = getSection('🎨 \\*\\*A/B TESTING RECOMMENDATIONS:\\*\\*', '\\*\\*PSYCHOLOGICAL TRIGGERS IDENTIFIED:\\*\\*');
            const triggersText = getSection('\\*\\*PSYCHOLOGICAL TRIGGERS IDENTIFIED:\\*\\*', '$');

            const headlineCategories: HeadlineCategory[] = [];
            const categoryBlocks = optionsText.split(/\*\*\d+\.\s*(.*?)\*\*/).filter(s => s.trim());
            for (let i = 0; i < categoryBlocks.length; i += 2) {
                const title = categoryBlocks[i].replace(/:/g, '').trim();
                const headlines = categoryBlocks[i+1].split('•').map(h => h.trim().replace(/"/g, '')).filter(Boolean);
                if (title && headlines.length > 0) {
                    headlineCategories.push({ title, headlines });
                }
            }

            const platformAdaptations: PlatformAdaptation[] = [];
            const platformBlocks = adaptationsText.split(/\*\*(.*?)\*\*/).filter(s => s.trim());
            for (let i = 0; i < platformBlocks.length; i += 2) {
                const platform = platformBlocks[i].replace(/:/g, '').trim();
                const headlines = platformBlocks[i+1].split('•').map(h => h.trim().replace(/"/g, '')).filter(Boolean);
                if (platform && headlines.length > 0) {
                    platformAdaptations.push({ platform, headlines });
                }
            }

            const performancePredictions: PerformancePrediction[] = [];
            const predictionItems = predictionsText.match(/\d\.\s*"[\s\S]*?Emotional Impact:[\s\S]*?\d+\/\d+/g);
            if (predictionItems) {
                predictionItems.forEach(item => {
                    const headlineMatch = item.match(/"(.*?)"/);
                    if (headlineMatch) {
                        performancePredictions.push({
                            headline: headlineMatch[1],
                            ctr: item.match(/CTR Prediction:\s*(.*?)(?:\n|$)/)?.[1].trim(),
                            shareProbability: item.match(/Social Share Probability:\s*(.*?)(?:\n|$)/)?.[1].trim(),
                            impact: item.match(/Emotional Impact:\s*(.*?)(?:\n|$)/)?.[1].trim(),
                        });
                    }
                });
            }

            return {
                headlineCategories,
                platformAdaptations,
                performancePredictions,
                abTesting: abText.split('•').map(s => s.trim()).filter(Boolean).join('\n'),
                psychologicalTriggers: triggersText.split('•').map(s => s.trim()).filter(Boolean).join('\n'),
            };
        } catch (e) {
            console.error("Failed to parse Headline Generator output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return HEADLINE_GENERATOR_PROMPT
            .replace('{MAIN_TOPIC}', mainTopic)
            .replace('{CONTENT_TYPE}', contentType)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{PLATFORM}', platform)
            .replace('{DESIRED_ACTION}', desiredAction)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [mainTopic, contentType, targetAudience, platform, desiredAction, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);
        const prompt = getPrompt();
        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }
        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\n/g, '<br />') };
    };
    
    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={mainTopic} onChange={e => setMainTopic(e.target.value)} placeholder="Enter your main topic or idea..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Headline Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Content Type</label>
                                <select value={contentType} onChange={e => setContentType(e.target.value as ContentType)} className={commonInputClasses}>
                                    <option>Blog Post</option><option>Article</option><option>Video</option><option>Email</option><option>Ad</option><option>Social Media</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Target Audience</label>
                                <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as TargetAudience)} className={commonInputClasses}>
                                    <option>General</option><option>Experts</option><option>Beginners</option><option>Professionals</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Platform</label>
                                <select value={platform} onChange={e => setPlatform(e.target.value as Platform)} className={commonInputClasses}>
                                    <option>Google</option><option>Facebook</option><option>YouTube</option><option>Email</option><option>Instagram</option><option>Twitter</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Desired Action</label>
                                <select value={desiredAction} onChange={e => setDesiredAction(e.target.value as DesiredAction)} className={commonInputClasses}>
                                    <option>Click</option><option>Share</option><option>Subscribe</option><option>Buy</option><option>Learn</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Generating...' : (isQueued ? 'Request Queued' : 'Generate Headlines')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && mainTopic.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Generating your headline suite...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your high-performing headlines will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-6">
                            <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">High-Performing Headline Options</h3>
                                {parsedOutput.headlineCategories.map((cat, i) => (
                                    <div key={i} className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg">
                                        <h4 className="font-semibold text-text-primary dark:text-d-text-primary mb-2">{cat.title}</h4>
                                        <ul className="space-y-2">{cat.headlines.map((h, j) => <li key={j} className="text-sm flex justify-between items-center group">{h}<button onClick={() => navigator.clipboard.writeText(h)} className="p-1 opacity-0 group-hover:opacity-100 transition-opacity"><CopyIcon className="h-4 w-4 text-text-secondary"/></button></li>)}</ul>
                                    </div>
                                ))}
                            </div>
                            <div className="space-y-2 pt-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Strategy & Analysis</h3>
                                <Accordion title={<>📱 <span className="ml-2">Platform-Specific Adaptations</span></>} defaultOpen={true}>
                                    <div className="space-y-3">{parsedOutput.platformAdaptations.map((p, i) => (<div key={i}><strong className="text-sm font-semibold text-text-primary dark:text-d-text-primary">{p.platform}</strong><ul className="mt-1 text-xs list-disc list-inside">{p.headlines.map((h, j) => <li key={j}>{h}</li>)}</ul></div>))}</div>
                                </Accordion>
                                <Accordion title={<>📊 <span className="ml-2">Performance Predictions</span></>}>
                                    <ul className="space-y-3">{parsedOutput.performancePredictions.map((p, i) => (<li key={i} className="text-sm"><strong>"{p.headline}"</strong><div className="text-xs flex space-x-4 mt-1"><span title="Click-Through Rate">CTR: {p.ctr}</span><span title="Share Probability">Share: {p.shareProbability}</span><span title="Emotional Impact">Impact: {p.impact}</span></div></li>))}</ul>
                                </Accordion>
                                <Accordion title={<>🎨 <span className="ml-2">A/B Testing Recommendations</span></>}>
                                    <div dangerouslySetInnerHTML={formatContent(parsedOutput.abTesting)}/>
                                </Accordion>
                                <Accordion title={<>🧠 <span className="ml-2">Psychological Triggers</span></>}>
                                     <div dangerouslySetInnerHTML={formatContent(parsedOutput.psychologicalTriggers)}/>
                                </Accordion>
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default HeadlineGeneratorView;
