import React from 'react';
import StarIcon from './icons/StarIcon';

interface RatingProps {
  rating: number;
  onRatingChange: (rating: number) => void;
  maxRating?: number;
}

const Rating: React.FC<RatingProps> = ({ rating, onRatingChange, maxRating = 5 }) => {
  return (
    <div className="flex items-center space-x-1">
      {[...Array(maxRating)].map((_, index) => {
        const starValue = index + 1;
        return (
          <button
            key={starValue}
            type="button"
            onClick={() => onRatingChange(starValue)}
            className="focus:outline-none"
            aria-label={`Set rating to ${starValue}`}
          >
            <StarIcon
              className={`h-6 w-6 transition-colors ${
                starValue <= rating
                  ? 'text-amber-400'
                  : 'text-base-300 dark:text-d-base-300'
              }`}
            />
          </button>
        );
      })}
    </div>
  );
};

export default Rating;