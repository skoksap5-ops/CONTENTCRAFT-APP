import React, { useState, useEffect } from 'react';
import { TONE_CATEGORIES, Tone } from '../constants';
import InfoIcon from './icons/InfoIcon';
import CloseIcon from './icons/CloseIcon';
import { useFeedback } from '../hooks/useFeedback';

interface ToneSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTones: string[];
  onTonesChange: (tones: string[]) => void;
}

const ToneSelector: React.FC<ToneSelectorProps> = ({ isOpen, onClose, selectedTones, onTonesChange }) => {
  const [previewTone, setPreviewTone] = useState<Tone | null>(null);
  const { playClick } = useFeedback();

  useEffect(() => {
    if (!isOpen) {
      // Delay reset to allow closing animation to finish
      const timer = setTimeout(() => setPreviewTone(null), 300);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleToneClick = (toneName: string) => {
    playClick();
    const isSelected = selectedTones.includes(toneName);
    if (isSelected) {
      onTonesChange(selectedTones.filter(t => t !== toneName));
    } else {
      if (selectedTones.length < 3) {
        onTonesChange([...selectedTones, toneName]);
      }
    }
  };
  
  const handleInfoClick = (e: React.MouseEvent, tone: Tone) => {
    e.stopPropagation(); // Prevent tone selection when clicking info
    playClick();
    setPreviewTone(tone);
  };

  const handleClose = () => {
    playClick();
    onClose();
  }

  return (
    <div className="fixed inset-0 bg-base-100/80 dark:bg-d-base-100/80 backdrop-blur-sm z-50 flex flex-col" role="dialog" aria-modal="true">
      {/* Header */}
      <header className="flex-shrink-0 bg-base-200/80 dark:bg-d-base-200/80 border-b border-base-300 dark:border-d-base-300 sticky top-0">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
            <h2 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Select Tones</h2>
             <button
                onClick={handleClose}
                className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-300 dark:hover:bg-d-base-300 hover:text-text-primary dark:hover:text-d-text-primary transition-colors"
                aria-label="Close tone selector"
              >
                <CloseIcon className="h-6 w-6" />
              </button>
          </div>
      </header>

      {/* Content */}
      <div className="flex-grow overflow-y-auto">
        <div className="max-w-4xl mx-auto space-y-8 p-4 sm:p-6 lg:p-8">
          {TONE_CATEGORIES.map(category => (
            <section key={category.name}>
              <h3 className="text-lg font-semibold text-text-secondary dark:text-d-text-secondary mb-4">{category.name}</h3>
              <div className="space-y-3">
                {category.tones.map(tone => {
                  const isSelected = selectedTones.includes(tone.name);
                  return (
                    <button
                      key={tone.name}
                      onClick={() => handleToneClick(tone.name)}
                      type="button"
                      aria-pressed={isSelected}
                      className={`w-full flex items-center justify-between p-4 text-left rounded-lg border-2 transition-all duration-200 ${
                        isSelected
                          ? `${category.color.bg} ${category.color.border}`
                          : `bg-base-200 border-base-300 dark:bg-d-base-200 dark:border-d-base-300 ${category.color.hoverBorder}`
                      }`}
                    >
                      <span className={`font-medium ${isSelected ? category.color.text : 'text-text-primary dark:text-d-text-primary'}`}>
                        {tone.name}
                      </span>
                      <button 
                        onClick={(e) => handleInfoClick(e, tone)}
                        className="p-1 text-text-secondary dark:text-d-text-secondary hover:text-text-primary dark:hover:text-d-text-primary"
                        aria-label={`More info about ${tone.name} tone`}
                      >
                        <InfoIcon className="h-5 w-5" />
                      </button>
                    </button>
                  )
                })}
              </div>
            </section>
          ))}
        </div>
      </div>
      
      {/* Footer */}
      <footer className="flex-shrink-0 bg-base-200/80 dark:bg-d-base-200/80 border-t border-base-300 dark:border-d-base-300 sticky bottom-0 transition-all duration-300">
        <div className="max-w-4xl mx-auto p-4 space-y-4">
            {previewTone && (
                <div className="bg-base-300/50 dark:bg-d-base-300/50 p-4 rounded-lg animate-fade-in">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary mb-2">{previewTone.name}</h4>
                    <p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">{previewTone.description}</p>
                    <div className="space-y-3 text-sm font-mono">
                        <div>
                            <p className="text-text-secondary dark:text-d-text-secondary text-xs uppercase tracking-wider mb-1">BEFORE:</p>
                            <p className="text-text-primary dark:text-d-text-primary bg-base-100 dark:bg-d-base-100 p-2 rounded">"{previewTone.example.before}"</p>
                        </div>
                        <div>
                            <p className="text-accent text-xs uppercase tracking-wider mb-1">AFTER ({previewTone.name}):</p>
                            <p className="text-text-primary dark:text-d-text-primary bg-brand-primary/10 p-2 rounded border-l-2 border-accent">"{previewTone.example.after}"</p>
                        </div>
                    </div>
                </div>
            )}
            <div className="flex justify-center items-center pt-2">
                <button
                    onClick={handleClose}
                    className="w-full max-w-xs flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary transition-all duration-300"
                >
                    Done ({selectedTones.length}/3)
                </button>
            </div>
        </div>
      </footer>
    </div>
  );
};

export default ToneSelector;
