import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import Switch from './Switch';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type EnglishDialect = 'US' | 'UK' | 'CA' | 'AU' | 'International';
type Formality = 'Casual' | 'Professional' | 'Academic';
type UserLevel = 'Beginner' | 'Intermediate' | 'Advanced';

const grammarSchema = {
    type: Type.OBJECT,
    properties: {
        overallScore: { type: Type.STRING, description: "The overall score as a string, e.g., '85/100'." },
        detailedBreakdown: { type: Type.STRING, description: "A markdown-formatted string containing Critical Errors, Style Improvements, and Minor Enhancements." },
        versions: {
            type: Type.OBJECT,
            properties: {
                quickFix: { type: Type.STRING, description: "The full text with only critical errors fixed." },
                enhanced: { type: Type.STRING, description: "The full text with style improvements applied." },
                professional: { type: Type.STRING, description: "The fully polished and optimized version of the text." },
            },
            required: ['quickFix', 'enhanced', 'professional']
        },
        learningInsights: { type: Type.STRING, description: "A markdown-formatted string with common mistake patterns and personalized learning tips." }
    },
    required: ['overallScore', 'detailedBreakdown', 'versions', 'learningInsights']
};

const GRAMMAR_PROOFER_PROMPT = `
You are an expert linguist and grammar correction specialist. Your primary task is to generate multiple corrected versions of the user's text, followed by a comprehensive analysis.

**INPUT:**
- Text to Analyze: {USER_TEXT}
- Target Dialect: {ENGLISH_DIALECT}
- Formality Level: {FORMALITY}
- Tone Preservation: {PRESERVE_TONE}
- Learning Level: {USER_LEVEL}

**INSTRUCTIONS:**
Your response MUST be a valid JSON object conforming to the provided schema.
- The 'versions' object MUST contain the complete, ready-to-use rewritten texts. This is the most important part.
- Populate the markdown string fields ('detailedBreakdown', 'learningInsights') with rich, formatted content including headings and bullet points.
`;

interface ParsedOutput {
    overallScore: string;
    detailedBreakdown: string;
    versions: {
        quickFix: string;
        enhanced: string;
        professional: string;
    };
    learningInsights: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const GrammarProoferView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const [dialect, setDialect] = useState<EnglishDialect>('US');
    const [formality, setFormality] = useState<Formality>('Professional');
    const [preserveTone, setPreserveTone] = useState(true);
    const [userLevel, setUserLevel] = useState<UserLevel>('Intermediate');

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();

    const getPrompt = useCallback(() => {
        return GRAMMAR_PROOFER_PROMPT
            .replace('{USER_TEXT}', input)
            .replace('{ENGLISH_DIALECT}', dialect)
            .replace('{FORMALITY}', formality)
            .replace('{PRESERVE_TONE}', preserveTone ? 'Yes' : 'No')
            .replace('{USER_LEVEL}', userLevel);
    }, [input, dialect, formality, preserveTone, userLevel]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing. Notification permissions may be required.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: grammarSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
             if (!parsed.versions?.quickFix) {
                setError("The AI returned an incomplete response. Please try again.");
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        const sanitized = text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
        return { __html: sanitized
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/🔴/g, '<span class="text-red-500">🔴</span>')
            .replace(/🟡/g, '<span class="text-yellow-500">🟡</span>')
            .replace(/🟢/g, '<span class="text-green-500">🟢</span>')
            .replace(/→/g, '<span class="mx-2 font-bold text-brand-primary">→</span>')
            .replace(/\n/g, '<br />')
        };
    };
    
    const VersionCard: React.FC<{ title: string; content: string }> = ({ title, content }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!content) return;
            navigator.clipboard.writeText(content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!content) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative">
                <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{title}</h4>
                     <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${title}`}>
                        <CopyIcon className="h-5 w-5" />
                    </button>
                </div>
                <p className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed">{content}</p>
                 {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[250px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter text to proofread..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Target Dialect</label>
                                <select value={dialect} onChange={e => setDialect(e.target.value as EnglishDialect)} className={commonInputClasses}>
                                    <option value="US">US English</option><option value="UK">UK English</option><option value="CA">Canadian English</option><option value="AU">Australian English</option><option value="International">International</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Formality Level</label>
                                <select value={formality} onChange={e => setFormality(e.target.value as Formality)} className={commonInputClasses}>
                                    <option>Casual</option><option>Professional</option><option>Academic</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Learning Level</label>
                                <select value={userLevel} onChange={e => setUserLevel(e.target.value as UserLevel)} className={commonInputClasses}>
                                    <option>Beginner</option><option>Intermediate</option><option>Advanced</option>
                                </select>
                            </div>
                       </div>
                       <div className="flex items-center gap-2 pt-2">
                           <Switch label="Preserve Original Tone" checked={preserveTone} onChange={setPreserveTone} />
                           <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">Preserve Original Tone</span>
                       </div>
                    </div>

                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Proofreading...' : (isQueued ? 'Request Queued' : 'Proofread Text')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please provide text to proofread.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Analyzing your text...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your detailed analysis will appear here.</p>}
                    {error && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">An Error Occurred</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">{error}</p></div>}
                    {parsedOutput && (
                        <div className="space-y-6">
                            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg text-center border border-base-300 dark:border-d-base-300">
                                <h3 className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">Overall Score</h3>
                                <p className="text-5xl font-bold text-brand-primary my-2">{parsedOutput.overallScore}</p>
                            </div>

                            <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Corrected Versions</h3>
                                <VersionCard title="Quick Fix Version" content={parsedOutput.versions.quickFix} />
                                <VersionCard title="Enhanced Version" content={parsedOutput.versions.enhanced} />
                                <VersionCard title="Professional Version" content={parsedOutput.versions.professional} />
                            </div>
                            
                            <div className="space-y-2 pt-4">
                                 <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Detailed Breakdown & Insights</h3>
                                 <Accordion title="🔴 Detailed Breakdown" defaultOpen={true}><div dangerouslySetInnerHTML={formatContent(parsedOutput.detailedBreakdown)}/></Accordion>
                                 <Accordion title="💡 Learning Insights"><div dangerouslySetInnerHTML={formatContent(parsedOutput.learningInsights)}/></Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default GrammarProoferView;