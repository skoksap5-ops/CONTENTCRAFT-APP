import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type ContentType = "Thought Leadership" | "Career Update" | "Company News";
type Audience = "Executives" | "Recruiters" | "Industry Peers" | "General";
type Goal = "Visibility" | "Networking" | "Lead Generation";

interface ParsedOutput {
    linkedinPost: string;
    contentQuality: {
        hookEffectiveness: number;
        valueClarity: number;
        engagementPotential: number;
        professionalTone: number;
    };
    hashtagAnalysis: {
        hashtags: { tag: string; tier: string }[];
        reachScore: number;
        relevanceScore: number;
        authorityScore: number;
    };
}

const LINKEDIN_STYLER_PROMPT = `
You are an expert LinkedIn content strategist and copywriter. Transform the user's message into a compelling, professional LinkedIn post.

**INPUT:**
- User Message: {USER_MESSAGE}
- Content Type: {CONTENT_TYPE}
- Target Audience: {AUDIENCE}
- Desired Tone: {TONE}
- Primary Goal: {GOAL}

**INSTRUCTIONS:**
1.  Analyze the user's input and goals.
2.  If the Content Type is 'Career Update', structure the post using the Career Update Template: {HOOK}, {JOURNEY}, {IMPACT}, {GRATITUDE}, {QUESTION}.
3.  If the Content Type is 'Company News', structure the post using the Company Announcement Template: {PROBLEM}, {SOLUTION}, {IMPACT}, {VISION}, {ENGAGEMENT}.
4.  For 'Thought Leadership', craft an authoritative post that presents an insight or opinion.
5.  Generate a list of 3-5 strategic hashtags using the 4-Tier Strategy: Broad, Niche, Targeted, Personal.
6.  Generate a complete, valid JSON object that conforms to the provided schema. The \`linkedinPost\` field should contain the final, polished post content including the generated hashtags at the end, formatted with markdown for line breaks. The analysis fields should be your expert evaluation of the content you created.
`;

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        linkedinPost: { type: Type.STRING, description: "The full, formatted LinkedIn post content, including emojis and hashtags. Use \\n for line breaks." },
        contentQuality: {
            type: Type.OBJECT,
            properties: {
                hookEffectiveness: { type: Type.NUMBER, description: "Score from 0-10 for the hook's effectiveness." },
                valueClarity: { type: Type.NUMBER, description: "Score from 0-10 for the clarity of the value proposition." },
                engagementPotential: { type: Type.NUMBER, description: "Score from 0-10 for the post's potential to generate engagement." },
                professionalTone: { type: Type.NUMBER, description: "Score from 0-10 for how well the tone matches professional LinkedIn standards." }
            },
            required: ['hookEffectiveness', 'valueClarity', 'engagementPotential', 'professionalTone']
        },
        hashtagAnalysis: {
            type: Type.OBJECT,
            properties: {
                hashtags: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            tag: { type: Type.STRING },
                            tier: { type: Type.STRING, description: "Broad, Niche, Targeted, or Personal" }
                        },
                         required: ['tag', 'tier']
                    }
                },
                reachScore: { type: Type.NUMBER, description: "Overall hashtag reach score from 0-10." },
                relevanceScore: { type: Type.NUMBER, description: "Overall hashtag relevance score from 0-10." },
                authorityScore: { type: Type.NUMBER, description: "Overall hashtag authority-building score from 0-10." }
            },
            required: ['hashtags', 'reachScore', 'relevanceScore', 'authorityScore']
        }
    },
    required: ['linkedinPost', 'contentQuality', 'hashtagAnalysis']
};

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};

const ScoreBar: React.FC<{ score: number; label: string }> = ({ score, label }) => (
  <div>
    <div className="flex justify-between items-center mb-1">
      <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">{label}</span>
      <span className="text-sm font-bold text-text-primary dark:text-d-text-primary">{score}/10</span>
    </div>
    <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2">
      <div className="bg-brand-primary h-2 rounded-full transition-all duration-500" style={{ width: `${score * 10}%` }}></div>
    </div>
  </div>
);

const LinkedInStylerView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [contentType, setContentType] = useState<ContentType>('Thought Leadership');
    const [audience, setAudience] = useState<Audience>('Industry Peers');
    const [goal, setGoal] = useState<Goal>('Visibility');
    const [tones, setTones] = useState<string[]>(['Authoritative']);
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    const [copySuccess, setCopySuccess] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();
    
    const getPrompt = useCallback(() => {
        return LINKEDIN_STYLER_PROMPT
            .replace('{USER_MESSAGE}', input)
            .replace('{CONTENT_TYPE}', contentType)
            .replace('{AUDIENCE}', audience)
            .replace('{GOAL}', goal)
            .replace('{TONE}', tones.length > 0 ? tones.join(', ') : 'Professional');
    }, [input, contentType, audience, goal, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: parsed.linkedinPost,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse content: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);

     const handleCopy = () => {
        if (parsedOutput?.linkedinPost) {
            navigator.clipboard.writeText(parsedOutput.linkedinPost).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        }
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter your core message or update..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Post Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Content Type</label>
                                <select value={contentType} onChange={e => setContentType(e.target.value as ContentType)} className={commonInputClasses}>
                                    <option>Thought Leadership</option><option>Career Update</option><option>Company News</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Audience</label>
                                <select value={audience} onChange={e => setAudience(e.target.value as Audience)} className={commonInputClasses}>
                                    <option>Industry Peers</option><option>Executives</option><option>Recruiters</option><option>General</option>
                                </select>
                            </div>
                             <div>
                                <label className={commonLabelClasses}>Goal</label>
                                <select value={goal} onChange={e => setGoal(e.target.value as Goal)} className={commonInputClasses}>
                                    <option>Visibility</option><option>Networking</option><option>Lead Generation</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Crafting Post...' : (isQueued ? 'Request Queued' : 'Generate LinkedIn Post')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please enter a message to generate a post.</p>}
                </div>

                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Crafting your professional post...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your expert-crafted LinkedIn post and analysis will appear here.</p>}
                    {parsedOutput && (
                        <div className="space-y-6">
                            <div className="relative bg-base-100 dark:bg-d-base-100 p-4 rounded-lg shadow-sm">
                                <h3 className="font-bold text-lg text-text-primary dark:text-d-text-primary mb-3">Generated LinkedIn Post</h3>
                                <pre className="text-text-primary dark:text-d-text-primary whitespace-pre-wrap font-sans text-sm leading-relaxed">{parsedOutput.linkedinPost}</pre>
                                <button onClick={handleCopy} className="absolute top-3 right-3 p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label="Copy post content">
                                    <CopyIcon className="h-5 w-5" />
                                </button>
                                {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
                            </div>
                            
                            <div className="space-y-2">
                                <Accordion title="📊 Content Quality Score" defaultOpen={true}>
                                    <div className="space-y-4 p-2">
                                        <ScoreBar score={parsedOutput.contentQuality.hookEffectiveness} label="Hook Effectiveness" />
                                        <ScoreBar score={parsedOutput.contentQuality.valueClarity} label="Value Clarity" />
                                        <ScoreBar score={parsedOutput.contentQuality.engagementPotential} label="Engagement Potential" />
                                        <ScoreBar score={parsedOutput.contentQuality.professionalTone} label="Professional Tone" />
                                    </div>
                                </Accordion>
                                <Accordion title="🚀 Hashtag Performance & Strategy" defaultOpen={true}>
                                    <div className="space-y-4 p-2">
                                         <div className="grid grid-cols-3 gap-4 text-center">
                                            <div><p className="text-lg font-bold text-brand-primary">{parsedOutput.hashtagAnalysis.reachScore}/10</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Reach</p></div>
                                            <div><p className="text-lg font-bold text-brand-primary">{parsedOutput.hashtagAnalysis.relevanceScore}/10</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Relevance</p></div>
                                            <div><p className="text-lg font-bold text-brand-primary">{parsedOutput.hashtagAnalysis.authorityScore}/10</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Authority</p></div>
                                         </div>
                                         <div className="pt-2">
                                            <h4 className="text-sm font-semibold text-text-primary dark:text-d-text-primary mb-2">Recommended Hashtags:</h4>
                                            <div className="flex flex-wrap gap-2">
                                                {parsedOutput.hashtagAnalysis.hashtags.map((h, i) => (
                                                    <div key={i} className="bg-base-300 dark:bg-d-base-300 px-2 py-1 rounded-md text-xs">
                                                        <span className="font-semibold text-text-primary dark:text-d-text-primary">{h.tag}</span>
                                                        <span className="text-text-secondary dark:text-d-text-secondary ml-1.5">({h.tier})</span>
                                                    </div>
                                                ))}
                                            </div>
                                         </div>
                                    </div>
                                </Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default LinkedInStylerView;
