import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface PerformanceAnalysis {
    metric: string;
    score: number;
    analysis: string;
}

interface PredictionResult {
    overallScore: number;
    engagementRate: string;
    estimatedReach: string;
    viralityScore: number;
    performanceAnalysis: PerformanceAnalysis[];
    improvementSuggestions: string[];
}

const predictionSchema = {
    type: Type.OBJECT,
    properties: {
        overallScore: { type: Type.NUMBER, description: "Overall performance score (0-100), representing a weighted average of all factors." },
        engagementRate: { type: Type.STRING, description: "Predicted engagement rate as a string range (e.g., '2.5% - 4.0%')." },
        estimatedReach: { type: Type.STRING, description: "Estimated potential reach as a string range (e.g., '10k - 15k')." },
        viralityScore: { type: Type.NUMBER, description: "Virality potential score (0-100)." },
        performanceAnalysis: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    metric: { type: Type.STRING, description: "The metric being analyzed (e.g., 'Hook Strength', 'Readability', 'Call to Action')." },
                    score: { type: Type.NUMBER, description: "Score for the metric (0-10)." },
                    analysis: { type: Type.STRING, description: "Brief, actionable analysis or suggestion for this metric." }
                },
                 required: ['metric', 'score', 'analysis']
            }
        },
        improvementSuggestions: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 3-5 actionable, high-impact suggestions to improve the content's performance."
        }
    },
    required: ['overallScore', 'engagementRate', 'estimatedReach', 'viralityScore', 'performanceAnalysis', 'improvementSuggestions']
};

const AIPerformancePredictorView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [step, setStep] = useState<'input' | 'results'>('input');
    
    // Form State
    const [content, setContent] = useState('');
    const [platform, setPlatform] = useState('LinkedIn');
    const [audienceSize, setAudienceSize] = useState('10k-100k');
    const [contentType, setContentType] = useState('Educational');
    const [tones, setTones] = useState<string[]>([]);
    
    // API State
    const [prediction, setPrediction] = useState<PredictionResult | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && content.trim();

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setPrediction(null);
        setIsQueued(false);

        const prompt = `You are a world-class social media data scientist. Based on the following content and its context, predict its performance and provide actionable feedback. Your response must be a valid JSON object conforming to the provided schema.

        **Content to Analyze:**
        ---
        ${content}
        ---

        **Context:**
        - Platform: ${platform}
        - Audience Size: ${audienceSize}
        - Content Type: ${contentType}
        - Tones: ${tones.length > 0 ? tones.join(', ') : 'Not specified'}

        Generate a detailed performance prediction. The scores should be realistic based on the platform and audience. The suggestions should be specific and helpful.`;

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: predictionSchema,
            });
            const parsed = JSON.parse(result);
            setPrediction(parsed);
            setStep('results');
            
            if(userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: `Content: ${content.substring(0,100)}... | Platform: ${platform}`,
                    output: JSON.stringify(parsed, null, 2),
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse prediction: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, content, platform, audienceSize, contentType, tones, module.id, module.name, userId, usesLeft, decrementUse]);

    const handleStartOver = () => {
        setStep('input');
        setPrediction(null);
        setError(null);
    };

    const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    const ScoreGauge: React.FC<{ score: number }> = ({ score }) => {
        const circumference = 2 * Math.PI * 45;
        const offset = circumference - (score / 100) * circumference;
        const color = score >= 80 ? 'text-brand-secondary' : score >= 60 ? 'text-yellow-500' : 'text-error';

        return (
            <div className="relative flex items-center justify-center h-48 w-48">
                <svg className="absolute" width="100%" height="100%" viewBox="0 0 100 100">
                    <circle className="text-base-300 dark:text-d-base-300" strokeWidth="10" stroke="currentColor" fill="transparent" r="45" cx="50" cy="50" />
                    <circle
                        className={`${color} transition-all duration-1000 ease-out`}
                        strokeWidth="10"
                        strokeDasharray={circumference}
                        strokeDashoffset={offset}
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="transparent"
                        r="45"
                        cx="50"
                        cy="50"
                        transform="rotate(-90 50 50)"
                    />
                </svg>
                <span className={`text-5xl font-bold ${color}`}>{score}</span>
            </div>
        )
    };

    return (
        <>
        <div className="max-w-4xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            
            {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}

            {step === 'input' && (
                <div className="space-y-6">
                    <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-4">
                        <h3 className="text-xl font-bold font-heading">📝 Content & Context</h3>
                         <div>
                            <label htmlFor="content" className={commonLabelClasses}>Content to Analyze</label>
                            <textarea id="content" value={content} onChange={e => setContent(e.target.value)} placeholder="Paste your social media post, blog content, or any text..." className={`${commonInputClasses} min-h-[150px]`} />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Platform</label>
                                <select value={platform} onChange={e => setPlatform(e.target.value)} className={commonInputClasses}>
                                    <option>LinkedIn</option><option>Twitter</option><option>Instagram</option><option>Facebook</option><option>Blog</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Audience Size</label>
                                 <select value={audienceSize} onChange={e => setAudienceSize(e.target.value)} className={commonInputClasses}>
                                    <option value="1k-10k">Small (1k-10k)</option><option value="10k-100k">Medium (10k-100k)</option><option value="100k-1M">Large (100k-1M)</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Content Type</label>
                                 <select value={contentType} onChange={e => setContentType(e.target.value)} className={commonInputClasses}>
                                    <option>Educational</option><option>Promotional</option><option>Inspirational</option><option>Entertainment</option>
                                </select>
                            </div>
                        </div>
                         <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg p-3 w-full text-left hover:border-brand-primary/50 transition-colors">
                            <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                        </button>
                    </div>

                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed transition-all">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : '🔮 Predict Performance'}
                    </button>
                </div>
            )}
            
            {isLoading && step === 'input' && <div className="text-center p-8">Loading...</div>}
            
            {step === 'results' && prediction && (
                <div className="space-y-8">
                    <div className="bg-base-200 dark:bg-d-base-200 rounded-xl p-6 flex flex-col md:flex-row items-center gap-6">
                        <ScoreGauge score={prediction.overallScore} />
                        <div className="flex-1 text-center md:text-left">
                             <h3 className="text-2xl font-bold font-heading">Overall Score: {prediction.overallScore}/100</h3>
                             <p className="text-text-secondary dark:text-d-text-secondary mt-2">{prediction.overallScore >= 80 ? "Excellent! This content has high potential to perform well." : prediction.overallScore >= 60 ? "Good start! This content has solid potential with some tweaks." : "This content could be improved to reach its full potential."}</p>
                             <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-4 text-center">
                                <div><p className="text-xl font-bold text-brand-primary">{prediction.engagementRate}</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Engagement</p></div>
                                <div><p className="text-xl font-bold text-brand-primary">{prediction.estimatedReach}</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Reach</p></div>
                                <div><p className="text-xl font-bold text-brand-primary">{prediction.viralityScore}/100</p><p className="text-xs text-text-secondary dark:text-d-text-secondary">Virality Score</p></div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 className="text-xl font-bold font-heading mb-4">🔬 Performance Breakdown</h3>
                        <div className="space-y-3">
                            {prediction.performanceAnalysis.map((item, i) => (
                                <div key={i} className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg">
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="font-semibold">{item.metric}</span>
                                        <span className="font-bold">{item.score}/10</span>
                                    </div>
                                    <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2 mb-2">
                                        <div className="bg-brand-secondary h-2 rounded-full" style={{width: `${item.score * 10}%`}}></div>
                                    </div>
                                    <p className="text-xs text-text-secondary dark:text-d-text-secondary">{item.analysis}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                    
                    <div>
                        <h3 className="text-xl font-bold font-heading mb-4">💡 Improvement Suggestions</h3>
                         <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg">
                            <ul className="list-disc list-inside space-y-2 text-text-primary dark:text-d-text-primary">
                                {prediction.improvementSuggestions.map((tip, i) => <li key={i}>{tip}</li>)}
                            </ul>
                        </div>
                    </div>
                    
                    <button onClick={handleStartOver} className="w-full flex justify-center items-center px-6 py-3 border-2 border-base-300 dark:border-d-base-300 text-base font-medium rounded-xl shadow-sm hover:bg-base-200 dark:hover:bg-d-base-200 transition-colors">
                        Analyze Another Post
                    </button>
                </div>
            )}

        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default AIPerformancePredictorView;