import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { saveGeneration } from '../services/historyService';
import { addToQueue } from '../services/offlineService';
import { useFeedback } from '../hooks/useFeedback';
import { Type } from '@google/genai';
import CopyIcon from './icons/CopyIcon';
import SparklesIcon from './icons/settings/SparklesIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface Slogan {
    type: string;
    text: string;
    rating: number;
}

interface ParsedOutput {
    slogans: Slogan[];
}

const sloganSchema = {
    type: Type.OBJECT,
    properties: {
        slogans: {
            type: Type.ARRAY,
            description: "An array of 4-6 distinct slogan ideas based on the user's input.",
            items: {
                type: Type.OBJECT,
                properties: {
                    type: { type: Type.STRING, description: "The strategic type of the slogan (e.g., Memorable, Benefit-driven, Descriptive, Emotional)." },
                    text: { type: Type.STRING, description: "The slogan text." },
                    rating: { type: Type.NUMBER, description: "A score from 1 to 5 indicating quality and effectiveness." },
                },
                required: ['type', 'text', 'rating']
            }
        }
    },
    required: ['slogans']
};

const StarRating: React.FC<{ rating: number }> = ({ rating }) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
        stars.push(
            <svg key={i} className={`h-4 w-4 ${i <= rating ? 'text-yellow-400' : 'text-gray-300 dark:text-gray-600'}`} fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.368 2.448a1 1 0 00-.364 1.118l1.286 3.957c.3.921-.755 1.688-1.54 1.118l-3.368-2.448a1 1 0 00-1.175 0l-3.368 2.448c-.784.57-1.838-.197-1.54-1.118l1.286-3.957a1 1 0 00-.364-1.118L2.05 9.392c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69L9.049 2.927z" />
            </svg>
        );
    }
    return <div className="flex">{stars}</div>;
};


const SloganGeneratorView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const { playClick, playSuccess } = useFeedback();

    const [brandName, setBrandName] = useState('');
    const [brandDescription, setBrandDescription] = useState('');
    const [targetAudience, setTargetAudience] = useState('');
    const [keyBenefits, setKeyBenefits] = useState('');
    const [selectedSloganType, setSelectedSloganType] = useState('memorable');
    const [selectedTone, setSelectedTone] = useState('professional');
    const [sloganLength, setSloganLength] = useState('medium');

    const [generatedSlogans, setGeneratedSlogans] = useState<Slogan[]>([]);
    const [featuredSlogan, setFeaturedSlogan] = useState('Your Perfect Slogan Awaits');
    const [sloganContext, setSloganContext] = useState('Generate slogan ideas to see them displayed here');

    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && brandName.trim() && brandDescription.trim();

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        playClick();
        setIsLoading(true);
        setError(null);
        setGeneratedSlogans([]);
        setIsQueued(false);

        const prompt = `You are an expert copywriter and branding specialist. Generate a set of compelling slogans based on the user's input.

        **INPUT:**
        - Brand Name: ${brandName}
        - Description: ${brandDescription}
        - Target Audience: ${targetAudience}
        - Key Benefits: ${keyBenefits}
        - Slogan Type Focus: ${selectedSloganType}
        - Desired Tone: ${selectedTone}
        - Desired Length: ${sloganLength}

        **INSTRUCTIONS:**
        1. Generate 4-6 distinct slogan variations that align with the user's input.
        2. Ensure the slogans are creative, memorable, and relevant.
        3. For each slogan, provide a strategic 'type', the slogan 'text', and a 'rating' from 1 to 5 on its potential effectiveness.
        4. Your response must be a valid JSON object conforming to the provided schema.`;

        if (!navigator.onLine) {
            try {
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: 'application/json',
                responseSchema: sloganSchema as any,
            });
            const parsed: ParsedOutput = JSON.parse(result);
            setGeneratedSlogans(parsed.slogans);
            if (parsed.slogans.length > 0) {
                setFeaturedSlogan(parsed.slogans[0].text);
                setSloganContext(`Perfect for ${brandName} - ${parsed.slogans[0].type} approach`);
            }
            playSuccess();

            if (userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt.split('**INSTRUCTIONS**')[0],
                    output: parsed.slogans.map(s => s.text).join('\n'),
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();

        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, brandName, brandDescription, targetAudience, keyBenefits, selectedSloganType, selectedTone, sloganLength, playClick, playSuccess, module.id, module.name, userId, usesLeft, decrementUse]);

    const sloganTypes = [
        { id: 'memorable', name: 'Memorable', icon: '🧠', desc: 'Catchy & easy to remember' },
        { id: 'benefit', name: 'Benefit-driven', icon: '⭐', desc: 'Focuses on customer value' },
        { id: 'descriptive', name: 'Descriptive', icon: '📋', desc: 'Clearly explains what you do' },
        { id: 'emotional', name: 'Emotional', icon: '❤️', desc: 'Creates emotional connection' }
    ];

    const tones = [
        { id: 'professional', name: 'Professional' },
        { id: 'friendly', name: 'Friendly' },
        { id: 'bold', name: 'Bold' },
        { id: 'inspirational', name: 'Inspirational' },
        { id: 'modern', name: 'Modern' },
        { id: 'playful', name: 'Playful' }
    ];

    return (
        <div className="slogan-generator-module max-w-7xl mx-auto flex flex-col gap-8">
            <header className="text-center">
                <h1 className="text-3xl font-bold font-heading">{module.name}</h1>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <section className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-4">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="section-icon w-12 h-12 rounded-xl flex items-center justify-center text-white text-2xl">
                            <i className="fas fa-bullhorn"></i>
                        </div>
                        <h2 className="text-2xl font-bold font-heading">Create Your Slogan</h2>
                    </div>
                    <input type="text" value={brandName} onChange={e => setBrandName(e.target.value)} placeholder="Brand/Company Name" className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                    <textarea value={brandDescription} onChange={e => setBrandDescription(e.target.value)} placeholder="What You Do/Offer..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[100px]"></textarea>
                    <input type="text" value={targetAudience} onChange={e => setTargetAudience(e.target.value)} placeholder="Target Audience (e.g., young professionals)" className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                    <textarea value={keyBenefits} onChange={e => setKeyBenefits(e.target.value)} placeholder="Key Benefits (comma separated)..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[100px]"></textarea>
                    
                    <div>
                        <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">Slogan Type</label>
                        <div className="grid grid-cols-2 gap-2">
                            {sloganTypes.map(type => (
                                <button key={type.id} onClick={() => setSelectedSloganType(type.id)} className={`option-card p-3 rounded-lg border-2 text-center transition-all duration-200 bg-base-100 dark:bg-d-base-100 ${selectedSloganType === type.id ? 'selected' : 'border-transparent'}`}>
                                    <div className="option-icon text-2xl mx-auto">{type.icon}</div>
                                    <div className="text-sm font-semibold">{type.name}</div>
                                </button>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">Tone of Voice</label>
                        <div className="grid grid-cols-3 gap-2">
                             {tones.map(tone => (
                                <button key={tone.id} onClick={() => setSelectedTone(tone.id)} className={`option-card p-3 rounded-lg border-2 text-sm font-semibold ${selectedTone === tone.id ? 'selected' : 'border-transparent bg-base-100 dark:bg-d-base-100'}`}>
                                    {tone.name}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">Preferred Length</label>
                        <select value={sloganLength} onChange={e => setSloganLength(e.target.value)} className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100">
                            <option value="short">Short (3-5 words)</option>
                            <option value="medium">Medium (6-8 words)</option>
                            <option value="long">Long (9-12 words)</option>
                        </select>
                    </div>

                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full btn-primary flex items-center justify-center p-4 rounded-xl text-white font-bold text-lg gap-2">
                        {isLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/50 border-t-white rounded-full"></span> : <SparklesIcon className="h-6 w-6" />}
                        {isLoading ? 'Generating...' : 'Generate Slogan Ideas'}
                    </button>
                    {error && <div className="text-center bg-error/20 text-error p-2 rounded-lg text-sm">{error}</div>}
                </section>
                <section className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl flex flex-col">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="section-icon w-12 h-12 rounded-xl flex items-center justify-center text-white text-2xl">
                           <i className="fas fa-eye"></i>
                        </div>
                        <h2 className="text-2xl font-bold font-heading">Slogan Preview</h2>
                    </div>
                    <div className="flex-1 bg-base-100 dark:bg-d-base-100 p-4 rounded-lg overflow-y-auto border border-base-300 dark:border-d-base-300">
                        <div className="slogan-display bg-gradient-to-r from-marketing to-orange-400 p-6 rounded-lg text-white text-center">
                            <div className="text-2xl font-bold">{featuredSlogan}</div>
                            <div className="text-xs opacity-80 mt-2">{sloganContext}</div>
                        </div>

                        <div className="results-grid space-y-3 mt-4">
                            {generatedSlogans.map((slogan, index) => (
                                <div key={index} className={`result-card bg-base-200 dark:bg-d-base-200 p-3 rounded-lg ${slogan.text === featuredSlogan ? 'featured' : ''}`}>
                                    <div className="flex justify-between items-center mb-2">
                                        <div className="result-type text-xs font-bold uppercase text-white px-2 py-0.5 rounded-full">{slogan.type}</div>
                                        <StarRating rating={slogan.rating} />
                                    </div>
                                    <p className="font-semibold text-lg">{slogan.text}</p>
                                    <div className="flex justify-between items-center mt-2">
                                        <span className="text-xs text-text-secondary dark:text-d-text-secondary">{slogan.text.split(' ').length} words</span>
                                        <button onClick={() => { setFeaturedSlogan(slogan.text); setSloganContext(`Perfect for ${brandName} - ${slogan.type} approach`); }} className="px-3 py-1 text-xs font-semibold bg-brand-primary text-white rounded-md">Use</button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
};

export default SloganGeneratorView;