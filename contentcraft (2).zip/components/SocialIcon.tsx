import React from 'react';
import FacebookIcon from './icons/social/FacebookIcon';
import InstagramIcon from './icons/social/InstagramIcon';
import TwitterIcon from './icons/social/TwitterIcon';
import LinkedInIcon from './icons/social/LinkedInIcon';
import YouTubeIcon from './icons/social/YouTubeIcon';
import TikTokIcon from './icons/social/TikTokIcon';
import PinterestIcon from './icons/social/PinterestIcon';
import QuoraIcon from './icons/social/QuoraIcon';
import HashtagIcon from './icons/social/HashtagIcon';
import BlogIcon from './icons/social/BlogIcon';

interface SocialIconProps {
  moduleId: string;
}

const IconWrapper: React.FC<{ children: React.ReactNode; className?: string; }> = ({ children, className = '' }) => (
  <div className={`h-12 w-12 rounded-xl flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform duration-200 ${className}`}>
    {children}
  </div>
);

const SocialIcon: React.FC<SocialIconProps> = ({ moduleId }) => {
  switch (moduleId) {
    case 'linkedin-styler':
      return <IconWrapper className="bg-[#0077b5]"><LinkedInIcon className="h-7 w-7 text-white" /></IconWrapper>;
    case 'instagram-styler':
      return <IconWrapper className="bg-gradient-to-br from-[#833ab4] via-[#fd1d1d] to-[#fcb045]"><InstagramIcon className="h-8 w-8 text-white" /></IconWrapper>;
    case 'twitter-styler':
      return <IconWrapper className="bg-[#1DA1F2]"><TwitterIcon className="h-7 w-7 text-white" /></IconWrapper>;
    case 'facebook-styler':
      return <IconWrapper className="bg-[#1877F2]"><FacebookIcon className="h-8 w-8 text-white" /></IconWrapper>;
    case 'youtube-styler':
      return <IconWrapper className="bg-[#FF0000]"><YouTubeIcon className="h-7 w-7 text-white" /></IconWrapper>;
    case 'youtube-to-blog':
       return <IconWrapper className="bg-[#FF0000]"><YouTubeIcon className="h-7 w-7 text-white" /></IconWrapper>;
    case 'tiktok-styler':
      return <IconWrapper className="bg-black"><TikTokIcon className="h-8 w-8" /></IconWrapper>;
    case 'hashtag-generator':
      return <IconWrapper className="bg-gradient-to-br from-teal-400 to-cyan-500"><HashtagIcon className="h-7 w-7 text-white" /></IconWrapper>;
    case 'pinterest-styler':
      return <IconWrapper className="bg-[#E60023]"><PinterestIcon className="h-7 w-7 text-white" /></IconWrapper>;
    case 'blog-ideas-generator':
      return <IconWrapper className="bg-gradient-to-br from-purple-500 to-indigo-500"><BlogIcon className="h-7 w-7 text-white" /></IconWrapper>;
    case 'quora-answer':
      return <IconWrapper className="bg-[#b92b27]"><QuoraIcon className="h-8 w-8 text-white" /></IconWrapper>;
    default:
      return null;
  }
};

export default SocialIcon;
