import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ToneSelector from './ToneSelector';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type AnnouncementType = 'Product Launch' | 'Partnership' | 'Funding' | 'Acquisition' | 'Event' | 'Hiring' | 'Award';
type TargetMedia = 'Trade Press' | 'Business Media' | 'Local News' | 'Industry Blogs';
type GeoScope = 'Local' | 'National' | 'International' | 'Global';
type Urgency = 'Standard' | 'Embargoed' | 'Immediate';

const PRESS_RELEASE_PROMPT = `
You are an expert PR strategist and media relations specialist following professional journalism standards. Create a comprehensive press release package.

**INPUT:**
- Announcement Type: {ANNOUNCEMENT_TYPE}
- Company/Organization: {COMPANY_NAME}
- Key News Angle & Details: {NEWS_ANGLE}
- Target Media: {TARGET_MEDIA}
- Geographic Scope: {GEO_SCOPE}
- Urgency Level: {URGENCY}
- Tone: {SELECTED_TONES}

**TASK:**
Generate a complete press release package. The output MUST follow this structure exactly:

---PRESS RELEASE START---

**FOR {URGENCY_TEXT} RELEASE**

**HEADLINE:**
[Your headline here, 80-110 characters, active voice]

**SUBHEADLINE:**
[Your subheadline here, 120-160 characters, expands on headline]

**DATELINE:** [City, State] – [Date] –
[Your lead paragraph (Who, What, When, Where, Why) here.]

[Your body paragraphs here, providing context, details, and at least one executive quote and one external validation quote (e.g., customer, partner).]

**About {COMPANY_NAME}:**
[Your boilerplate here: company mission, key differentiators, founding year, location.]

**Media Contact:**
[Name]
[Title]
[Email]
[Phone Number]
[Website/Media Kit Link]

###

---PRESS RELEASE END---

---ANALYSIS START---

**STRATEGY FRAMEWORK:**
- **Newsworthiness Assessment:** [Brief analysis of Timeliness, Impact, Prominence, and Human Interest of the announcement.]
- **Media Targeting Strategy:** [Brief strategy for pitching to {TARGET_MEDIA}, Business Media, and Local Media.]

**PERFORMANCE PREDICTION:**
- **Media Appeal Score:** [X]/10
- **Newsworthiness Score:** [Y]/10
- **SEO Optimization Score:** [Z]/10

**MEDIA PITCH ANGLES:**
1. **For {TARGET_MEDIA}:** [A concise pitch angle tailored for this media type.]
2. **For General Business Press:** [A pitch angle focused on financial impact or market implications.]
3. **For Social Media (e.g., LinkedIn):** [A short, engaging post to announce the news.]

---ANALYSIS END---
`;

interface ParsedPressRelease {
    urgencyText: string;
    headline: string;
    subheadline: string;
    body: string; // Combined dateline, body, about, contact
}
interface ParsedAnalysis {
    strategyFramework: string;
    performancePrediction: string;
    mediaPitchAngles: string;
}
interface ParsedOutput {
    pressRelease: ParsedPressRelease;
    analysis: ParsedAnalysis;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const PressReleaseView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [announcementType, setAnnouncementType] = useState<AnnouncementType>('Product Launch');
    const [companyName, setCompanyName] = useState('');
    const [newsAngle, setNewsAngle] = useState('');
    const [targetMedia, setTargetMedia] = useState<TargetMedia>('Trade Press');
    const [geoScope, setGeoScope] = useState<GeoScope>('National');
    const [urgency, setUrgency] = useState<Urgency>('Immediate');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && companyName.trim() && newsAngle.trim();
    
    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string, source = text) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = source.match(regex);
                return match ? match[1].trim() : 'Could not parse section.';
            };

            const pressReleaseText = getSection('---PRESS RELEASE START---', '---PRESS RELEASE END---');
            const analysisText = getSection('---ANALYSIS START---', '---ANALYSIS END---');
            
            return {
                pressRelease: {
                    urgencyText: getSection('\\*\\*FOR', 'RELEASE\\*\\*'),
                    headline: getSection('\\*\\*HEADLINE:\\*\\*', '\\*\\*SUBHEADLINE:\\*\\*', pressReleaseText),
                    subheadline: getSection('\\*\\*SUBHEADLINE:\\*\\*', '\\*\\*DATELINE:\\*\\*', pressReleaseText),
                    body: getSection('\\*\\*DATELINE:\\*\\*', '###', pressReleaseText),
                },
                analysis: {
                    strategyFramework: getSection('\\*\\*STRATEGY FRAMEWORK:\\*\\*', '\\*\\*PERFORMANCE PREDICTION:\\*\\*', analysisText),
                    performancePrediction: getSection('\\*\\*PERFORMANCE PREDICTION:\\*\\*', '\\*\\*MEDIA PITCH ANGLES:\\*\\*', analysisText),
                    mediaPitchAngles: getSection('\\*\\*MEDIA PITCH ANGLES:\\*\\*', '$', analysisText),
                }
            };
        } catch (e) {
            console.error("Failed to parse Press Release output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return PRESS_RELEASE_PROMPT
            .replace('{ANNOUNCEMENT_TYPE}', announcementType)
            .replace(/{COMPANY_NAME}/g, companyName)
            .replace('{NEWS_ANGLE}', newsAngle)
            .replace(/{TARGET_MEDIA}/g, targetMedia)
            .replace('{GEO_SCOPE}', geoScope)
            .replace('{URGENCY}', urgency)
            .replace('{URGENCY_TEXT}', urgency.toUpperCase())
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Professional');
    }, [announcementType, companyName, newsAngle, targetMedia, geoScope, urgency, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };
    
    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <div>
                        <label className={commonLabelClasses}>Company/Organization Name</label>
                        <input value={companyName} onChange={e => setCompanyName(e.target.value)} placeholder="e.g., InnovateTech Solutions" className={commonInputClasses} />
                    </div>
                    <textarea value={newsAngle} onChange={e => setNewsAngle(e.target.value)} placeholder="Describe the key news angle and core details of your announcement..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Press Release Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Announcement Type</label>
                                <select value={announcementType} onChange={e => setAnnouncementType(e.target.value as AnnouncementType)} className={commonInputClasses}>
                                    <option>Product Launch</option><option>Partnership</option><option>Funding</option><option>Acquisition</option><option>Event</option><option>Hiring</option><option>Award</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Target Media</label>
                                <select value={targetMedia} onChange={e => setTargetMedia(e.target.value as TargetMedia)} className={commonInputClasses}>
                                    <option>Trade Press</option><option>Business Media</option><option>Local News</option><option>Industry Blogs</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Geographic Scope</label>
                                <select value={geoScope} onChange={e => setGeoScope(e.target.value as GeoScope)} className={commonInputClasses}>
                                    <option>National</option><option>Local</option><option>International</option><option>Global</option>
                                </select>
                            </div>
                             <div>
                                <label className={commonLabelClasses}>Urgency</label>
                                <select value={urgency} onChange={e => setUrgency(e.target.value as Urgency)} className={commonInputClasses}>
                                    <option>Immediate</option><option>Standard</option><option>Embargoed</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Generating Release...' : (isQueued ? 'Request Queued' : 'Generate Press Release')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && (companyName.trim() || newsAngle.trim()) && <p className="text-center text-yellow-500 text-sm mt-2">Please fill in Company Name and News Angle.</p>}
                </div>
                <div className="bg-base-100 dark:bg-d-base-100 rounded-lg p-6 min-h-[500px] overflow-y-auto shadow-inner prose prose-sm dark:prose-invert max-w-none relative group">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Building your professional press release...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your comprehensive press release will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-6">
                            <button onClick={() => navigator.clipboard.writeText(Object.values(parsedOutput.pressRelease).join('\n\n'))} className="absolute top-4 right-4 p-2 rounded-lg bg-base-300/50 dark:bg-d-base-300/50 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Copy Full Press Release">
                               <CopyIcon className="h-5 w-5" />
                            </button>

                            <div className="text-center font-semibold text-text-secondary dark:text-d-text-secondary text-xs tracking-widest">FOR {urgency.toUpperCase()} RELEASE</div>
                            <h1 className="text-2xl font-bold font-heading text-text-primary dark:text-d-text-primary text-center !my-2">{parsedOutput.pressRelease.headline}</h1>
                            <p className="text-center text-md italic text-text-secondary dark:text-d-text-secondary !my-2">{parsedOutput.pressRelease.subheadline}</p>
                            
                            <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.pressRelease.body)} />
                            
                            <div className="space-y-2 pt-8">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-4">Strategy & Analysis</h3>
                                <Accordion title={<>📊 <span className="ml-2">Strategy Framework</span></>} defaultOpen={true}><div dangerouslySetInnerHTML={formatContent(parsedOutput.analysis.strategyFramework)}/></Accordion>
                                <Accordion title={<>📈 <span className="ml-2">Performance Prediction</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.analysis.performancePrediction)}/></Accordion>
                                <Accordion title={<>🎯 <span className="ml-2">Media Pitch Angles</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.analysis.mediaPitchAngles)}/></Accordion>
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default PressReleaseView;
