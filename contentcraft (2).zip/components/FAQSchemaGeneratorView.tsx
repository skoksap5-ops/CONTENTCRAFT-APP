import React, { useState, useCallback, useMemo } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { saveGeneration } from '../services/historyService';
import { addToQueue } from '../services/offlineService';
import { useFeedback } from '../hooks/useFeedback';
import { Type } from '@google/genai';
import CopyIcon from './icons/CopyIcon';
import TrashIcon from './icons/TrashIcon';
import SparklesIcon from './icons/settings/SparklesIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import SearchIcon from './icons/SearchIcon';
import CodeBracketIcon from './icons/settings/CodeBracketIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface FAQItem {
    id: number;
    question: string;
    answer: string;
}

const faqPairsSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            question: { type: Type.STRING },
            answer: { type: Type.STRING }
        },
        required: ['question', 'answer']
    }
};

const FAQSchemaGeneratorView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const { playClick, playSuccess } = useFeedback();

    const [pageTitle, setPageTitle] = useState('');
    const [pageUrl, setPageUrl] = useState('');
    const [pageContent, setPageContent] = useState('');
    const [faqItems, setFaqItems] = useState<FAQItem[]>([{ id: 1, question: '', answer: '' }]);
    const [selectedFormat, setSelectedFormat] = useState<'json-ld' | 'microdata'>('json-ld');
    const [activeTab, setActiveTab] = useState<'code' | 'preview'>('preview');
    
    const [generatedSchema, setGeneratedSchema] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isAiLoading, setIsAiLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);

    const canGenerateSchema = useMemo(() => faqItems.some(item => item.question.trim() && item.answer.trim()), [faqItems]);

    const handleAddFaq = () => {
        playClick();
        setFaqItems(prev => [...prev, { id: Date.now(), question: '', answer: '' }]);
    };

    const handleRemoveFaq = (id: number) => {
        playClick();
        if (faqItems.length > 1) {
            setFaqItems(prev => prev.filter(item => item.id !== id));
        }
    };

    const handleFaqChange = (id: number, field: 'question' | 'answer', value: string) => {
        setFaqItems(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
    };
    
    const generateSchema = () => {
        if (!canGenerateSchema) {
             setError('Please add at least one complete FAQ item.');
             return;
        }
        playClick();
        setError(null);

        const validFaqItems = faqItems.filter(item => item.question.trim() && item.answer.trim());

        if (selectedFormat === 'json-ld') {
            const schema = {
                "@context": "https://schema.org",
                "@type": "FAQPage",
                "mainEntity": validFaqItems.map(faq => ({
                    "@type": "Question",
                    "name": faq.question,
                    "acceptedAnswer": {
                        "@type": "Answer",
                        "text": faq.answer
                    }
                }))
            };
            setGeneratedSchema(JSON.stringify(schema, null, 2));
        } else { // microdata
            let microdata = `<div itemscope itemtype="https://schema.org/FAQPage">\n`;
            validFaqItems.forEach(faq => {
                microdata += `  <div itemprop="mainEntity" itemscope itemtype="https://schema.org/Question">\n`;
                microdata += `    <h3 itemprop="name">${faq.question}</h3>\n`;
                microdata += `    <div itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">\n`;
                microdata += `      <div itemprop="text">${faq.answer}</div>\n`;
                microdata += `    </div>\n  </div>\n`;
            });
            microdata += `</div>`;
            setGeneratedSchema(microdata);
        }
        playSuccess();
    };
    
    const handleGenerateQAWithAI = useCallback(async () => {
        if (!pageContent.trim() || (usesLeft !== 'Unlimited' && usesLeft <= 0)) {
            setError("Please provide some page content to generate Q&A from, and ensure you have uses left.");
            return;
        }
        setIsAiLoading(true);
        setError(null);
        playClick();

        const prompt = `Based on the following page title and content, generate 5 relevant and concise frequently asked questions and their answers.
        
        Page Title: "${pageTitle}"
        
        Content:
        ---
        ${pageContent}
        ---
        
        Your response must be a valid JSON array conforming to the schema.`;

        try {
            const result = await generateContent(prompt, {
                responseMimeType: 'application/json',
                responseSchema: faqPairsSchema,
            });
            const newFaqs: {question: string, answer: string}[] = JSON.parse(result);
            setFaqItems(newFaqs.map((faq, i) => ({ id: Date.now() + i, ...faq })));
            if (usesLeft !== 'Unlimited') decrementUse();
            playSuccess();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An error occurred generating Q&A.');
        } finally {
            setIsAiLoading(false);
        }
    }, [pageTitle, pageContent, usesLeft, decrementUse, playClick, playSuccess]);

    const syntaxHighlight = (json: string) => {
        if (!json) return '';
        json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
            let cls = 'schema-number';
            if (/^"/.test(match)) {
                cls = /:$/.test(match) ? 'schema-key' : 'schema-string';
            } else if (/true|false/.test(match)) {
                cls = 'schema-boolean';
            }
            return `<span class="${cls}">${match}</span>`;
        });
    };

    // FIX: Define commonInputClasses to resolve reference errors.
    const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";

    return (
        <div className="faq-schema-module max-w-7xl mx-auto flex flex-col gap-8">
            <header className="text-center">
                <h1 className="text-3xl font-bold font-heading">{module.name}</h1>
                <p className="subtitle text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </header>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <section className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-4">
                    <h2 className="text-2xl font-bold font-heading mb-4">FAQ Details</h2>
                    <input type="text" value={pageTitle} onChange={e => setPageTitle(e.target.value)} placeholder="Page Title (where FAQ will appear)" className={commonInputClasses} />
                    <input type="text" value={pageUrl} onChange={e => setPageUrl(e.target.value)} placeholder="Page URL (https://...)" className={commonInputClasses} />
                    <textarea value={pageContent} onChange={e => setPageContent(e.target.value)} placeholder="Paste page content here to auto-generate Q&A (optional)..." className={`${commonInputClasses} min-h-[120px]`} />
                    <button onClick={handleGenerateQAWithAI} disabled={isAiLoading || !pageContent.trim()} className="w-full btn-primary flex items-center justify-center p-3 rounded-lg text-white font-semibold gap-2 disabled:bg-gray-400">
                        {isAiLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/50 border-t-white rounded-full"></span> : <SparklesIcon className="h-5 w-5" />}
                        {isAiLoading ? 'Generating...' : 'Generate Q&A with AI'}
                    </button>
                    
                    <div className="space-y-3 pt-4">
                        {faqItems.map((item, index) => (
                            <div key={item.id} className="faq-item bg-base-100 dark:bg-d-base-100 p-4 rounded-lg border border-base-300 dark:border-d-base-300">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="font-bold">Q{index + 1}</span>
                                    <button onClick={() => handleRemoveFaq(item.id)} disabled={faqItems.length <= 1} className="p-1 text-text-secondary dark:text-d-text-secondary hover:text-error disabled:opacity-50"><TrashIcon className="h-5 w-5"/></button>
                                </div>
                                <input type="text" value={item.question} onChange={e => handleFaqChange(item.id, 'question', e.target.value)} placeholder="Question..." className={`${commonInputClasses} mb-2`}/>
                                <textarea value={item.answer} onChange={e => handleFaqChange(item.id, 'answer', e.target.value)} placeholder="Answer..." className={`${commonInputClasses} min-h-[80px]`}/>
                            </div>
                        ))}
                    </div>

                    <button onClick={handleAddFaq} className="w-full p-3 font-semibold border-2 border-dashed border-base-300 dark:border-d-base-300 rounded-lg hover:border-brand-primary hover:text-brand-primary transition-colors">+ Add Question</button>
                </section>

                 <section className="preview-section bg-base-200 dark:bg-d-base-200 p-6 rounded-xl flex flex-col">
                    <h2 className="text-2xl font-bold font-heading mb-4">Schema & Preview</h2>
                    
                    <div className="flex justify-center border-b border-base-300 dark:border-d-base-300 mb-4">
                        <button onClick={() => setActiveTab('preview')} className={`tab px-4 py-2 font-semibold ${activeTab === 'preview' ? 'active' : ''}`}>Search Preview</button>
                        <button onClick={() => { setActiveTab('code'); generateSchema(); }} className={`tab px-4 py-2 font-semibold ${activeTab === 'code' ? 'active' : ''}`}>Schema Code</button>
                    </div>

                    <div className="flex-1 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg p-4 overflow-y-auto">
                        {activeTab === 'preview' && (
                            <div className="search-preview">
                                <div className="search-url">{pageUrl || 'https://example.com/page'}</div>
                                <h3 className="search-title">{pageTitle || 'Your Page Title'}</h3>
                                <div className="mt-4 space-y-3">
                                    {faqItems.filter(i => i.question && i.answer).map(item => (
                                        <div key={item.id} className="faq-preview-item bg-base-200 dark:bg-d-base-200 p-3 rounded">
                                            <p className="faq-preview-question font-semibold">{item.question}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                        {activeTab === 'code' && (
                            <div>
                                <div className="flex justify-between items-center mb-2">
                                    <div className="flex gap-1 bg-base-200 dark:bg-d-base-200 p-1 rounded-md">
                                        <button onClick={() => { setSelectedFormat('json-ld'); generateSchema(); }} className={`px-3 py-1 text-xs rounded ${selectedFormat === 'json-ld' ? 'bg-white dark:bg-d-base-300' : ''}`}>JSON-LD</button>
                                        <button onClick={() => { setSelectedFormat('microdata'); generateSchema(); }} className={`px-3 py-1 text-xs rounded ${selectedFormat === 'microdata' ? 'bg-white dark:bg-d-base-300' : ''}`}>Microdata</button>
                                    </div>
                                    <button onClick={() => navigator.clipboard.writeText(generatedSchema)} className="p-2 rounded-lg bg-base-200 dark:bg-d-base-200"><CopyIcon className="h-5 w-5"/></button>
                                </div>
                                <pre className="schema-preview" dangerouslySetInnerHTML={{ __html: syntaxHighlight(generatedSchema) || '// Your schema will appear here after generation.' }} />
                                <button onClick={() => window.open(`https://search.google.com/test/rich-results`, '_blank')} className="w-full mt-2 p-2 text-sm font-semibold bg-blue-500 text-white rounded-lg">Validate with Google</button>
                            </div>
                        )}
                    </div>
                </section>
            </div>
            {error && <div className="text-center bg-error/20 text-error p-2 rounded-lg text-sm mt-4">{error}</div>}
        </div>
    );
};

export default FAQSchemaGeneratorView;
