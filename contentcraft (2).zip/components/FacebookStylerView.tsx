import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

const POST_TEMPLATES = [
    'Story + Lesson',
    'Question + Story',
    'Tip + Demonstration',
    'Nostalgia + Connection',
    'Transformation + Inspiration',
    'Poll + Discussion',
    'Fill-in-the-Blank',
    'Heartwarming Story',
    'Funny & Relatable',
];

const AUDIENCE_CONTEXTS = [
    'Personal Profile',
    'Business Page',
    'Group Content',
    'Family-Focused',
];

interface ParsedOutput {
    postVariations: {
        title: string;
        content: string;
        analysis: string;
    }[];
    visualRecommendations: {
        variationTitle: string;
        recommendation: string;
    }[];
    ctaUpgrades: string[];
    performanceAnalysis: {
        emotionalHook: number;
        relatabilityFactor: number;
        shareabilityScore: number;
        conversationStarter: number;
    };
}

const FACEBOOK_STYLER_PROMPT = `
You are an expert Facebook content strategist and viral marketer. Your task is to transform a user's idea into multiple high-performing Facebook posts, complete with strategic analysis.

**INPUT:**
- User's Core Idea: {USER_MESSAGE}
- Desired Post Template: {POST_TEMPLATE}
- Audience Context: {AUDIENCE_CONTEXT}
- Desired Tone: {TONE}

**INSTRUCTIONS:**
1.  Analyze the user's input and goals.
2.  Craft three distinct post variations based on different viral triggers (e.g., Emotional, Practical, Identity) while adhering to the user's chosen template style.
3.  For each post, use emojis strategically, ensure readability with line breaks, and include a strong engagement-driving CTA.
4.  Provide a detailed performance analysis with scores.
5.  Suggest specific visual content for each post variation.
6.  Generate a complete, valid JSON object that conforms to the provided schema. The \`content\` fields should use markdown for line breaks (\\n).
`;

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        postVariations: {
            type: Type.ARRAY,
            description: "Three distinct post variations, each with a title, content, and analysis.",
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "A creative title for the post's strategic angle (e.g., 'The Heartwarming Story')." },
                    content: { type: Type.STRING, description: "The full post content, including emojis and line breaks (use \\n)." },
                    analysis: { type: Type.STRING, description: "A brief explanation of the strategy behind this post version." }
                },
                required: ['title', 'content', 'analysis']
            }
        },
        visualRecommendations: {
            type: Type.ARRAY,
            description: "Visual ideas for each post variation.",
            items: {
                type: Type.OBJECT,
                properties: {
                    variationTitle: { type: Type.STRING, description: "Matches the title from postVariations." },
                    recommendation: { type: Type.STRING, description: "A specific visual idea (e.g., 'A candid photo of the family laughing')." }
                },
                required: ['variationTitle', 'recommendation']
            }
        },
        ctaUpgrades: {
            type: Type.ARRAY,
            description: "Alternative Call-to-Action suggestions.",
            items: {
                type: Type.STRING
            }
        },
        performanceAnalysis: {
            type: Type.OBJECT,
            properties: {
                emotionalHook: { type: Type.NUMBER, description: "Score from 0-10 for the emotional hook strength." },
                relatabilityFactor: { type: Type.NUMBER, description: "Score from 0-10 for how relatable the content is." },
                shareabilityScore: { type: Type.NUMBER, description: "Score from 0-10 for the post's potential to be shared." },
                conversationStarter: { type: Type.NUMBER, description: "Score from 0-10 for its ability to start conversations." }
            },
            required: ['emotionalHook', 'relatabilityFactor', 'shareabilityScore', 'conversationStarter']
        }
    },
    required: ['postVariations', 'visualRecommendations', 'ctaUpgrades', 'performanceAnalysis']
};

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};

const ScoreBar: React.FC<{ score: number; label: string }> = ({ score, label }) => (
  <div>
    <div className="flex justify-between items-center mb-1">
      <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">{label}</span>
      <span className="text-sm font-bold text-text-primary dark:text-d-text-primary">{score}/10</span>
    </div>
    <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2">
      <div className="bg-brand-primary h-2 rounded-full transition-all duration-500" style={{ width: `${score * 10}%` }}></div>
    </div>
  </div>
);

const FacebookStylerView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [postTemplate, setPostTemplate] = useState<string>(POST_TEMPLATES[0]);
    const [audienceContext, setAudienceContext] = useState<string>(AUDIENCE_CONTEXTS[0]);
    const [tones, setTones] = useState<string[]>([]);
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();
    
    const getPrompt = useCallback(() => {
        return FACEBOOK_STYLER_PROMPT
            .replace('{USER_MESSAGE}', input)
            .replace('{POST_TEMPLATE}', postTemplate)
            .replace('{AUDIENCE_CONTEXT}', audienceContext)
            .replace('{TONE}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [input, postTemplate, audienceContext, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId && parsed.postVariations?.[0]?.content) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: parsed.postVariations[0].content,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse content: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);

    const PostCard: React.FC<{variation: ParsedOutput['postVariations'][0]}> = ({ variation }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            navigator.clipboard.writeText(variation.content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        return (
            <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg shadow-sm relative">
                <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{variation.title}</h4>
                <p className="text-xs text-text-secondary dark:text-d-text-secondary mb-3">{variation.analysis}</p>
                <pre className="text-text-primary dark:text-d-text-primary whitespace-pre-wrap font-sans text-sm leading-relaxed">{variation.content}</pre>
                <button onClick={handleCopy} className="absolute top-3 right-3 p-2 rounded-lg bg-base-200 dark:bg-d-base-200 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label="Copy post content">
                    <CopyIcon className="h-5 w-5" />
                </button>
                {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        )
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter your core message, idea, or story..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Post Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Post Template</label>
                                <select value={postTemplate} onChange={e => setPostTemplate(e.target.value)} className={commonInputClasses}>
                                    {POST_TEMPLATES.map(t => <option key={t}>{t}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Audience Context</label>
                                <select value={audienceContext} onChange={e => setAudienceContext(e.target.value)} className={commonInputClasses}>
                                    {AUDIENCE_CONTEXTS.map(a => <option key={a}>{a}</option>)}
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Crafting Post...' : (isQueued ? 'Request Queued' : 'Generate Facebook Post')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please enter a message to generate a post.</p>}
                </div>

                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Crafting your engaging post...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your expert-crafted Facebook post and analysis will appear here.</p>}
                    {parsedOutput && (
                        <div className="space-y-6">
                             <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Post Variations</h3>
                                {parsedOutput.postVariations.map((v, i) => <PostCard key={i} variation={v} />)}
                            </div>
                            
                            <div className="space-y-2">
                                <Accordion title="📊 Performance Analysis" defaultOpen={true}>
                                    <div className="space-y-4 p-2">
                                        <ScoreBar score={parsedOutput.performanceAnalysis.emotionalHook} label="Emotional Hook" />
                                        <ScoreBar score={parsedOutput.performanceAnalysis.relatabilityFactor} label="Relatability Factor" />
                                        <ScoreBar score={parsedOutput.performanceAnalysis.shareabilityScore} label="Shareability Score" />
                                        <ScoreBar score={parsedOutput.performanceAnalysis.conversationStarter} label="Conversation Starter" />
                                    </div>
                                </Accordion>
                                <Accordion title="🎨 Visual Recommendations" defaultOpen={true}>
                                    <ul className="space-y-3 p-2">
                                        {parsedOutput.visualRecommendations.map((v, i) => (
                                            <li key={i} className="text-sm">
                                                <strong className="text-text-primary dark:text-d-text-primary">{v.variationTitle}:</strong> {v.recommendation}
                                            </li>
                                        ))}
                                    </ul>
                                </Accordion>
                                <Accordion title="🚀 CTA Upgrades" defaultOpen={true}>
                                     <ul className="space-y-2 p-2 list-disc list-inside">
                                        {parsedOutput.ctaUpgrades.map((cta, i) => (
                                            <li key={i} className="text-sm">{cta}</li>
                                        ))}
                                    </ul>
                                </Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default FacebookStylerView;
