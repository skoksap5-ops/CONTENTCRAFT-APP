import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import { Type } from '@google/genai';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type SeoTask = 'rewrite' | 'density' | 'readability' | 'meta' | 'length' | 'unified';
type AudienceLevel = 'General' | 'Expert' | 'Technical';
type ContentType = 'Blog Post' | 'Product Page' | 'Landing Page';
type CompetitionLevel = 'Low' | 'Medium' | 'High';

const SEO_TASK_OPTIONS: { value: SeoTask; label: string }[] = [
    { value: 'rewrite', label: 'Keyword Integration & Rewriting' },
    { value: 'density', label: 'Keyword Density Analysis' },
    { value: 'readability', label: 'Readability Scoring' },
    { value: 'meta', label: 'Meta Tag Optimizer' },
    { value: 'length', label: 'Content Length Recommendations' },
    { value: 'unified', label: 'Unified SEO Report (All-in-One)' },
];

const rewritePrompt = `You are an expert SEO content strategist. Rewrite the following text to be perfectly optimized for search engines while maintaining natural readability.\n\n**INPUT:**\n- Original Text: {USER_TEXT}\n- Primary Keywords: {PRIMARY_KEYWORDS}\n- Secondary Keywords: {SECONDARY_KEYWORDS}\n- Target Tone: {SELECTED_TONES}\n\n**REQUIREMENTS:**\n1. Naturally integrate primary keywords with 1-2% density\n2. Strategically place secondary keywords where relevant\n3. Maintain the original core message and meaning\n4. Adapt to the selected emotional tone(s)\n5. Ensure content flows naturally without keyword stuffing\n6. Optimize for both search engines and human readers\n\n**OUTPUT FORMAT:**\n- Rewritten SEO-optimized text\n- Keywords highlighted with **bold**\n- Brief explanation of key changes made`;
const densityPrompt = `You are an SEO analytics expert. Analyze the following text for keyword density and distribution.\n\n**INPUT:**\n- Text to Analyze: {USER_TEXT}\n- Target Keywords: {TARGET_KEYWORDS}\n\n**ANALYSIS REQUIREMENTS:**\n1. Calculate exact density percentage for each keyword\n2. Identify keyword distribution throughout the text\n3. Flag potential over-optimization (keyword stuffing)\n4. Highlight optimal keyword placement opportunities\n5. Compare against industry standards (1-2% ideal density)\n\n**OUTPUT FORMAT:**\n**KEYWORD DENSITY REPORT:**\n- Primary Keywords: [X]% (Ideal: 1-2%)\n- Secondary Keywords: [X]% (Ideal: 0.5-1%)\n- Total Keyword Density: [X]%\n\n**DISTRIBUTION ANALYSIS:**\n- Introduction Paragraph: [X] keywords\n- Body Content: [X] keywords\n- Conclusion: [X] keywords\n- Headings: [X] keywords\n\n**RECOMMENDATIONS:**\n- [Specific suggestions for improvement]\n- [Areas with insufficient keyword presence]\n- [Potential over-optimization warnings]`;
const readabilityPrompt = `You are a readability and content clarity expert. Analyze and score the following text for readability and user engagement.\n\n**INPUT:**\n- Text to Analyze: {USER_TEXT}\n- Target Audience: {AUDIENCE_LEVEL}\n\n**ANALYSIS REQUIREMENTS:**\n1. Calculate estimated Flesch-Kincaid Reading Ease score\n2. Identify complex sentences and difficult vocabulary\n3. Evaluate paragraph structure and length\n4. Assess overall content flow and coherence\n5. Provide specific improvement recommendations\n\n**OUTPUT FORMAT:**\n**READABILITY SCORE: [X]/100**\n- Reading Level: [Grade Level]\n- Estimated Reading Time: [X] minutes\n\n**DETAILED ANALYSIS:**\n✅ **Strengths:**\n- [List what works well]\n\n⚠️ **Areas for Improvement:**\n- [Complex sentences to simplify]\n- [Difficult vocabulary to replace]\n- [Paragraph structure suggestions]\n\n**SPECIFIC RECOMMENDATIONS:**\n1. Sentence Length: Average [X] words (Ideal: 15-20)\n2. Paragraph Length: Average [X] sentences (Ideal: 3-5)\n3. Complex Words: [X]% (Target: <10%)\n4. Passive Voice: [X] instances (Reduce where possible)\n\n**QUICK FIXES:**\n- [3-5 specific, actionable improvements]`;
const metaPrompt = `You are an SEO meta tag specialist. Generate optimized meta content for the following text.\n\n**INPUT:**\n- Main Content: {USER_TEXT}\n- Primary Keywords: {PRIMARY_KEYWORDS}\n- Content Type: {CONTENT_TYPE}\n- Character Limits: Title: 60 chars, Description: 160 chars\n\n**GENERATION REQUIREMENTS:**\n1. Create 3 compelling title tag options (under 60 characters)\n2. Generate 3 engaging meta descriptions (under 160 characters)\n3. Suggest an SEO-friendly URL slug\n4. Include primary keywords naturally\n5. Add emotional triggers and CTAs where appropriate\n6. Ensure mobile preview optimization\n\n**OUTPUT FORMAT:**\n**TITLE TAG OPTIONS:**\n1. [Option 1 - X characters] - [Key benefit]\n2. [Option 2 - X characters] - [Key benefit]\n3. [Option 3 - X characters] - [Key benefit]\n\n**META DESCRIPTION OPTIONS:**\n1. [Option 1 - X characters] - [Engaging description with CTA]\n2. [Option 2 - X characters] - [Problem/solution format]\n3. [Option 3 - X characters] - [Feature/benefit approach]\n\n**URL SLUG SUGGESTION:**\n- Optimized: /[keyword-rich-url-slug]\n\n**SOCIAL MEDIA OPTIMIZATION:**\n- Twitter Card Snippet: [120 character preview]\n- Facebook OG Description: [200 character preview]`;
const lengthPrompt = `You are an SEO content strategist. Analyze the current content and provide ideal length recommendations based on SEO best practices.\n\n**INPUT:**\n- Current Content: {USER_TEXT}\n- Current Word Count: {WORD_COUNT}\n- Content Type: {CONTENT_TYPE}\n- Competition Level: {COMPETITION}\n- Target Keywords: {TARGET_KEYWORDS}\n\n**ANALYSIS REQUIREMENTS:**\n1. Compare current length against ideal benchmarks\n2. Assess content comprehensiveness for target topic\n3. Identify content gaps and expansion opportunities\n4. Recommend optimal length based on competition\n5. Provide specific sections to add/expand\n\n**OUTPUT FORMAT:**\n**CURRENT CONTENT ANALYSIS:**\n- Current Word Count: [X] words\n- Ideal Word Count Range: [Y-Z] words\n- Gap Analysis: [X] words under/over ideal\n\n**CONTENT TYPE BENCHMARKS:**\n- Blog Post: 1,500-2,500 words\n- Product Page: 800-1,200 words\n- Landing Page: 500-800 words\n- Pillar Content: 3,000+ words\n\n**COMPETITION-BASED RECOMMENDATIONS:**\n- Low Competition: [X] words minimum\n- Medium Competition: [Y] words recommended\n- High Competition: [Z] words comprehensive\n\n**CONTENT EXPANSION SUGGESTIONS:**\n**Add These Sections:**\n1. [Section 1 - Estimated +X words]\n2. [Section 2 - Estimated +Y words]\n3. [Section 3 - Estimated +Z words]`;

const UNIFIED_SEO_PROMPT = `
You are ContentCraft's complete SEO optimization engine. Analyze the provided information and generate a comprehensive SEO analysis and optimization report as a valid JSON object that conforms to the provided schema.

**MASTER INPUT:**
- Original Text: {USER_TEXT}
- Primary Keywords: {PRIMARY_KEYWORDS}
- Secondary Keywords: {SECONDARY_KEYWORDS}
- Target Tone: {SELECTED_TONES}
- Target Audience: {AUDIENCE_LEVEL}
- Content Type: {CONTENT_TYPE}
- Competition Level: {COMPETITION}

For all string-based report fields in the JSON schema, use markdown for formatting (e.g., "**SECTION TITLE:**\\n- Point 1\\n- Point 2"). For 'rewrittenText', use markdown's **bold** syntax to highlight keywords.
`;

const PROMPTS: Record<SeoTask, string> = {
    rewrite: rewritePrompt,
    density: densityPrompt,
    readability: readabilityPrompt,
    meta: metaPrompt,
    length: lengthPrompt,
    unified: UNIFIED_SEO_PROMPT,
};

const seoResponseSchema = {
    type: Type.OBJECT,
    properties: {
        rewrittenText: {
            type: Type.STRING,
            description: "The rewritten, SEO-optimized text. Use markdown's **bold** for keywords."
        },
        keywordReport: {
            type: Type.STRING,
            description: "A formatted string containing the keyword density report and distribution analysis. Use markdown."
        },
        readabilityReport: {
            type: Type.STRING,
            description: "A formatted string containing the readability score and detailed analysis. Use markdown."
        },
        metaTags: {
            type: Type.OBJECT,
            properties: {
                titleOptions: { type: Type.ARRAY, items: { type: Type.STRING } },
                descriptionOptions: { type: Type.ARRAY, items: { type: Type.STRING } },
                urlSlug: { type: Type.STRING }
            }
        },
        contentLengthReport: {
            type: Type.STRING,
            description: "A formatted string containing content length analysis and expansion suggestions. Use markdown."
        }
    },
    required: ['rewrittenText', 'keywordReport', 'readabilityReport', 'metaTags', 'contentLengthReport']
};

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const SeoOptimizerView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [task, setTask] = useState<SeoTask>('rewrite');
    const [input, setInput] = useState('');
    const [output, setOutput] = useState('');
    const [parsedSeoOutput, setParsedSeoOutput] = useState<any | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const [primaryKeywords, setPrimaryKeywords] = useState('');
    const [secondaryKeywords, setSecondaryKeywords] = useState('');
    const [audience, setAudience] = useState<AudienceLevel>('General');
    const [contentType, setContentType] = useState<ContentType>('Blog Post');
    const [competition, setCompetition] = useState<CompetitionLevel>('Medium');

    const [tones, setTones] = useState<string[]>([]);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const [copySuccess, setCopySuccess] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();

    const getPrompt = useCallback(() => {
        let prompt = PROMPTS[task];
        const allKeywords = [primaryKeywords, secondaryKeywords].filter(Boolean).join(', ');
        prompt = prompt.replace(/{USER_TEXT}/g, input);
        prompt = prompt.replace(/{PRIMARY_KEYWORDS}/g, primaryKeywords);
        prompt = prompt.replace(/{SECONDARY_KEYWORDS}/g, secondaryKeywords);
        prompt = prompt.replace(/{TARGET_KEYWORDS}/g, allKeywords);
        prompt = prompt.replace(/{SELECTED_TONES}/g, tones.length ? tones.join(', ') : 'neutral');
        prompt = prompt.replace(/{AUDIENCE_LEVEL}/g, audience);
        prompt = prompt.replace(/{CONTENT_TYPE}/g, contentType);
        prompt = prompt.replace(/{COMPETITION}/g, competition);
        prompt = prompt.replace(/{WORD_COUNT}/g, String(input.split(/\s+/).length));
        return prompt;
    }, [input, task, primaryKeywords, secondaryKeywords, tones, audience, contentType, competition]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;

        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedSeoOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            if (task === 'unified') {
                const result = await generateContent(prompt, {
                    responseMimeType: "application/json",
                    responseSchema: seoResponseSchema,
                });
                try {
                    const parsed = JSON.parse(result);
                    setParsedSeoOutput(parsed);
                } catch (e) {
                    console.error("Failed to parse SEO JSON:", e, result);
                    setError("AI returned an unexpected format. Displaying raw output.");
                    setOutput(result);
                }
            } else {
                const result = await generateContent(prompt);
                setOutput(result);
            }
            
            if (usesLeft !== 'Unlimited') {
                decrementUse();
            }
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, task]);
    
    const formatOutput = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        const sanitized = text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
        const html = sanitized
            .replace(/\*\*(.*?)\*\*/g, '<strong class="text-brand-primary">$1</strong>')
            .replace(/(\✅|\⚠️|🚀|💡)/g, '<span class="mr-2">$1</span>')
            .replace(/^(KEYWORD DENSITY REPORT|DISTRIBUTION ANALYSIS|RECOMMENDATIONS|READABILITY SCORE|DETAILED ANALYSIS|SPECIFIC RECOMMENDATIONS|QUICK FIXES|TITLE TAG OPTIONS|META DESCRIPTION OPTIONS|URL SLUG SUGGESTION|SOCIAL MEDIA OPTIMIZATION|CURRENT CONTENT ANALYSIS|CONTENT TYPE BENCHMARKS|COMPETITION-BASED RECOMMENDATIONS|CONTENT EXPANSION SUGGESTIONS|PRIORITY RECOMMENDATIONS|Add These Sections|Specific Content to Include)/gm, '<h4 class="text-lg font-semibold text-text-primary dark:text-d-text-primary mt-4 mb-2">$1</h4>')
            .replace(/\n/g, '<br />');
        return { __html: html };
    };

    const handleCopy = () => {
        let textToCopy = '';
        if (parsedSeoOutput) {
            textToCopy = `
## Rewritten Text\n${parsedSeoOutput.rewrittenText}\n\n
## Keyword Report\n${parsedSeoOutput.keywordReport}\n\n
## Readability Report\n${parsedSeoOutput.readabilityReport}\n\n
## Meta Tags\nTitles:\n- ${parsedSeoOutput.metaTags.titleOptions.join('\n- ')}\n\nDescriptions:\n- ${parsedSeoOutput.metaTags.descriptionOptions.join('\n- ')}\n\nSlug: ${parsedSeoOutput.metaTags.urlSlug}\n\n
## Content Length Report\n${parsedSeoOutput.contentLengthReport}
            `;
        } else if (output) {
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = output.replace(/<br\s*\/?>/gi, '\n');
            textToCopy = tempDiv.textContent || tempDiv.innerText || "";
        }
        
        if (textToCopy) {
            navigator.clipboard.writeText(textToCopy.trim()).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        }
    };
    
    const commonTextareaClasses = "w-full min-h-[200px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    const renderTaskSpecificInputs = () => {
      const showKeywords = ['rewrite', 'density', 'meta', 'length', 'unified'].includes(task);
      const showSecondaryKeywords = ['rewrite', 'unified'].includes(task);
      const showAudience = ['readability', 'unified'].includes(task);
      const showContentType = ['meta', 'length', 'unified'].includes(task);
      const showCompetition = ['length', 'unified'].includes(task);

      if (!showKeywords && !showAudience && !showContentType && !showCompetition) return null;

      return (
        <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
          <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Task Details</h3>
          {showKeywords && (
            <div>
                <label htmlFor="primaryKeywords" className={commonLabelClasses}>Primary Keywords (comma-separated)</label>
                <input id="primaryKeywords" type="text" value={primaryKeywords} onChange={e => setPrimaryKeywords(e.target.value)} placeholder="e.g. content marketing, AI tools" className={commonInputClasses} />
            </div>
          )}
          {showSecondaryKeywords && (
             <div>
                <label htmlFor="secondaryKeywords" className={commonLabelClasses}>Secondary Keywords (comma-separated)</label>
                <input id="secondaryKeywords" type="text" value={secondaryKeywords} onChange={e => setSecondaryKeywords(e.target.value)} placeholder="e.g. digital strategy, seo" className={commonInputClasses} />
            </div>
          )}
          {showAudience && (
            <div>
              <label htmlFor="audience" className={commonLabelClasses}>Target Audience</label>
              <select id="audience" value={audience} onChange={e => setAudience(e.target.value as AudienceLevel)} className={commonInputClasses}>
                <option>General</option>
                <option>Expert</option>
                <option>Technical</option>
              </select>
            </div>
          )}
          {showContentType && (
             <div>
              <label htmlFor="contentType" className={commonLabelClasses}>Content Type</label>
              <select id="contentType" value={contentType} onChange={e => setContentType(e.target.value as ContentType)} className={commonInputClasses}>
                <option>Blog Post</option>
                <option>Product Page</option>
                <option>Landing Page</option>
              </select>
            </div>
          )}
          {showCompetition && (
            <div>
              <label htmlFor="competition" className={commonLabelClasses}>Competition Level</label>
              <select id="competition" value={competition} onChange={e => setCompetition(e.target.value as CompetitionLevel)} className={commonInputClasses}>
                <option>Low</option>
                <option>Medium</option>
                <option>High</option>
              </select>
            </div>
          )}
        </div>
      );
    }

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                    <div>
                        <label htmlFor="seoTask" className={commonLabelClasses}>Select SEO Task</label>
                        <select id="seoTask" value={task} onChange={e => setTask(e.target.value as SeoTask)} className={commonInputClasses}>
                           {SEO_TASK_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                        </select>
                    </div>

                    <textarea
                        value={input}
                        onChange={e => setInput(e.target.value)}
                        placeholder="Enter your text, topic, or content here..."
                        className={commonTextareaClasses}
                        style={{minHeight: '250px'}}
                    />
                    
                    {renderTaskSpecificInputs()}

                    {['rewrite', 'unified'].includes(task) && (
                         <button 
                            onClick={() => setIsToneSelectorOpen(true)}
                            className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors"
                            >
                            <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2">
                                    <span role="img" aria-label="palette emoji" className="text-xl">🎨</span>
                                    <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3>
                                </div>
                                <div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary">
                                <span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3
                                </div>
                            </div>
                         </button>
                    )}
                    
                    <button
                        onClick={handleGenerate}
                        disabled={isLoading || !canGenerate}
                        className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300"
                    >
                        {isLoading ? ( <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> ) : null}
                        {isLoading ? 'Generating...' : (isQueued ? 'Request Queued' : 'Run SEO Task')}
                    </button>
                     {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && input.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                </div>

                <div className="relative">
                    <div className={`${commonTextareaClasses} bg-base-200/50 dark:bg-d-base-200/50 min-h-[500px] overflow-y-auto leading-relaxed`}>
                        {isLoading && <p className="text-text-secondary dark:text-d-text-secondary">Generating report...</p>}
                        {!isLoading && !output && !parsedSeoOutput && <p className="text-text-secondary dark:text-d-text-secondary">Your AI-crafted SEO report will appear here...</p>}
                        
                        {parsedSeoOutput && (
                            <div className="space-y-4 p-2">
                                <Accordion title="Rewritten & Optimized Text" defaultOpen={true}>
                                    <div dangerouslySetInnerHTML={formatOutput(parsedSeoOutput.rewrittenText)} />
                                </Accordion>
                                <Accordion title="Keyword Report">
                                    <div dangerouslySetInnerHTML={formatOutput(parsedSeoOutput.keywordReport)} />
                                </Accordion>
                                <Accordion title="Readability Report">
                                    <div dangerouslySetInnerHTML={formatOutput(parsedSeoOutput.readabilityReport)} />
                                </Accordion>
                                <Accordion title="Meta Tag Suggestions">
                                    <h4 className="font-semibold text-text-primary dark:text-d-text-primary">Title Options:</h4>
                                    <ul className="list-disc list-inside mb-4">{parsedSeoOutput.metaTags.titleOptions.map((t: string, i: number) => <li key={i}>{t}</li>)}</ul>
                                    <h4 className="font-semibold text-text-primary dark:text-d-text-primary">Description Options:</h4>
                                    <ul className="list-disc list-inside mb-4">{parsedSeoOutput.metaTags.descriptionOptions.map((d: string, i: number) => <li key={i}>{d}</li>)}</ul>
                                    <h4 className="font-semibold text-text-primary dark:text-d-text-primary">URL Slug:</h4>
                                    <p className="font-mono bg-base-100 dark:bg-d-base-100 p-2 rounded">{parsedSeoOutput.metaTags.urlSlug}</p>
                                </Accordion>
                                <Accordion title="Content Length Analysis">
                                    <div dangerouslySetInnerHTML={formatOutput(parsedSeoOutput.contentLengthReport)} />
                                </Accordion>
                            </div>
                        )}
                        {output && !parsedSeoOutput && <div dangerouslySetInnerHTML={formatOutput(output)} />}
                    </div>
                     {(output || parsedSeoOutput) && !isLoading && (
                        <button
                            onClick={handleCopy}
                            className="absolute top-3 right-3 p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors"
                            aria-label="Copy to clipboard"
                        >
                            <CopyIcon className="h-5 w-5" />
                        </button>
                    )}
                    {copySuccess && <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-success text-white text-xs px-3 py-1 rounded-full animate-fade-in">Copied!</div>}
                </div>
            </div>
             {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector 
            isOpen={isToneSelectorOpen}
            onClose={() => setIsToneSelectorOpen(false)}
            selectedTones={tones}
            onTonesChange={setTones}
        />
        </>
    );
};

export default SeoOptimizerView;