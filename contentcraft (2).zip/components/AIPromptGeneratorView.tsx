import React, { useState, useEffect } from 'react';
import type { Module } from '../types';
import { usePromptAI, type PromptRequestData } from '../hooks/usePromptAI';
import { PromptCreator } from './ai-prompt-generator/PromptCreator';
import { PromptOptimizer } from './ai-prompt-generator/PromptOptimizer';
import { StyleTemplates } from './ai-prompt-generator/StyleTemplates';
import { AISelector } from './ai-prompt-generator/AISelector';

interface AIPromptGeneratorViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type View = 'create' | 'optimize' | 'templates';

const AIPromptGeneratorView: React.FC<AIPromptGeneratorViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
  const [currentView, setCurrentView] = useState<View>('create');
  const [selectedAI, setSelectedAI] = useState('chatgpt');
  const [currentPrompt, setCurrentPrompt] = useState('');
  const [optimizedPrompt, setOptimizedPrompt] = useState('');
  const { generatePrompt, optimizePrompt, analyzePrompt, isLoading, error } = usePromptAI(userId, module.id, module.name, usesLeft, decrementUse);

  const views: { [key in View]: { name: string; icon: string } } = {
    create: { name: 'Create Prompt', icon: '✨' },
    optimize: { name: 'Optimize Prompt', icon: '🔧' },
    templates: { name: 'Style Templates', icon: '🎨' },
  };

  const handleGeneratePrompt = async (promptRequest: PromptRequestData) => {
    const generated = await generatePrompt(promptRequest, selectedAI);
    if (generated) {
      setCurrentPrompt(generated.prompt);
      setOptimizedPrompt(generated.optimizedVersion);
      setCurrentView('optimize');
    }
  };

  const handleOptimizePrompt = async (promptToOptimize: string) => {
    const optimized = await optimizePrompt(promptToOptimize, selectedAI);
    if (optimized) {
      setOptimizedPrompt(optimized);
    }
  };

  const handleAnalyzePrompt = async (promptToAnalyze: string) => {
    return await analyzePrompt(promptToAnalyze, selectedAI);
  };

  const handleTemplateSelect = (template: string) => {
    setCurrentPrompt(template);
    setCurrentView('optimize');
  };

  return (
    <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
        <div className="text-center">
            <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">⚡ {module.name}</h2>
            <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
        </div>

        <AISelector 
            selectedAI={selectedAI}
            onAIChange={setSelectedAI}
        />

        <div className="border-b border-base-300 dark:border-d-base-300 flex items-center justify-center">
            {Object.entries(views).map(([key, view]) => (
            <button
                key={key}
                className={`px-4 py-3 font-semibold transition-colors duration-200 border-b-2 -mb-px ${
                    currentView === key
                    ? 'border-brand-primary text-brand-primary'
                    : 'border-transparent text-text-secondary dark:text-d-text-secondary hover:text-text-primary dark:hover:text-d-text-primary'
                }`}
                onClick={() => setCurrentView(key as View)}
            >
                <span className="mr-2">{view.icon}</span>
                {view.name}
            </button>
            ))}
        </div>

        <div className="view-content">
            {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg mb-4">{error}</div>}

            {currentView === 'create' && (
            <PromptCreator
                onGenerate={handleGeneratePrompt}
                selectedAI={selectedAI}
                isLoading={isLoading}
            />
            )}

            {currentView === 'optimize' && (
            <PromptOptimizer
                currentPrompt={currentPrompt}
                optimizedPrompt={optimizedPrompt}
                onOptimize={handleOptimizePrompt}
                onAnalyze={handleAnalyzePrompt}
                onUpdatePrompt={setCurrentPrompt}
                isLoading={isLoading}
            />
            )}

            {currentView === 'templates' && (
            <StyleTemplates
                onTemplateSelect={handleTemplateSelect}
                selectedAI={selectedAI}
            />
            )}
        </div>
    </div>
  );
};

export default AIPromptGeneratorView;
