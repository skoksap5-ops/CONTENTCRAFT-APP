import React from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';

interface PrivacyPolicyProps {
  onClose: () => void;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ onClose }) => {
  const H3: React.FC<{children: React.ReactNode}> = ({ children }) => <h3 className="text-xl font-bold font-heading mt-5 mb-2 text-text-primary dark:text-d-text-primary">{children}</h3>;
  const P: React.FC<{children: React.ReactNode}> = ({ children }) => <p className="mb-4 leading-relaxed text-text-secondary dark:text-d-text-secondary">{children}</p>;
  const LI: React.FC<{children: React.ReactNode}> = ({ children }) => <li className="mb-2">{children}</li>;
  
  return (
    <div className="fixed inset-0 bg-base-100 dark:bg-d-base-100 z-50 animate-fade-in-up overflow-y-auto" role="dialog" aria-modal="true">
      <header className="sticky top-0 bg-base-100/80 dark:bg-d-base-100/80 backdrop-blur-sm z-10 border-b border-base-300 dark:border-d-base-300">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-16 gap-4">
          <button
            onClick={onClose}
            className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-200"
            aria-label="Back to profile"
          >
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Privacy Policy</h1>
        </div>
      </header>
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 className="text-2xl font-bold font-heading mt-6 mb-3 text-text-primary dark:text-d-text-primary">Privacy Policy for ContentCraft</h2>
        <P><em>Last Updated: December 2024</em></P>
        <P>
            You can also view this policy on our website: 
            <a href="http://contentcraft.free.nf/privacy.html" target="_blank" rel="noopener noreferrer" className="text-brand-primary hover:underline ml-1">
                contentcraft.free.nf/privacy.html
            </a>
        </P>

        <H3>1. Introduction</H3>
        <P>ContentCraft ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application (the "App") and related services (collectively, the "Services").</P>
        <P>Please read this policy carefully. By using our Services, you agree to the collection and use of information in accordance with this policy.</P>

        <H3>2. Information We Collect</H3>
        <P>We collect information to provide, improve, and secure our Services. The data we collect falls into the following categories:</P>
        
        <h4 className="text-lg font-bold font-heading mt-4 mb-2 text-text-primary dark:text-d-text-primary">a) Personal Information:</h4>
        <P>This is information that can be used to identify you.</P>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI><strong>Account Information:</strong> When you create an account, we collect your email address for authentication and communication.</LI>
            <LI><strong>Support Inquiries:</strong> Information you provide when you contact us for support.</LI>
            <LI><strong>Payment Information:</strong> All payments are processed by third-party payment processors (e.g., Google Play Store, Apple App Store). We do not collect or store your credit card details. We only receive confirmation of your subscription status.</LI>
        </ul>

        <h4 className="text-lg font-bold font-heading mt-4 mb-2 text-text-primary dark:text-d-text-primary">b) Usage Data:</h4>
        <P>This is anonymized or aggregated data that helps us understand how our Services are used.</P>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI><strong>App Interactions:</strong> Information about your activity in the App, such as features you use and buttons you click.</LI>
            <LI><strong>Diagnostic Data:</strong> Crash reports and error logs that help us identify and fix bugs.</LI>
            <LI><strong>Device Information:</strong> Non-personal identifiers like your device model, operating system version, and app version.</LI>
        </ul>

        <h4 className="text-lg font-bold font-heading mt-4 mb-2 text-text-primary dark:text-d-text-primary">c) Content Data:</h4>
        <P>This is the core data you generate while using our AI features.</P>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI><strong>User Input/Content Prompts:</strong> The text you provide to the App for content generation.</LI>
            <LI><strong>Generated Content:</strong> The output text created by our AI based on your input.</LI>
            <LI><strong>Preferences:</strong> Your selected tone, style, and other content preferences.</LI>
            <LI><strong>SEO Data:</strong> Keywords, competitor analysis, and search opportunity data.</LI>
            <LI><strong>Social Media Content:</strong> Posts, calendars, and hashtag information.</LI>
            <LI><strong>Professional Documents:</strong> Pitches, proposals, case studies, and business content.</LI>
            <LI><strong>Marketing Materials:</strong> Ad copies, landing page content, product descriptions.</LI>
        </ul>

        <h4 className="text-lg font-bold font-heading mt-4 mb-2 text-text-primary dark:text-d-text-primary">d) Module Explanation Assistant Specific:</h4>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI><strong>Chatbot Interactions:</strong> The Module Explanation Assistant provides pre-defined information about ContentCraft's 53 modules and does not collect, store, or process personal user data.</LI>
            <LI>All chatbot interactions are anonymous and require no user identification.</LI>
            <LI>Standard and expanded explanation options generate no data trails or personal information.</LI>
        </ul>

        <H3>3. How We Use Your Information</H3>
        <P>We use the information we collect for the following purposes:</P>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI><strong>To Provide the Services:</strong> To operate the App and fulfill your content generation requests across all 53 modules.</LI>
            <LI><strong>To Improve & Train our AI Models:</strong> To enhance the accuracy and quality of our AI. This is done with a strong commitment to your privacy (see Section 4: AI Model Training & Privacy).</LI>
            <LI><strong>Customer Support:</strong> To respond to your requests and provide assistance.</LI>
            <LI><strong>Service Communication:</strong> To send you important updates, security alerts, and administrative messages related to the Services.</LI>
            <LI><strong>Analytics:</strong> To analyze usage trends and optimize the user experience.</LI>
            <LI><strong>Security & Fraud Prevention:</strong> To protect the security and integrity of our Services and users.</LI>
        </ul>

        <H3>4. AI Model Training & Privacy</H3>
        <P>For AI-Powered Modules:</P>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI><strong>Real-time Processing:</strong> Your input text (prompts) is processed temporarily and in real-time to generate your requested content.</LI>
            <LI><strong>No Long-Term Storage of Linked Data:</strong> We do not permanently store your input text or generated content in a way that is linked to your personal identity.</LI>
            <LI><strong>Anonymous Model Improvement:</strong> To improve our AI models for all users, your input and generated content may be used in an anonymized and aggregated manner. This means any data used for training is stripped of all personal identifiers and cannot be traced back to you.</LI>
        </ul>
        <P>Module Explanation Assistant Exception:</P>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI>This chatbot uses pre-defined, generic module descriptions and does not undergo AI training based on user interactions.</LI>
            <LI>All explanations are static and do not learn from or retain user conversations.</LI>
        </ul>

        <H3>5. How We Store Your Content</H3>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI><strong>Input Text (Prompts):</strong> Deleted immediately after the content is generated and the anonymization process for model improvement is complete.</LI>
            <LI><strong>Generated Content:</strong> Stored locally only on your device. It is not stored on our servers unless you explicitly use a cloud-sync feature in the future (which would be subject to a separate notice).</LI>
            <LI><strong>Module Explanation Assistant:</strong> No data storage - all interactions are transient and anonymous.</LI>
            <LI><strong>Account Data:</strong> Retained for as long as your account is active.</LI>
        </ul>

        <H3>6. Information Sharing and Disclosure</H3>
        <P>We do not sell, trade, or rent your personal information. We may share information only in the following limited circumstances:</P>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI><strong>With Your Consent:</strong> When you have given us explicit permission to share it.</LI>
            <LI><strong>With Service Providers:</strong> With trusted third-party vendors who assist us in operating our Services (e.g., cloud hosting, analytics providers). These partners are contractually bound to use your data only for the services we request.</LI>
            <LI><strong>For Legal Reasons:</strong> To comply with a legal obligation, protect our rights, or prevent fraud or harm.</LI>
            <LI><strong>Business Transfer:</strong> In connection with a merger, sale, or acquisition of all or a part of our business.</LI>
        </ul>

        <H3>7. Your Privacy Rights</H3>
        <P>Depending on your location, you may have the following rights regarding your personal data:</P>
        <ul className="list-disc list-inside space-y-2 text-text-secondary dark:text-d-text-secondary">
            <LI><strong>Access:</strong> You can request a copy of the personal data we hold about you.</LI>
            <LI><strong>Deletion:</strong> You can request that we delete your personal data.</LI>
            <LI><strong>Correction:</strong> You can update or correct your information through the App's settings or by contacting us.</LI>
            <LI><strong>Data Portability:</strong> You can request an export of your data in a structured, machine-readable format.</LI>
            <LI><strong>Objection:</strong> You can object to certain processing activities.</LI>
        </ul>
        <P>To exercise these rights, please contact us at <a href="mailto:Contentcraft.free.nf@gmail.com" className="text-brand-primary hover:underline">Contentcraft.free.nf@gmail.com</a>. We will respond to your request within a reasonable timeframe.</P>

        <H3>8. Data Security</H3>
        <P>We implement appropriate technical and organizational measures designed to protect your information. However, no method of transmission over the Internet or electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your personal information, we cannot guarantee its absolute security.</P>

        <H3>9. International Data Transfers</H3>
        <P>Your information may be transferred to and processed in countries other than your own. We ensure that such transfers are governed by appropriate safeguards, such as standard contractual clauses, to ensure a level of protection equivalent to the laws in your country.</P>

        <H3>10. Children's Privacy</H3>
        <P>Our Services are not intended for individuals under the age of 13. We do not knowingly collect personal information from children under 13. If you are a parent or guardian and believe your child has provided us with personal information, please contact us, and we will take steps to delete such information.</P>

        <H3>11. Changes to This Privacy Policy</H3>
        <P>We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the new policy on this page and updating the "Last Updated" date. We encourage you to review this policy periodically.</P>

        <H3>12. Contact Us</H3>
        <P>If you have any questions about this Privacy Policy or our data practices, please do not hesitate to contact us at:</P>
        <P>Email: <a href="mailto:Contentcraft.free.nf@gmail.com" className="text-brand-primary hover:underline">Contentcraft.free.nf@gmail.com</a></P>
      </main>
    </div>
  );
};

export default PrivacyPolicy;