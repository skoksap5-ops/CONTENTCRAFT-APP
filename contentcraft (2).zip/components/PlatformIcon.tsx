import React from 'react';
import TwitterIcon from './icons/social/TwitterIcon';
import LinkedInIcon from './icons/social/LinkedInIcon';
import FacebookIcon from './icons/social/FacebookIcon';
import InstagramIcon from './icons/social/InstagramIcon';

interface PlatformIconProps {
  platform: 'Twitter' | 'LinkedIn' | 'Facebook' | 'Instagram' | string;
  className?: string;
}

const PlatformIcon: React.FC<PlatformIconProps> = ({ platform, className="h-5 w-5" }) => {
  switch (platform.toLowerCase()) {
    case 'twitter':
      return <TwitterIcon className={className} />;
    case 'linkedin':
      return <LinkedInIcon className={className} />;
    case 'facebook':
      return <FacebookIcon className={className} />;
    case 'instagram':
      return <InstagramIcon className={className} />;
    default:
      return null;
  }
};

export default PlatformIcon;
