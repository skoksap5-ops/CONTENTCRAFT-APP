import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type ContentType = 'Tutorial' | 'Review' | 'Educational' | 'Entertainment';
type Audience = 'General' | 'Beginners' | 'Experts';

interface TitleVariation {
    title: string;
    strategy: string;
    characterCount: number;
}

interface ParsedOutput {
    titleVariations: TitleVariation[];
    optimizedDescription: string;
    hashtagStrategy: {
        hashtags: string[];
        analysis: string;
    };
    performancePrediction: {
        ctrPotential: number;
        searchVisibility: number;
        audienceRetention: number;
    };
}

const YOUTUBE_STYLER_PROMPT = `
You are a world-class YouTube strategist and SEO expert. Your task is to transform a user's video idea into a complete, optimized package of titles, description, and strategy to maximize views, engagement, and retention.

**INPUT:**
- Video Topic: {VIDEO_TOPIC}
- Content Type: {CONTENT_TYPE}
- Target Audience: {AUDIENCE}
- Desired Tone: {TONE}

**INSTRUCTIONS:**
1.  Analyze the user's input to understand the core value and target viewer.
2.  Generate 3-5 distinct, compelling title variations using proven frameworks (Curiosity, Benefit-Driven, Numbered Lists, Questions). Each title should be 50-60 characters and include the primary keyword.
3.  Craft a complete, SEO-optimized description using the professional template:
    *   Start with a 2-line, keyword-rich summary.
    *   Include a value proposition with bullet points.
    *   Provide a placeholder for timestamps (e.g., 0:00 - Intro).
    *   Include placeholders for relevant links.
    *   End with an engagement question.
4.  Develop a hashtag strategy with 3-5 relevant tags.
5.  Provide a performance prediction analysis, scoring key metrics from 1-10.
6.  Generate a complete, valid JSON object that conforms to the provided schema. The \`optimizedDescription\` field should use markdown for line breaks (\\n).
`;

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        titleVariations: {
            type: Type.ARRAY,
            description: "3-5 distinct, SEO-optimized YouTube title variations.",
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    strategy: { type: Type.STRING, description: "The strategy behind this title (e.g., Curiosity Hook, Benefit-Driven)." },
                    characterCount: { type: Type.NUMBER }
                },
                required: ['title', 'strategy', 'characterCount']
            }
        },
        optimizedDescription: {
            type: Type.STRING,
            description: "The full, optimized YouTube description, including a summary, timestamps placeholder, links placeholder, and hashtags. Use \\n for line breaks."
        },
        hashtagStrategy: {
            type: Type.OBJECT,
            properties: {
                hashtags: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING, description: "e.g., #Python" }
                },
                analysis: { type: Type.STRING, description: "A brief explanation of the hashtag choices." }
            },
            required: ['hashtags', 'analysis']
        },
        performancePrediction: {
            type: Type.OBJECT,
            properties: {
                ctrPotential: { type: Type.NUMBER, description: "Predicted Click-Through Rate potential score (1-10)." },
                searchVisibility: { type: Type.NUMBER, description: "Predicted search visibility score (1-10)." },
                audienceRetention: { type: Type.NUMBER, description: "Predicted audience retention impact score (1-10)." }
            },
            required: ['ctrPotential', 'searchVisibility', 'audienceRetention']
        }
    },
    required: ['titleVariations', 'optimizedDescription', 'hashtagStrategy', 'performancePrediction']
};


const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};

const ScoreBar: React.FC<{ score: number; label: string }> = ({ score, label }) => (
  <div>
    <div className="flex justify-between items-center mb-1">
      <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">{label}</span>
      <span className="text-sm font-bold text-text-primary dark:text-d-text-primary">{score}/10</span>
    </div>
    <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2">
      <div className="bg-brand-primary h-2 rounded-full transition-all duration-500" style={{ width: `${score * 10}%` }}></div>
    </div>
  </div>
);


const YouTubeStylerView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [contentType, setContentType] = useState<ContentType>('Tutorial');
    const [audience, setAudience] = useState<Audience>('Beginners');
    const [tones, setTones] = useState<string[]>([]);
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();
    
    const getPrompt = useCallback(() => {
        return YOUTUBE_STYLER_PROMPT
            .replace('{VIDEO_TOPIC}', input)
            .replace('{CONTENT_TYPE}', contentType)
            .replace('{AUDIENCE}', audience)
            .replace('{TONE}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [input, contentType, audience, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId && parsed.optimizedDescription) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: `Title: ${parsed.titleVariations[0]?.title}\n\n${parsed.optimizedDescription}`,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse content: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);

    const TitleCard: React.FC<{variation: TitleVariation}> = ({ variation }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            navigator.clipboard.writeText(variation.title).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };
        const charColor = variation.characterCount > 70 ? 'text-error' : variation.characterCount > 60 ? 'text-yellow-500' : 'text-text-secondary dark:text-d-text-secondary';

        return (
            <div className="bg-base-100 dark:bg-d-base-100 p-3 rounded-lg shadow-sm relative group">
                <p className="font-semibold text-text-primary dark:text-d-text-primary">{variation.title}</p>
                <div className="flex justify-between items-center mt-2 text-xs">
                    <span className="text-text-secondary dark:text-d-text-secondary">{variation.strategy}</span>
                    <span className={charColor}>{variation.characterCount} chars</span>
                </div>
                 <button onClick={handleCopy} className="absolute top-2 right-2 p-1 rounded-md bg-base-200 dark:bg-d-base-200 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Copy title">
                    <CopyIcon className="h-4 w-4" />
                </button>
                 {copySuccess && <div className="absolute -top-2 -right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        )
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter your video topic or idea..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Content Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Content Type</label>
                                <select value={contentType} onChange={e => setContentType(e.target.value as ContentType)} className={commonInputClasses}>
                                    <option>Tutorial</option><option>Review</option><option>Educational</option><option>Entertainment</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Audience</label>
                                <select value={audience} onChange={e => setAudience(e.target.value as Audience)} className={commonInputClasses}>
                                    <option>Beginners</option><option>General</option><option>Experts</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Optimizing...' : (isQueued ? 'Request Queued' : 'Optimize Content')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please enter a video topic to get started.</p>}
                </div>

                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Optimizing for the algorithm...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your optimized YouTube content package will appear here.</p>}
                    {parsedOutput && (
                        <div className="space-y-6">
                             <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Title Variations</h3>
                                {parsedOutput.titleVariations.map((v, i) => <TitleCard key={i} variation={v} />)}
                            </div>
                            
                            <div className="space-y-2">
                                <Accordion title="📝 Optimized Description" defaultOpen={true}>
                                    <div className="relative bg-base-100 dark:bg-d-base-100 p-3 rounded-lg group">
                                         <pre className="text-text-primary dark:text-d-text-primary whitespace-pre-wrap font-sans text-sm leading-relaxed">{parsedOutput.optimizedDescription}</pre>
                                         <button onClick={() => navigator.clipboard.writeText(parsedOutput.optimizedDescription)} className="absolute top-2 right-2 p-1 rounded-md bg-base-200 dark:bg-d-base-200 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Copy description">
                                            <CopyIcon className="h-4 w-4" />
                                        </button>
                                    </div>
                                </Accordion>
                                 <Accordion title="🚀 Hashtag Strategy" defaultOpen={true}>
                                    <div className="space-y-3 p-2">
                                         <p className="text-xs text-text-secondary dark:text-d-text-secondary">{parsedOutput.hashtagStrategy.analysis}</p>
                                        <div className="flex flex-wrap gap-2">
                                            {parsedOutput.hashtagStrategy.hashtags.map((h, i) => (
                                                <div key={i} className="bg-base-300 dark:bg-d-base-300 px-2 py-1 rounded-md text-xs font-semibold text-text-primary dark:text-d-text-primary">
                                                    {h}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </Accordion>
                                <Accordion title="📊 Performance Prediction" defaultOpen={true}>
                                    <div className="space-y-4 p-2">
                                        <ScoreBar score={parsedOutput.performancePrediction.ctrPotential} label="CTR Potential" />
                                        <ScoreBar score={parsedOutput.performancePrediction.searchVisibility} label="Search Visibility" />
                                        <ScoreBar score={parsedOutput.performancePrediction.audienceRetention} label="Retention Impact" />
                                    </div>
                                </Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default YouTubeStylerView;
