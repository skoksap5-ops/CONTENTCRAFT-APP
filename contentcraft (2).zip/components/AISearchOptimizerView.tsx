import React, { useState, useCallback, useMemo } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { saveGeneration } from '../services/historyService';
import { addToQueue } from '../services/offlineService';
import { useFeedback } from '../hooks/useFeedback';
import { Type } from '@google/genai';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import SparklesIcon from './icons/settings/SparklesIcon';
import CloseIcon from './icons/CloseIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface KeywordOpportunity {
    term: string;
    search_volume: string;
    difficulty: 'low' | 'medium' | 'high';
    opportunity_score: number;
    cpc: number;
    competition: number;
    competitor_ranking?: string[];
}
interface CompetitorAnalysis {
    domain: string;
    domain_authority: number;
    keyword_count: number;
    content_gaps: { topic: string; volume: string }[];
}
interface ContentGap {
    topic: string;
    description: string;
    intent: 'informational' | 'commercial' | 'navigational' | 'transactional';
    priority: 'high' | 'medium' | 'low';
    search_volume: string;
    difficulty: number;
    competitor_count: number;
    top_competitors: string[];
    content_ideas?: string[];
}
interface OverallMetrics {
    total_opportunities: number;
    high_opportunity: number;
    estimated_traffic_value: string;
    opportunity_score: number;
    estimated_monthly_traffic: string;
    gap_keywords: number;
    content_opportunities: number;
}
// FIX: Define missing interfaces based on the geoSchema.
interface AIResponsePreview {
    query: string;
    response_html: string;
}

interface OptimizationStrategy {
    type: string;
    platforms: string;
    content: string;
    priority: 'High' | 'Medium' | 'Low';
    impact_percentage: number;
}

interface ImplementationGuide {
    immediate_actions: string[];
    long_term_strategy: string[];
}

// FIX: Added executive_summary to match usage in handleGenerate and display in results.
interface AnalysisResult {
    executive_summary: string;
    ai_response_preview: AIResponsePreview;
    optimization_strategy: OptimizationStrategy[];
    implementation_guide: ImplementationGuide;
}

const geoSchema = {
  type: Type.OBJECT,
  properties: {
    // FIX: Added executive_summary to schema.
    executive_summary: { type: Type.STRING, description: "A 2-3 sentence executive summary of the GEO analysis and key opportunities." },
    ai_response_preview: {
      type: Type.OBJECT,
      description: "A simulated AI search engine response mentioning the user's brand.",
      properties: {
        query: { type: Type.STRING },
        response_html: { type: Type.STRING, description: "The response formatted as a simple HTML string." }
      },
      required: ['query', 'response_html']
    },
    optimization_strategy: {
      type: Type.ARRAY,
      description: "A list of 3-4 key optimization recommendations.",
      items: {
        type: Type.OBJECT,
        properties: {
          type: { type: Type.STRING, description: "e.g., 'Content Authority', 'Technical Optimization'" },
          platforms: { type: Type.STRING, description: "Which AI platforms this applies to." },
          content: { type: Type.STRING, description: "The recommendation detail." },
          priority: { type: Type.STRING, enum: ['High', 'Medium', 'Low'] },
          impact_percentage: { type: Type.NUMBER, description: "Estimated impact score from 0-100." }
        },
        required: ['type', 'platforms', 'content', 'priority', 'impact_percentage']
      }
    },
    implementation_guide: {
      type: Type.OBJECT,
      description: "An action plan for the user.",
      properties: {
        immediate_actions: { type: Type.ARRAY, items: { type: Type.STRING } },
        long_term_strategy: { type: Type.ARRAY, items: { type: Type.STRING } }
      },
      required: ['immediate_actions', 'long_term_strategy']
    }
  },
  // FIX: Added executive_summary to required fields.
  required: ['executive_summary', 'ai_response_preview', 'optimization_strategy', 'implementation_guide']
};


const AISearchOptimizerView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const { playClick, playSuccess } = useFeedback();

    const [websiteUrl, setWebsiteUrl] = useState('');
    const [businessType, setBusinessType] = useState('');
    const [targetTopics, setTargetTopics] = useState('');
    const [competitors, setCompetitors] = useState<string[]>([]);
    const [competitorInput, setCompetitorInput] = useState('');
    const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(['chatgpt', 'copilot']);
    const [selectedFocus, setSelectedFocus] = useState<string>('content');
    
    const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [activeTab, setActiveTab] = useState('preview');

    const canGenerate = useMemo(() => (usesLeft === 'Unlimited' || usesLeft > 0) && websiteUrl.trim(), [usesLeft, websiteUrl]);

    const handleAddCompetitor = () => {
        if (competitorInput.trim() && !competitors.includes(competitorInput.trim())) {
            setCompetitors(prev => [...prev, competitorInput.trim()]);
            setCompetitorInput('');
        }
    };

    const handleRemoveCompetitor = (competitorToRemove: string) => {
        setCompetitors(prev => prev.filter(c => c !== competitorToRemove));
    };
    
    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        playClick();
        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);
        setIsQueued(false);

        const prompt = `You are a Generative Engine Optimization (GEO) expert. Analyze the provided website and generate a comprehensive AI Search Optimization strategy.
        - Website URL: ${websiteUrl}
        - Business Type: ${businessType}
        - Target Topics: ${targetTopics}
        - Competitors: ${competitors.join(', ')}
        - Platforms to optimize for: ${selectedPlatforms.join(', ')}
        - Optimization Focus: ${selectedFocus}
        Your response must be a valid JSON object conforming to the provided schema. Generate realistic but illustrative data.`;
        
        if (!navigator.onLine) {
            try {
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (err) {
                setError("Could not queue request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: 'application/json',
                responseSchema: geoSchema as any,
            });
            const parsed: AnalysisResult = JSON.parse(result);
            setAnalysisResult(parsed);
            playSuccess();

            if (userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: `URL: ${websiteUrl}, Topics: ${targetTopics}`,
                    output: parsed.executive_summary,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }

    }, [canGenerate, websiteUrl, businessType, targetTopics, competitors, selectedPlatforms, selectedFocus, playClick, playSuccess, module, userId, usesLeft, decrementUse]);

    const platforms = [
        { id: 'chatgpt', name: 'ChatGPT' }, { id: 'copilot', name: 'Copilot' }, { id: 'bard', name: 'Google Gemini' },
        { id: 'claude', name: 'Claude AI' }, { id: 'deepseek', name: 'DeepSeek' }, { id: 'perplexity', name: 'Perplexity' },
    ];
    const focuses = [
        { id: 'content', name: 'Content Structure' }, { id: 'technical', name: 'Technical SEO' },
        { id: 'authority', name: 'Authority Signals' }, { id: 'conversational', name: 'Conversational' },
    ];

    if (analysisResult) {
         return (
            <div className="ai-search-optimizer-module max-w-7xl mx-auto flex flex-col gap-8">
                 <div className="text-center">
                    <h1 className="text-3xl font-bold font-heading">Optimization Results for {websiteUrl}</h1>
                    {/* FIX: Display executive summary in the results view. */}
                    <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{analysisResult.executive_summary}</p>
                    <button onClick={() => setAnalysisResult(null)} className="text-brand-primary font-semibold mt-2">← Start New Analysis</button>
                </div>
                <div className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl">
                    <div className="preview-tabs flex border-b border-base-300 dark:border-d-base-300 mb-4">
                        <button className={`tab px-4 py-2 font-semibold ${activeTab === 'preview' ? 'active' : ''}`} onClick={() => setActiveTab('preview')}>AI Response Preview</button>
                        <button className={`tab px-4 py-2 font-semibold ${activeTab === 'strategy' ? 'active' : ''}`} onClick={() => setActiveTab('strategy')}>Optimization Strategy</button>
                        <button className={`tab px-4 py-2 font-semibold ${activeTab === 'implementation' ? 'active' : ''}`} onClick={() => setActiveTab('implementation')}>Implementation Guide</button>
                    </div>
                     {activeTab === 'preview' && (
                        <div>
                            <div className="ai-query p-4 rounded-lg font-semibold">{analysisResult.ai_response_preview.query}</div>
                            <div className="ai-response mt-4 p-4 rounded-lg bg-base-100 dark:bg-d-base-100 border-l-4" dangerouslySetInnerHTML={{ __html: analysisResult.ai_response_preview.response_html }} />
                        </div>
                    )}
                    {activeTab === 'strategy' && (
                         <div className="space-y-4">
                            {analysisResult.optimization_strategy.map((item, index) => (
                                <div key={index} className="result-card bg-base-100 dark:bg-d-base-100 p-4 rounded-lg">
                                    <div className="flex justify-between items-center mb-2">
                                        <span className="result-type text-xs font-bold uppercase text-white px-2 py-0.5 rounded-full">{item.type}</span>
                                        <span className="text-sm font-semibold">{item.platforms}</span>
                                    </div>
                                    <p className="text-sm">{item.content}</p>
                                    <div className="flex justify-between items-center text-xs mt-2">
                                        <span>Priority: {item.priority}</span>
                                        <span>Impact: {item.impact_percentage}%</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                    {activeTab === 'implementation' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <h4 className="font-bold text-lg mb-2">Immediate Actions</h4>
                                <ul className="list-disc list-inside space-y-2 text-sm">
                                    {analysisResult.implementation_guide.immediate_actions.map((action, i) => <li key={i}>{action}</li>)}
                                </ul>
                            </div>
                             <div>
                                <h4 className="font-bold text-lg mb-2">Long-term Strategy</h4>
                                <ul className="list-disc list-inside space-y-2 text-sm">
                                    {analysisResult.implementation_guide.long_term_strategy.map((action, i) => <li key={i}>{action}</li>)}
                                </ul>
                            </div>
                        </div>
                    )}
                </div>
            </div>
         )
    }

    return (
        <div className="ai-search-optimizer-module max-w-4xl mx-auto flex flex-col gap-8">
            <header className="text-center">
                <h1 className="text-3xl font-bold font-heading">{module.name}</h1>
                <p className="subtitle text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </header>
            
            <section className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-6">
                <div className="section-title border-b border-base-300 dark:border-d-base-300 pb-4">
                    <div className="section-icon w-12 h-12 flex items-center justify-center rounded-xl text-white"><SparklesIcon className="w-6 h-6"/></div>
                    <h2 className="text-2xl font-bold font-heading">Optimize for AI Search</h2>
                </div>

                <div className="form-group">
                    <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1">Website URL</label>
                    <input type="url" value={websiteUrl} onChange={e => setWebsiteUrl(e.target.value)} placeholder="https://yourwebsite.com" className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                </div>
                 <div className="form-group">
                    <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1">Target Topics/Keywords</label>
                    <textarea value={targetTopics} onChange={e => setTargetTopics(e.target.value)} placeholder="List main topics, products, or services..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[100px]"></textarea>
                </div>
                
                 <div className="form-group">
                    <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">AI Platforms to Optimize For</label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                         {platforms.map(p => (
                            <button key={p.id} onClick={() => setSelectedPlatforms(prev => prev.includes(p.id) ? prev.filter(i => i !== p.id) : [...prev, p.id])} className={`platform-card p-3 rounded-lg border-2 text-center transition-all duration-200 bg-base-100 dark:bg-d-base-100 ${selectedPlatforms.includes(p.id) ? 'selected' : 'border-transparent'}`}>
                                <p className="font-semibold text-sm">{p.name}</p>
                            </button>
                         ))}
                    </div>
                </div>

                <div className="form-group">
                    <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">Optimization Focus</label>
                     <div className="grid grid-cols-2 gap-2">
                        {focuses.map(f => (
                            <button key={f.id} onClick={() => setSelectedFocus(f.id)} className={`optimization-card p-3 rounded-lg border-2 text-center transition-all duration-200 bg-base-100 dark:bg-d-base-100 ${selectedFocus === f.id ? 'selected' : 'border-transparent'}`}>
                                <p className="font-semibold text-sm">{f.name}</p>
                            </button>
                        ))}
                    </div>
                </div>

                 <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full btn-primary flex items-center justify-center p-4 rounded-xl text-white font-bold text-lg gap-2">
                    {isLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/50 border-t-white rounded-full"></span> : <SparklesIcon className="h-6 w-6" />}
                    {isLoading ? 'Analyzing...' : 'Generate Optimization Strategy'}
                </button>
                {error && <div className="text-center bg-error/20 text-error p-2 rounded-lg text-sm">{error}</div>}
            </section>
        </div>
    );
};

export default AISearchOptimizerView;