import React from 'react';

interface StyleTemplatesProps {
    onTemplateSelect: (template: string) => void;
    selectedAI: string;
}

export const StyleTemplates: React.FC<StyleTemplatesProps> = ({ onTemplateSelect, selectedAI }) => {
  const promptTemplates: { [key: string]: any[] } = {
    chatgpt: [
      {
        id: 1,
        name: 'Comprehensive Content Creator',
        description: 'Detailed prompt for long-form content creation',
        template: `Act as an expert [industry] content creator. Create a comprehensive [content type] about [topic] that:

1. Starts with an engaging hook that addresses [target audience]'s pain points
2. Provides 3-5 key insights with actionable advice
3. Includes real-world examples and case studies
4. Ends with a compelling call-to-action

Tone: [tone]
Length: [length]
Include: [specific elements]`
      },
      {
        id: 2,
        name: 'Social Media Viral Post',
        description: 'Optimized for social media engagement',
        template: `Create a viral social media post for [platform] about [topic] that:

- Starts with a shocking statistic or provocative question
- Provides valuable insights in bite-sized format
- Includes emojis and engaging elements
- Ends with an interactive CTA (question or poll)

Target audience: [audience]
Hashtags: [3-5 relevant hashtags]
Tone: [tone]`
      }
    ],
    midjourney: [
      {
        id: 1,
        name: 'Professional Product Shot',
        description: 'Create stunning product photography',
        template: `[product description], professional product photography, studio lighting, clean background, highly detailed, sharp focus, 8K, photorealistic, --ar 16:9 --style raw`
      },
      {
        id: 2, 
        name: 'Creative Art Concept',
        description: 'Generate unique artistic concepts',
        template: `[concept description], digital art, fantasy art, vibrant colors, intricate details, epic composition, trending on artstation, unreal engine 5, octane render --ar 2:3 --style 4b`
      }
    ]
  };

  const templates = promptTemplates[selectedAI] || promptTemplates.chatgpt;

  return (
    <div className="space-y-4">
      <div className="text-center">
        <h3 className="text-xl font-bold font-heading text-text-primary dark:text-d-text-primary">🎨 Prompt Templates for {selectedAI.charAt(0).toUpperCase() + selectedAI.slice(1)}</h3>
        <p className="text-text-secondary dark:text-d-text-secondary mt-1">Select a template to get started, then customize it for your specific needs.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {templates.map(template => (
          <div key={template.id} className="bg-base-200 dark:bg-d-base-200 p-4 rounded-xl flex flex-col">
            <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{template.name}</h4>
            <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1 flex-grow">{template.description}</p>
            <pre className="bg-base-100 dark:bg-d-base-100 text-xs p-3 rounded-lg my-3 whitespace-pre-wrap font-mono">{template.template}</pre>
            <button 
              onClick={() => onTemplateSelect(template.template)}
              className="w-full mt-auto px-4 py-2 text-sm font-semibold bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90"
            >
              Use This Template
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
