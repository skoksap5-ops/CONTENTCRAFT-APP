import React, { useState } from 'react';
import type { PromptRequestData } from '../../hooks/usePromptAI';

interface PromptCreatorProps {
    onGenerate: (data: PromptRequestData) => void;
    selectedAI: string;
    isLoading: boolean;
}

export const PromptCreator: React.FC<PromptCreatorProps> = ({ onGenerate, selectedAI, isLoading }) => {
  const [promptRequest, setPromptRequest] = useState<PromptRequestData>({
    goal: '',
    context: '',
    desiredOutput: '',
    tone: 'professional',
    length: 'medium',
    includeExamples: true
  });

  const tones = ['professional', 'casual', 'academic', 'creative', 'technical', 'friendly'];
  const lengths = ['short', 'medium', 'long', 'detailed'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(promptRequest);
  };

  const handleQuickPrompt = (type: string) => {
    const quickPrompts: { [key: string]: string } = {
      content: `Create a comprehensive blog post about [topic] that engages readers and provides actionable insights.`,
      social: `Write a viral social media post about [topic] that drives engagement and shares.`,
      email: `Compose a persuasive email campaign for [product/service] that converts readers into customers.`,
      creative: `Generate creative ideas for [project] that are innovative and attention-grabbing.`
    };
    
    setPromptRequest(prev => ({
      ...prev,
      goal: quickPrompts[type] || ''
    }));
  };

  const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
  const commonInputClasses = "w-full p-2 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
  const commonTextareaClasses = `${commonInputClasses} min-h-[80px]`;

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-4">
          <h3 className="text-xl font-bold font-heading text-text-primary dark:text-d-text-primary">🎯 What do you want to create?</h3>
          
          <div>
            <label className={commonLabelClasses}>Main Goal or Task</label>
            <textarea
              value={promptRequest.goal}
              onChange={(e) => setPromptRequest(prev => ({...prev, goal: e.target.value}))}
              placeholder="Describe what you want the AI to create or do..."
              className={commonTextareaClasses}
              required
            />
          </div>

          <div>
            <label className={commonLabelClasses}>Additional Context (Optional)</label>
            <textarea
              value={promptRequest.context}
              onChange={(e) => setPromptRequest(prev => ({...prev, context: e.target.value}))}
              placeholder="Any background information, specific requirements, or constraints..."
              className={commonTextareaClasses}
            />
          </div>

          <div>
            <label className={commonLabelClasses}>Desired Output Format</label>
            <input
              type="text"
              value={promptRequest.desiredOutput}
              onChange={(e) => setPromptRequest(prev => ({...prev, desiredOutput: e.target.value}))}
              placeholder="e.g., blog post, email, social media caption, code, etc."
              className={commonInputClasses}
            />
          </div>
        </div>

        <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-4">
          <h3 className="text-xl font-bold font-heading text-text-primary dark:text-d-text-primary">🎨 Style & Preferences</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className={commonLabelClasses}>Tone</label>
              <select value={promptRequest.tone} onChange={(e) => setPromptRequest(prev => ({...prev, tone: e.target.value}))} className={commonInputClasses}>
                {tones.map(tone => (<option key={tone} value={tone} className="capitalize">{tone}</option>))}
              </select>
            </div>

            <div>
              <label className={commonLabelClasses}>Length</label>
              <select value={promptRequest.length} onChange={(e) => setPromptRequest(prev => ({...prev, length: e.target.value}))} className={commonInputClasses}>
                {lengths.map(length => (<option key={length} value={length} className="capitalize">{length}</option>))}
              </select>
            </div>
          </div>
        </div>
        
        <div className="p-4 bg-base-200/50 dark:bg-d-base-200/50 rounded-xl">
          <h4 className="text-lg font-semibold text-text-primary dark:text-d-text-primary mb-2">🚀 Quick Start Prompts</h4>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
            <button type="button" onClick={() => handleQuickPrompt('content')} className="p-3 rounded-lg bg-base-100 dark:bg-d-base-100 text-sm font-semibold hover:bg-base-300 dark:hover:bg-d-base-300 transition-colors">📝 Content Creation</button>
            <button type="button" onClick={() => handleQuickPrompt('social')} className="p-3 rounded-lg bg-base-100 dark:bg-d-base-100 text-sm font-semibold hover:bg-base-300 dark:hover:bg-d-base-300 transition-colors">📱 Social Media</button>
            <button type="button" onClick={() => handleQuickPrompt('email')} className="p-3 rounded-lg bg-base-100 dark:bg-d-base-100 text-sm font-semibold hover:bg-base-300 dark:hover:bg-d-base-300 transition-colors">📧 Email Campaign</button>
            <button type="button" onClick={() => handleQuickPrompt('creative')} className="p-3 rounded-lg bg-base-100 dark:bg-d-base-100 text-sm font-semibold hover:bg-base-300 dark:hover:bg-d-base-300 transition-colors">💡 Creative Ideas</button>
          </div>
        </div>

        <button type="submit" className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary disabled:bg-base-300 dark:disabled:bg-d-base-300 transition-all duration-300" disabled={isLoading}>
          {isLoading ? 'Generating...' : 'Generate Powerful Prompt ⚡'}
        </button>
      </form>
    </div>
  );
};
