import React from 'react';

interface AISelectorProps {
  selectedAI: string;
  onAIChange: (ai: string) => void;
}

export const AISelector: React.FC<AISelectorProps> = ({ selectedAI, onAIChange }) => {
  const aiPlatforms = [
    { id: 'chatgpt', name: 'ChatGPT', icon: '🤖', color: '#10a37f' },
    { id: 'midjourney', name: 'Midjourney', icon: '🎨', color: '#2d5fe3' },
    { id: 'dalle', name: 'DALL-E', icon: '🖼️', color: '#8b5cf6' },
    { id: 'claude', name: 'Claude', icon: '🧠', color: '#f59e0b' },
    { id: 'bard', name: 'Google Gemini', icon: '✨', color: '#4285f4' },
    { id: 'custom', name: 'Custom AI', icon: '⚙️', color: '#6b7280' }
  ];

  return (
    <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-xl">
      <h3 className="text-lg font-semibold text-text-primary dark:text-d-text-primary mb-3 text-center">Select AI Platform</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
        {aiPlatforms.map(platform => (
          <button
            key={platform.id}
            className={`p-3 rounded-lg text-center border-2 transition-all duration-200 ${
              selectedAI === platform.id ? 'border-brand-primary bg-brand-primary/10 shadow-md' : 'border-transparent bg-base-100 dark:bg-d-base-100 hover:bg-base-300 dark:hover:bg-d-base-300'
            }`}
            onClick={() => onAIChange(platform.id)}
            style={{ borderColor: selectedAI === platform.id ? platform.color : 'transparent' }}
          >
            <div className="text-3xl mx-auto" style={{ color: selectedAI === platform.id ? platform.color : '' }}>{platform.icon}</div>
            <p className="text-xs font-bold mt-2 text-text-primary dark:text-d-text-primary">{platform.name}</p>
          </button>
        ))}
      </div>
    </div>
  );
};
