import React, { useState, useEffect } from 'react';
import type { PromptAnalysis } from '../../hooks/usePromptAI';
import CopyIcon from '../icons/CopyIcon';

interface PromptOptimizerProps {
  currentPrompt: string;
  optimizedPrompt: string;
  onOptimize: (prompt: string) => void;
  onAnalyze: (prompt: string) => Promise<PromptAnalysis>;
  onUpdatePrompt: (prompt: string) => void;
  isLoading: boolean;
}

export const PromptOptimizer: React.FC<PromptOptimizerProps> = ({ 
  currentPrompt, 
  optimizedPrompt, 
  onOptimize, 
  onAnalyze, 
  onUpdatePrompt,
  isLoading 
}) => {
  const [analysis, setAnalysis] = useState<PromptAnalysis | null>(null);
  const [showAnalysis, setShowAnalysis] = useState(false);

  useEffect(() => {
    if (currentPrompt) {
      handleAnalyzePrompt(currentPrompt);
    }
  }, []);

  const handleAnalyzePrompt = async (prompt: string) => {
    if (!prompt) return;
    const result = await onAnalyze(prompt);
    setAnalysis(result);
    setShowAnalysis(true);
  };
  
  const commonTextareaClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors min-h-[150px]";

  const ScoreBar: React.FC<{ score: number; label: string }> = ({ score, label }) => (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">{label}</span>
        <span className="text-sm font-bold text-text-primary dark:text-d-text-primary">{score}/10</span>
      </div>
      <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2">
        <div className="bg-brand-primary h-2 rounded-full" style={{ width: `${score * 10}%` }}></div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-4 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-3">
          <h3 className="text-lg font-bold">📝 Original Prompt</h3>
            <textarea
              value={currentPrompt}
              onChange={(e) => onUpdatePrompt(e.target.value)}
              placeholder="Paste or type your prompt here..."
              className={commonTextareaClasses}
            />
            <div className="flex gap-2">
              <button onClick={() => handleAnalyzePrompt(currentPrompt)} className="flex-1 px-4 py-2 text-sm font-semibold bg-base-300 dark:bg-d-base-300 rounded-lg hover:bg-base-400 dark:hover:bg-d-base-400" disabled={!currentPrompt || isLoading}>Analyze</button>
              <button onClick={() => onOptimize(currentPrompt)} className="flex-1 px-4 py-2 text-sm font-semibold bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90" disabled={!currentPrompt || isLoading}>
                {isLoading ? 'Optimizing...' : 'Optimize 🔧'}
              </button>
            </div>
        </div>

        <div className="p-4 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-3">
          <h3 className="text-lg font-bold">🚀 Optimized Prompt</h3>
          <div className={`${commonTextareaClasses} overflow-auto relative`}>
            {optimizedPrompt ? <pre className="whitespace-pre-wrap font-sans">{optimizedPrompt}</pre> : <p className="text-text-secondary dark:text-d-text-secondary">Your optimized prompt will appear here...</p>}
            {optimizedPrompt && (
                <button onClick={() => navigator.clipboard.writeText(optimizedPrompt)} className="absolute top-2 right-2 p-2 rounded-lg bg-base-100 dark:bg-d-base-100 hover:bg-base-300 dark:hover:bg-d-base-300" aria-label="Copy optimized prompt">
                    <CopyIcon className="h-4 w-4" />
                </button>
            )}
          </div>
           {optimizedPrompt && <button onClick={() => onUpdatePrompt(optimizedPrompt)} className="w-full px-4 py-2 text-sm font-semibold bg-base-300 dark:bg-d-base-300 rounded-lg hover:bg-base-400 dark:hover:bg-d-base-400">Use as New Prompt</button>}
        </div>
      </div>

      {analysis && (
        <div className="p-4 bg-base-200 dark:bg-d-base-200 rounded-xl animate-fade-in">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-bold">📊 Prompt Analysis</h3>
            <button onClick={() => setShowAnalysis(!showAnalysis)} className="text-sm font-semibold text-brand-primary">{showAnalysis ? 'Hide' : 'Show'}</button>
          </div>
          {showAnalysis && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4 pt-4 border-t border-base-300 dark:border-d-base-300">
                <div className="space-y-4">
                    <ScoreBar score={analysis.clarityScore} label="Clarity" />
                    <ScoreBar score={analysis.specificityScore} label="Specificity" />
                    <ScoreBar score={analysis.expectedResultsScore} label="Result Definition" />
                </div>
                <div>
                    <h4 className="font-semibold mb-2">💡 Improvement Suggestions</h4>
                    <ul className="space-y-2 list-disc list-inside text-sm text-text-secondary dark:text-d-text-secondary">
                        {analysis.suggestions?.map((suggestion, index) => <li key={index}>{suggestion}</li>)}
                    </ul>
                </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
