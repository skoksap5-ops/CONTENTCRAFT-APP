import React, { useState, useCallback, useMemo } from 'react';
import type { Module } from '../types';
import { useResumeAI } from '../hooks/useResumeAI';
import type { ResumeData, Experience, Education, Skill } from './resume-generator/types';
import { useFeedback } from '../hooks/useFeedback';
import SparklesIcon from './icons/settings/SparklesIcon';
import DownloadIcon from './icons/settings/DownloadIcon';
import PlusIcon from './icons/PlusIcon';
import TrashIcon from './icons/TrashIcon';

interface ResumeGeneratorViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
}

const initialResumeData: ResumeData = {
    personal: { firstName: '', lastName: '', title: '', email: '', phone: '', location: '', linkedin: '', portfolio: '' },
    summary: '',
    experience: [{ id: 1, title: '', company: '', startDate: '', endDate: '', description: '' }],
    education: [{ id: 1, degree: '', school: '', date: '' }],
    skills: [{ id: 1, name: '' }],
};

const ResumeGeneratorView: React.FC<ResumeGeneratorViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const { playClick, playSuccess } = useFeedback();
    const [resumeData, setResumeData] = useState<ResumeData>(initialResumeData);
    const { enhanceResume, isLoading, error } = useResumeAI(userId, module.id, module.name, usesLeft, decrementUse);

    const canGenerate = useMemo(() => (usesLeft === 'Unlimited' || usesLeft > 0) && !!resumeData.personal.firstName && !!resumeData.personal.title, [usesLeft, resumeData.personal]);

    const handleChange = <T,>(section: keyof ResumeData, id: number | null, field: keyof T, value: string) => {
        setResumeData(prev => {
            if (id === null) { // For non-array sections like 'personal' or 'summary'
                return { ...prev, [section]: { ...(prev[section] as object), [field]: value } };
            }
            const items = (prev[section] as any[]).map(item =>
                item.id === id ? { ...item, [field]: value } : item
            );
            return { ...prev, [section]: items };
        });
    };
    
    const handleAddItem = (section: 'experience' | 'education' | 'skills') => {
        playClick();
        const newItem = {
            id: Date.now(),
            ...(section === 'experience' && { title: '', company: '', startDate: '', endDate: '', description: '' }),
            ...(section === 'education' && { degree: '', school: '', date: '' }),
            ...(section === 'skills' && { name: '' }),
        };
        setResumeData(prev => ({ ...prev, [section]: [...(prev[section] as any[]), newItem] }));
    };

    const handleRemoveItem = (section: 'experience' | 'education' | 'skills', id: number) => {
        playClick();
        setResumeData(prev => ({
            ...prev,
            [section]: (prev[section] as any[]).length > 1 ? (prev[section] as any[]).filter(item => item.id !== id) : prev[section]
        }));
    };
    
    const handleEnhance = async () => {
        if (!canGenerate) return;
        playClick();
        const enhancedData = await enhanceResume(resumeData);
        if (enhancedData) {
            setResumeData(prev => ({
                ...prev,
                summary: enhancedData.summary || prev.summary,
                experience: prev.experience.map((exp, index) => ({
                    ...exp,
                    description: enhancedData.experience[index]?.description || exp.description
                }))
            }));
            playSuccess();
        }
    };

    const handleDownload = () => {
        playClick();
        let markdown = `# ${resumeData.personal.firstName} ${resumeData.personal.lastName}\n`;
        markdown += `${resumeData.personal.title}\n\n`;
        markdown += `${resumeData.personal.email} | ${resumeData.personal.phone} | ${resumeData.personal.location}\n`;
        if (resumeData.personal.linkedin) markdown += `LinkedIn: ${resumeData.personal.linkedin}\n`;
        if (resumeData.personal.portfolio) markdown += `Portfolio: ${resumeData.personal.portfolio}\n`;
        markdown += `\n## Summary\n${resumeData.summary}\n`;
        markdown += `\n## Experience\n`;
        resumeData.experience.forEach(exp => {
            markdown += `### ${exp.title} at ${exp.company}\n*${exp.startDate} - ${exp.endDate}*\n${exp.description}\n\n`;
        });
        markdown += `## Education\n`;
        resumeData.education.forEach(edu => {
            markdown += `### ${edu.degree}, ${edu.school}\n*${edu.date}*\n\n`;
        });
        markdown += `## Skills\n`;
        markdown += resumeData.skills.map(skill => skill.name).join(', ') + '\n';

        const blob = new Blob([markdown], { type: 'text/markdown' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${resumeData.personal.firstName}_${resumeData.personal.lastName}_Resume.md`;
        a.click();
        URL.revokeObjectURL(url);
    };

    const inputClasses = "w-full p-2 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-resume-blue";
    const textareaClasses = `${inputClasses} min-h-[100px]`;
    const labelClasses = "block text-sm font-medium mb-1";

    return (
        <div className="resume-generator-module max-w-7xl mx-auto flex flex-col gap-8">
            <header className="text-center">
                <h1 className="text-3xl font-bold font-heading">{module.name}</h1>
                <p className="subtitle text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-6">
                    {/* Personal Info */}
                    <div className="space-y-4">
                        <h2 className="text-xl font-bold font-heading">Personal Information</h2>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div><label className={labelClasses}>First Name</label><input type="text" value={resumeData.personal.firstName} onChange={e => handleChange( 'personal', null, 'firstName', e.target.value)} className={inputClasses}/></div>
                            <div><label className={labelClasses}>Last Name</label><input type="text" value={resumeData.personal.lastName} onChange={e => handleChange( 'personal', null, 'lastName', e.target.value)} className={inputClasses}/></div>
                            <div className="sm:col-span-2"><label className={labelClasses}>Professional Title</label><input type="text" value={resumeData.personal.title} onChange={e => handleChange( 'personal', null, 'title', e.target.value)} className={inputClasses}/></div>
                            <div><label className={labelClasses}>Email</label><input type="email" value={resumeData.personal.email} onChange={e => handleChange( 'personal', null, 'email', e.target.value)} className={inputClasses}/></div>
                            <div><label className={labelClasses}>Phone</label><input type="tel" value={resumeData.personal.phone} onChange={e => handleChange( 'personal', null, 'phone', e.target.value)} className={inputClasses}/></div>
                            <div className="sm:col-span-2"><label className={labelClasses}>Location</label><input type="text" value={resumeData.personal.location} onChange={e => handleChange( 'personal', null, 'location', e.target.value)} className={inputClasses}/></div>
                            <div><label className={labelClasses}>LinkedIn</label><input type="url" value={resumeData.personal.linkedin} onChange={e => handleChange( 'personal', null, 'linkedin', e.target.value)} className={inputClasses}/></div>
                            <div><label className={labelClasses}>Portfolio/Website</label><input type="url" value={resumeData.personal.portfolio} onChange={e => handleChange( 'personal', null, 'portfolio', e.target.value)} className={inputClasses}/></div>
                        </div>
                    </div>
                    {/* Summary */}
                    <div className="space-y-2">
                        <h2 className="text-xl font-bold font-heading">Professional Summary</h2>
                        <textarea value={resumeData.summary} onChange={e => setResumeData(p => ({ ...p, summary: e.target.value }))} className={textareaClasses} />
                    </div>
                     {/* Experience */}
                    <div className="space-y-2">
                        <h2 className="text-xl font-bold font-heading">Work Experience</h2>
                        {resumeData.experience.map(exp => (
                            <div key={exp.id} className="p-4 rounded-lg bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 space-y-2 item-container">
                                <div className="flex justify-end"><button onClick={() => handleRemoveItem('experience', exp.id)} className="p-1 text-error disabled:opacity-50" disabled={resumeData.experience.length <= 1}><TrashIcon className="h-5 w-5"/></button></div>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                    <div><label className={labelClasses}>Job Title</label><input type="text" value={exp.title} onChange={e => handleChange('experience', exp.id, 'title', e.target.value)} className={inputClasses}/></div>
                                    <div><label className={labelClasses}>Company</label><input type="text" value={exp.company} onChange={e => handleChange('experience', exp.id, 'company', e.target.value)} className={inputClasses}/></div>
                                    <div><label className={labelClasses}>Start Date</label><input type="text" value={exp.startDate} onChange={e => handleChange('experience', exp.id, 'startDate', e.target.value)} className={inputClasses}/></div>
                                    <div><label className={labelClasses}>End Date</label><input type="text" value={exp.endDate} onChange={e => handleChange('experience', exp.id, 'endDate', e.target.value)} className={inputClasses}/></div>
                                </div>
                                <label className={labelClasses}>Description</label><textarea value={exp.description} onChange={e => handleChange('experience', exp.id, 'description', e.target.value)} className={textareaClasses}/>
                            </div>
                        ))}
                         <button onClick={() => handleAddItem('experience')} className="w-full mt-2 p-2 flex items-center justify-center gap-2 border-2 border-dashed rounded-lg hover:border-brand-primary transition-colors"><PlusIcon className="h-5 w-5"/>Add Experience</button>
                    </div>
                    {/* Education & Skills */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <h2 className="text-xl font-bold font-heading">Education</h2>
                            {resumeData.education.map(edu => (
                                <div key={edu.id} className="p-4 rounded-lg bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 space-y-2 item-container">
                                    <div className="flex justify-end"><button onClick={() => handleRemoveItem('education', edu.id)} className="p-1 text-error disabled:opacity-50" disabled={resumeData.education.length <= 1}><TrashIcon className="h-5 w-5"/></button></div>
                                    <div><label className={labelClasses}>Degree/Field</label><input type="text" value={edu.degree} onChange={e => handleChange('education', edu.id, 'degree', e.target.value)} className={inputClasses}/></div>
                                    <div><label className={labelClasses}>School/University</label><input type="text" value={edu.school} onChange={e => handleChange('education', edu.id, 'school', e.target.value)} className={inputClasses}/></div>
                                    <div><label className={labelClasses}>Date</label><input type="text" value={edu.date} onChange={e => handleChange('education', edu.id, 'date', e.target.value)} className={inputClasses}/></div>
                                </div>
                            ))}
                             <button onClick={() => handleAddItem('education')} className="w-full mt-2 p-2 flex items-center justify-center gap-2 border-2 border-dashed rounded-lg hover:border-brand-primary transition-colors"><PlusIcon className="h-5 w-5"/>Add Education</button>
                        </div>
                         <div className="space-y-2">
                            <h2 className="text-xl font-bold font-heading">Skills</h2>
                            {resumeData.skills.map(skill => (
                                <div key={skill.id} className="flex items-center gap-2 item-container pl-2">
                                    <input type="text" value={skill.name} onChange={e => handleChange('skills', skill.id, 'name', e.target.value)} className={inputClasses}/>
                                    <button onClick={() => handleRemoveItem('skills', skill.id)} className="p-1 text-error disabled:opacity-50" disabled={resumeData.skills.length <= 1}><TrashIcon className="h-5 w-5"/></button>
                                </div>
                            ))}
                             <button onClick={() => handleAddItem('skills')} className="w-full mt-2 p-2 flex items-center justify-center gap-2 border-2 border-dashed rounded-lg hover:border-brand-primary transition-colors"><PlusIcon className="h-5 w-5"/>Add Skill</button>
                        </div>
                    </div>
                </div>
                {/* Preview & Actions */}
                <div className="sticky top-24 self-start">
                    <div className="p-4 bg-base-100 dark:bg-d-base-100 rounded-lg shadow-lg max-h-[60vh] overflow-y-auto">
                        <div className="bg-white p-6 text-black">
                            <h2 className="text-3xl font-bold text-center">{resumeData.personal.firstName} {resumeData.personal.lastName}</h2>
                            <h3 className="text-center text-lg text-resume-blue font-semibold">{resumeData.personal.title}</h3>
                            <p className="text-center text-xs text-gray-500 mt-2">{resumeData.personal.email} | {resumeData.personal.phone} | {resumeData.personal.location}</p>
                            
                            <h4 className="font-bold border-b-2 border-gray-200 pb-1 mt-4">Summary</h4>
                            <p className="text-sm mt-2">{resumeData.summary}</p>

                            <h4 className="font-bold border-b-2 border-gray-200 pb-1 mt-4">Experience</h4>
                            {resumeData.experience.map(exp => (
                                <div key={exp.id} className="mt-2">
                                    <p className="font-bold">{exp.title} <span className="font-normal text-gray-600">at {exp.company}</span></p>
                                    <p className="text-xs text-gray-500">{exp.startDate} - {exp.endDate}</p>
                                    <p className="text-sm mt-1 whitespace-pre-wrap">{exp.description}</p>
                                </div>
                            ))}
                            {/* ... similar rendering for education and skills */}
                        </div>
                    </div>
                    <div className="mt-4 space-y-2">
                        <button onClick={handleEnhance} disabled={isLoading || !canGenerate} className="w-full btn-primary flex items-center justify-center p-3 rounded-xl text-white font-bold gap-2">
                             {isLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/50 border-t-white rounded-full"></span> : <SparklesIcon className="h-5 w-5" />}
                             {isLoading ? 'Enhancing...' : 'AI Enhance'}
                        </button>
                        <button onClick={handleDownload} className="w-full flex items-center justify-center p-3 rounded-xl bg-brand-secondary text-white font-bold gap-2">
                            <DownloadIcon className="h-5 w-5" /> Download (.md)
                        </button>
                        {error && <div className="text-center bg-error/20 text-error p-2 rounded-lg text-sm">{error}</div>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ResumeGeneratorView;
