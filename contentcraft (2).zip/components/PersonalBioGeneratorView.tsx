import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { saveGeneration } from '../services/historyService';
import { addToQueue } from '../services/offlineService';
import { useFeedback } from '../hooks/useFeedback';
import { Type } from '@google/genai';
import CopyIcon from './icons/CopyIcon';
import SparklesIcon from './icons/settings/SparklesIcon';
import BriefcaseIcon from './icons/professional/BriefcaseIcon';
import SmileIcon from './icons/professional/SmileIcon';
import AnalyticsIcon from './icons/settings/AnalyticsIcon';
import LinkedInIcon from './icons/social/LinkedInIcon';
import TwitterIcon from './icons/social/TwitterIcon';
import InstagramIcon from './icons/social/InstagramIcon';
import GlobeAltIcon from './icons/settings/GlobeAltIcon';


interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface Bio {
    platform: 'LinkedIn' | 'Twitter' | 'Instagram' | 'Website';
    bio: string;
    char_count: number;
}
interface ParsedOutput {
    bios: Bio[];
}

const bioResponseSchema = {
    type: Type.OBJECT,
    properties: {
        bios: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    platform: { type: Type.STRING, enum: ['LinkedIn', 'Twitter', 'Instagram', 'Website'] },
                    bio: { type: Type.STRING, description: "The generated bio content for the specified platform." },
                    char_count: { type: Type.NUMBER, description: "The character count of the generated bio." }
                },
                required: ['platform', 'bio', 'char_count']
            }
        }
    },
    required: ['bios']
};

const PersonalBioGeneratorView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const { playClick, playSuccess } = useFeedback();

    // Form state
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [profession, setProfession] = useState('');
    const [experience, setExperience] = useState('3-5');
    const [industry, setIndustry] = useState('');
    const [skills, setSkills] = useState('');
    const [achievements, setAchievements] = useState('');
    const [selectedBioType, setSelectedBioType] = useState('professional');
    const [selectedPlatforms, setSelectedPlatforms] = useState(['linkedin']);

    // Output state
    const [generatedBios, setGeneratedBios] = useState<{[key: string]: {bio: string, charCount: number}}>({});
    const [activeTab, setActiveTab] = useState('linkedin');
    
    // API state
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [copySuccess, setCopySuccess] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && firstName.trim() && lastName.trim() && profession.trim();

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        playClick();
        setIsLoading(true);
        setError(null);
        setGeneratedBios({});
        setIsQueued(false);

        const prompt = `You are a personal branding expert and copywriter. Generate tailored bios for the specified platforms based on the user's details.

        **USER DETAILS:**
        - Name: ${firstName} ${lastName}
        - Profession/Title: ${profession}
        - Experience: ${experience} years
        - Industry: ${industry}
        - Key Skills: ${skills}
        - Achievements: ${achievements}
        - Desired Bio Type/Tone: ${selectedBioType}
        - Platforms to generate for: ${selectedPlatforms.join(', ')}

        **INSTRUCTIONS:**
        1. For each platform, create a compelling bio that adheres to its character limits (Twitter: 160, Instagram: 150) and best practices.
        2. Tailor the tone and content based on the "Bio Type".
        3. Your response MUST be a valid JSON object conforming to the provided schema. The "bios" array should contain an object for each requested platform.`;

        if (!navigator.onLine) {
            try {
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: 'application/json',
                responseSchema: bioResponseSchema,
            });
            const parsed: ParsedOutput = JSON.parse(result);
            const biosMap = parsed.bios.reduce((acc: any, item: Bio) => {
                acc[item.platform.toLowerCase()] = { bio: item.bio, charCount: item.char_count };
                return acc;
            }, {});

            setGeneratedBios(biosMap);
            playSuccess();
            
            if (userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt.split('**INSTRUCTIONS**')[0],
                    // FIX: Explicitly type 'b' to prevent potential 'unknown' type error.
                    output: Object.entries(biosMap).map(([p, b]: [string, { bio: string }]) => `${p.toUpperCase()}:\n${b.bio}`).join('\n\n'),
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();

        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, firstName, lastName, profession, experience, industry, skills, achievements, selectedBioType, selectedPlatforms, playClick, playSuccess, module.id, module.name, userId, usesLeft, decrementUse]);

    const handleCopyAll = () => {
        // FIX: Explicitly type 'bioData' to resolve 'unknown' type error. This is the reported error.
        const text = Object.entries(generatedBios).map(([platform, bioData]: [string, { bio: string }]) => `${platform.toUpperCase()}:\n${bioData.bio}`).join('\n\n');
        navigator.clipboard.writeText(text).then(() => {
            setCopySuccess(true);
            setTimeout(() => setCopySuccess(false), 2000);
        });
    };
    
    const bioTypes = [
        { id: 'professional', name: 'Professional', icon: <BriefcaseIcon className="h-6 w-6" />, desc: 'LinkedIn, corporate sites' },
        { id: 'creative', name: 'Creative', icon: <SparklesIcon className="h-6 w-6" />, desc: 'Portfolios, artistic profiles' },
        { id: 'casual', name: 'Casual', icon: <SmileIcon className="h-6 w-6" />, desc: 'Social media, personal blogs' },
        { id: 'executive', name: 'Executive', icon: <AnalyticsIcon className="h-6 w-6" />, desc: 'Leadership profiles, about pages' }
    ];

    const platforms = [
        { id: 'linkedin', name: 'LinkedIn', icon: <LinkedInIcon className="h-6 w-6" />, limit: 2600 },
        { id: 'twitter', name: 'Twitter', icon: <TwitterIcon className="h-6 w-6" />, limit: 160 },
        { id: 'instagram', name: 'Instagram', icon: <InstagramIcon className="h-6 w-6" />, limit: 150 },
        { id: 'website', name: 'Website', icon: <GlobeAltIcon className="h-6 w-6" />, limit: null }
    ];

    const getCharCounterClass = (count: number, limit: number | null) => {
        if (!limit) return '';
        if (count > limit) return 'danger';
        if (count > limit * 0.9) return 'warning';
        return 'optimal';
    };

    return (
        <div className="personal-bio-module max-w-7xl mx-auto flex flex-col gap-8">
            <header className="text-center">
                <h1 className="text-3xl font-bold font-heading">{module.name}</h1>
                <p className="subtitle text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <section className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-4">
                    <h2 className="text-2xl font-bold font-heading mb-4">Create Your Bio</h2>
                    
                    <div className="grid grid-cols-2 gap-4">
                        <input type="text" value={firstName} onChange={e => setFirstName(e.target.value)} placeholder="First Name" required className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                        <input type="text" value={lastName} onChange={e => setLastName(e.target.value)} placeholder="Last Name" required className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                    </div>

                    <input type="text" value={profession} onChange={e => setProfession(e.target.value)} placeholder="Profession/Title (e.g., Software Engineer)" required className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />

                    <div className="grid grid-cols-2 gap-4">
                        <select value={experience} onChange={e => setExperience(e.target.value)} className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100"><option value="0-2">0-2 years</option><option value="3-5">3-5 years</option><option value="6-10">6-10 years</option><option value="10+">10+ years</option></select>
                        <input type="text" value={industry} onChange={e => setIndustry(e.target.value)} placeholder="Industry (e.g., Technology)" className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                    </div>

                    <textarea value={skills} onChange={e => setSkills(e.target.value)} placeholder="Key Skills & Expertise (comma separated)..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[80px]"></textarea>
                    <textarea value={achievements} onChange={e => setAchievements(e.target.value)} placeholder="Notable Achievements (optional)..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[80px]"></textarea>
                    
                    <div>
                        <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">Bio Type</label>
                        <div className="grid grid-cols-2 gap-2">
                            {bioTypes.map(type => (
                                <button key={type.id} onClick={() => setSelectedBioType(type.id)} className={`option-card p-3 rounded-lg border-2 text-center transition-all duration-200 bg-base-100 dark:bg-d-base-100 ${selectedBioType === type.id ? 'selected' : 'border-transparent'}`}>
                                    <div className="option-icon text-2xl mx-auto">{type.icon}</div>
                                    <div className="text-sm font-semibold">{type.name}</div>
                                </button>
                            ))}
                        </div>
                    </div>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full btn-primary flex items-center justify-center p-4 rounded-xl text-white font-bold text-lg gap-2">
                        {isLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/50 border-t-white rounded-full"></span> : <SparklesIcon className="h-6 w-6" />}
                        {isLoading ? 'Generating...' : 'Generate Bio Variations'}
                    </button>
                    {error && <div className="text-center bg-error/20 text-error p-2 rounded-lg text-sm">{error}</div>}
                </section>
                <section className="bg-base-200 dark:bg-d-base-200 p-6 rounded-xl flex flex-col">
                    <h2 className="text-2xl font-bold font-heading mb-4">Bio Previews</h2>
                    <div className="flex border-b border-base-300 dark:border-d-base-300 mb-4">
                        {platforms.map(p => (
                            <button key={p.id} onClick={() => setActiveTab(p.id)} className={`result-tab px-4 py-2 font-semibold border-b-2 transition-colors ${activeTab === p.id ? 'active' : 'border-transparent text-text-secondary dark:text-d-text-secondary'}`}>
                                {p.name}
                            </button>
                        ))}
                    </div>
                    <div className="flex-1 bg-base-100 dark:bg-d-base-100 p-4 rounded-lg overflow-y-auto">
                        {platforms.map(p => (
                            <div key={p.id} className={activeTab === p.id ? 'block' : 'hidden'}>
                                <div className={`p-4 rounded-lg bg-base-200 dark:bg-d-base-200 min-h-[150px] whitespace-pre-wrap`}>
                                    {generatedBios[p.id]?.bio || `Your ${p.name} bio will appear here.`}
                                </div>
                                <div className={`char-counter text-sm font-medium mt-2 text-right ${getCharCounterClass(generatedBios[p.id]?.charCount || 0, p.limit)}`}>
                                    <span>{generatedBios[p.id]?.charCount || 0}</span>{p.limit && `/${p.limit}`} characters
                                </div>
                            </div>
                        ))}
                    </div>
                     <div className="flex gap-4 mt-4">
                        <button onClick={handleCopyAll} disabled={Object.keys(generatedBios).length === 0} className="flex-1 flex items-center justify-center gap-2 p-3 bg-brand-secondary text-white font-semibold rounded-lg disabled:bg-gray-400">
                            <CopyIcon className="h-5 w-5"/> Copy All
                        </button>
                    </div>
                </section>
            </div>
        </div>
    );
};

export default PersonalBioGeneratorView;
