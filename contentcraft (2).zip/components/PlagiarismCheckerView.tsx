import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ChevronDownIcon from './icons/ChevronDownIcon';
import Switch from './Switch';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type ContentType = 'Academic' | 'Business' | 'Creative' | 'Technical' | 'General';
type OriginalityStandard = 'Strict' | 'Moderate' | 'Lenient';
type CitationStyle = 'APA' | 'MLA' | 'Chicago' | 'Harvard' | 'IEEE' | 'None';
type EducationMode = 'Beginner' | 'Intermediate' | 'Expert';

const PLAGIARISM_CHECKER_PROMPT = `
You are an advanced plagiarism detection and academic integrity expert. Provide comprehensive originality analysis, similarity detection, and intelligent rewriting recommendations while educating users about proper citation and attribution practices.

**INPUT:**
- Text to Analyze: {USER_TEXT}
- Content Type: {CONTENT_TYPE}
- Originality Standard: {ORIGINALITY_STANDARD}
- Citation Style: {CITATION_STYLE}
- Rewriting Assistance: {REWRITING_HELP}
- Educational Mode: {EDUCATION_MODE}

**COMPREHENSIVE ORIGINALITY ANALYSIS:**

## 1. ORIGINALITY ASSESSMENT

**ORIGINALITY SCORE: [X]/100**
- **Text Originality**: [X]% - Unique content percentage
- **Phrasing Uniqueness**: [X]% - Original sentence structures
- **Idea Originality**: [X]% - Novel concepts and insights
- **Expression Authenticity**: [X]% - Personal voice and style

**SIMILARITY BREAKDOWN:**
- **Direct Copying**: [X]% - Verbatim or near-verbatim matches
- **Paraphrased Content**: [X]% - Rephrased but similar content
- **Common Knowledge**: [X]% - Widely accepted facts
- **Industry Terminology**: [X]% - Standard professional phrases

## 2. DETAILED SIMILARITY ANALYSIS

### A. TEXT MATCH IDENTIFICATION
**DIRECT MATCHES FOUND:**
1. **[Matched Phrase]** → [Similarity %]
   - **Source Type**: [Academic Paper/Online Article/Book/Website]
   - **Likely Source**: [Estimated origin]
   - **Match Confidence**: [High/Medium/Low]
   - **Recommended Action**: [Cite/Rewrite/Remove]

**PARAPHRASE DETECTION:**
1. **[Original Phrase]** → **[Similar Phrase]**
   - **Similarity Pattern**: [Sentence structure/Vocabulary/Concept]
   - **Originality Impact**: [High/Medium/Low concern]
   - **Academic Concern**: [Plagiarism Risk/Acceptable Paraphrase]

### B. CITATION ANALYSIS
**MISSING ATTRIBUTIONS:**
- [Number] uncited facts or ideas
- [Number] borrowed concepts without credit
- [Number] statistical data without sources

**PROPER CITATION GUIDANCE:**
- Required citations for: [List specific content]
- Suggested citation format: [Style-specific examples]
- Common knowledge exceptions: [What doesn't need citation]

## 3. INTELLIGENT REWRITING ASSISTANCE

### A. ORIGINALITY-ENHANCED REWRITES
**DIRECT REWRITE OPTIONS:**
1. **Conservative Rewrite** (Preserves meaning):
   - Original: [Problematic text]
   - Improved: [Original version with proper attribution]
   - Changes: [Specific modifications made]

2. **Substantial Rewrite** (Enhances originality):
   - Original: [Problematic text]
   - Improved: [More original version]
   - Originality Boost: [+X%]

3. **Conceptual REWRITE** (Fresh perspective):
   - Original: [Problematic text]
   - Improved: [Completely new approach]
   - Innovation Level: [High/Medium/Low]

### B. TONE-PRESERVING REWRITES
**MAINTAINING VOICE WHILE ENHANCING ORIGINALITY:**
- Original voice preservation: [X]%
- Original meaning retention: [X]%
- Originality improvement: [+X]%
- Readability impact: [Positive/Negative/Neutral]

## 4. EDUCATIONAL INSIGHTS

### A. PLAGIARISM PREVENTION GUIDANCE
**COMMON PITFALLS IDENTIFIED:**
1. **[Pitfall Type]**: [Specific issue found]
   - Why it's problematic: [Academic/business impact]
   - How to fix: [Step-by-step solution]
   - Prevention tips: [Future avoidance strategies]

**PROPER PARAPHRASING TECHNIQUES:**
- Synonym substitution vs. conceptual rewriting
- Sentence structure transformation
- Voice and perspective changes
- Integration of personal insights

### B. CITATION MASTERY
**CITATION BEST PRACTICES:**
- When to cite: [Specific scenarios]
- How to integrate sources smoothly
- Avoiding over-citation
- Balancing original thought with referenced content

## 5. CONTEXT-SPECIFIC ANALYSIS

**ACADEMIC SETTINGS:**
- University plagiarism standards
- Discipline-specific citation norms
- Research paper originality expectations
- Thesis/dissertation integrity requirements

**BUSINESS CONTEXTS:**
- Intellectual property considerations
- Competitive analysis boundaries
- Internal vs. external content standards
- Industry benchmarking appropriateness

**CREATIVE WRITING:**
- Inspiration vs. imitation boundaries
- Homage vs. plagiarism distinctions
- Genre convention adherence
- Style influence acknowledgment

## 6. ORIGINALITY ENHANCEMENT ROADMAP

**IMMEDIATE ACTIONS:**
1. **[High Priority]**: [Most critical fixes]
2. **[Medium Priority]**: [Important improvements]
3. **[Low Priority]**: [Optional enhancements]

**SKILL DEVELOPMENT:**
- Paraphrasing mastery exercises
- Citation integration practice
- Original thinking techniques
- Research synthesis methods

**LONG-TERM ORIGINALITY:**
- Developing unique voice
- Building original insights
- Creating innovative content
- Establishing authoritative perspective
`;


interface ParsedOutput {
    originalityScore: string;
    assessment: string;
    similarityAnalysis: string;
    rewritingAssistance: string;
    educationalInsights: string;
    contextAnalysis: string;
    roadmap: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};

const PlagiarismCheckerView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const [contentType, setContentType] = useState<ContentType>('General');
    const [originalityStandard, setOriginalityStandard] = useState<OriginalityStandard>('Moderate');
    const [citationStyle, setCitationStyle] = useState<CitationStyle>('None');
    const [rewritingHelp, setRewritingHelp] = useState(true);
    const [educationMode, setEducationMode] = useState<EducationMode>('Intermediate');

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();

    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = text.match(regex);
                return match ? match[1].trim() : 'Could not parse this section.';
            };
            const originalityScoreMatch = text.match(/\*\*ORIGINALITY SCORE:\s*(.*?)\*\*/i);
            
            return {
                originalityScore: originalityScoreMatch ? originalityScoreMatch[1] : 'N/A',
                assessment: getSection('## 1. ORIGINALITY ASSESSMENT', '## 2. DETAILED SIMILARITY ANALYSIS'),
                similarityAnalysis: getSection('## 2. DETAILED SIMILARITY ANALYSIS', '## 3. INTELLIGENT REWRITING ASSISTANCE'),
                rewritingAssistance: getSection('## 3. INTELLIGENT REWRITING ASSISTANCE', '## 4. EDUCATIONAL INSIGHTS'),
                educationalInsights: getSection('## 4. EDUCATIONAL INSIGHTS', '## 5. CONTEXT-SPECIFIC ANALYSIS'),
                contextAnalysis: getSection('## 5. CONTEXT-SPECIFIC ANALYSIS', '## 6. ORIGINALITY ENHANCEMENT ROADMAP'),
                roadmap: getSection('## 6. ORIGINALITY ENHANCEMENT ROADMAP', '$'),
            };
        } catch (e) {
            console.error("Failed to parse Plagiarism Checker output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return PLAGIARISM_CHECKER_PROMPT
            .replace('{USER_TEXT}', input)
            .replace('{CONTENT_TYPE}', contentType)
            .replace('{ORIGINALITY_STANDARD}', originalityStandard)
            .replace('{CITATION_STYLE}', citationStyle)
            .replace('{REWRITING_HELP}', rewritingHelp ? 'Yes' : 'No')
            .replace('{EDUCATION_MODE}', educationMode);
    }, [input, contentType, originalityStandard, citationStyle, rewritingHelp, educationMode]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing. Notification permissions may be required.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/###\s*(.*)/g, '<h4 class="text-md font-semibold text-text-primary dark:text-d-text-primary mt-3 mb-1">$1</h4>')
            .replace(/\n- (.*$)/gm, '\n<li class="ml-4 list-disc">$1</li>')
            .replace(/→/g, '<span class="mx-2 font-bold text-brand-primary">→</span>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };

    const commonTextareaClasses = "w-full min-h-[250px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter text for originality analysis..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Content Type</label>
                                <select value={contentType} onChange={e => setContentType(e.target.value as ContentType)} className={commonInputClasses}>
                                    <option>General</option><option>Academic</option><option>Business</option><option>Creative</option><option>Technical</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Originality Standard</label>
                                <select value={originalityStandard} onChange={e => setOriginalityStandard(e.target.value as OriginalityStandard)} className={commonInputClasses}>
                                    <option>Moderate</option><option>Strict</option><option>Lenient</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Citation Style</label>
                                <select value={citationStyle} onChange={e => setCitationStyle(e.target.value as CitationStyle)} className={commonInputClasses}>
                                    <option>None</option><option>APA</option><option>MLA</option><option>Chicago</option><option>Harvard</option><option>IEEE</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Educational Mode</label>
                                <select value={educationMode} onChange={e => setEducationMode(e.target.value as EducationMode)} className={commonInputClasses}>
                                    <option>Intermediate</option><option>Beginner</option><option>Expert</option>
                                </select>
                            </div>
                       </div>
                       <Switch label="Rewriting Assistance" checked={rewritingHelp} onChange={setRewritingHelp} />
                    </div>

                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Analyzing...' : (isQueued ? 'Request Queued' : 'Check Originality')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && input.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Analyzing originality...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your comprehensive originality report will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-4">
                            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg text-center border border-base-300 dark:border-d-base-300">
                                <h3 className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">Originality Score</h3>
                                <p className="text-5xl font-bold text-brand-primary my-2">{parsedOutput.originalityScore}</p>
                            </div>
                            
                            <div className="space-y-2">
                                 <Accordion title={<>📊 <span className="ml-2">Originality Assessment</span></>} defaultOpen={true}><div dangerouslySetInnerHTML={formatContent(parsedOutput.assessment)}/></Accordion>
                                 <Accordion title={<>🔎 <span className="ml-2">Detailed Similarity Analysis</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.similarityAnalysis)}/></Accordion>
                                 <Accordion title={<>✍️ <span className="ml-2">Intelligent Rewriting Assistance</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.rewritingAssistance)}/></Accordion>
                                 <Accordion title={<>💡 <span className="ml-2">Educational Insights</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.educationalInsights)}/></Accordion>
                                 <Accordion title={<>🌐 <span className="ml-2">Context-Specific Analysis</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.contextAnalysis)}/></Accordion>
                                 <Accordion title={<>🚀 <span className="ml-2">Originality Enhancement Roadmap</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.roadmap)}/></Accordion>
                            </div>
                        </div>
                    ) : (
                        !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
    );
};

export default PlagiarismCheckerView;