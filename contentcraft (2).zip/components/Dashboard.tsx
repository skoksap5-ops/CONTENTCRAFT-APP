import React from 'react';
import type { Module } from '../types';
import { MODULES, MODULE_GROUPS_MAP } from '../constants';
import ModuleCard from './ModuleCard';
import { useLanguage } from '../hooks/useLanguage';

interface DashboardProps {
  onModuleSelect: (module: Module) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onModuleSelect }) => {
  const { t } = useLanguage();
  
  const groupedModules = Object.values(MODULE_GROUPS_MAP).map(group => ({
    groupName: t(group.nameKey),
    groupId: group.id,
    modules: MODULES.filter(m => m.group === group.nameKey),
  }));

  return (
    <div className="space-y-12">
      {groupedModules.map(({ groupName, groupId, modules }) => (
        <section key={groupId} id={groupId}>
          <h2 className="text-2xl font-bold text-text-primary dark:text-d-text-primary mb-6 border-l-4 border-brand-primary pl-4 font-heading">{groupName}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {modules.map(module => (
              <ModuleCard key={module.id} module={module} onSelect={() => onModuleSelect(module)} />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
};

export default Dashboard;