import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { useCalendarAI } from '../hooks/useCalendarAI';
import CampaignSetup from './social-campaign-planner/CampaignSetup';
import PlatformStrategy from './social-campaign-planner/PlatformStrategy';
import CalendarView from './social-campaign-planner/CalendarView';
import type { CampaignDay, CampaignConfig, StrategyData } from './social-campaign-planner/types';

interface SocialCampaignPlannerViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type View = 'setup' | 'strategy' | 'calendar' | 'preview' | 'export';

const SocialCampaignPlannerView: React.FC<SocialCampaignPlannerViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
  const [currentView, setCurrentView] = useState<View>('setup');
  const [calendarConfig, setCalendarConfig] = useState<CampaignConfig | null>(null);
  const [generatedCalendar, setGeneratedCalendar] = useState<CampaignDay[] | null>(null);
  
  const { generateCalendar, isLoading, error } = useCalendarAI(userId, module.id, module.name, usesLeft, decrementUse);

  const views: { [key in View]: { name: string; icon: string } } = {
    setup: { name: 'Campaign Setup', icon: '🎯' },
    strategy: { name: 'Platform Strategy', icon: '📱' },
    calendar: { name: 'Calendar View', icon: '📅' },
    preview: { name: 'Content Preview', icon: '👀' },
    export: { name: 'Export', icon: '📤' }
  };

  const handleCampaignSetup = (campaignData: CampaignConfig) => {
    setCalendarConfig(campaignData);
    setCurrentView('strategy');
  };

  const handleStrategySetup = async (strategyData: StrategyData) => {
    if (!calendarConfig) return;
    const fullConfig = { ...calendarConfig, ...strategyData };
    setCalendarConfig(fullConfig);
    const calendar = await generateCalendar(fullConfig);
    if (calendar) {
      setGeneratedCalendar(calendar);
      setCurrentView('calendar');
    } else {
        // Error is handled by the hook, but we can stay on the current step
        setCurrentView('strategy');
    }
  };
  
  const renderContent = () => {
    switch (currentView) {
      case 'setup':
        return <CampaignSetup onSubmit={handleCampaignSetup} isLoading={isLoading} />;
      case 'strategy':
        return calendarConfig && <PlatformStrategy config={calendarConfig} onGenerate={handleStrategySetup} isLoading={isLoading} />;
      case 'calendar':
        return generatedCalendar && calendarConfig && <CalendarView calendar={generatedCalendar} config={calendarConfig} />;
      case 'preview':
      case 'export':
        return (
            <div className="text-center p-8">
              <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">Coming Soon!</h2>
              <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">This feature is under construction.</p>
              <button onClick={() => setCurrentView('calendar')} className="mt-4 px-4 py-2 bg-brand-primary text-white rounded-lg">Back to Calendar</button>
            </div>
        );
      default:
        return null;
    }
  }

  return (
    <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
        <div className="text-center">
            <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
            <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
        </div>
        {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        
        <div className="bg-base-200/50 dark:bg-d-base-200/50 p-6 rounded-xl border border-base-300 dark:border-d-base-300 min-h-[300px]">
            {renderContent()}
        </div>
    </div>
  );
};

export default SocialCampaignPlannerView;
