import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { Module } from '../types';
import { earningMethods, EarningMethod } from '../constants/earningMethods';
import { useLanguage } from '../hooks/useLanguage';
import SearchIcon from './icons/SearchIcon';
import { MODULES } from '../constants';
import CloseIcon from './icons/CloseIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import { LANGUAGES } from '../constants/languages';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

const getModuleNames = (moduleIds: string[]) => {
    return moduleIds.map(id => MODULES.find(m => m.id === id)?.name).filter(Boolean).join(', ');
};

const incomeColors: { [key: string]: string } = {
    beginner: 'bg-green-500/10 text-green-600 dark:text-green-400 border border-green-500/20',
    intermediate: 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border border-yellow-500/20',
    advanced: 'bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20',
};

const timeInfo: { [key: string]: string } = {
    quick: 'Quick (< 2h)',
    medium: 'Medium (2-8h)',
    long: 'Long (1d+)',
};

const categoryColors: { [key: string]: string } = {
    freelance: 'bg-sky-500/10 text-sky-600 dark:text-sky-400 border border-sky-500/20',
    agency: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20',
    ecommerce: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20',
    premium: 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20',
    creator: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20',
};

const HowToContent: React.FC<{ text: string }> = ({ text }) => {
    // If translation is missing, t() returns the key.
    if (text.startsWith('earning_method_')) {
        return <p className="text-text-secondary dark:text-d-text-secondary">Details for this method will be available soon.</p>;
    }
    const htmlContent = text
        .split('\n')
        .map(line => line.trim())
        .filter(line => line)
        .map(line => {
            const boldedLine = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            if (/^\d+\.\s/.test(boldedLine)) {
                return `<li>${boldedLine.replace(/^\d+\.\s*/, '')}</li>`;
            }
            return `<p>${boldedLine}</p>`;
        })
        .join('');

    const finalHtml = htmlContent.includes('<li>')
        ? `<ol class="list-decimal list-inside space-y-2">${htmlContent.replace(/<p>|<\/p>/g, '')}</ol>`
        : htmlContent;

    return <div dangerouslySetInnerHTML={{ __html: finalHtml }} />;
};

const GlobeAltIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21V3m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m0 18c1.657 0 3-4.03 3-9s-1.343-9-3-9M3.28 9a11.96 11.96 0 0117.44 0" />
  </svg>
);

const CheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={3} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
    </svg>
);

const EarnWithContentCraftView: React.FC<ModuleViewProps> = ({ module }) => {
    const { t, language, setLanguage } = useLanguage();
    const [searchTerm, setSearchTerm] = useState('');
    const [filters, setFilters] = useState<{ [key: string]: string }>({
        category: 'all',
        incomeLevel: 'all',
        time: 'all'
    });
    const [completedMethods, setCompletedMethods] = useState<Set<number>>(() => {
        try {
            const saved = localStorage.getItem('completedEarningMethods');
            return saved ? new Set(JSON.parse(saved)) : new Set();
        } catch {
            return new Set();
        }
    });
    
    const [selectedMethod, setSelectedMethod] = useState<EarningMethod | null>(null);
    const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
                setIsLangDropdownOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [dropdownRef]);

    const filterOptions: { [key: string]: string[] } = {
        category: ['all', 'freelance', 'agency', 'ecommerce', 'premium', 'creator'],
        incomeLevel: ['all', 'beginner', 'intermediate', 'advanced'],
        time: ['all', 'quick', 'medium', 'long']
    };

    const handleFilterChange = (filterType: string, value: string) => {
        setFilters(prev => ({ ...prev, [filterType]: value }));
    };

    const toggleCompleted = (e: React.MouseEvent, day: number) => {
        e.stopPropagation();
        setCompletedMethods(prev => {
            const newSet = new Set(prev);
            if (newSet.has(day)) {
                newSet.delete(day);
            } else {
                newSet.add(day);
            }
            localStorage.setItem('completedEarningMethods', JSON.stringify(Array.from(newSet)));
            return newSet;
        });
    };

    const filteredMethods = useMemo(() => {
        return earningMethods.filter(method => {
            const searchMatch = searchTerm === '' ||
                t(method.titleKey).toLowerCase().includes(searchTerm.toLowerCase()) ||
                t(method.descriptionKey).toLowerCase().includes(searchTerm.toLowerCase());

            const categoryMatch = filters.category === 'all' || method.category === filters.category;
            const incomeMatch = filters.incomeLevel === 'all' || method.incomeLevel === filters.incomeLevel;
            const timeMatch = filters.time === 'all' || method.time === filters.time;

            return searchMatch && categoryMatch && incomeMatch && timeMatch;
        });
    }, [searchTerm, filters, t]);
    
    const progress = Math.round((completedMethods.size / earningMethods.length) * 100);

    const EarningMethodCard: React.FC<{ method: EarningMethod }> = ({ method }) => {
        const isCompleted = completedMethods.has(method.day);
        return (
            <button 
                onClick={() => setSelectedMethod(method)}
                className={`earn-card bg-base-200 dark:bg-d-base-200 rounded-2xl p-6 text-left flex flex-col h-full transition-opacity ${isCompleted ? 'opacity-60' : ''}`}
            >
                <div className="flex justify-between items-start">
                    <span className="earn-card-day font-bold text-2xl text-text-secondary dark:text-d-text-secondary">Day {method.day}</span>
                    <button 
                        onClick={(e) => toggleCompleted(e, method.day)}
                        className={`earn-card-complete-btn w-8 h-8 rounded-full flex items-center justify-center transition-colors ${isCompleted ? 'bg-green-500 text-white' : 'bg-base-300 dark:bg-d-base-300 text-text-secondary dark:text-d-text-secondary'}`}
                        aria-label={isCompleted ? 'Mark as incomplete' : 'Mark as complete'}
                    >
                        <CheckCircleIcon className="w-5 h-5" />
                    </button>
                </div>
                <h3 className="earn-card-title text-lg font-bold mt-3 text-text-primary dark:text-d-text-primary flex-grow">{t(method.titleKey)}</h3>
                <div className="mt-4 pt-4 border-t border-base-300 dark:border-d-base-300">
                    <div className="flex flex-wrap gap-2">
                        <span className={`earn-tag ${categoryColors[method.category]}`}>{t(`category_${method.category}`)}</span>
                        <span className={`earn-tag ${incomeColors[method.incomeLevel]}`}>{t(`income_${method.incomeLevel}`)}</span>
                        <span className="earn-tag bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">{timeInfo[method.time]}</span>
                    </div>
                </div>
            </button>
        );
    };

    return (
        <div className="earn-module max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="earn-header relative">
                <div className="absolute top-4 right-4 z-10">
                    <div className="relative">
                        <button onClick={() => setIsLangDropdownOpen(prev => !prev)} className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/5 dark:bg-white/10 text-text-secondary dark:text-d-text-secondary hover:bg-black/10 dark:hover:bg-white/20 transition">
                            <GlobeAltIcon className="w-5 h-5"/>
                            <span className="text-sm font-medium">{language.code.toUpperCase()}</span>
                        </button>
                        {isLangDropdownOpen && (
                            <div ref={dropdownRef} className="absolute top-full right-0 mt-2 w-56 bg-base-100 dark:bg-d-base-300 rounded-lg shadow-2xl z-20 p-2 max-h-60 overflow-y-auto">
                                {LANGUAGES.map(lang => (
                                    <button 
                                        key={lang.code} 
                                        onClick={() => { setLanguage(lang.code); setIsLangDropdownOpen(false); }} 
                                        className="w-full flex items-center gap-3 p-2 rounded-md text-left hover:bg-base-200 dark:hover:bg-d-base-200"
                                    >
                                        <span className="text-lg">{lang.flag}</span>
                                        <span className="flex-grow text-sm font-medium text-text-primary dark:text-d-text-primary">{lang.name}</span>
                                        {language.code === lang.code && <CheckIcon className="w-5 h-5 text-brand-primary" />}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                <h2 className="earn-title text-4xl font-bold font-heading">{t(module.name)}</h2>
                <p className="earn-subtitle text-lg mt-2 max-w-2xl mx-auto">{t(module.description)}</p>
                <div className="earn-progress-container">
                    <div className="flex justify-between items-center mb-1">
                        <span className="earn-progress-label text-sm font-medium">{completedMethods.size} / {earningMethods.length} Complete</span>
                        <span className="earn-progress-label text-sm font-bold">{progress}%</span>
                    </div>
                    <div className="earn-progress-bar-bg w-full h-3 rounded-full overflow-hidden">
                        <div className="earn-progress-bar-fill h-full rounded-full" style={{ width: `${progress}%` }}></div>
                    </div>
                </div>
            </div>

            <div className="earn-filters flex flex-col md:flex-row items-center gap-4">
                <div className="relative flex-grow w-full md:w-auto">
                    <SearchIcon className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-text-secondary dark:text-d-text-secondary" />
                    <input 
                        type="text"
                        placeholder="Search methods..."
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 rounded-lg bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 focus:ring-2 focus:ring-brand-primary focus:outline-none"
                    />
                </div>
                {Object.entries(filterOptions).map(([type, options]) => (
                    <select key={type} onChange={e => handleFilterChange(type, e.target.value)} className="w-full md:w-auto capitalize p-2 rounded-lg bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 text-text-primary dark:text-d-text-primary">
                        {options.map(option => <option key={option} value={option}>{option === 'all' ? `All ${type.replace(/([A-Z])/g, ' $1')}` : option}</option>)}
                    </select>
                ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredMethods.map(method => <EarningMethodCard key={method.day} method={method} />)}
            </div>
            {filteredMethods.length === 0 && <p className="col-span-full text-center py-16 text-text-secondary dark:text-d-text-secondary">No earning methods match your criteria.</p>}

            {selectedMethod && (() => {
                const learnMoreUrl = selectedMethod.learnMoreUrl || `https://www.google.com/search?q=${encodeURIComponent(t(selectedMethod.titleKey) + ' guide')}`;
                return (
                    <div className="earn-modal-overlay fixed inset-0 bg-base-100/80 dark:bg-d-base-100/80 backdrop-blur-sm z-50 p-4 overflow-y-auto" onClick={() => setSelectedMethod(null)}>
                        <div 
                            className="earn-modal-content bg-base-100 dark:bg-d-base-200 animate-fade-in-up w-full max-w-2xl mx-auto my-8 p-8 relative rounded-2xl shadow-2xl"
                            onClick={e => e.stopPropagation()}
                        >
                            <button onClick={() => setSelectedMethod(null)} className="absolute top-4 right-4 p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-300 hover:text-text-primary dark:hover:text-d-text-primary transition-colors z-10">
                                <CloseIcon className="w-6 h-6" />
                            </button>
                            
                            <h3 className="text-2xl font-bold font-heading mb-2 text-text-primary dark:text-d-text-primary pr-8">{t(selectedMethod.titleKey)}</h3>
                            <p className="text-text-secondary dark:text-d-text-secondary mb-4">{t(selectedMethod.descriptionKey)}</p>

                            <div className="flex flex-wrap gap-2 mb-6">
                                <span className={`earn-tag ${categoryColors[selectedMethod.category]}`}>{t(`category_${selectedMethod.category}`)}</span>
                                <span className={`earn-tag ${incomeColors[selectedMethod.incomeLevel]}`}>{t(`income_${selectedMethod.incomeLevel}`)}</span>
                                <span className="earn-tag bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">{timeInfo[selectedMethod.time]}</span>
                            </div>
                            
                            <div className="prose prose-sm dark:prose-invert max-w-none text-text-primary dark:text-d-text-primary">
                                <h4 className="font-bold text-lg mb-2">How to do it:</h4>
                                <HowToContent text={t(selectedMethod.howToKey)} />

                                <h4 className="font-bold text-lg mt-6 mb-2">Relevant Modules:</h4>
                                <p>{getModuleNames(selectedMethod.modules)}</p>
                            </div>

                            <a
                                href={learnMoreUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="mt-8 block w-full text-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary transition-all duration-300"
                            >
                                Learn More 📖
                            </a>
                        </div>
                    </div>
                );
            })()}
        </div>
    );
};

export default EarnWithContentCraftView;