import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface Scene {
    scene_number: number;
    visual_description: string;
    voiceover_script: string;
}

interface ParsedOutput {
    title: string;
    hook: string;
    description: string;
    tags: string[];
    scenes: Scene[];
}

const scriptSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "A catchy, SEO-optimized title for the video." },
        hook: { type: Type.STRING, description: "A powerful opening line (first 3-5 seconds) to grab viewer attention." },
        description: { type: Type.STRING, description: "A full, optimized description for the video platform, including a summary and call-to-action." },
        tags: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of 5-10 relevant tags or keywords." },
        scenes: {
            type: Type.ARRAY,
            description: "An array of scenes that make up the video script.",
            items: {
                type: Type.OBJECT,
                properties: {
                    scene_number: { type: Type.NUMBER },
                    visual_description: { type: Type.STRING, description: "A detailed description of the visuals for this scene." },
                    voiceover_script: { type: Type.STRING, description: "The voiceover or spoken dialogue for this scene." }
                },
                required: ['scene_number', 'visual_description', 'voiceover_script']
            }
        }
    },
    required: ['title', 'hook', 'description', 'tags', 'scenes']
};


const VideoScriptWriterView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [videoTopic, setVideoTopic] = useState('');
    const [platform, setPlatform] = useState('YouTube');
    const [videoLength, setVideoLength] = useState('Short (1-3 min)');
    const [audience, setAudience] = useState('General');
    const [tones, setTones] = useState<string[]>([]);
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && videoTopic.trim();

    const getPrompt = useCallback(() => {
        return `You are an expert video scriptwriter and content strategist. Create a complete, engaging video script package based on the user's requirements.

        **INPUT:**
        - Video Topic: ${videoTopic}
        - Platform: ${platform}
        - Desired Length: ${videoLength}
        - Target Audience: ${audience}
        - Desired Tone: ${tones.length > 0 ? tones.join(', ') : 'Informative & Engaging'}
        
        **INSTRUCTIONS:**
        1.  Generate a compelling, SEO-optimized title.
        2.  Write a powerful hook for the first 3-5 seconds.
        3.  Create a full, optimized description for the platform.
        4.  Provide 5-10 relevant tags/keywords.
        5.  Structure the script into logical scenes, each with a scene number, a detailed visual description, and the corresponding voiceover script.
        6.  Your response MUST be a valid JSON object conforming to the provided schema.
        `;
    }, [videoTopic, platform, videoLength, audience, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: scriptSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: `Title: ${parsed.title}\n\n${parsed.scenes.map((s: Scene) => `Scene ${s.scene_number}:\n${s.voiceover_script}`).join('\n\n')}`,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse script: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);

    const copyFullScript = () => {
        if (!parsedOutput) return;
        const scriptText = `Title: ${parsedOutput.title}\n\nDescription: ${parsedOutput.description}\n\nTags: ${parsedOutput.tags.join(', ')}\n\n---\n\nSCRIPT\n\n${parsedOutput.scenes.map(s => `SCENE ${s.scene_number}\nVISUAL: ${s.visual_description}\nVOICEOVER: ${s.voiceover_script}`).join('\n\n')}`;
        navigator.clipboard.writeText(scriptText);
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-3 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={videoTopic} onChange={e => setVideoTopic(e.target.value)} placeholder="Describe your video topic or core idea..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Script Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Platform</label>
                                <select value={platform} onChange={e => setPlatform(e.target.value)} className={commonInputClasses}>
                                    <option>YouTube</option><option>TikTok</option><option>Instagram Reels</option><option>Corporate</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Video Length</label>
                                <select value={videoLength} onChange={e => setVideoLength(e.target.value)} className={commonInputClasses}>
                                    <option>Short (1-3 min)</option><option>Medium (5-10 min)</option><option>Long (10+ min)</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Audience</label>
                                <select value={audience} onChange={e => setAudience(e.target.value)} className={commonInputClasses}>
                                    <option>General</option><option>Beginners</option><option>Experts</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : 'Generate Script'}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please enter a video topic.</p>}
                </div>

                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Writing your script...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your complete video script package will appear here.</p>}
                    {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
                    {parsedOutput && (
                        <div className="space-y-6">
                            <div className="relative group">
                                <h3 className="text-2xl font-bold font-heading">{parsedOutput.title}</h3>
                                <p className="text-sm text-brand-secondary font-semibold mt-1">Hook: "{parsedOutput.hook}"</p>
                                <button onClick={copyFullScript} className="absolute top-0 right-0 p-2 rounded-lg bg-base-300/50 dark:bg-d-base-300/50 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Copy Full Script">
                                    <CopyIcon className="h-5 w-5" />
                                </button>
                            </div>

                            <div className="space-y-3">
                                {parsedOutput.scenes.map(scene => (
                                    <div key={scene.scene_number} className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg">
                                        <h4 className="font-bold text-text-primary dark:text-d-text-primary">Scene {scene.scene_number}</h4>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2 text-sm">
                                            <div>
                                                <p className="font-semibold text-xs uppercase tracking-wider text-text-secondary dark:text-d-text-secondary mb-1">🎬 Visual</p>
                                                <p>{scene.visual_description}</p>
                                            </div>
                                            <div>
                                                <p className="font-semibold text-xs uppercase tracking-wider text-text-secondary dark:text-d-text-secondary mb-1">🎙️ Voiceover</p>
                                                <p>{scene.voiceover_script}</p>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="space-y-2">
                                <h4 className="font-bold text-lg">Optimized Description</h4>
                                <p className="text-sm bg-base-100 dark:bg-d-base-100 p-3 rounded-lg whitespace-pre-wrap">{parsedOutput.description}</p>
                            </div>

                            <div className="space-y-2">
                                <h4 className="font-bold text-lg">Tags & Keywords</h4>
                                <div className="flex flex-wrap gap-2">
                                    {parsedOutput.tags.map(tag => (
                                        <span key={tag} className="bg-base-300 dark:bg-d-base-300 px-2 py-1 text-xs font-semibold text-brand-primary rounded">{tag}</span>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default VideoScriptWriterView;