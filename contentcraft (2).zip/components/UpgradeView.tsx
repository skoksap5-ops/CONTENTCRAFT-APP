import React, { useState, useEffect } from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import CrownIcon from './icons/CrownIcon';
import LightningIcon from './icons/LightningIcon';
import ShieldIcon from './icons/ShieldIcon';
import BarChartIcon from './icons/BarChartIcon';
import GridIcon from './icons/GridIcon';
import StarIcon from './icons/StarIcon';
import CheckIcon from './icons/CheckIcon';

interface UpgradeViewProps {
  onClose: () => void;
}

const UpgradeView: React.FC<UpgradeViewProps> = ({ onClose }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('annual');
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const proFeatures = ['Unlimited Generations', 'All 60+ Modules', 'Priority Support', 'Ad-Free Experience'];

  const testimonials = [
      {
          quote: "As a freelance writer, ContentCraft is my secret weapon. The AI Prompt Generator helps me craft the perfect prompts for any task, and the SEO Optimizer has boosted my clients' rankings. My productivity has literally doubled!",
          name: 'Jelena Petrović',
          role: 'SEO Content Strategist, Serbia'
      },
      {
          quote: "Managing social media for multiple clients was chaotic. The Social Campaign Planner and platform-specific stylers let me create a month of high-quality content in an afternoon. A must-have tool for any agency.",
          name: 'Michael Anderson',
          role: 'Social Media Manager, USA'
      },
      {
          quote: "I used the AI Ebook Creator to turn my blog posts into a full ebook in just a few hours. The process was incredibly simple, and I now have a new digital product to sell. This app pays for itself.",
          name: 'Priya Sharma',
          role: 'Blogger & Entrepreneur, India'
      },
      {
          quote: "The ability to quickly create professional, platform-optimized content is priceless. The Brand Voice Generator ensures consistency across all channels. Absolutely recommended!",
          name: 'Lukas Weber',
          role: 'Marketing Director, Germany'
      },
      {
          quote: "We used the AI Competitor Analyzer to understand our market position. The insights and content gap analysis helped us adjust our strategy, and we saw significant traffic growth within three months. It's a powerful strategic tool.",
          name: 'Chen Wei',
          role: 'Digital Strategist, China'
      }
  ];
  
  useEffect(() => {
    const interval = setInterval(() => {
        setActiveTestimonial(prev => (prev + 1) % testimonials.length);
    }, 7000); // Rotirajte na svakih 7 sekundi
    return () => clearInterval(interval);
  }, [testimonials.length]);


  return (
    <div className="fixed inset-0 bg-base-200 dark:bg-d-base-100 z-50 animate-fade-in-up overflow-y-auto" role="dialog" aria-modal="true">
        <header className="sticky top-0 bg-base-200/80 dark:bg-d-base-100/80 backdrop-blur-sm z-10 border-b border-base-300 dark:border-d-base-300">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-16 gap-4">
            <button
                onClick={onClose}
                className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-300 dark:hover:bg-d-base-300"
                aria-label="Back to profile"
            >
                <ArrowLeftIcon className="h-6 w-6" />
            </button>
            <h1 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Upgrade to Craft Pro</h1>
            </div>
        </header>
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-12">
                <div className="h-24 flex items-center justify-center mb-4">
                    <div className="perspective-1000">
                        <div className="relative w-20 h-20 animate-rotate-3d upgrade-cube" style={{ transformStyle: 'preserve-3d' }}>
                            <div className="upgrade-cube-face w-20 h-20" style={{ transform: 'rotateY(0deg) translateZ(40px)'}}><span className="upgrade-cube-face-text text-xs">CONTENT<br/>CRAFT</span></div>
                            <div className="upgrade-cube-face w-20 h-20" style={{ transform: 'rotateY(90deg) translateZ(40px)'}}></div>
                            <div className="upgrade-cube-face w-20 h-20" style={{ transform: 'rotateY(180deg) translateZ(40px)'}}><span className="upgrade-cube-face-text text-xs">CONTENT<br/>CRAFT</span></div>
                            <div className="upgrade-cube-face w-20 h-20" style={{ transform: 'rotateY(-90deg) translateZ(40px)'}}></div>
                            <div className="upgrade-cube-face w-20 h-20" style={{ transform: 'rotateX(90deg) translateZ(40px)'}}></div>
                            <div className="upgrade-cube-face w-20 h-20" style={{ transform: 'rotateX(-90deg) translateZ(40px)'}}></div>
                        </div>
                    </div>
                </div>
                <h2 className="text-4xl font-bold font-heading text-text-primary dark:text-d-text-primary">Unlock Your Full Potential</h2>
                <p className="mt-2 text-text-secondary dark:text-d-text-secondary max-w-2xl mx-auto">
                    Go beyond the limits. With Craft Pro, you get unlimited access to all our powerful AI tools, priority processing, and an ad-free experience.
                </p>
            </div>

            <div className="text-center mb-10">
                <div className="bg-base-100 dark:bg-d-base-200 p-1.5 rounded-full inline-flex items-center space-x-2">
                    <button onClick={() => setBillingCycle('monthly')} className={`px-4 py-1.5 text-sm font-semibold rounded-full ${billingCycle === 'monthly' ? 'bg-white dark:bg-d-base-300 shadow' : 'text-text-secondary dark:text-d-text-secondary'}`}>Monthly</button>
                    <button onClick={() => setBillingCycle('annual')} className={`relative px-4 py-1.5 text-sm font-semibold rounded-full ${billingCycle === 'annual' ? 'bg-white dark:bg-d-base-300 shadow' : 'text-text-secondary dark:text-d-text-secondary'}`}>Annual <span className="absolute -top-2 -right-3 text-xs bg-brand-secondary text-white px-2 py-0.5 rounded-full">Save 17%</span></button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
                {/* Subscription Card */}
                <div className="plan-card flex flex-col">
                    <h3 className="text-2xl font-bold font-heading">Craft Pro</h3>
                    <p className="text-text-secondary dark:text-d-text-secondary">Perfect for consistent creators.</p>
                    <div className="my-8">
                        <span className="text-5xl font-extrabold text-text-primary dark:text-d-text-primary">
                            {billingCycle === 'annual' ? '$99.99' : '$9.99'}
                        </span>
                        <span className="text-text-secondary dark:text-d-text-secondary ml-2">
                            / {billingCycle === 'annual' ? 'year' : 'month'}
                        </span>
                         {billingCycle === 'annual' && <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1">Billed annually. Was $119.88.</p>}
                    </div>
                    <ul className="space-y-3 mb-8">
                        {proFeatures.map(feature => (
                            <li key={feature} className="flex items-center">
                                <CheckIcon className="h-5 w-5 text-green-500 mr-3"/>
                                <span className="text-text-primary dark:text-d-text-primary">{feature}</span>
                            </li>
                        ))}
                    </ul>
                    <button className="w-full mt-auto p-4 rounded-xl text-white font-bold text-lg bg-brand-primary hover:opacity-90 transition-opacity">
                        Upgrade Now
                    </button>
                </div>

                {/* Lifetime Card */}
                <div className="plan-card highlight relative flex flex-col">
                    <div className="plan-badge">Best Value</div>
                    <h3 className="text-2xl font-bold font-heading text-slate-900 dark:text-white">Craft Pro Lifetime</h3>
                    <p className="text-slate-600 dark:text-d-text-secondary">Pay once, create forever.</p>
                     <div className="my-8">
                        <span className="text-5xl font-extrabold text-slate-900 dark:text-white">
                            $299.99
                        </span>
                        <span className="text-slate-600 dark:text-d-text-secondary ml-2">
                           / one-time
                        </span>
                    </div>
                    <ul className="space-y-3 mb-8">
                        {[...proFeatures, 'Early Access to New Features', 'Lifetime Updates'].map(feature => (
                             <li key={feature} className="flex items-center">
                                <CheckIcon className="h-5 w-5 text-green-500 mr-3"/>
                                <span className="text-slate-600 dark:text-d-text-primary">{feature}</span>
                            </li>
                        ))}
                    </ul>
                     <button className="w-full mt-auto p-4 rounded-xl text-white font-bold text-lg bg-brand-primary hover:opacity-90 transition-opacity">
                        Get Lifetime Access
                    </button>
                </div>
            </div>

            <div className="mt-20">
                 <h3 className="text-3xl font-bold font-heading text-center mb-12">Loved by Professionals Worldwide</h3>
                 <div className="relative max-w-2xl mx-auto">
                    <div key={activeTestimonial} className="bg-base-100 dark:bg-d-base-200 p-8 rounded-xl shadow-sm text-center animate-fade-in min-h-[280px] md:min-h-[240px] flex flex-col justify-center">
                        <div className="flex justify-center mb-4">
                            {[...Array(5)].map((_, i) => <StarIcon key={i} className="h-5 w-5 text-yellow-400" />)}
                        </div>
                        <blockquote className="flex-grow text-text-primary dark:text-d-text-primary italic text-lg">"{testimonials[activeTestimonial].quote}"</blockquote>
                        <footer className="mt-6 text-sm font-semibold">
                            <p className="text-text-primary dark:text-d-text-primary">{testimonials[activeTestimonial].name}</p>
                            <p className="text-text-secondary dark:text-d-text-secondary">{testimonials[activeTestimonial].role}</p>
                        </footer>
                    </div>

                     <div className="flex justify-center gap-3 mt-6">
                        {testimonials.map((_, index) => (
                            <button
                                key={index}
                                onClick={() => setActiveTestimonial(index)}
                                className={`w-3 h-3 rounded-full transition-all duration-300 ${activeTestimonial === index ? 'bg-brand-primary scale-125' : 'bg-base-300 dark:bg-d-base-300 hover:bg-base-400'}`}
                                aria-label={`Go to testimonial ${index + 1}`}
                            />
                        ))}
                    </div>
                </div>
            </div>

        </main>
    </div>
  );
};

export default UpgradeView;