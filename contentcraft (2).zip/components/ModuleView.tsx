import React, { useState, useCallback, useEffect, lazy } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import { useFeedback } from '../hooks/useFeedback';

// Import all specialized views dynamically with React.lazy
const SeoOptimizerView = lazy(() => import('./SeoOptimizerView'));
const AsoOptimizerView = lazy(() => import('./AsoOptimizerView'));
const SummarySynthesizerView = lazy(() => import('./SummarySynthesizerView'));
const GlobalTranslatorView = lazy(() => import('./GlobalTranslatorView'));
const TextCraftView = lazy(() => import('./TextCraftView'));
const GrammarProoferView = lazy(() => import('./GrammarProoferView'));
const StyleProoferView = lazy(() => import('./StyleProoferView'));
const PlagiarismCheckerView = lazy(() => import('./PlagiarismCheckerView'));
const CleanPasteView = lazy(() => import('./CleanPasteView'));
const StartupPitchView = lazy(() => import('./StartupPitchView'));
const EmailCraftView = lazy(() => import('./EmailCraftView'));
const ContentGeneratorView = lazy(() => import('./ContentGeneratorView'));
const ProductReviewView = lazy(() => import('./ProductReviewView'));
const NewsletterBuilderView = lazy(() => import('./NewsletterBuilderView'));
const LandingPageCopyView = lazy(() => import('./LandingPageCopyView'));
const FacebookAdView = lazy(() => import('./FacebookAdView'));
const FacebookStylerView = lazy(() => import('./FacebookStylerView'));
const GoogleAdView = lazy(() => import('./GoogleAdView'));
const EcommerceDescriptionView = lazy(() => import('./EcommerceDescriptionView'));
const HeadlineGeneratorView = lazy(() => import('./HeadlineGeneratorView'));
const ProposalGeneratorView = lazy(() => import('./ProposalGeneratorView'));
const WhitepaperWriterView = lazy(() => import('./WhitepaperWriterView'));
const CaseStudyCreatorView = lazy(() => import('./CaseStudyCreatorView'));
const PressReleaseView = lazy(() => import('./PressReleaseView'));
const ParagraphGeneratorView = lazy(() => import('./ParagraphGeneratorView'));
const ToneHarmonizerView = lazy(() => import('./ToneHarmonizerView'));
const NarrativeSoftenerView = lazy(() => import('./NarrativeSoftenerView'));
const ClarityEnhancerView = lazy(() => import('./ClarityEnhancerView'));
const CorporatePolishView = lazy(() => import('./CorporatePolishView'));
const HumanWarmthView = lazy(() => import('./HumanWarmthView'));
const EmpatheticToneView = lazy(() => import('./EmpatheticToneView'));
const LinkedInStylerView = lazy(() => import('./LinkedInStylerView'));
const InstagramStylerView = lazy(() => import('./InstagramStylerView'));
const TwitterStylerView = lazy(() => import('./TwitterStylerView'));
const YouTubeStylerView = lazy(() => import('./YouTubeStylerView'));
const TikTokStylerView = lazy(() => import('./TikTokStylerView'));
const HashtagGeneratorView = lazy(() => import('./HashtagGeneratorView'));
const PinterestStylerView = lazy(() => import('./PinterestStylerView'));
const BlogIdeasGeneratorView = lazy(() => import('./BlogIdeasGeneratorView'));
const YouTubeToBlogView = lazy(() => import('./YouTubeToBlogView'));
const QuoraAnswerAssistantView = lazy(() => import('./QuoraAnswerAssistantView'));
const SocialCampaignPlannerView = lazy(() => import('./SocialCampaignPlannerView'));
const AITemplateBuilderView = lazy(() => import('./AITemplateBuilderView'));
const AIPromptGeneratorView = lazy(() => import('./AIPromptGeneratorView'));
const AITrendSpotterView = lazy(() => import('./AITrendSpotterView'));
const AIContentRepurposingView = lazy(() => import('./AIContentRepurposingView'));
const AITrainingDataGeneratorView = lazy(() => import('./AITrainingDataGeneratorView'));
const AISeoOpportunityFinderView = lazy(() => import('./AISeoOpportunityFinderView'));
const AISearchOptimizerView = lazy(() => import('./AISearchOptimizerView'));
const AIPerformancePredictorView = lazy(() => import('./AIPerformancePredictorView'));
const AICommentResponseGeneratorView = lazy(() => import('./AICommentResponseGeneratorView'));
const AICompetitorAnalyzerView = lazy(() => import('./AICompetitorAnalyzerView'));
const AIQuizCreatorView = lazy(() => import('./AIQuizCreatorView'));
const VideoScriptWriterView = lazy(() => import('./VideoScriptWriterView'));
const AIEbookCreatorView = lazy(() => import('./AIEbookCreatorView'));
const MetaDescriptionGeneratorView = lazy(() => import('./MetaDescriptionGeneratorView'));
const PersonalBioGeneratorView = lazy(() => import('./PersonalBioGeneratorView'));
const SloganGeneratorView = lazy(() => import('./SloganGeneratorView'));
const FAQSchemaGeneratorView = lazy(() => import('./FAQSchemaGeneratorView'));
const ResumeGeneratorView = lazy(() => import('./ResumeGeneratorView'));
const BrandVoiceGeneratorView = lazy(() => import('./BrandVoiceGeneratorView'));
const EarnWithContentCraftView = lazy(() => import('./EarnWithContentCraftView'));

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

const moduleViewMap: { [key: string]: React.FC<ModuleViewProps> } = {
  'ai-comment-response-generator': AICommentResponseGeneratorView,
  'ai-competitor-analyzer': AICompetitorAnalyzerView,
  'ai-template-builder': AITemplateBuilderView,
  'ai-prompt-generator': AIPromptGeneratorView,
  'ai-trend-spotter': AITrendSpotterView,
  'ai-content-repurposing': AIContentRepurposingView,
  'ai-chatbot-training': AITrainingDataGeneratorView,
  'ai-seo-opportunity-finder': AISeoOpportunityFinderView,
  'ai-search-optimizer': AISearchOptimizerView,
  'ai-performance-predictor': AIPerformancePredictorView,
  'ai-quiz-creator': AIQuizCreatorView,
  'ai-ebook-creator': AIEbookCreatorView,
  'brand-voice-generator': BrandVoiceGeneratorView,
  'seo-optimizer': SeoOptimizerView,
  'meta-description-generator': MetaDescriptionGeneratorView,
  'faq-schema-generator': FAQSchemaGeneratorView,
  'aso-optimizer': AsoOptimizerView,
  'summary-synthesizer': SummarySynthesizerView,
  'translation-master': GlobalTranslatorView,
  'text-craft': TextCraftView,
  'grammar-proofer': GrammarProoferView,
  'style-proofer': StyleProoferView,
  'plagiarism-checker': PlagiarismCheckerView,
  'clean-paste': CleanPasteView,
  'startup-pitch': StartupPitchView,
  'email-craft': EmailCraftView,
  'content-generator': ContentGeneratorView,
  'product-review': ProductReviewView,
  'landing-page-copy': LandingPageCopyView,
  'newsletter-builder': NewsletterBuilderView,
  'facebook-ad': FacebookAdView,
  'facebook-styler': FacebookStylerView,
  'google-ad': GoogleAdView,
  'ecommerce-description': EcommerceDescriptionView,
  'slogan-generator': SloganGeneratorView,
  'headline-generator': HeadlineGeneratorView,
  'proposal-generator': ProposalGeneratorView,
  'whitepaper-writer': WhitepaperWriterView,
  'case-study-creator': CaseStudyCreatorView,
  'personal-bio-generator': PersonalBioGeneratorView,
  'press-release': PressReleaseView,
  'video-script-writer': VideoScriptWriterView,
  'paragraph-generator': ParagraphGeneratorView,
  'tone-harmonizer': ToneHarmonizerView,
  'narrative-softener': NarrativeSoftenerView,
  'clarity-enhancer': ClarityEnhancerView,
  'corporate-polish': CorporatePolishView,
  'human-warmth': HumanWarmthView,
  'empathetic-tone': EmpatheticToneView,
  'linkedin-styler': LinkedInStylerView,
  'instagram-styler': InstagramStylerView,
  'twitter-styler': TwitterStylerView,
  'youtube-styler': YouTubeStylerView,
  'youtube-to-blog': YouTubeToBlogView,
  'tiktok-styler': TikTokStylerView,
  'pinterest-styler': PinterestStylerView,
  'blog-ideas-generator': BlogIdeasGeneratorView,
  'hashtag-generator': HashtagGeneratorView,
  'quora-answer': QuoraAnswerAssistantView,
  'social-campaign-planner': SocialCampaignPlannerView,
  'resume-generator': ResumeGeneratorView,
  'earn-with-content-craft-365': EarnWithContentCraftView,
};

// Generic Module View for modules without a specialized component
const GenericModuleView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [tones, setTones] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copySuccess, setCopySuccess] = useState(false);
  const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
  const [isQueued, setIsQueued] = useState(false);

  const { playClick, playSuccess } = useFeedback();
  const autoSaveKey = `autosave-${module.id}`;

  const canGenerate = usesLeft === 'Unlimited' || usesLeft > 0;
  
  // Load from localStorage on mount
  useEffect(() => {
    try {
      const savedInput = localStorage.getItem(autoSaveKey);
      if (savedInput) {
        setInput(savedInput);
      }
    } catch (e) {
      console.warn('Could not read autosaved content from localStorage', e);
    }
  }, [autoSaveKey]);

  // Save to localStorage on input change
  useEffect(() => {
    try {
      localStorage.setItem(autoSaveKey, input);
    } catch (e) {
      console.warn('Could not autosave content to localStorage', e);
    }
  }, [input, autoSaveKey]);


  const handleGenerate = useCallback(async () => {
    if (!input.trim() || !canGenerate) return;
    playClick();

    setIsLoading(true);
    setError(null);
    setOutput('');
    setIsQueued(false);

    const prompt = module.prompt(input, tones);

    // Offline logic
    if (!navigator.onLine) {
        try {
            if (Notification.permission !== 'granted') {
                const permission = await Notification.requestPermission();
                if (permission !== 'granted') {
                    setError("Notification permission is required to queue offline requests.");
                    setIsLoading(false);
                    return;
                }
            }
            await addToQueue({ prompt, moduleName: module.name });
            setIsQueued(true);
        } catch (queueError) {
            setError("Could not save request for offline processing.");
        } finally {
            setIsLoading(false);
        }
        return;
    }

    // Online logic
    try {
      const result = await generateContent(prompt);
      setOutput(result);
      if (usesLeft !== 'Unlimited') {
        decrementUse();
      }
      playSuccess();
       // Clear autosave and input on success
      localStorage.removeItem(autoSaveKey);
      setInput('');
      setTones([]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
    } finally {
      setIsLoading(false);
    }
  }, [input, tones, module, decrementUse, canGenerate, usesLeft, userId, playClick, playSuccess, autoSaveKey]);

  const handleCopy = () => {
    if (output) {
      navigator.clipboard.writeText(output).then(() => {
        setCopySuccess(true);
        playSuccess();
        setTimeout(() => setCopySuccess(false), 2000);
      });
    }
  };

  const commonTextareaClasses = "w-full min-h-[250px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";

  return (
    <>
      <div className="max-w-7xl mx-auto flex flex-col gap-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
          <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Enter your text or topic here..."
              className={commonTextareaClasses}
            />
            
            <button 
              onClick={() => { playClick(); setIsToneSelectorOpen(true); }}
              className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 space-y-3 w-full text-left hover:border-brand-primary/50 transition-colors"
            >
              <div className="flex justify-between items-center">
                 <div className="flex items-center gap-2">
                    <span role="img" aria-label="palette emoji" className="text-xl">🎨</span>
                    <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3>
                 </div>
                 <div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary">
                  <span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3
                </div>
              </div>
              <p className="text-sm text-text-secondary dark:text-d-text-secondary">
                {tones.length > 0 ? tones.join(', ') : 'Tap to select emotional tones for your content.'}
              </p>
            </button>
            
            <button
              onClick={handleGenerate}
              disabled={isLoading || !input.trim() || !canGenerate}
              className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300"
            >
              {isLoading ? (
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : null}
              {isLoading ? 'Generating...' : (isQueued ? 'Request Queued' : 'Craft Content')}
            </button>
            {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
            {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
          </div>

          <div className="relative">
            <textarea
              value={output}
              readOnly
              placeholder="Your AI-crafted content will appear here..."
              className={`${commonTextareaClasses} bg-base-200/50 dark:bg-d-base-200/50`}
            />
            {output && (
              <button
                onClick={handleCopy}
                className="absolute top-3 right-3 p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors"
                aria-label="Copy to clipboard"
              >
                <CopyIcon className="h-5 w-5" />
              </button>
            )}
            {copySuccess && <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-success text-white text-xs px-3 py-1 rounded-full">Copied!</div>}
          </div>
        </div>
        {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
      </div>
      <ToneSelector 
        isOpen={isToneSelectorOpen}
        onClose={() => setIsToneSelectorOpen(false)}
        selectedTones={tones}
        onTonesChange={setTones}
      />
    </>
  );
};

const ModuleView: React.FC<ModuleViewProps> = (props) => {
  const { module } = props;
  const SpecificModuleView = moduleViewMap[module.id];

  if (SpecificModuleView) {
    return <SpecificModuleView {...props} />;
  }

  // Fallback to the generic view if no specific view is found
  return <GenericModuleView {...props} />;
};

export default ModuleView;
