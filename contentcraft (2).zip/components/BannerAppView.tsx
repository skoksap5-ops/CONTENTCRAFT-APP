import React from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';

interface BannerAppViewProps {
  onClose: () => void;
}

const BannerAppView: React.FC<BannerAppViewProps> = ({ onClose }) => {
  const cubeFaceText = <span className="banner-cube-face-text">CONTENT<br/>CRAFT</span>;
  
  return (
    <div className="fixed inset-0 bg-d-base-100 z-50 flex flex-col animate-fade-in-up banner-view-container" role="dialog" aria-modal="true">
      <header className="sticky top-0 bg-transparent z-10 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-16 gap-4">
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10"
            aria-label="Back to settings"
          >
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold">Promotional Banner</h1>
        </div>
      </header>
      <main className="flex-1 flex flex-col items-center justify-center text-center p-4">
        <div className="banner-cube-perspective">
            <div className="banner-cube animate-cube-spin">
                <div className="banner-cube-face banner-face-front animate-aurora-glow">{cubeFaceText}</div>
                <div className="banner-cube-face banner-face-back animate-aurora-glow">{cubeFaceText}</div>
                <div className="banner-cube-face banner-face-right animate-aurora-glow">{cubeFaceText}</div>
                <div className="banner-cube-face banner-face-left animate-aurora-glow">{cubeFaceText}</div>
                <div className="banner-cube-face banner-face-top animate-aurora-glow">{cubeFaceText}</div>
                <div className="banner-cube-face banner-face-bottom animate-aurora-glow">{cubeFaceText}</div>
            </div>
        </div>
        <div className="mt-16">
            <h1 className="text-5xl font-bold font-heading text-white" style={{ textShadow: '0 0 20px rgba(255, 255, 255, 0.3)'}}>
                CONTENT<span style={{ color: '#10B981' }}>CRAFT</span>
            </h1>
            <p className="text-white/80 mt-2">The Future of AI Content Creation</p>
        </div>
      </main>
    </div>
  );
};

export default BannerAppView;