import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import InfoIcon from './icons/InfoIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type VideoType = 'Tutorial/How-To' | 'Educational/Explainer' | 'Review/Comparison';

const YOUTUBE_TO_BLOG_PROMPT = `
You are an expert content strategist and SEO specialist. Your task is to transform the following YouTube video transcript into a comprehensive, SEO-optimized blog article.

**INPUT:**
- Original Video Title: {VIDEO_TITLE}
- Video URL: {VIDEO_URL}
- Video Transcript: {TRANSCRIPT}
- Target Keywords: {KEYWORDS}
- Video Type: {VIDEO_TYPE}
- Desired Tone: {TONES}

**INSTRUCTIONS:**
1.  **Analyze the transcript** to extract the core message, key points, structure, and the creator's tone.
2.  **Craft a new, SEO-optimized blog post title** that is compelling and under 60 characters.
3.  **Write a meta description** (155-160 characters) summarizing the content and including keywords.
4.  **Structure the blog post** logically with a clear introduction, H2 headings for main sections, and a strong conclusion. Use a template appropriate for the specified "Video Type".
5.  **Enhance the content for readability:**
    *   Rewrite spoken language into clear, concise written prose.
    *   Break up long paragraphs into shorter, scannable ones.
    *   Use bullet points (•) and numbered lists where appropriate.
    *   Add context or deeper explanations to provide more value than the video alone.
6.  **Maintain the creator's original tone** as much as possible, as specified in "Desired Tone".
7.  **At the end of the article**, if a Video URL is provided, add a video reference line like: "--- \\n\\n**Video Reference:** This article is based on the video '[Video Title]'. Watch the full video here: {VIDEO_URL}". Do not invent a creator name.
8.  **Format the entire output** using Markdown.
    *   Use one H1 (#) for the main title.
    *   Use H2 (##) for main section headings.
    *   Use bold (**) for emphasis on key terms.

**OUTPUT FORMAT:**
Provide only the complete blog article in Markdown format. Do not add any commentary before or after the article. The article should start with the H1 title.
`;


const YouTubeToBlogView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [transcript, setTranscript] = useState('');
    const [videoTitle, setVideoTitle] = useState('');
    const [videoUrl, setVideoUrl] = useState('');
    const [targetKeywords, setTargetKeywords] = useState('');
    const [videoType, setVideoType] = useState<VideoType>('Tutorial/How-To');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    const [copySuccess, setCopySuccess] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && transcript.trim() && videoTitle.trim();
    
    const getPrompt = useCallback(() => {
        return YOUTUBE_TO_BLOG_PROMPT
            .replace('{TRANSCRIPT}', transcript)
            .replace(/{VIDEO_TITLE}/g, videoTitle)
            .replace('{VIDEO_URL}', videoUrl || 'Not provided')
            .replace('{KEYWORDS}', targetKeywords)
            .replace('{VIDEO_TYPE}', videoType)
            .replace('{TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [transcript, videoTitle, videoUrl, targetKeywords, videoType, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            
            if(userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: result,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);

    const handleCopy = () => {
        if (output) {
            navigator.clipboard.writeText(output).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        }
    };

    const formatOutput = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/^# (.*$)/gm, '<h1 class="text-3xl font-bold font-heading my-4">$1</h1>')
            .replace(/^## (.*$)/gm, '<h2 class="text-2xl font-bold font-heading my-4 border-l-4 border-brand-primary pl-4">$1</h2>')
            .replace(/^### (.*$)/gm, '<h3 class="text-xl font-bold font-heading my-3">$1</h3>')
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold">$1</strong>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-6 list-disc">$1</li>')
            .replace(/^- (.*$)/gm, '<li class="ml-6 list-disc">$1</li>')
            .replace(/^\d+\.\s*(.*$)/gm, '<li class="ml-6 list-decimal">$1</li>')
            .replace(/---/g, '<hr class="my-6 border-base-300 dark:border-d-base-300">')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };

    const commonTextareaClasses = "w-full p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                     <div className="space-y-2">
                        <label htmlFor="videoUrl" className={commonLabelClasses}>YouTube URL (Optional)</label>
                        <input id="videoUrl" value={videoUrl} onChange={e => setVideoUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." className={commonInputClasses} />
                    </div>

                    <div className="bg-base-300/50 dark:bg-d-base-300/50 p-3 rounded-lg text-sm text-text-secondary dark:text-d-text-secondary space-y-2">
                        <div className="flex items-center gap-2 font-semibold text-text-primary dark:text-d-text-primary">
                            <InfoIcon className="h-5 w-5 text-brand-primary" />
                            <span>How to get a YouTube transcript:</span>
                        </div>
                        <ol className="list-decimal list-inside text-xs space-y-1 pl-2">
                            <li>On YouTube, go to the video page.</li>
                            <li>Click the "..." (More) button below the video.</li>
                            <li>Select "Show transcript".</li>
                            <li>Copy the transcript text and paste it below.</li>
                        </ol>
                    </div>

                    <textarea value={transcript} onChange={e => setTranscript(e.target.value)} placeholder="Paste your full video transcript here..." className={commonTextareaClasses} style={{minHeight: '250px'}}/>
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Blog Post Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="md:col-span-2">
                                <label htmlFor="videoTitle" className={commonLabelClasses}>Original Video Title</label>
                                <input id="videoTitle" value={videoTitle} onChange={e => setVideoTitle(e.target.value)} placeholder="e.g., My 5 Secrets to Productivity" className={commonInputClasses} />
                            </div>
                            <div className="md:col-span-2">
                                <label htmlFor="keywords" className={commonLabelClasses}>Target Keywords (comma-separated)</label>
                                <input id="keywords" value={targetKeywords} onChange={e => setTargetKeywords(e.target.value)} placeholder="e.g., productivity hacks, morning routine" className={commonInputClasses} />
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Video Type</label>
                                <select value={videoType} onChange={e => setVideoType(e.target.value as VideoType)} className={commonInputClasses}>
                                    <option>Tutorial/How-To</option>
                                    <option>Educational/Explainer</option>
                                    <option>Review/Comparison</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Converting...' : (isQueued ? 'Request Queued' : 'Convert to Blog Post')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please provide a transcript and title.</p>}
                </div>

                <div className="bg-base-100 dark:bg-d-base-100 rounded-lg p-6 min-h-[500px] overflow-y-auto shadow-inner relative group">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Converting your video to a blog post...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your SEO-optimized blog article will appear here.</p>}
                    {output && (
                        <>
                            <button onClick={handleCopy} className="absolute top-4 right-4 p-2 rounded-lg bg-base-300/50 dark:bg-d-base-300/50 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Copy blog post">
                               <CopyIcon className="h-5 w-5" />
                            </button>
                            {copySuccess && <div className="absolute top-14 right-4 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
                            <div className="prose prose-sm dark:prose-invert max-w-none" dangerouslySetInnerHTML={formatOutput(output)} />
                        </>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default YouTubeToBlogView;