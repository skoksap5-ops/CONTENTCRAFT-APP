import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type ParagraphPurpose = 'Explain' | 'Argue' | 'Describe' | 'Narrate' | 'Persuade' | 'Inform';
type TargetAudience = 'General' | 'Expert' | 'Academic' | 'Business' | 'Casual';
type ParagraphType = 'Introductory' | 'Supporting' | 'Concluding' | 'Standalone';
type Length = 'Short (50-100w)' | 'Medium (100-200w)' | 'Long (200-300w)';

const PARAGRAPH_GENERATOR_PROMPT = `
You are a master writer and content expansion specialist. Based on the user's request, generate a primary paragraph, a quality analysis, three alternative versions, a list of techniques applied, and readability metrics.

**INPUT:**
- Core Topic/Theme: {CORE_TOPIC}
- Purpose: {PARAGRAPH_PURPOSE}
- Target Audience: {TARGET_AUDIENCE}
- Paragraph Type: {PARAGRAPH_TYPE}
- Length: {LENGTH}
- Tone: {SELECTED_TONES}

**TASK:**
Generate a comprehensive report. The output MUST follow this structure exactly:

---START---

🎯 **PRIMARY PARAGRAPH:**
[Your main generated paragraph here, tailored to all inputs.]

📊 **QUALITY ANALYSIS:**
- **Structural Excellence:** [X]/10
- **Development Depth:** [X]/10
- **Persuasive Impact:** [X]/10
- **Audience Alignment:** [X]/10

🔧 **ALTERNATIVE VERSIONS:**
- **Short Version:** [A concise version, ~50 words]
- **Long Version:** [A more detailed version, +100 words]
- **Creative Version:** [A version with more narrative or stylistic flair]

🎨 **DEVELOPMENT TECHNIQUES APPLIED:**
• [Technique 1]
• [Technique 2]
• [Technique 3]

📈 **READABILITY METRICS:**
- **Flesch Reading Ease:** [Score]
- **Grade Level:** [Level]
- **Sentence Variety:** [Comment]
- **Active Voice:** [Percentage]

---END---
`;

interface ParsedOutput {
    primaryParagraph: string;
    qualityAnalysis: string;
    alternatives: {
        short: string;
        long: string;
        creative: string;
    };
    techniques: string;
    readability: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const ParagraphGeneratorView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [coreTopic, setCoreTopic] = useState('');
    const [purpose, setPurpose] = useState<ParagraphPurpose>('Inform');
    const [audience, setAudience] = useState<TargetAudience>('General');
    const [type, setType] = useState<ParagraphType>('Supporting');
    const [length, setLength] = useState<Length>('Medium (100-200w)');
    const [tones, setTones] = useState<string[]>([]);

    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && coreTopic.trim();

    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string, sourceText = text) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = sourceText.match(regex);
                return match ? match[1].trim() : 'Could not parse this section.';
            };
            
            const alternativesText = getSection('🔧 \\*\\*ALTERNATIVE VERSIONS:\\*\\*', '🎨 \\*\\*DEVELOPMENT TECHNIQUES APPLIED:\\*\\*');

            return {
                primaryParagraph: getSection('🎯 \\*\\*PRIMARY PARAGRAPH:\\*\\*', '📊 \\*\\*QUALITY ANALYSIS:\\*\\*'),
                qualityAnalysis: getSection('📊 \\*\\*QUALITY ANALYSIS:\\*\\*', '🔧 \\*\\*ALTERNATIVE VERSIONS:\\*\\*'),
                alternatives: {
                    short: getSection('- \\*\\*Short Version:\\*\\*', '- \\*\\*Long Version:\\*\\*', alternativesText),
                    long: getSection('- \\*\\*Long Version:\\*\\*', '- \\*\\*Creative Version:\\*\\*', alternativesText),
                    creative: getSection('- \\*\\*Creative Version:\\*\\*', '$', alternativesText),
                },
                techniques: getSection('🎨 \\*\\*DEVELOPMENT TECHNIQUES APPLIED:\\*\\*', '📈 \\*\\*READABILITY METRICS:\\*\\*'),
                readability: getSection('📈 \\*\\*READABILITY METRICS:\\*\\*', '---END---'),
            };
        } catch (e) {
            console.error("Failed to parse Paragraph Generator output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return PARAGRAPH_GENERATOR_PROMPT
            .replace('{CORE_TOPIC}', coreTopic)
            .replace('{PARAGRAPH_PURPOSE}', purpose)
            .replace('{TARGET_AUDIENCE}', audience)
            .replace('{PARAGRAPH_TYPE}', type)
            .replace('{LENGTH}', length)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [coreTopic, purpose, audience, type, length, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };

    const VersionCard: React.FC<{ title: string; content: string }> = ({ title, content }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!content) return;
            navigator.clipboard.writeText(content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!content || content.toLowerCase().includes('could not parse')) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative">
                <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{title}</h4>
                     <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${title}`}>
                        <CopyIcon className="h-5 w-5" />
                    </button>
                </div>
                <p className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed">{content}</p>
                 {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={coreTopic} onChange={e => setCoreTopic(e.target.value)} placeholder="Enter your core topic, theme, or keywords..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Paragraph Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Purpose</label>
                                <select value={purpose} onChange={e => setPurpose(e.target.value as ParagraphPurpose)} className={commonInputClasses}>
                                    <option>Inform</option><option>Explain</option><option>Argue</option><option>Describe</option><option>Narrate</option><option>Persuade</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Target Audience</label>
                                <select value={audience} onChange={e => setAudience(e.target.value as TargetAudience)} className={commonInputClasses}>
                                    <option>General</option><option>Expert</option><option>Academic</option><option>Business</option><option>Casual</option>
                                </select>
                            </div>
                             <div>
                                <label className={commonLabelClasses}>Paragraph Type</label>
                                <select value={type} onChange={e => setType(e.target.value as ParagraphType)} className={commonInputClasses}>
                                    <option>Supporting</option><option>Introductory</option><option>Concluding</option><option>Standalone</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Length</label>
                                <select value={length} onChange={e => setLength(e.target.value as Length)} className={commonInputClasses}>
                                    <option>Medium (100-200w)</option><option>Short (50-100w)</option><option>Long (200-300w)</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Generating...' : (isQueued ? 'Request Queued' : 'Generate Paragraph')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && coreTopic.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Generating your comprehensive report...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your expert-crafted paragraph and analysis will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-6">
                            <VersionCard title="Primary Paragraph" content={parsedOutput.primaryParagraph} />
                            
                            <div className="space-y-2 pt-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Analysis & Alternatives</h3>
                                <Accordion title={<>📊 <span className="ml-2">Quality Analysis</span></>} defaultOpen={true}>
                                    <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.qualityAnalysis)}/>
                                </Accordion>
                                <Accordion title={<>🔧 <span className="ml-2">Alternative Versions</span></>} defaultOpen={true}>
                                    <div className="space-y-4">
                                        <VersionCard title="Short Version" content={parsedOutput.alternatives.short} />
                                        <VersionCard title="Long Version" content={parsedOutput.alternatives.long} />
                                        <VersionCard title="Creative Version" content={parsedOutput.alternatives.creative} />
                                    </div>
                                </Accordion>
                                <Accordion title={<>🎨 <span className="ml-2">Development Techniques</span></>}>
                                    <div dangerouslySetInnerHTML={formatContent(parsedOutput.techniques)}/>
                                </Accordion>
                                <Accordion title={<>📈 <span className="ml-2">Readability Metrics</span></>}>
                                    <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.readability)}/>
                                </Accordion>
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default ParagraphGeneratorView;
