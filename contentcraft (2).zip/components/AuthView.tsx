import React, { useState } from 'react';
import {
  signInWithGoogle,
  signInWithFacebook,
  signInWithGithub,
  signInWithMicrosoft,
  signUpWithEmail,
  signInWithEmail,
  sendPasswordReset,
  firebaseInitialized
} from '../services/firebase';
import { useLanguage } from '../hooks/useLanguage';

import GoogleIcon from './icons/social/GoogleIcon';
import FacebookIcon from './icons/social/FacebookIcon';
import GithubIcon from './icons/social/GithubIcon';
import MicrosoftIcon from './icons/social/MicrosoftIcon';
import UserIcon from './icons/UserIcon';
import MailIcon from './icons/MailIcon';
import LockClosedIcon from './icons/LockClosedIcon';
import SparklesIcon from './icons/settings/SparklesIcon';

const AuthView: React.FC = () => {
  const [view, setView] = useState<'signIn' | 'signUp' | 'verifyEmail' | 'forgotPassword'>('signIn');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [stayLoggedIn, setStayLoggedIn] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<string | null>(null);
  const { t } = useLanguage();
  
  const handleSocialSignIn = async (provider: 'google' | 'facebook' | 'github' | 'microsoft') => {
    if (!firebaseInitialized) {
        setError("Social login is disabled because Firebase is not configured.");
        return;
    }
    setIsLoading(provider);
    setError(null);
    try {
      switch (provider) {
        case 'google': await signInWithGoogle(); break;
        case 'facebook': await signInWithFacebook(); break;
        case 'github': await signInWithGithub(); break;
        case 'microsoft': await signInWithMicrosoft(); break;
      }
    } catch (err: any) {
      setError(err.message || 'Failed to sign in. Please try again.');
    } finally {
      setIsLoading(null);
    }
  };

  const handleEmailSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
     if (!firebaseInitialized) {
        setError("Email signup is disabled because Firebase is not configured.");
        return;
    }
    setIsLoading('email');
    setError(null);
    try {
      await signUpWithEmail(name, email, password);
      setView('verifyEmail');
    } catch (err: any) {
      setError(err.message || 'Failed to sign up. Please try again.');
    } finally {
      setIsLoading(null);
    }
  };

  const handleEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
     if (!firebaseInitialized) {
        setError("Email login is disabled because Firebase is not configured.");
        return;
    }
    setIsLoading('email');
    setError(null);
    try {
      await signInWithEmail(email, password, stayLoggedIn);
    } catch (err: any) {
       setError(err.message || 'Failed to sign in. Please check your credentials.');
    } finally {
      setIsLoading(null);
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError("Please enter your email address.");
      return;
    }
    setIsLoading('email');
    setError(null);
    setSuccess(null);
    try {
      await sendPasswordReset(email);
      setSuccess("Password reset link sent! Check your inbox.");
    } catch (err: any) {
      setError(err.message || 'Failed to send password reset email.');
    } finally {
      setIsLoading(null);
    }
  };

  const socialProviders = [
    { provider: 'google', name: 'Google', icon: <GoogleIcon className="h-5 w-5" />, onClick: () => handleSocialSignIn('google') },
    { provider: 'facebook', name: 'Facebook', icon: <FacebookIcon className="h-5 w-5" />, onClick: () => handleSocialSignIn('facebook') },
    { provider: 'github', name: 'GitHub', icon: <GithubIcon className="h-5 w-5" />, onClick: () => handleSocialSignIn('github') },
    { provider: 'microsoft', name: 'Microsoft', icon: <MicrosoftIcon className="h-5 w-5" />, onClick: () => handleSocialSignIn('microsoft') },
  ];

  const InputField: React.FC<{icon: React.ReactNode, type: string, placeholder: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, required?: boolean}> = 
    ({ icon, type, placeholder, value, onChange, required=true }) => (
    <div className="relative">
      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
        {icon}
      </div>
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        required={required}
        className="w-full pl-10 pr-3 py-2 bg-base-100 dark:bg-d-base-300 rounded-lg border border-base-300 dark:border-d-base-300 focus:outline-none focus:ring-2 focus:ring-brand-primary transition-colors text-text-primary dark:text-d-text-primary"
      />
    </div>
  );

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 bg-d-base-100 animate-gradient [background:linear-gradient(-45deg,#0F0F1A,#1E293B,#334155,#10B981,#6366F1)] [background-size:400%_400%]">
      <div className="w-full max-w-4xl h-auto lg:h-[700px] flex flex-col lg:flex-row bg-base-200/80 dark:bg-d-base-200/80 backdrop-blur-2xl rounded-3xl shadow-2xl overflow-hidden animate-fade-in-up">
        {/* Left Branding Panel */}
        <div className="hidden lg:flex lg:w-1/2 flex-col justify-center items-center p-12 bg-gradient-to-br from-brand-primary to-accent text-white text-center">
            <SparklesIcon className="w-24 h-24 opacity-80" />
            <h1 className="text-4xl font-bold font-heading mt-4">ContentCraft AI</h1>
            <p className="mt-2 opacity-90">Unlock your creative potential with the power of AI. From SEO optimization to viral social media posts, craft your best content yet.</p>
        </div>

        {/* Right Form Panel */}
        <div className="w-full lg:w-1/2 p-8 sm:p-12 flex flex-col justify-center overflow-y-auto">
          {view === 'signIn' && (
            <form onSubmit={handleEmailSignIn} className="space-y-6 animate-fade-in">
              <h2 className="text-3xl font-bold font-heading text-text-primary dark:text-d-text-primary">Sign In</h2>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <InputField icon={<MailIcon className="w-5 h-5"/>} type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
              <InputField icon={<LockClosedIcon className="w-5 h-5"/>} type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 text-text-secondary dark:text-d-text-secondary"><input type="checkbox" checked={stayLoggedIn} onChange={e => setStayLoggedIn(e.target.checked)} className="rounded"/> Stay logged in</label>
                <button type="button" onClick={() => setView('forgotPassword')} className="font-semibold text-brand-primary hover:underline">Forgot password?</button>
              </div>
              <button type="submit" disabled={!!isLoading} className="w-full primary-button">{isLoading === 'email' ? <div className="spinner"></div> : 'Sign In'}</button>
              <p className="text-sm text-center text-text-secondary dark:text-d-text-secondary">Don't have an account? <button type="button" onClick={() => setView('signUp')} className="font-semibold text-brand-primary hover:underline">Sign up</button></p>
            </form>
          )}

          {view === 'signUp' && (
            <form onSubmit={handleEmailSignUp} className="space-y-6 animate-fade-in">
              <h2 className="text-3xl font-bold font-heading text-text-primary dark:text-d-text-primary">Create Account</h2>
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <InputField icon={<UserIcon className="w-5 h-5"/>} type="text" placeholder="Full Name" value={name} onChange={e => setName(e.target.value)} />
              <InputField icon={<MailIcon className="w-5 h-5"/>} type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
              <InputField icon={<LockClosedIcon className="w-5 h-5"/>} type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} />
              <button type="submit" disabled={!!isLoading} className="w-full primary-button">{isLoading === 'email' ? <div className="spinner"></div> : 'Create Account'}</button>
              <p className="text-sm text-center text-text-secondary dark:text-d-text-secondary">Already have an account? <button type="button" onClick={() => setView('signIn')} className="font-semibold text-brand-primary hover:underline">Sign in</button></p>
            </form>
          )}
          
          {view === 'verifyEmail' && (
              <div className="text-center space-y-4 animate-fade-in">
                  <MailIcon className="w-16 h-16 mx-auto text-brand-primary"/>
                  <h2 className="text-3xl font-bold font-heading text-text-primary dark:text-d-text-primary">Verify Your Email</h2>
                  <p className="text-text-secondary dark:text-d-text-secondary">We've sent a verification link to <strong>{email}</strong>. Please check your inbox and click the link to activate your account.</p>
                  <button onClick={() => setView('signIn')} className="w-full primary-button">Back to Sign In</button>
              </div>
          )}

          {view === 'forgotPassword' && (
              <form onSubmit={handlePasswordReset} className="space-y-6 animate-fade-in">
                  <h2 className="text-3xl font-bold font-heading text-text-primary dark:text-d-text-primary">Reset Password</h2>
                  {error && <p className="text-red-500 text-sm">{error}</p>}
                  {success && <p className="text-green-500 text-sm">{success}</p>}
                  <p className="text-text-secondary dark:text-d-text-secondary">Enter your email and we'll send you a link to reset your password.</p>
                  <InputField icon={<MailIcon className="w-5 h-5"/>} type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
                  <button type="submit" disabled={!!isLoading} className="w-full primary-button">{isLoading === 'email' ? <div className="spinner"></div> : 'Send Reset Link'}</button>
                  <p className="text-sm text-center"><button type="button" onClick={() => setView('signIn')} className="font-semibold text-brand-primary hover:underline">Back to Sign In</button></p>
              </form>
          )}

          { (view === 'signIn' || view === 'signUp') && (
            <>
              <div className="my-6 flex items-center">
                  <div className="flex-grow border-t border-base-300 dark:border-d-base-300"></div>
                  <span className="flex-shrink mx-4 text-xs font-medium text-text-secondary dark:text-d-text-secondary">{t('or')}</span>
                  <div className="flex-grow border-t border-base-300 dark:border-d-base-300"></div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {socialProviders.map(({ provider, icon, onClick }) => (
                  <button key={provider} type="button" onClick={onClick} disabled={!!isLoading} className="social-button">
                    {isLoading === provider ? <div className="spinner text-brand-primary"></div> : icon}
                  </button>
                ))}
              </div>
            </>
          )}
          <p className="text-xs text-text-secondary dark:text-d-text-secondary text-center mt-8">{t('termsAgreement')}</p>
        </div>
      </div>
    </div>
  );
};

export default AuthView;