import React, { useState, useRef, useEffect, useMemo } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { MODULES, MODULE_GROUPS_MAP } from '../constants';
import type { Content } from '@google/genai';
import CopyIcon from './icons/CopyIcon';
import TrashIcon from './icons/TrashIcon';
import { useLanguage } from '../hooks/useLanguage';

interface ModuleExplanationChatbotViewProps {
  module: Module;
}

interface Message {
    id: number;
    type: 'user' | 'bot';
    content: string;
    timestamp: Date;
}

// Build a database of module info for the AI
const moduleDatabase: { [key: string]: any } = {};
MODULES.forEach(m => {
    moduleDatabase[m.id] = {
        name: m.name,
        category: m.group,
        description: m.description,
        // Simplified prompt for context
        mainTask: m.prompt('input', ['tone1', 'tone2']).split('.')[0],
    };
});

const systemInstruction = `You are a helpful and friendly assistant for the "ContentCraft AI" application. Your sole purpose is to explain what each module in the application does and how to use it. You MUST detect the user's language and respond ONLY in that same language. Be concise and clear, using markdown for formatting like **bold** text and lists.

Here is all the information about the available modules. Use this information to answer user questions:
\n\n` + Object.entries(moduleDatabase).map(([id, data]) => `
---
Module ID: '${id}'
Name: '${data.name}'
Description: ${data.description}
Main Task: ${data.mainTask}
---
`).join('\n\n');

const MessageItem: React.FC<{ message: Message; onDelete: (id: number) => void; }> = ({ message, onDelete }) => {
    const [copySuccess, setCopySuccess] = useState(false);
    
    const handleCopy = () => {
        navigator.clipboard.writeText(message.content).then(() => {
            setCopySuccess(true);
            setTimeout(() => setCopySuccess(false), 2000);
        });
    };

    return (
        <div className={`message ${message.type}`}>
             <div className="message-content" dangerouslySetInnerHTML={{ __html: message.content.replace(/\n/g, '<br/>').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\*(.*?)\*/g, '<em>$1</em>') }}></div>
            <div className="flex items-center justify-end mt-2">
                <div className="message-actions">
                    <button onClick={handleCopy} className="message-action-button" aria-label="Copy message">
                        <CopyIcon className="h-4 w-4" />
                    </button>
                    <button onClick={() => onDelete(message.id)} className="message-action-button" aria-label="Delete message">
                        <TrashIcon className="h-4 w-4" />
                    </button>
                </div>
                <div className="message-time">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    {copySuccess && <span className="ml-2 text-success font-semibold">Copied!</span>}
                </div>
            </div>
        </div>
    );
};


const ModuleExplanationChatbotView: React.FC<ModuleExplanationChatbotViewProps> = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: Date.now(), type: 'bot', content: '👋 Hi! I\'m your Module Explanation Assistant. How can I help you understand ContentCraft today?', timestamp: new Date() }
  ]);
  const nextId = useRef(2);

  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<null | HTMLDivElement>(null);
  const { t } = useLanguage();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);
  
  const handleSendMessage = async (messageText?: string) => {
    const currentInput = messageText || inputMessage;
    if (!currentInput.trim() || isLoading) return;

    const userMessage: Message = { id: nextId.current++, type: 'user', content: currentInput, timestamp: new Date() };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInputMessage('');
    
    setIsLoading(true);
    const history: Content[] = newMessages.map(msg => ({
        role: msg.type === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }]
    }));

    try {
        const result = await generateContent(history, { systemInstruction });
        const botMessage: Message = { id: nextId.current++, type: 'bot', content: result, timestamp: new Date() };
        setMessages(prev => [...prev, botMessage]);
    } catch (err) {
         const errorMessage: Message = {
            id: nextId.current++,
            type: 'bot',
            content: 'Sorry, I encountered an error. Please check your connection or try again later.',
            timestamp: new Date()
        };
        setMessages(prev => [...prev, errorMessage]);
    } finally {
        setIsLoading(false);
    }
  };

  const handleDeleteMessage = (id: number) => {
    setMessages(prev => prev.filter(m => m.id !== id));
  };
  
  const ChatSidebar: React.FC = () => {
      const groupedModules = useMemo(() => Object.values(MODULE_GROUPS_MAP).map(group => ({
        groupName: t(group.nameKey),
        modules: MODULES.filter(m => m.group === group.nameKey),
      })), [t]);

      const handleModuleClick = (moduleName: string) => {
        handleSendMessage(`Tell me about the "${moduleName}" module.`);
      };

      const groupIcons: { [key: string]: string } = {
        group_ai_power: 'fas fa-robot',
        group_core: 'fas fa-cube',
        group_social: 'fas fa-share-alt',
        group_professional: 'fas fa-briefcase',
        group_marketing: 'fas fa-chart-line'
      }

      return (
          <div className="sidebar">
              <div className="logo">
                  <div className="logo-icon"><i className="fas fa-pen-fancy"></i></div>
                  <div className="logo-text">CONTENT<span className="text-accent">CRAFT</span></div>
              </div>
              <div className="module-categories">
                  {groupedModules.map(group => (
                      <div key={group.groupId} className="category">
                          <div className="category-title">
                              <i className={groupIcons[group.modules[0].group] || 'fas fa-folder'}></i>
                              {group.groupName}
                          </div>
                          <ul className="module-list">
                              {group.modules.map(module => (
                                  <li key={module.id} className="module-item" onClick={() => handleModuleClick(module.name)}>
                                      <i className="fas fa-caret-right"></i>
                                      {module.name}
                                  </li>
                              ))}
                          </ul>
                      </div>
                  ))}
              </div>
          </div>
      );
  };

  const QuickActions: React.FC = () => {
    const actions = [
        "What is AI Prompt Generator?",
        "How do I optimize for SEO?",
        "Explain Brand Voice Generator",
    ];
    return (
        <div className="quick-actions">
            {actions.map(action => (
                <button key={action} className="quick-action" onClick={() => handleSendMessage(action)}>
                    {action}
                </button>
            ))}
        </div>
    )
  }

  return (
    <div className="chatbot-module-view">
        <div className="chatbot-container-wrapper">
            <ChatSidebar />
            <div className="chat-container">
                <div className="chat-messages">
                    {messages.map((message) => (
                        <MessageItem key={message.id} message={message} onDelete={handleDeleteMessage} />
                    ))}
                    {messages.length === 1 && <QuickActions />}
                    {isLoading && (
                        <div className="message bot">
                            <div className="message-content">
                                <div className="typing-indicator"><span></span><span></span><span></span></div>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
                <div className="chat-input-container">
                    <textarea 
                        className="chat-input"
                        placeholder="Ask about any module..."
                        value={inputMessage}
                        onChange={e => setInputMessage(e.target.value)}
                        onKeyPress={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSendMessage();
                            }
                        }}
                    ></textarea>
                    <button className="send-btn" onClick={() => handleSendMessage()} disabled={isLoading || !inputMessage.trim()}>
                        <i className="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
  );
};

export default ModuleExplanationChatbotView;