import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import { Type } from '@google/genai';
import CloseIcon from './icons/CloseIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface CompetitorRanking {
    name: string;
    overall_score: number;
    strengths: string[];
    weaknesses: string[];
}

interface ContentGap {
    topic: string;
    description: string;
    opportunity_score: number;
    priority: 'High' | 'Medium' | 'Low';
}

interface ActionPlanItem {
    title: string;
    description: string;
    priority: 'High' | 'Medium' | 'Low';
}

interface AnalysisResult {
    executive_summary: string;
    competitor_ranking: CompetitorRanking[];
    content_gaps: ContentGap[];
    action_plan: ActionPlanItem[];
}

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        executive_summary: { type: Type.STRING, description: "A 2-3 sentence summary of the competitive landscape and key opportunities." },
        competitor_ranking: {
            type: Type.ARRAY,
            description: "A ranked list of all analyzed brands, including the user's.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING },
                    overall_score: { type: Type.NUMBER, description: "A score from 0-100." },
                    strengths: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Top 2-3 strengths." },
                    weaknesses: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Top 2-3 weaknesses." },
                },
                 required: ['name', 'overall_score', 'strengths', 'weaknesses']
            }
        },
        content_gaps: {
            type: Type.ARRAY,
            description: "A list of content topics where the user's brand is weaker than competitors.",
            items: {
                type: Type.OBJECT,
                properties: {
                    topic: { type: Type.STRING },
                    description: { type: Type.STRING },
                    opportunity_score: { type: Type.NUMBER, description: "Score 0-100 indicating potential." },
                    priority: { type: Type.STRING, enum: ['High', 'Medium', 'Low'] }
                },
                required: ['topic', 'description', 'opportunity_score', 'priority']
            }
        },
        action_plan: {
            type: Type.ARRAY,
            description: "A list of prioritized, actionable steps for the user.",
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "Actionable title for the task." },
                    description: { type: Type.STRING, description: "Detailed description of what to do." },
                    priority: { type: Type.STRING, enum: ['High', 'Medium', 'Low'] }
                },
                required: ['title', 'description', 'priority']
            }
        }
    },
    required: ['executive_summary', 'competitor_ranking', 'content_gaps', 'action_plan']
};


const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-100 dark:bg-d-base-100 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-200/50 dark:hover:bg-d-base-200/50 transition-colors"
        aria-expanded={isOpen}
      >
        <div className="font-bold text-lg text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</div>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 space-y-4 animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const AICompetitorAnalyzerView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [step, setStep] = useState<'input' | 'analysis'>('input');

    const [yourBrand, setYourBrand] = useState('');
    const [competitors, setCompetitors] = useState<string[]>([]);
    const [competitorInput, setCompetitorInput] = useState('');
    const [industry, setIndustry] = useState('');

    const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && yourBrand.trim() && competitors.length > 0;

    const handleAddCompetitor = () => {
        if (competitorInput.trim() && !competitors.includes(competitorInput.trim()) && competitors.length < 5) {
            setCompetitors(prev => [...prev, competitorInput.trim()]);
            setCompetitorInput('');
        }
    };

    const handleRemoveCompetitor = (competitorToRemove: string) => {
        setCompetitors(prev => prev.filter(c => c !== competitorToRemove));
    };

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setAnalysisResult(null);
        setIsQueued(false);

        const prompt = `You are an expert market and SEO analyst. Perform a comprehensive competitive analysis based on the provided information. Include yourself ('${yourBrand}') in the analysis and ranking.
        - Your Brand: ${yourBrand}
        - Competitor Brands: ${competitors.join(', ')}
        - Industry: ${industry || 'Not specified'}
        Generate realistic but illustrative data for all fields. Your response must be a valid JSON object conforming to the provided schema.`;
        
        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: analysisSchema as any,
            });
            const parsed = JSON.parse(result);
            // Ensure ranking is sorted
            parsed.competitor_ranking.sort((a: CompetitorRanking, b: CompetitorRanking) => b.overall_score - a.overall_score);
            setAnalysisResult(parsed);
            setStep('analysis');
            
            if (userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: JSON.stringify(parsed, null, 2),
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, yourBrand, competitors, industry, module.id, module.name, userId, usesLeft, decrementUse]);

    const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    const renderInputForm = () => (
        <div className="space-y-6">
            <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-4">
                <h3 className="text-xl font-bold font-heading">🏢 Your Brand & Industry</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="yourBrand" className={commonLabelClasses}>Your Brand/Company Name</label>
                        <input id="yourBrand" value={yourBrand} onChange={e => setYourBrand(e.target.value)} placeholder="e.g., My Awesome App" className={commonInputClasses} />
                    </div>
                    <div>
                        <label htmlFor="industry" className={commonLabelClasses}>Industry (Optional)</label>
                        <input id="industry" value={industry} onChange={e => setIndustry(e.target.value)} placeholder="e.g., SaaS, E-commerce" className={commonInputClasses} />
                    </div>
                </div>
            </div>
             <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-4">
                 <h3 className="text-xl font-bold font-heading">🎯 Competitors to Analyze</h3>
                 <div className="flex gap-2">
                     <input value={competitorInput} onChange={e => setCompetitorInput(e.target.value)} placeholder="Enter competitor name or domain..." className="flex-grow p-2 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg"/>
                     <button onClick={handleAddCompetitor} className="px-4 py-2 bg-base-300 dark:bg-d-base-300 font-semibold rounded-lg hover:bg-base-300/80 dark:hover:bg-d-base-300/80">Add</button>
                 </div>
                 <div className="flex flex-wrap gap-2">
                     {competitors.map(c => (
                         <span key={c} className="flex items-center bg-base-300 dark:bg-d-base-300 text-sm font-medium px-3 py-1 rounded-full">
                             {c}
                             <button onClick={() => handleRemoveCompetitor(c)} className="ml-2 text-text-secondary dark:text-d-text-secondary hover:text-error">
                                <CloseIcon className="h-4 w-4" />
                            </button>
                         </span>
                     ))}
                 </div>
             </div>
             <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 transition-all">
                {isLoading ? 'Analyzing...' : '🔍 Find Opportunities'}
            </button>
        </div>
    );
    
    // In a real implementation, the renderResults function would be much more complex
    // This is a simplified version to demonstrate the structure
    const renderResults = () => (
         <div className="space-y-8 animate-fade-in">
            <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl">
                <h3 className="text-2xl font-bold font-heading mb-2">Analysis for "{yourBrand}"</h3>
                <p className="text-text-secondary dark:text-d-text-secondary">{analysisResult?.executive_summary}</p>
                 <button onClick={() => setStep('input')} className="text-sm font-semibold text-brand-primary mt-4 hover:underline">New Analysis</button>
            </div>
            
            <div>
                <h3 className="text-xl font-bold font-heading mb-4">🏆 Competitor Ranking</h3>
                <div className="space-y-2">
                    {analysisResult?.competitor_ranking.map((brand, index) => (
                        <div key={brand.name} className={`p-4 rounded-lg border-2 ${brand.name === yourBrand ? 'border-brand-primary bg-brand-primary/10' : 'bg-base-200 dark:bg-d-base-200 border-transparent'}`}>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <span className="text-2xl font-bold text-text-secondary dark:text-d-text-secondary">#{index + 1}</span>
                                    <span className="font-bold text-lg">{brand.name} {brand.name === yourBrand && '(You)'}</span>
                                </div>
                                <div className="text-2xl font-bold text-brand-primary">{brand.overall_score}/100</div>
                            </div>
                             <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2 mt-2">
                                <div className="bg-brand-primary h-2 rounded-full" style={{width: `${brand.overall_score}%`}}></div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div>
                <h3 className="text-xl font-bold font-heading mb-4">🔍 Content Gaps</h3>
                 <div className="space-y-4">
                    {analysisResult?.content_gaps.map((gap, i) => (
                        <Accordion key={i} title={<><span>{gap.topic}</span><span className={`text-sm font-bold px-2 py-0.5 rounded-full ${gap.priority === 'High' ? 'bg-error/20 text-error' : 'bg-amber-500/20 text-amber-500'}`}>{gap.priority}</span></>}>
                            <p>{gap.description}</p>
                            <p className="font-bold mt-2">Opportunity Score: {gap.opportunity_score}/100</p>
                        </Accordion>
                    ))}
                </div>
            </div>
            
             <div>
                <h3 className="text-xl font-bold font-heading mb-4">🎯 Action Plan</h3>
                 <div className="space-y-4">
                    {analysisResult?.action_plan.map((item, i) => (
                        <Accordion key={i} title={<><span>{item.title}</span><span className={`text-sm font-bold px-2 py-0.5 rounded-full ${item.priority === 'High' ? 'bg-error/20 text-error' : 'bg-amber-500/20 text-amber-500'}`}>{item.priority}</span></>}>
                            <p>{item.description}</p>
                        </Accordion>
                    ))}
                </div>
            </div>
         </div>
    );

    return (
        <div className="max-w-4xl mx-auto flex flex-col gap-8">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>

            {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
            {isQueued && <p className="text-center text-accent">Request queued for when you're back online.</p>}

            {isLoading && (
                 <div className="text-center p-8">
                     <svg className="animate-spin mx-auto h-12 w-12 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                    <h3 className="text-xl font-bold font-heading mt-4">Analyzing competitors...</h3>
                    <p className="text-text-secondary dark:text-d-text-secondary mt-2">This may take a moment.</p>
                </div>
            )}
            
            {!isLoading && !error && (
                step === 'analysis' && analysisResult ? renderResults() : renderInputForm()
            )}
        </div>
    );
};

export default AICompetitorAnalyzerView;