export interface CampaignConfig {
  campaignName: string;
  timeframe: string;
  contentPillars: string[];
  targetAudience: string;
  goals: string[];
  brandVoice: string;
}

export interface StrategyData {
  platforms: string[];
  postingFrequency: string;
  contentMix: string;
  optimalTimes: boolean;
  hashtagStrategy: string;
  includeVisuals: boolean;
}

export interface CampaignDay {
    day: number;
    theme: string;
    posts: {
        platform: string;
        postContent: string;
        visualSuggestion: string;
        hashtags: string[];
    }[];
}
