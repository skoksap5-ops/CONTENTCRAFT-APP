import React, { useState } from 'react';
import type { CampaignConfig } from './types';

interface CampaignSetupProps {
  onSubmit: (data: CampaignConfig) => void;
  isLoading: boolean;
}

const CampaignSetup: React.FC<CampaignSetupProps> = ({ onSubmit, isLoading }) => {
  const [campaignData, setCampaignData] = useState<CampaignConfig>({
    campaignName: '',
    timeframe: '7d',
    contentPillars: [],
    targetAudience: '',
    goals: [],
    brandVoice: 'friendly'
  });

  // Data for the form options
  const timeframes = [ { id: '7d', name: '1 Week' }, { id: '30d', name: '1 Month' }, { id: '90d', name: '3 Months' } ];
  const contentPillars = [ { id: 'educational', name: 'Educational' }, { id: 'entertaining', name: 'Entertaining' }, { id: 'inspirational', name: 'Inspirational' }, { id: 'promotional', name: 'Promotional' }, { id: 'behind-the-scenes', name: 'Behind the Scenes' }, { id: 'user-generated', name: 'User-Generated' } ];
  const campaignGoals = [ { id: 'awareness', name: 'Brand Awareness' }, { id: 'engagement', name: 'Engagement' }, { id: 'leads', name: 'Lead Generation' }, { id: 'sales', name: 'Sales' } ];
  const brandVoices = [ { id: 'friendly', name: 'Friendly & Casual' }, { id: 'professional', name: 'Professional' }, { id: 'humorous', name: 'Humorous' }, { id: 'inspirational', name: 'Inspirational' } ];

  const handleToggle = (field: 'contentPillars' | 'goals', value: string) => {
    setCampaignData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(id => id !== value)
        : [...prev[field], value]
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (campaignData.campaignName && campaignData.contentPillars.length > 0 && campaignData.goals.length > 0) {
      onSubmit(campaignData);
    }
  };

  const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
  const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2";

  return (
    <div className="animate-fade-in">
      <form onSubmit={handleSubmit} className="space-y-8">
        <div>
          <label htmlFor="campaignName" className={commonLabelClasses}>Campaign Name</label>
          <input id="campaignName" type="text" value={campaignData.campaignName} onChange={(e) => setCampaignData(prev => ({ ...prev, campaignName: e.target.value }))} placeholder="e.g., Summer 2024 Product Launch" required className={commonInputClasses} />
        </div>

        <div>
            <label className={commonLabelClasses}>Timeframe</label>
            <div className="grid grid-cols-3 gap-2 bg-base-100 dark:bg-d-base-100 p-1 rounded-lg">
                {timeframes.map(tf => (
                    <button type="button" key={tf.id} onClick={() => setCampaignData(prev => ({...prev, timeframe: tf.id}))} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${campaignData.timeframe === tf.id ? 'bg-brand-primary text-white shadow' : 'text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-200'}`}>{tf.name}</button>
                ))}
            </div>
        </div>
        
        <div>
            <label className={commonLabelClasses}>Content Pillars (Select 2-4)</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {contentPillars.map(pillar => (
                    <button type="button" key={pillar.id} onClick={() => handleToggle('contentPillars', pillar.id)} className={`p-3 text-sm font-semibold rounded-lg border-2 transition-colors text-left ${campaignData.contentPillars.includes(pillar.id) ? 'border-brand-primary bg-brand-primary/10' : 'bg-base-100 dark:bg-d-base-100 border-transparent'}`}>{pillar.name}</button>
                ))}
            </div>
        </div>

        <div>
            <label className={commonLabelClasses}>Campaign Goals (Select 1-2)</label>
             <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {campaignGoals.map(goal => (
                    <button type="button" key={goal.id} onClick={() => handleToggle('goals', goal.id)} className={`p-3 text-sm font-semibold rounded-lg border-2 transition-colors text-left ${campaignData.goals.includes(goal.id) ? 'border-brand-primary bg-brand-primary/10' : 'bg-base-100 dark:bg-d-base-100 border-transparent'}`}>{goal.name}</button>
                ))}
            </div>
        </div>

        <div>
          <label htmlFor="targetAudience" className={commonLabelClasses}>Target Audience</label>
          <input id="targetAudience" type="text" value={campaignData.targetAudience} onChange={(e) => setCampaignData(prev => ({ ...prev, targetAudience: e.target.value }))} placeholder="e.g., Tech enthusiasts, small business owners" required className={commonInputClasses}/>
        </div>

        <button type="submit" disabled={isLoading} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary disabled:bg-base-300 dark:disabled:bg-d-base-300 transition-all duration-300">
          {isLoading ? 'Saving...' : 'Next: Configure Platform Strategy →'}
        </button>
      </form>
    </div>
  );
};

export default CampaignSetup;
