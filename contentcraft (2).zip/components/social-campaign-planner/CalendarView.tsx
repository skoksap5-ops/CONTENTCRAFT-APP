import React, { useState, useCallback } from 'react';
import type { CampaignConfig, CampaignDay, StrategyData } from './types';
import CopyIcon from '../icons/CopyIcon';
import ChevronDownIcon from '../icons/ChevronDownIcon';
import PlatformIcon from '../PlatformIcon';
import ShareButtons from '../ShareButtons';
import ShareIcon from '../icons/ShareIcon';

interface CalendarViewProps {
  calendar: CampaignDay[];
  config: CampaignConfig & StrategyData;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-xl border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <div className="font-bold text-lg text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</div>
        <ChevronDownIcon className={`h-6 w-6 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 space-y-4 animate-fade-in">
          {children}
        </div>
      )}
    </div>
  );
};

const PostCard: React.FC<{post: CampaignDay['posts'][0]}> = ({ post }) => {
    const [copySuccess, setCopySuccess] = useState(false);
    const [isShareOpen, setIsShareOpen] = useState(false);
    const [notification, setNotification] = useState<string | null>(null);

    const showNotification = useCallback((message: string, duration = 3000) => {
        setNotification(message);
        setTimeout(() => setNotification(null), duration);
    }, []);

    const handleCopy = () => {
        const fullPostContent = `${post.postContent}\n\n${post.hashtags.join(' ')}`;
        navigator.clipboard.writeText(fullPostContent).then(() => {
            setCopySuccess(true);
            setTimeout(() => setCopySuccess(false), 2000);
        });
    };
    return (
        <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg shadow-sm relative group">
            <div className="absolute top-3 right-3 flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10">
                <div className="relative">
                    <button onClick={() => setIsShareOpen(prev => !prev)} className="p-2 rounded-lg bg-base-200 dark:bg-d-base-200" aria-label="Share Post">
                        <ShareIcon className="h-5 w-5" />
                    </button>
                    {isShareOpen && <ShareButtons content={post.postContent} hashtags={post.hashtags} onClose={() => setIsShareOpen(false)} showNotification={showNotification} />}
                </div>
                <button onClick={handleCopy} className="p-2 rounded-lg bg-base-200 dark:bg-d-base-200" aria-label="Copy Post">
                    <CopyIcon className="h-5 w-5" />
                </button>
            </div>

            <div className="flex items-center gap-2 font-bold text-text-primary dark:text-d-text-primary">
                <PlatformIcon platform={post.platform} className="h-6 w-6" />
                {post.platform}
            </div>
            
            <pre className="text-sm text-text-primary dark:text-d-text-primary whitespace-pre-wrap font-sans mt-2">{post.postContent}</pre>
            <p className="text-xs text-text-secondary dark:text-d-text-secondary mt-3 italic">🎨 Visual: {post.visualSuggestion}</p>
            <div className="flex flex-wrap gap-1.5 mt-3">
                {post.hashtags.map((tag, i) => (
                    <span key={i} className="bg-base-200 dark:bg-d-base-200 px-2 py-0.5 rounded text-xs text-brand-primary font-medium">{tag}</span>
                ))}
            </div>
            {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            {notification && (
                <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-gray-900/80 dark:bg-gray-100/80 text-white dark:text-black px-4 py-2 rounded-lg shadow-lg text-sm animate-fade-in-up z-50">
                    {notification}
                </div>
            )}
        </div>
    )
}

const CalendarView: React.FC<CalendarViewProps> = ({ calendar, config }) => {
  return (
    <div className="animate-fade-in space-y-4">
        <h2 className="text-2xl font-bold font-heading text-center">Your {config.timeframe} Campaign for "{config.campaignName}"</h2>
        {calendar.map((day, i) => (
            <Accordion key={day.day} title={<><span>Day {day.day}:</span><span className="font-normal text-text-secondary dark:text-d-text-secondary">{day.theme}</span></>} defaultOpen={i === 0}>
                {day.posts.map((post, j) => <PostCard key={j} post={post} />)}
            </Accordion>
        ))}
    </div>
  );
};

export default CalendarView;
