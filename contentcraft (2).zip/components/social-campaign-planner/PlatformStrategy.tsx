import React, { useState } from 'react';
import type { CampaignConfig, StrategyData } from './types';

interface PlatformStrategyProps {
  config: CampaignConfig;
  onGenerate: (data: StrategyData) => void;
  isLoading: boolean;
}

const PlatformStrategy: React.FC<PlatformStrategyProps> = ({ config, onGenerate, isLoading }) => {
  const [strategyData, setStrategyData] = useState<StrategyData>({
    platforms: ['LinkedIn', 'Twitter'],
    postingFrequency: 'medium',
    contentMix: 'balanced',
    optimalTimes: true,
    hashtagStrategy: 'industry',
    includeVisuals: true
  });
  
  const platforms = [ { id: 'Instagram', icon: '📸' }, { id: 'Facebook', icon: '👥' }, { id: 'Twitter', icon: '🐦' }, { id: 'LinkedIn', icon: '💼' }, { id: 'TikTok', icon: '🎵' }, { id: 'YouTube', icon: '📺' } ];
  
  const handlePlatformToggle = (platformId: string) => {
    setStrategyData(prev => ({
      ...prev,
      platforms: prev.platforms.includes(platformId)
        ? prev.platforms.filter(id => id !== platformId)
        : [...prev.platforms, platformId]
    }));
  };
  
  const handleGenerate = () => {
    onGenerate(strategyData);
  };

  const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2";
  const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
  
  return (
    <div className="animate-fade-in space-y-8">
       <div>
            <label className={commonLabelClasses}>Target Platforms (Select 1-4)</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {platforms.map(p => (
                    <button type="button" key={p.id} onClick={() => handlePlatformToggle(p.id)} className={`p-4 text-lg font-semibold rounded-lg border-2 transition-colors text-center flex flex-col items-center justify-center gap-2 h-24 ${strategyData.platforms.includes(p.id) ? 'border-brand-primary bg-brand-primary/10' : 'bg-base-100 dark:bg-d-base-100 border-base-300 dark:border-d-base-300'}`}>
                        <span className="text-3xl">{p.icon}</span>
                        <span>{p.id}</span>
                    </button>
                ))}
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="postingFrequency" className={commonLabelClasses}>Posting Frequency</label>
                <select id="postingFrequency" value={strategyData.postingFrequency} onChange={e => setStrategyData(prev => ({...prev, postingFrequency: e.target.value}))} className={commonInputClasses}>
                    <option value="light">Light (3-5/week)</option>
                    <option value="medium">Medium (7-12/week)</option>
                    <option value="heavy">Heavy (14-20/week)</option>
                </select>
            </div>
            <div>
                <label htmlFor="contentMix" className={commonLabelClasses}>Content Mix Strategy</label>
                <select id="contentMix" value={strategyData.contentMix} onChange={e => setStrategyData(prev => ({...prev, contentMix: e.target.value}))} className={commonInputClasses}>
                    <option value="balanced">Balanced Mix</option>
                    <option value="educational">Educational Focus (70%)</option>
                    <option value="promotional">Promotional Focus (50%)</option>
                    <option value="engagement">Engagement Focus</option>
                </select>
            </div>
        </div>
      
        <button
          onClick={handleGenerate}
          className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 transition-all"
          disabled={isLoading || strategyData.platforms.length === 0}
        >
          {isLoading ? 'Generating Calendar...' : 'Generate Social Media Calendar 📅'}
        </button>
    </div>
  );
};

export default PlatformStrategy;
