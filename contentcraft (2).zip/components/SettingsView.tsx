import React from 'react';
import { useTheme } from '../hooks/useTheme';
import Switch from './Switch';
import { useSettings, AppSettings } from '../hooks/useSettings';
import { useLanguage } from '../hooks/useLanguage';
import { useFontSize } from '../hooks/useFontSize';
import type { View } from '../types';

// Icons
import NotificationsIcon from './icons/settings/NotificationsIcon';
import EmailIcon from './icons/settings/EmailIcon';
import SparklesIcon from './icons/settings/SparklesIcon';
import MoonIcon from './icons/MoonIcon';
import GlobeAltIcon from './icons/settings/GlobeAltIcon';
import EyeIcon from './icons/settings/EyeIcon';
import AnalyticsIcon from './icons/settings/AnalyticsIcon';
import CrashReportingIcon from './icons/settings/CrashReportingIcon';
import StoreIcon from './icons/settings/StoreIcon';
import LightningIcon from './icons/LightningIcon';
import UploadIcon from './icons/settings/UploadIcon';
import DownloadIcon from './icons/settings/DownloadIcon';
import RefreshIcon from './icons/settings/RefreshIcon';
import CodeBracketIcon from './icons/settings/CodeBracketIcon';
import BetaFeaturesIcon from './icons/settings/BetaFeaturesIcon';
import RestoreIcon from './icons/settings/RestoreIcon';
import HelpIcon from './icons/HelpIcon';
import ShieldIcon from './icons/ShieldIcon';
import StarOutlineIcon from './icons/StarOutlineIcon';
import ShareIcon from './icons/ShareIcon';
import BannerAppIcon from './icons/settings/BannerAppIcon';
import DocumentTextIcon from './icons/DocumentTextIcon';


const SettingsSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <section>
        <h2 className="text-lg font-bold text-text-primary dark:text-d-text-primary mb-4 px-2">{title}</h2>
        <div className="bg-base-200 dark:bg-d-base-200 rounded-xl shadow-sm">
            {children}
        </div>
    </section>
);

const SettingsItem: React.FC<{ 
    icon: React.ReactNode; 
    title: string; 
    subtitle: string; 
    action?: 'toggle' | 'navigate';
    isChecked?: boolean;
    onToggle?: (checked: boolean) => void;
    onClick?: () => void;
}> = ({ icon, title, subtitle, action, isChecked, onToggle, onClick }) => {
    const content = (
        <div className="w-full flex items-center p-4 text-left transition-colors first:rounded-t-xl last:rounded-b-xl border-b border-base-300 dark:border-d-base-300 last:border-b-0">
            <div className="mr-4 text-text-secondary dark:text-d-text-secondary">{icon}</div>
            <div className="flex-grow">
                <h3 className="font-semibold text-text-primary dark:text-d-text-primary">{title}</h3>
                <p className="text-sm text-text-secondary dark:text-d-text-secondary">{subtitle}</p>
            </div>
            {action === 'toggle' && onToggle && (
                <div className="ml-4">
                    <Switch checked={isChecked || false} onChange={onToggle} label={title} />
                </div>
            )}
            {action === 'navigate' && (
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5 text-base-300 dark:text-d-base-300">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                </svg>
            )}
        </div>
    );

    if (action === 'navigate') {
        return (
            <button onClick={onClick || (() => alert(`${title} feature coming soon!`))} className="w-full hover:bg-base-300/50 dark:hover:bg-d-base-300/50 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-brand-primary first:rounded-t-xl last:rounded-b-xl">
                {content}
            </button>
        )
    }
    
    // For toggles, the label itself handles interaction.
    return <div className="relative">{content}</div>;
};


const SettingsView: React.FC<{ setView: (view: View) => void }> = ({ setView }) => {
    const { theme, toggleTheme } = useTheme();
    const { settings, updateSetting } = useSettings();
    const { language, t } = useLanguage();
    const { fontSize } = useFontSize();
    
    const handleToggle = (key: keyof AppSettings) => (checked: boolean) => {
        updateSetting(key, checked);
    };

    const handlePushNotificationsToggle = async (checked: boolean) => {
        if (checked) {
            // User wants to turn notifications ON
            if (!('Notification' in window)) {
                alert("This browser does not support desktop notifications.");
                updateSetting('pushNotifications', false);
                return;
            }

            if (Notification.permission === 'granted') {
                updateSetting('pushNotifications', true);
            } else if (Notification.permission !== 'denied') { // 'default' state, ask for permission
                try {
                    const permission = await Notification.requestPermission();
                    // The state is updated based on the user's choice
                    if (permission === 'granted') {
                        updateSetting('pushNotifications', true);
                        console.log('Notification permission granted.');
                    } else {
                        // User denied or dismissed, so we ensure the setting is OFF
                        updateSetting('pushNotifications', false);
                        console.log('Notification permission was not granted.');
                    }
                } catch (err) {
                    console.error("Error requesting notification permission:", err);
                    updateSetting('pushNotifications', false); // Keep it off if there's an error
                }
            } else { // 'denied' state
                alert('Notification permission has been blocked. Please enable it in your browser settings to receive notifications.');
                // The setting is already false, but ensure it.
                updateSetting('pushNotifications', false);
            }
        } else {
            // User wants to turn notifications OFF
            updateSetting('pushNotifications', false);
        }
    };
    
    const handleExport = () => {
        const allSettings = {
            theme,
            language: language,
            fontSize,
            settings
        };
        const blob = new Blob([JSON.stringify(allSettings, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'contentcraft-settings.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleImport = () => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json,application/json';
        input.onchange = (e) => {
            const file = (e.target as HTMLInputElement).files?.[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (event) => {
                try {
                    const importedData = JSON.parse(event.target?.result as string);
                    
                    if (window.confirm("This will overwrite your current settings and reload the app. Are you sure you want to proceed?")) {
                        if (importedData.theme) localStorage.setItem('theme', importedData.theme);
                        if (importedData.language?.code) localStorage.setItem('language', importedData.language.code);
                        if (importedData.fontSize) localStorage.setItem('fontSize', importedData.fontSize);
                        if (importedData.settings) localStorage.setItem('appSettings', JSON.stringify(importedData.settings));

                        alert("Settings imported successfully! The app will now reload.");
                        window.location.reload();
                    }
                } catch (err) {
                    alert("Failed to import settings. The file may be invalid or corrupted.");
                    console.error("Import error:", err);
                }
            };
            reader.readAsText(file);
        };
        input.click();
    };

    const handleReset = () => {
        if (window.confirm("Are you sure you want to reset all settings to their defaults? This action cannot be undone and the app will reload.")) {
            localStorage.removeItem('appSettings');
            localStorage.removeItem('language');
            localStorage.removeItem('fontSize');
            localStorage.removeItem('theme');
            alert("Settings have been reset. The app will now reload.");
            window.location.reload();
        }
    };


    const fontSizeLabel = {
        sm: t('small'),
        md: t('medium'),
        lg: t('large'),
    };

    return (
        <div className="max-w-4xl mx-auto flex flex-col gap-10 animate-fade-in pb-12">
            <div className="text-center">
                <h1 className="text-4xl font-bold font-heading">Settings</h1>
            </div>

            <SettingsSection title={t('notifications')}>
                <SettingsItem 
                    icon={<NotificationsIcon className="h-6 w-6"/>} 
                    title={t('pushNotifications')} 
                    subtitle={t('pushNotificationsSub')} 
                    action="toggle" 
                    isChecked={settings.pushNotifications} 
                    onToggle={handlePushNotificationsToggle} 
                />
                <SettingsItem 
                    icon={<EmailIcon className="h-6 w-6"/>} 
                    title={t('emailUpdates')} 
                    subtitle={t('emailUpdatesSub')} 
                    action="toggle" 
                    isChecked={settings.emailUpdates} 
                    onToggle={handleToggle('emailUpdates')} 
                />
                <SettingsItem 
                    icon={<SparklesIcon className="h-6 w-6"/>} 
                    title={t('marketingEmails')} 
                    subtitle={t('marketingEmailsSub')} 
                    action="toggle" 
                    isChecked={settings.marketingEmails} 
                    onToggle={handleToggle('marketingEmails')} 
                />
            </SettingsSection>
            
            <SettingsSection title={t('display')}>
                <SettingsItem icon={<MoonIcon className="h-6 w-6"/>} title={t('darkMode')} subtitle="Switch to dark theme" action="toggle" isChecked={theme === 'dark'} onToggle={() => toggleTheme()} />
                <SettingsItem icon={<GlobeAltIcon className="h-6 w-6"/>} title={t('language')} subtitle={language.name} action="navigate" onClick={() => setView('language')} />
                <SettingsItem 
                    icon={<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-6 w-6"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-12.75 5.25h12.75" /></svg>} 
                    title={t('fontSize')} 
                    subtitle={fontSizeLabel[fontSize]} 
                    action="navigate" 
                    onClick={() => setView('fontSize')} 
                />
                <SettingsItem icon={<EyeIcon className="h-6 w-6"/>} title={t('compactMode')} subtitle="Reduce spacing and padding" action="toggle" isChecked={settings.compactMode} onToggle={handleToggle('compactMode')} />
            </SettingsSection>

            <SettingsSection title={t('privacySecurity')}>
                <SettingsItem icon={<AnalyticsIcon className="h-6 w-6"/>} title={t('analytics')} subtitle={t('analyticsSub')} action="toggle" isChecked={settings.analytics} onToggle={handleToggle('analytics')} />
                <SettingsItem icon={<CrashReportingIcon className="h-6 w-6"/>} title={t('crashReporting')} subtitle={t('crashReportingSub')} action="toggle" isChecked={settings.crashReporting} onToggle={handleToggle('crashReporting')} />
            </SettingsSection>

            <SettingsSection title={t('asoPreferences')}>
                <SettingsItem icon={<StoreIcon className="h-6 w-6"/>} title={t('defaultStore')} subtitle="iOS & Android" action="navigate" />
                <SettingsItem icon={<LightningIcon className="h-6 w-6"/>} title={t('autoOptimize')} subtitle="Automatically optimize content" action="toggle" isChecked={settings.autoOptimize} onToggle={handleToggle('autoOptimize')} />
                <SettingsItem icon={<SparklesIcon className="h-6 w-6"/>} title={t('keywordSuggestions')} subtitle="Show keyword recommendations" action="toggle" isChecked={settings.keywordSuggestions} onToggle={handleToggle('keywordSuggestions')} />
            </SettingsSection>

            <SettingsSection title={t('advanced')}>
                <SettingsItem icon={<UploadIcon className="h-6 w-6"/>} title={t('exportPreferences')} subtitle={t('exportPreferencesSub')} action="navigate" onClick={handleExport} />
                <SettingsItem icon={<DownloadIcon className="h-6 w-6"/>} title={t('importPreferences')} subtitle={t('importPreferencesSub')} action="navigate" onClick={handleImport} />
                <SettingsItem icon={<RefreshIcon className="h-6 w-6"/>} title={t('resetPreferences')} subtitle={t('resetPreferencesSub')} action="navigate" onClick={handleReset} />
                <SettingsItem icon={<CodeBracketIcon className="h-6 w-6"/>} title={t('developerMode')} subtitle="Enable advanced debugging" action="toggle" isChecked={settings.developerMode} onToggle={handleToggle('developerMode')} />
                <SettingsItem icon={<BetaFeaturesIcon className="h-6 w-6"/>} title={t('betaFeatures')} subtitle="Try experimental features" action="toggle" isChecked={settings.betaFeatures} onToggle={handleToggle('betaFeatures')} />
            </SettingsSection>
            
            <SettingsSection title={t('legal')}>
                <SettingsItem icon={<ShieldIcon className="h-6 w-6"/>} title={t('privacyPolicy')} subtitle="Read our privacy policy" action="navigate" onClick={() => setView('privacy')} />
                <SettingsItem icon={<DocumentTextIcon className="h-6 w-6"/>} title={t('termsOfService')} subtitle="Read our terms of service" action="navigate" onClick={() => setView('terms')} />
            </SettingsSection>

            <SettingsSection title={t('support')}>
                <SettingsItem icon={<RestoreIcon className="h-6 w-6"/>} title={t('restorePurchases')} subtitle="Restore previous purchases" action="navigate" />
                <SettingsItem icon={<HelpIcon className="h-6 w-6"/>} title={t('helpSupport')} subtitle="Get help and contact support" action="navigate" onClick={() => setView('helpFromSettings')}/>
                <SettingsItem icon={<StarOutlineIcon className="h-6 w-6"/>} title={t('rateApp')} subtitle="Rate us on the App Store" action="navigate" onClick={() => window.open('https://play.google.com/store/apps/details?id=com.novasky.contentcraft', '_blank', 'noopener,noreferrer')} />
                <SettingsItem icon={<ShareIcon className="h-6 w-6"/>} title={t('shareApp')} subtitle="Tell your friends about Content Craft" action="navigate" onClick={() => setView('share')} />
                <SettingsItem icon={<BannerAppIcon className="h-6 w-6"/>} title={t('bannerApp')} subtitle="View promotional banner design" action="navigate" onClick={() => setView('banner')} />
            </SettingsSection>

            <footer className="text-center text-sm text-text-secondary dark:text-d-text-secondary pb-8">
                <p>Content Craft v1.0.0</p>
                <p>Made with ❤️ for content creators</p>
            </footer>
        </div>
    );
};

export default SettingsView;