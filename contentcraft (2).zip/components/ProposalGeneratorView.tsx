import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ToneSelector from './ToneSelector';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type ProjectType = 'Service' | 'Product' | 'Partnership' | 'Consulting' | 'Grant';
type ProposalPurpose = 'New Business' | 'Retention' | 'Upsell' | 'Renewal';
type BudgetRange = 'Under $10K' | '$10K-50K' | '$50K-100K' | '$100K+';
type RelationshipStage = 'New Client' | 'Existing' | 'Referral' | 'RFP';

const PROPOSAL_GENERATOR_PROMPT = `
You are an expert business proposal strategist and professional writer. Create comprehensive, persuasive business proposals that win contracts, secure funding, and build lasting client relationships.

**INPUT:**
- Client/Company: {CLIENT_COMPANY}
- Project Details & Offered Services: {PROJECT_DETAILS}
- Project Type: {PROJECT_TYPE}
- Proposal Purpose: {PROPOSAL_PURPOSE}
- Budget Range: {BUDGET_RANGE}
- Relationship Stage: {RELATIONSHIP_STAGE}
- Tone: {SELECTED_TONES}

**COMPREHENSIVE PROPOSAL CREATION:**

## 1. PROPOSAL STRATEGY FRAMEWORK
### A. CLIENT-CENTRIC APPROACH
**UNDERSTANDING CLIENT NEEDS:**
- Business objectives and pain points
- Decision-maker priorities and concerns
- Budget constraints and ROI expectations
- Timeline and urgency factors
- Competitive landscape considerations
### B. VALUE PROPOSITION DEVELOPMENT
**DIFFERENTIATION STRATEGY:**
- Unique solution benefits
- Competitive advantage highlighting
- ROI and value demonstration
- Risk mitigation assurances
- Long-term partnership value

## 2. PROFESSIONAL PROPOSAL STRUCTURE
### A. EXECUTIVE SUMMARY
### B. PROBLEM ANALYSIS
### C. PROPOSED SOLUTION
### D. SCOPE OF WORK
### E. TIMELINE & MILESTONES
### F. INVESTMENT & PRICING
### G. COMPANY OVERVIEW
### H. TERMS & CONDITIONS

## 3. PERSUASIVE ELEMENTS INTEGRATION
### A. SOCIAL PROOF & CREDIBILITY
### B. ROI DEMONSTRATION
### C. RISK MITIGATION

## 4. CLIENT-SPECIFIC CUSTOMIZATION
### A. INDUSTRY ADAPTATION
### B. DECISION-MAKER ALIGNMENT
`;

interface ParsedProposalSection {
    executiveSummary: string;
    problemAnalysis: string;
    proposedSolution: string;
    scopeOfWork: string;
    timeline: string;
    investment: string;
    companyOverview: string;
    terms: string;
}

interface ParsedOutput {
    proposal: ParsedProposalSection;
    strategyFramework: string;
    persuasiveElements: string;
    customization: string;
}


const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const ProposalGeneratorView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [clientCompany, setClientCompany] = useState('');
    const [projectDetails, setProjectDetails] = useState('');
    const [projectType, setProjectType] = useState<ProjectType>('Service');
    const [proposalPurpose, setProposalPurpose] = useState<ProposalPurpose>('New Business');
    const [budgetRange, setBudgetRange] = useState<BudgetRange>('$10K-50K');
    const [relationshipStage, setRelationshipStage] = useState<RelationshipStage>('New Client');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && clientCompany.trim() && projectDetails.trim();
    
    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string, source = text) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = source.match(regex);
                return match ? match[1].trim() : 'Could not parse this section.';
            };
            
            const proposalStructure = getSection('## 2. PROFESSIONAL PROPOSAL STRUCTURE', '## 3. PERSUASIVE ELEMENTS INTEGRATION');

            return {
                strategyFramework: getSection('## 1. PROPOSAL STRATEGY FRAMEWORK', '## 2. PROFESSIONAL PROPOSAL STRUCTURE'),
                proposal: {
                    executiveSummary: getSection('### A. EXECUTIVE SUMMARY', '### B. PROBLEM ANALYSIS', proposalStructure),
                    problemAnalysis: getSection('### B. PROBLEM ANALYSIS', '### C. PROPOSED SOLUTION', proposalStructure),
                    proposedSolution: getSection('### C. PROPOSED SOLUTION', '### D. SCOPE OF WORK', proposalStructure),
                    scopeOfWork: getSection('### D. SCOPE OF WORK', '### E. TIMELINE & MILESTONES', proposalStructure),
                    timeline: getSection('### E. TIMELINE & MILESTONES', '### F. INVESTMENT & PRICING', proposalStructure),
                    investment: getSection('### F. INVESTMENT & PRICING', '### G. COMPANY OVERVIEW', proposalStructure),
                    companyOverview: getSection('### G. COMPANY OVERVIEW', '### H. TERMS & CONDITIONS', proposalStructure),
                    terms: getSection('### H. TERMS & CONDITIONS', '$', proposalStructure),
                },
                persuasiveElements: getSection('## 3. PERSUASIVE ELEMENTS INTEGRATION', '## 4. CLIENT-SPECIFIC CUSTOMIZATION'),
                customization: getSection('## 4. CLIENT-SPECIFIC CUSTOMIZATION', '$'),
            };
        } catch (e) {
            console.error("Failed to parse Proposal Generator output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return PROPOSAL_GENERATOR_PROMPT
            .replace('{CLIENT_COMPANY}', clientCompany)
            .replace('{PROJECT_DETAILS}', projectDetails)
            .replace('{PROJECT_TYPE}', projectType)
            .replace('{PROPOSAL_PURPOSE}', proposalPurpose)
            .replace('{BUDGET_RANGE}', budgetRange)
            .replace('{RELATIONSHIP_STAGE}', relationshipStage)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [clientCompany, projectDetails, projectType, proposalPurpose, budgetRange, relationshipStage, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/^###\s*[A-Z]\.\s*(.*)/gm, '<h4 class="text-lg font-semibold text-text-primary dark:text-d-text-primary mt-6 mb-3 font-heading border-l-4 border-brand-primary pl-3">$1</h4>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };
    
    const ProposalSection: React.FC<{ title: string; content: string; icon: string }> = ({ title, icon, content }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!content) return;
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = content.replace(/<br \/>/g, '\n');
            navigator.clipboard.writeText(tempDiv.textContent || "").then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!content || content.toLowerCase().includes('could not parse')) return null;
        return (
            <div className="relative group">
                <button onClick={handleCopy} className="absolute top-4 right-4 p-2 rounded-lg bg-base-300/50 dark:bg-d-base-300/50 opacity-0 group-hover:opacity-100 transition-opacity" aria-label={`Copy ${title}`}>
                    {copySuccess ? 'Copied!' : <CopyIcon className="h-5 w-5" />}
                </button>
                <div dangerouslySetInnerHTML={formatContent(`### A. ${title}\n${content}`)} />
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <div>
                        <label className={commonLabelClasses}>Client/Company Name</label>
                        <input value={clientCompany} onChange={e => setClientCompany(e.target.value)} placeholder="e.g., GlobalTech Solutions" className={commonInputClasses} />
                    </div>
                    <textarea value={projectDetails} onChange={e => setProjectDetails(e.target.value)} placeholder="Describe the client's needs, project goals, and services you are offering..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Proposal Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Project Type</label>
                                <select value={projectType} onChange={e => setProjectType(e.target.value as ProjectType)} className={commonInputClasses}>
                                    <option>Service</option><option>Product</option><option>Partnership</option><option>Consulting</option><option>Grant</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Proposal Purpose</label>
                                <select value={proposalPurpose} onChange={e => setProposalPurpose(e.target.value as ProposalPurpose)} className={commonInputClasses}>
                                    <option>New Business</option><option>Retention</option><option>Upsell</option><option>Renewal</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Budget Range</label>
                                <select value={budgetRange} onChange={e => setBudgetRange(e.target.value as BudgetRange)} className={commonInputClasses}>
                                    <option>Under $10K</option><option>$10K-50K</option><option>$50K-100K</option><option>$100K+</option>
                                </select>
                            </div>
                             <div>
                                <label className={commonLabelClasses}>Relationship Stage</label>
                                <select value={relationshipStage} onChange={e => setRelationshipStage(e.target.value as RelationshipStage)} className={commonInputClasses}>
                                    <option>New Client</option><option>Existing</option><option>Referral</option><option>RFP</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Generating Proposal...' : (isQueued ? 'Request Queued' : 'Generate Proposal')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && (clientCompany.trim() || projectDetails.trim()) && <p className="text-center text-yellow-500 text-sm mt-2">Please fill in Client Name and Project Details.</p>}
                </div>
                <div className="bg-base-100 dark:bg-d-base-100 rounded-lg p-6 min-h-[500px] overflow-y-auto shadow-inner prose prose-sm dark:prose-invert max-w-none">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Building your professional proposal...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your comprehensive business proposal will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-8">
                            <div>
                                <h2 className="text-2xl font-bold font-heading">PROFESSIONAL PROPOSAL</h2>
                                <p className="lead">For: {clientCompany}</p>
                            </div>
                            <ProposalSection title="Executive Summary" icon="🎯" content={parsedOutput.proposal.executiveSummary} />
                            <ProposalSection title="Problem Analysis" icon="🔍" content={parsedOutput.proposal.problemAnalysis} />
                            <ProposalSection title="Proposed Solution" icon="💡" content={parsedOutput.proposal.proposedSolution} />
                            <ProposalSection title="Scope of Work" icon="📋" content={parsedOutput.proposal.scopeOfWork} />
                            <ProposalSection title="Timeline & Milestones" icon="📅" content={parsedOutput.proposal.timeline} />
                            <ProposalSection title="Investment & Pricing" icon="💰" content={parsedOutput.proposal.investment} />
                            <ProposalSection title="Company Overview" icon="🏆" content={parsedOutput.proposal.companyOverview} />
                            <ProposalSection title="Terms & Conditions" icon="⚖️" content={parsedOutput.proposal.terms} />
                            
                            <div className="space-y-2 pt-8">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-4">Strategy & Analysis</h3>
                                <Accordion title={<>📊 <span className="ml-2">Proposal Strategy Framework</span></>} defaultOpen={true}><div dangerouslySetInnerHTML={formatContent(parsedOutput.strategyFramework)}/></Accordion>
                                <Accordion title={<>✨ <span className="ml-2">Persuasive Elements</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.persuasiveElements)}/></Accordion>
                                <Accordion title={<>🎯 <span className="ml-2">Client-Specific Customization</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.customization)}/></Accordion>
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default ProposalGeneratorView;