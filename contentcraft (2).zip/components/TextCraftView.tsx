import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type EnhancementGoal = 'Clarity' | 'Engagement' | 'Professionalism' | 'Persuasion' | 'Creativity' | 'All';
type TargetAudience = 'General' | 'Technical' | 'Business' | 'Academic' | 'Creative';
type DesiredImpact = 'Inform' | 'Persuade' | 'Entertain' | 'Inspire' | 'Educate';
type EnhancementLevel = 'Subtle' | 'Moderate' | 'Transformative';

const TEXT_CRAFT_PROMPT = `
You are a master writing craftsman and text enhancement specialist. Transform ordinary text into extraordinary writing through comprehensive refinement, stylistic elevation, and creative enhancement.

**INPUT:**
- Original Text: {USER_TEXT}
- Enhancement Goal: {ENHANCEMENT_GOAL}
- Target Audience: {TARGET_AUDIENCE}
- Desired Impact: {DESIRED_IMPACT}
- Tone Selection: {SELECTED_TONES}
- Enhancement Level: {ENHANCEMENT_LEVEL}

**COMPREHENSIVE TEXT ENHANCEMENT:**

## 1. MULTI-DIMENSIONAL ANALYSIS

**WRITING QUALITY ASSESSMENT:**
- **Originality Score**: [X]/100 - Freshness and uniqueness
- **Engagement Quotient**: [X]/100 - Reader captivation potential
- **Clarity Index**: [X]/100 - Ease of understanding
- **Impact Potential**: [X]/100 - Memorable and actionable
- **Style Cohesion**: [X]/100 - Consistent voice and tone

**LINGUISTIC ANALYSIS:**
- Vocabulary Sophistication: [Basic/Intermediate/Advanced/Expert]
- Sentence Architecture: [Simple/Complex/Artistic]
- Rhythmic Flow: [Monotonous/Varied/Musical]
- Emotional Resonance: [Low/Medium/High/Intense]

## 2. ENHANCEMENT STRATEGIES APPLIED

### A. STRUCTURAL ENHANCEMENTS
**PARAGRAPH CRAFTING:**
- Topic sentence optimization
- Logical flow restructuring
- Transition sophistication
- Pacing and rhythm adjustment

**SENTENCE SCULPTING:**
- Varied sentence lengths and structures
- Power position optimization (beginning/end emphasis)
- Parallel structure implementation
- Fragment usage for dramatic effect

### B. LINGUISTIC ELEVATION
**VOCABULARY ENRICHMENT:**
- Precise word substitution
- Sensory and evocative language
- Domain-specific terminology
- Metaphor and simile integration

**STYLISTIC FLOURISHES:**
- Alliteration and assonance
- Rhetorical device implementation
- Voice and perspective refinement
- Cadence and musicality enhancement

### C. EMOTIONAL OPTIMIZATION
**TONE PERFECTION:**
- Emotional arc development
- Reader connection strengthening
- Authentic voice preservation
- Desired tone alignment

## 3. ENHANCED VERSION SUITE

**POLISHED VERSION** (Professional Refinement):
[Text with structural and linguistic improvements while preserving core message]

**ENGAGING VERSION** (Reader-Centric):
[Text optimized for maximum engagement and memorability]

**IMPACT VERSION** (Persuasive Power):
[Text crafted for maximum influence and action motivation]

**ARTISTIC VERSION** (Creative Excellence):
[Text elevated with literary devices and creative expression]

## 4. CRAFTING TECHNIQUES APPLIED

🔧 **STRUCTURAL TECHNIQUES:**
1. **The Inverted Pyramid**: [Key information first]
2. **Narrative Arc**: [Beginning-middle-end flow]
3. **Power of Three**: [Rule of three implementation]
4. **Call-and-Response**: [Question-answer patterning]

🎨 **STYLISTIC TECHNIQUES:**
1. **Show, Don't Tell**: [Descriptive vs declarative]
2. **Active Voice Dominance**: [Energy and directness]
3. **Sensory Language**: [Sight, sound, touch, taste, smell]
4. **Metaphorical Thinking**: [Concept comparison]

💫 **EMOTIONAL TECHNIQUES:**
1. **Empathy Building**: [Reader connection]
2. **Suspense Creation**: [Information pacing]
3. **Credibility Establishment**: [Authority and trust]
4. **Inspiration Generation**: [Aspirational language]

## 5. WRITING CRAFT INSIGHTS

**ORIGINAL WRITING FINGERPRINT:**
- Dominant Strengths: [3-5 inherent qualities]
- Unique Voice Elements: [Distinctive characteristics]
- Natural Rhythms: [Inherent flow patterns]
- Authentic Expressions: [Genuine voice markers]

**ENHANCEMENT IMPACT ANALYSIS:**
- Readability Improvement: [+X%]
- Engagement Boost: [+X%]
- Professional Polish: [+X%]
- Memorability Increase: [+X%]

**PERSONALIZED CRAFTING GUIDE:**
1. **Immediate Application**: [3 techniques to use now]
2. **Practice Exercises**: [2 daily writing drills]
3. **Mastery Path**: [Progressive skill development]
4. **Style Evolution**: [Long-term writing growth]
`;

interface ParsedOutput {
    analysis: string;
    strategies: string;
    versions: {
        polished: string;
        engaging: string;
        impact: string;
        artistic: string;
    };
    techniques: string;
    insights: string;
}

const Accordion: React.FC<{ title: string; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};

const TextCraftView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    // Specific inputs
    const [enhancementGoal, setEnhancementGoal] = useState<EnhancementGoal>('All');
    const [targetAudience, setTargetAudience] = useState<TargetAudience>('General');
    const [desiredImpact, setDesiredImpact] = useState<DesiredImpact>('Inform');
    const [enhancementLevel, setEnhancementLevel] = useState<EnhancementLevel>('Moderate');

    const [tones, setTones] = useState<string[]>([]);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();

    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            // FIX: Modified getSection to accept a third argument `sourceText`. This allows searching
            // within a subsection of the full text, resolving the "Expected 2 arguments, but got 3" error.
            const getSection = (start: string, end: string, sourceText = text) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'i');
                const match = sourceText.match(regex);
                return match ? match[1].trim() : '';
            };

            const versionsText = getSection('## 3. ENHANCED VERSION SUITE', '## 4. CRAFTING TECHNIQUES APPLIED');

            return {
                analysis: getSection('## 1. MULTI-DIMENSIONAL ANALYSIS', '## 2. ENHANCEMENT STRATEGIES APPLIED'),
                strategies: getSection('## 2. ENHANCEMENT STRATEGIES APPLIED', '## 3. ENHANCED VERSION SUITE'),
                versions: {
                    polished: getSection('\\*\\*POLISHED VERSION\\*\\*', '\\*\\*ENGAGING VERSION\\*\\*', versionsText),
                    engaging: getSection('\\*\\*ENGAGING VERSION\\*\\*', '\\*\\*IMPACT VERSION\\*\\*', versionsText),
                    impact: getSection('\\*\\*IMPACT VERSION\\*\\*', '\\*\\*ARTISTIC VERSION\\*\\*', versionsText),
                    artistic: getSection('\\*\\*ARTISTIC VERSION\\*\\*', '$', versionsText), // To end of section
                },
                techniques: getSection('## 4. CRAFTING TECHNIQUES APPLIED', '## 5. WRITING CRAFT INSIGHTS'),
                insights: getSection('## 5. WRITING CRAFT INSIGHTS', '$'), // To end of string
            };
        } catch (e) {
            console.error("Failed to parse Text Craft output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return TEXT_CRAFT_PROMPT
            .replace('{USER_TEXT}', input)
            .replace('{ENHANCEMENT_GOAL}', enhancementGoal)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{DESIRED_IMPACT}', desiredImpact)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified')
            .replace('{ENHANCEMENT_LEVEL}', enhancementLevel);
    }, [input, enhancementGoal, targetAudience, desiredImpact, tones, enhancementLevel]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') {
                    const permission = await Notification.requestPermission();
                    if (permission !== 'granted') throw new Error("Notification permission denied.");
                }
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);
    
    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        const sanitized = text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
        let html = sanitized
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/\n- (.*$)/gm, '\n<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />');

        html = html.replace(/<br \/>(<li)/g, '$1').replace(/(<\/li>)<br \/>/g, '$1');
        if (html.includes('<li')) {
            html = `<ul>${html.replace(/<br \/>/g, '')}</ul>`;
        }
        
        return { __html: html.replace(/<br \/>\s*<br \/>/g, '<br />') }; // clean up extra breaks
    };

    const VersionCard: React.FC<{ title: string; emoji: string; description: string; content: string; }> = ({ title, emoji, description, content }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            navigator.clipboard.writeText(content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };
        if (!content) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative">
                <div className="flex justify-between items-start mb-2">
                    <div>
                        <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary flex items-center gap-2">
                            <span className="text-xl">{emoji}</span> {title}
                        </h4>
                        <p className="text-xs text-text-secondary dark:text-d-text-secondary">{description}</p>
                    </div>
                     <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${title}`}>
                        <CopyIcon className="h-5 w-5" />
                    </button>
                </div>
                <p className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed">{content.replace(/^\(.*\):\s*/, '')}</p>
                {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[250px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
            <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
                <div className="text-center">
                    <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                    <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                    <div className="space-y-4">
                        <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter your text to transform..." className={commonTextareaClasses} />
                        
                        <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className={commonLabelClasses}>Enhancement Goal</label>
                                    <select value={enhancementGoal} onChange={e => setEnhancementGoal(e.target.value as EnhancementGoal)} className={commonInputClasses}>
                                        <option>All</option><option>Clarity</option><option>Engagement</option><option>Professionalism</option><option>Persuasion</option><option>Creativity</option>
                                    </select>
                                </div>
                                <div>
                                    <label className={commonLabelClasses}>Target Audience</label>
                                    <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as TargetAudience)} className={commonInputClasses}>
                                        <option>General</option><option>Technical</option><option>Business</option><option>Academic</option><option>Creative</option>
                                    </select>
                                </div>
                                <div>
                                    <label className={commonLabelClasses}>Desired Impact</label>
                                    <select value={desiredImpact} onChange={e => setDesiredImpact(e.target.value as DesiredImpact)} className={commonInputClasses}>
                                        <option>Inform</option><option>Persuade</option><option>Entertain</option><option>Inspire</option><option>Educate</option>
                                    </select>
                                </div>
                                <div>
                                    <label className={commonLabelClasses}>Enhancement Level</label>
                                    <select value={enhancementLevel} onChange={e => setEnhancementLevel(e.target.value as EnhancementLevel)} className={commonInputClasses}>
                                        <option>Subtle</option><option>Moderate</option><option>Transformative</option>
                                    </select>
                                </div>
                           </div>
                        </div>

                        <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                            <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                        </button>
                        
                        <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                            {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                            {isLoading ? 'Crafting...' : (isQueued ? 'Request Queued' : 'Craft Text')}
                        </button>
                        {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                        {!canGenerate && !isQueued && input.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                    </div>
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                        {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Crafting your enhanced text...</p>}
                        {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your AI-crafted text suite will appear here.</p>}
                        {parsedOutput ? (
                            <div className="space-y-6">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Enhanced Version Suite</h3>
                                <div className="space-y-4">
                                    <VersionCard title="Polished Version" emoji="🎯" description="Professional Refinement" content={parsedOutput.versions.polished} />
                                    <VersionCard title="Engaging Version" emoji="🚀" description="Reader-Centric" content={parsedOutput.versions.engaging} />
                                    <VersionCard title="Impact Version" emoji="💥" description="Persuasive Power" content={parsedOutput.versions.impact} />
                                    <VersionCard title="Artistic Version" emoji="🎨" description="Creative Excellence" content={parsedOutput.versions.artistic} />
                                </div>
                                <div className="space-y-2 pt-4">
                                     <Accordion title="Multi-Dimensional Analysis"><div dangerouslySetInnerHTML={formatContent(parsedOutput.analysis)}/></Accordion>
                                     <Accordion title="Enhancement Strategies Applied"><div dangerouslySetInnerHTML={formatContent(parsedOutput.strategies)}/></Accordion>
                                     <Accordion title="Crafting Techniques Applied"><div dangerouslySetInnerHTML={formatContent(parsedOutput.techniques)}/></Accordion>
                                     <Accordion title="Writing Craft Insights"><div dangerouslySetInnerHTML={formatContent(parsedOutput.insights)}/></Accordion>
                                </div>
                            </div>
                        ) : (
                            !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div>
                        )}
                    </div>
                </div>
                {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
            </div>
            <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default TextCraftView;
