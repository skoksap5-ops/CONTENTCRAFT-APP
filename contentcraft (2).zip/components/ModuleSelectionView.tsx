import React, { useState, useMemo } from 'react';
import { MODULES, MODULE_GROUPS } from '../constants';
import type { Module } from '../types';
import CloseIcon from './icons/CloseIcon';

interface ModuleSelectionViewProps {
  onSelectModule: (moduleName: string) => void;
  onClose: () => void;
}

const ModuleSelectionView: React.FC<ModuleSelectionViewProps> = ({ onSelectModule, onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const groupedModules = useMemo(() => {
    const allGrouped = Object.values(MODULE_GROUPS).map(groupName => ({
      groupName,
      modules: MODULES.filter(m => m.group === groupName),
    }));
    return allGrouped;
  }, []);

  const filteredAndGroupedModules = useMemo(() => {
    if (!searchTerm.trim()) {
      return groupedModules;
    }

    const lowerCaseSearchTerm = searchTerm.toLowerCase();
    const filtered = MODULES.filter(m => 
      m.name.toLowerCase().includes(lowerCaseSearchTerm) || 
      m.description.toLowerCase().includes(lowerCaseSearchTerm)
    );
    
    // Group the filtered results
    const searchResultGroups: { groupName: string; modules: Module[] }[] = [];
    groupedModules.forEach(group => {
        const matchingModules = group.modules.filter(m => filtered.includes(m));
        if (matchingModules.length > 0) {
            searchResultGroups.push({ groupName: group.groupName, modules: matchingModules });
        }
    });

    return searchResultGroups;

  }, [searchTerm, groupedModules]);

  return (
    <div className="fixed inset-0 bg-base-100/80 dark:bg-d-base-100/80 backdrop-blur-sm z-50 flex flex-col" role="dialog" aria-modal="true">
      <header className="flex-shrink-0 bg-base-200/80 dark:bg-d-base-200/80 border-b border-base-300 dark:border-d-base-300 sticky top-0">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16 gap-4">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search for a module..."
              className="w-full bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-brand-primary"
            />
             <button
                onClick={onClose}
                className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-300 dark:hover:bg-d-base-300 hover:text-text-primary dark:hover:text-d-text-primary transition-colors"
                aria-label="Close module selector"
              >
                <CloseIcon className="h-6 w-6" />
              </button>
          </div>
      </header>

      <div className="flex-grow overflow-y-auto">
        <div className="max-w-4xl mx-auto space-y-8 p-4 sm:p-6 lg:p-8">
          {filteredAndGroupedModules.length > 0 ? filteredAndGroupedModules.map(({ groupName, modules }) => (
            <section key={groupName}>
              <h3 className="text-lg font-semibold text-text-secondary dark:text-d-text-secondary mb-4">{groupName}</h3>
              <div className="space-y-2">
                {modules.map(module => (
                   <button
                    key={module.id}
                    onClick={() => onSelectModule(module.name)}
                    className="w-full flex items-center p-3 text-left rounded-lg bg-base-200 dark:bg-d-base-200 hover:bg-base-300/70 dark:hover:bg-d-base-300/70 border border-base-300 dark:border-d-base-300 hover:border-brand-primary transition-all duration-200"
                  >
                    <div className="w-10 h-10 flex-shrink-0 mr-4 bg-brand-primary/10 rounded-lg flex items-center justify-center text-xl text-brand-primary font-bold">
                        {module.name.charAt(0)}
                    </div>
                    <div>
                        <h4 className="font-semibold text-text-primary dark:text-d-text-primary">{module.name}</h4>
                        <p className="text-xs text-text-secondary dark:text-d-text-secondary">{module.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )) : (
            <div className="text-center py-16">
                <p className="text-text-secondary dark:text-d-text-secondary">No modules found for "{searchTerm}".</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ModuleSelectionView;