import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type TargetAudience = 'Investors' | 'Customers' | 'Partners' | 'Accelerators';
type PitchDuration = '30-sec' | '1-min' | '3-min' | '5-min' | 'Full Deck';
type Industry = 'Tech/SaaS' | 'HealthTech' | 'FinTech' | 'E-commerce' | 'Other';
type Stage = 'Idea' | 'Pre-seed' | 'Seed' | 'Series A' | 'Growth';
type Urgency = 'Normal' | 'High' | 'Very High';

const pitchSchema = {
    type: Type.OBJECT,
    properties: {
        fundamentalsAnalysis: { type: Type.STRING, description: "Markdown-formatted analysis of problem, solution, market, etc." },
        elevatorPitch: { type: Type.STRING, description: "The full text of the 30-second elevator pitch." },
        investorPitch: { type: Type.STRING, description: "The full text of the 3-minute investor pitch script." },
        pitchDeckOutline: { type: Type.STRING, description: "Markdown-formatted list of slides for a full pitch deck." },
        audienceTailoring: { type: Type.STRING, description: "Markdown-formatted notes on tailoring the pitch for different audiences." },
        enhancementTechniques: { type: Type.STRING, description: "Markdown-formatted notes on storytelling and data-driven persuasion." },
        deliveryOptimization: { type: Type.STRING, description: "Markdown-formatted notes on delivery and visuals." },
        industryPitching: { type: Type.STRING, description: "Markdown-formatted notes on industry-specific angles." },
        fundingStrategy: { type: Type.STRING, description: "Markdown-formatted notes on funding strategy." },
    },
    required: ['fundamentalsAnalysis', 'elevatorPitch', 'investorPitch', 'pitchDeckOutline', 'audienceTailoring', 'enhancementTechniques', 'deliveryOptimization', 'industryPitching', 'fundingStrategy']
};

interface ParsedOutput {
    fundamentalsAnalysis: string;
    elevatorPitch: string;
    investorPitch: string;
    pitchDeckOutline: string;
    audienceTailoring: string;
    enhancementTechniques: string;
    deliveryOptimization: string;
    industryPitching: string;
    fundingStrategy: string;
}


const STARTUP_PITCH_PROMPT = `
You are a seasoned venture capitalist and startup pitch coach. Your primary task is to generate a comprehensive pitch package based on the user's input.

**INPUT:**
- Startup Concept: {STARTUP_CONCEPT}
- Target Audience: {TARGET_AUDIENCE}
- Pitch Duration: {PITCH_DURATION}
- Industry: {INDUSTRY}
- Stage: {STAGE}
- Urgency Level: {URGENCY}

**INSTRUCTIONS:**
Your response MUST be a valid JSON object conforming to the provided schema.
- For all markdown string fields, provide detailed analysis and structure the content with headings (###) and bullet points (•).
- The 'elevatorPitch' and 'investorPitch' fields MUST contain the complete, ready-to-use scripts. This is the most important part. Ensure they are fully written out.
`;

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const StartupPitchView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [concept, setConcept] = useState('');
    const [targetAudience, setTargetAudience] = useState<TargetAudience>('Investors');
    const [pitchDuration, setPitchDuration] = useState<PitchDuration>('3-min');
    const [industry, setIndustry] = useState<Industry>('Tech/SaaS');
    const [stage, setStage] = useState<Stage>('Seed');
    const [urgency, setUrgency] = useState<Urgency>('Normal');
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && concept.trim();

    const getPrompt = useCallback(() => {
        return STARTUP_PITCH_PROMPT
            .replace('{STARTUP_CONCEPT}', concept)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{PITCH_DURATION}', pitchDuration)
            .replace('{INDUSTRY}', industry)
            .replace('{STAGE}', stage)
            .replace('{URGENCY}', urgency);
    }, [concept, targetAudience, pitchDuration, industry, stage, urgency]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing. Notification permissions may be required.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: pitchSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
             if (!parsed.elevatorPitch || !parsed.investorPitch) {
                setError("The AI returned an incomplete response. Please try again.");
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/^###\s*(.*)/gm, '<h4 class="text-md font-semibold text-text-primary dark:text-d-text-primary mt-4 mb-2">$1</h4>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/^\d+\.\s*(.*$)/gm, '<li class="ml-4 list-decimal">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
            .replace(/<br \/>\s*<br \/>/g, '<br />')
        };
    };
    
    const VersionCard: React.FC<{ title: string; content: string; icon: string }> = ({ title, icon, content }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!content) return;
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = content.replace(/<br \/>/g, '\n');
            const textToCopy = tempDiv.textContent || tempDiv.innerText || "";
            navigator.clipboard.writeText(textToCopy).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!content || content.toLowerCase().includes('could not parse')) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative">
                <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary flex items-center gap-2">
                        <span className="text-xl">{icon}</span> {title}
                    </h4>
                    <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${title}`}>
                        <CopyIcon className="h-5 w-5" />
                    </button>
                </div>
                <div className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed" dangerouslySetInnerHTML={formatContent(content)} />
                {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[200px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={concept} onChange={e => setConcept(e.target.value)} placeholder="Describe your startup concept, problem, and solution..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Pitch Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Target Audience</label>
                                <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as TargetAudience)} className={commonInputClasses}>
                                    <option>Investors</option><option>Customers</option><option>Partners</option><option>Accelerators</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Pitch Duration</label>
                                <select value={pitchDuration} onChange={e => setPitchDuration(e.target.value as PitchDuration)} className={commonInputClasses}>
                                    <option value="30-sec">30-sec Elevator Pitch</option><option value="1-min">1-min Pitch</option><option value="3-min">3-min Investor Pitch</option><option value="5-min">5-min Detailed Pitch</option><option value="Full Deck">Full Deck Outline</option>
                                </select>
                            </div>
                             <div>
                                <label className={commonLabelClasses}>Industry</label>
                                <select value={industry} onChange={e => setIndustry(e.target.value as Industry)} className={commonInputClasses}>
                                    <option>Tech/SaaS</option><option>HealthTech</option><option>FinTech</option><option>E-commerce</option><option>Other</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Stage</label>
                                <select value={stage} onChange={e => setStage(e.target.value as Stage)} className={commonInputClasses}>
                                    <option>Idea</option><option>Pre-seed</option><option>Seed</option><option value="Series A">Series A</option><option>Growth</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Crafting Pitch...' : (isQueued ? 'Request Queued' : 'Craft Pitch')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please describe your startup concept.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Crafting your comprehensive pitch...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your investor-ready pitch will appear here.</p>}
                    {error && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">An Error Occurred</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">{error}</p></div>}
                    {parsedOutput && (
                        <div className="space-y-6">
                            <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Multi-Format Pitch Versions</h3>
                                <VersionCard title="Elevator Pitch (30 seconds)" icon="⏱️" content={parsedOutput.elevatorPitch} />
                                <VersionCard title="Investor Pitch (3 minutes)" icon="📈" content={parsedOutput.investorPitch} />
                                <VersionCard title="Full Pitch Deck Outline" icon="📋" content={parsedOutput.pitchDeckOutline} />
                            </div>
                            <div className="space-y-2 pt-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Analysis & Strategy</h3>
                                <Accordion title="📊 Startup Fundamentals Analysis" defaultOpen={true}><div dangerouslySetInnerHTML={formatContent(parsedOutput.fundamentalsAnalysis)}/></Accordion>
                                <Accordion title="🎯 Audience-Specific Tailoring"><div dangerouslySetInnerHTML={formatContent(parsedOutput.audienceTailoring)}/></Accordion>
                                <Accordion title="💡 Pitch Enhancement Techniques"><div dangerouslySetInnerHTML={formatContent(parsedOutput.enhancementTechniques)}/></Accordion>
                                <Accordion title="🎤 Delivery Optimization"><div dangerouslySetInnerHTML={formatContent(parsedOutput.deliveryOptimization)}/></Accordion>
                                <Accordion title="🏢 Industry-Specific Pitching"><div dangerouslySetInnerHTML={formatContent(parsedOutput.industryPitching)}/></Accordion>
                                <Accordion title="💰 Funding Strategy Integration"><div dangerouslySetInnerHTML={formatContent(parsedOutput.fundingStrategy)}/></Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default StartupPitchView;