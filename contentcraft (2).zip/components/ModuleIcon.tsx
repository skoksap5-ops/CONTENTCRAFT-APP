import React from 'react';

// Social Suite Icons
import FacebookIcon from './icons/social/FacebookIcon';
import InstagramIcon from './icons/social/InstagramIcon';
import TwitterIcon from './icons/social/TwitterIcon';
import LinkedInIcon from './icons/social/LinkedInIcon';
import YouTubeIcon from './icons/social/YouTubeIcon';
import HashtagIcon from './icons/social/HashtagIcon';
import BlogIcon from './icons/social/BlogIcon';
import TikTokIcon from './icons/social/TikTokIcon';
import PinterestIcon from './icons/social/PinterestIcon';
import QuoraIcon from './icons/social/QuoraIcon';
import SocialCampaignPlannerIcon from './icons/social/SocialCampaignPlannerIcon';

// Core Module Icons
import SeoOptimizerIcon from './icons/core/SeoOptimizerIcon';
import HumanWarmthIcon from './icons/core/HumanWarmthIcon';
import CorporatePolishIcon from './icons/core/CorporatePolishIcon';
import EmpatheticToneIcon from './icons/core/EmpatheticToneIcon';
import ClarityEnhancerIcon from './icons/core/ClarityEnhancerIcon';
import SummarySynthesizerIcon from './icons/core/SummarySynthesizerIcon';
import NarrativeSoftenerIcon from './icons/core/NarrativeSoftenerIcon';
import ToneHarmonizerIcon from './icons/core/ToneHarmonizerIcon';
import GrammarProoferIcon from './icons/core/GrammarProoferIcon';
import StyleProoferIcon from './icons/core/StyleProoferIcon';
import TextCraftIcon from './icons/core/TextCraftIcon';
import ParagraphGeneratorIcon from './icons/core/ParagraphGeneratorIcon';
import PlagiarismCheckerIcon from './icons/core/PlagiarismCheckerIcon';
import TranslationMasterIcon from './icons/core/TranslationMasterIcon';
import MetaDescriptionGeneratorIcon from './icons/core/MetaDescriptionGeneratorIcon';
import FAQSchemaGeneratorIcon from './icons/core/FAQSchemaGeneratorIcon';
import BroomIcon from './icons/core/BroomIcon';

// Professional & Content Icons
import StartupPitchIcon from './icons/professional/StartupPitchIcon';
import EmailCraftIcon from './icons/professional/EmailCraftIcon';
import AsoOptimizerIcon from './icons/professional/AsoOptimizerIcon';
import ContentGeneratorIcon from './icons/professional/ContentGeneratorIcon';
import ProductReviewIcon from './icons/professional/ProductReviewIcon';
import PressReleaseIcon from './icons/professional/PressReleaseIcon';
import CaseStudyCreatorIcon from './icons/professional/CaseStudyCreatorIcon';
import WhitepaperWriterIcon from './icons/professional/WhitepaperWriterIcon';
import ProposalGeneratorIcon from './icons/professional/ProposalGeneratorIcon';
import VideoScriptIcon from './icons/professional/VideoScriptIcon';
import PersonalBioGeneratorIcon from './icons/professional/PersonalBioGeneratorIcon';
import ResumeIcon from './icons/professional/ResumeIcon';

// Marketing & Conversion Icons
import HeadlineGeneratorIcon from './icons/marketing/HeadlineGeneratorIcon';
import EcommerceDescriptionIcon from './icons/marketing/EcommerceDescriptionIcon';
import GoogleAdIcon from './icons/marketing/GoogleAdIcon';
import FacebookAdIcon from './icons/marketing/FacebookAdIcon';
import LandingPageCopyIcon from './icons/marketing/LandingPageCopyIcon';
import NewsletterBuilderIcon from './icons/marketing/NewsletterBuilderIcon';
import SloganGeneratorIcon from './icons/marketing/SloganGeneratorIcon';

// AI Power Suite Icons
import AiTemplateBuilderIcon from './icons/ai_power/AiTemplateBuilderIcon';
import AiPromptGeneratorIcon from './icons/ai_power/AiPromptGeneratorIcon';
import AiTrendSpotterIcon from './icons/ai_power/AiTrendSpotterIcon';
import AiContentRepurposingIcon from './icons/ai_power/AiContentRepurposingIcon';
import AiChatbotTrainingIcon from './icons/ai_power/AiChatbotTrainingIcon';
import AiSeoOpportunityIcon from './icons/ai_power/AiSeoOpportunityIcon';
import AiContentPerformanceIcon from './icons/ai_power/AiContentPerformanceIcon';
import AiCommentResponseIcon from './icons/ai_power/AiCommentResponseIcon';
import AiCompetitorAnalyzerIcon from './icons/ai_power/AiCompetitorAnalyzerIcon';
import AiQuizCreatorIcon from './icons/ai_power/AiQuizCreatorIcon';
import BookIcon from './icons/BookIcon';
import AISearchOptimizerIcon from './icons/ai_power/AISearchOptimizerIcon';
import BrandVoiceIcon from './icons/ai_power/BrandVoiceIcon';

// Earn & Monetize Icon
import EarnIcon from './icons/EarnIcon';

interface ModuleIconProps {
  moduleId: string;
}

const IconWrapper: React.FC<{ children: React.ReactNode; className?: string; }> = ({ children, className = '' }) => (
  <div className={`h-36 w-36 rounded-3xl flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform duration-200 ${className}`}>
    {children}
  </div>
);

const ModuleIcon: React.FC<ModuleIconProps> = ({ moduleId }) => {
  switch (moduleId) {
    // AI Power Suite
    case 'ai-template-builder':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiTemplateBuilderIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-prompt-generator':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiPromptGeneratorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-trend-spotter':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiTrendSpotterIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-content-repurposing':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiContentRepurposingIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-chatbot-training':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiChatbotTrainingIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-seo-opportunity-finder':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiSeoOpportunityIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-search-optimizer':
        return <IconWrapper className="bg-gradient-to-br from-cyan-500 to-blue-600"><AISearchOptimizerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-performance-predictor':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiContentPerformanceIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-comment-response-generator':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiCommentResponseIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-competitor-analyzer':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiCompetitorAnalyzerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-quiz-creator':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><AiQuizCreatorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ai-ebook-creator':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><BookIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'social-campaign-planner':
      return <IconWrapper className="bg-gradient-to-br from-blue-500 to-purple-600"><SocialCampaignPlannerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'brand-voice-generator':
        return <IconWrapper className="bg-gradient-to-br from-purple-500 to-teal-500"><BrandVoiceIcon className="h-20 w-20 text-white" /></IconWrapper>;

    // Social Suite
    case 'linkedin-styler':
      return <IconWrapper className="bg-[#0077b5]"><LinkedInIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'instagram-styler':
      return <IconWrapper className="bg-gradient-to-br from-[#833ab4] via-[#fd1d1d] to-[#fcb045]"><InstagramIcon className="h-24 w-24 text-white" /></IconWrapper>;
    case 'twitter-styler':
      return <IconWrapper className="bg-[#1DA1F2]"><TwitterIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'facebook-styler':
      return <IconWrapper className="bg-[#1877F2]"><FacebookIcon className="h-24 w-24 text-white" /></IconWrapper>;
    case 'youtube-styler':
    case 'youtube-to-blog':
      return <IconWrapper className="bg-[#FF0000]"><YouTubeIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'tiktok-styler':
      return <IconWrapper className="bg-black"><TikTokIcon className="h-24 w-24" /></IconWrapper>;
    case 'hashtag-generator':
      return <IconWrapper className="bg-gradient-to-br from-teal-400 to-cyan-500"><HashtagIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'pinterest-styler':
      return (
        <IconWrapper className="bg-[#E60023]">
          <div className="bg-white rounded-full h-28 w-28 flex items-center justify-center">
            <PinterestIcon className="h-16 w-16 text-[#E60023]" />
          </div>
        </IconWrapper>
      );
    case 'blog-ideas-generator':
      return <IconWrapper className="bg-gradient-to-br from-purple-500 to-indigo-500"><BlogIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'quora-answer':
      return <IconWrapper className="bg-[#b92b27]"><QuoraIcon className="h-24 w-24 text-white" /></IconWrapper>;

    // Core Modules
    case 'seo-optimizer':
      return <IconWrapper className="bg-gradient-to-br from-green-400 to-blue-500"><SeoOptimizerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'meta-description-generator':
      return <IconWrapper className="bg-gradient-to-br from-sky-400 to-blue-600"><MetaDescriptionGeneratorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'faq-schema-generator':
        return <IconWrapper className="bg-gradient-to-br from-purple-500 to-indigo-600"><FAQSchemaGeneratorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'human-warmth':
      return <IconWrapper className="bg-gradient-to-br from-red-400 to-yellow-400"><HumanWarmthIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'corporate-polish':
      return <IconWrapper className="bg-gradient-to-br from-gray-700 to-gray-900"><CorporatePolishIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'empathetic-tone':
        return <IconWrapper className="bg-gradient-to-br from-pink-400 to-rose-400"><EmpatheticToneIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'clarity-enhancer':
        return <IconWrapper className="bg-gradient-to-br from-cyan-300 to-sky-500"><ClarityEnhancerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'summary-synthesizer':
        return <IconWrapper className="bg-gradient-to-br from-orange-400 to-amber-500"><SummarySynthesizerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'narrative-softener':
        return <IconWrapper className="bg-gradient-to-br from-violet-300 to-fuchsia-400"><NarrativeSoftenerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'tone-harmonizer':
        return <IconWrapper className="bg-gradient-to-br from-lime-400 to-teal-500"><ToneHarmonizerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'grammar-proofer':
        return <IconWrapper className="bg-gradient-to-br from-emerald-500 to-green-600"><GrammarProoferIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'style-proofer':
        return <IconWrapper className="bg-gradient-to-br from-indigo-400 to-purple-500"><StyleProoferIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'text-craft':
        return <IconWrapper className="bg-gradient-to-br from-slate-500 to-slate-700"><TextCraftIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'paragraph-generator':
        return <IconWrapper className="bg-gradient-to-br from-sky-400 to-blue-600"><ParagraphGeneratorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'plagiarism-checker':
        return <IconWrapper className="bg-gradient-to-br from-yellow-400 to-orange-500"><PlagiarismCheckerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'clean-paste':
        return <IconWrapper className="bg-gradient-to-br from-teal-400 to-cyan-500"><BroomIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'translation-master':
        return <IconWrapper className="bg-gradient-to-br from-blue-500 to-indigo-600"><TranslationMasterIcon className="h-20 w-20 text-white" /></IconWrapper>;

    // Professional & Content
    case 'startup-pitch':
        return <IconWrapper className="bg-gradient-to-br from-red-500 to-orange-600"><StartupPitchIcon className="h-24 w-24 text-white" /></IconWrapper>;
    case 'personal-bio-generator':
        return <IconWrapper className="bg-gradient-to-br from-violet-500 to-purple-600"><PersonalBioGeneratorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'resume-generator':
        return <IconWrapper className="bg-gradient-to-br from-blue-500 to-cyan-500"><ResumeIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'email-craft':
        return <IconWrapper className="bg-gradient-to-br from-blue-400 to-cyan-400"><EmailCraftIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'aso-optimizer':
        return <IconWrapper className="bg-gradient-to-br from-teal-400 to-green-500"><AsoOptimizerIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'content-generator':
        return <IconWrapper className="bg-gradient-to-br from-purple-500 to-pink-500"><ContentGeneratorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'product-review':
        return <IconWrapper className="bg-gradient-to-br from-yellow-400 to-amber-500"><ProductReviewIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'press-release':
        return <IconWrapper className="bg-gradient-to-br from-slate-400 to-gray-500"><PressReleaseIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'case-study-creator':
        return <IconWrapper className="bg-gradient-to-br from-indigo-500 to-blue-600"><CaseStudyCreatorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'whitepaper-writer':
        return <IconWrapper className="bg-gradient-to-br from-gray-200 to-gray-400"><WhitepaperWriterIcon className="h-20 w-20 text-gray-800" /></IconWrapper>;
    case 'proposal-generator':
        return <IconWrapper className="bg-gradient-to-br from-green-500 to-emerald-600"><ProposalGeneratorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'video-script-writer':
        return <IconWrapper className="bg-gradient-to-br from-rose-500 to-fuchsia-600"><VideoScriptIcon className="h-20 w-20 text-white" /></IconWrapper>;
        
    // Marketing & Conversion
    case 'headline-generator':
        return <IconWrapper className="bg-gradient-to-br from-amber-400 to-orange-500"><HeadlineGeneratorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'slogan-generator':
        return <IconWrapper className="bg-gradient-to-br from-orange-400 to-red-500"><SloganGeneratorIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'ecommerce-description':
        return <IconWrapper className="bg-gradient-to-br from-lime-400 to-green-500"><EcommerceDescriptionIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'google-ad':
        return <IconWrapper className="bg-white"><GoogleAdIcon className="h-24 w-24" /></IconWrapper>;
    case 'facebook-ad':
        return <IconWrapper className="bg-[#1877F2]"><FacebookAdIcon className="h-24 w-24 text-white" /></IconWrapper>;
    case 'landing-page-copy':
        return <IconWrapper className="bg-gradient-to-br from-sky-400 to-cyan-500"><LandingPageCopyIcon className="h-20 w-20 text-white" /></IconWrapper>;
    case 'newsletter-builder':
        return <IconWrapper className="bg-gradient-to-br from-indigo-400 to-purple-500"><NewsletterBuilderIcon className="h-20 w-20 text-white" /></IconWrapper>;
    
    // Earn & Monetize
    case 'earn-with-content-craft-365':
        return <IconWrapper className="bg-gradient-to-br from-yellow-400 to-amber-500"><EarnIcon className="h-20 w-20 text-black" /></IconWrapper>;

    default:
      return null;
  }
};

export default ModuleIcon;
