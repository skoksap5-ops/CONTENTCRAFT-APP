import React, { useState } from 'react';
import { useQuizAI } from '../hooks/useQuizAI';
import type { QuizConfig, QuizData, QuizQuestion, QuizResult } from './ai-quiz-creator/types';
import QuizSetup from './ai-quiz-creator/QuizSetup';
import QuestionDesigner from './ai-quiz-creator/QuestionDesigner';
import ResultsBuilder from './ai-quiz-creator/ResultsBuilder';
import LeadCapture from './ai-quiz-creator/LeadCapture';
import PreviewPublisher from './ai-quiz-creator/PreviewPublisher';
import type { Module } from '../types';

interface AIQuizCreatorViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type View = 'setup' | 'questions' | 'results' | 'capture' | 'publish';

const AIQuizCreatorView: React.FC<AIQuizCreatorViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
  const [currentView, setCurrentView] = useState<View>('setup');
  const [quizData, setQuizData] = useState<QuizData | null>(null);

  const { generateQuiz, isLoading, error } = useQuizAI(userId, module.id, module.name, usesLeft, decrementUse);

  const views: { [key in View]: { name: string; icon: string } } = {
    setup: { name: 'Setup', icon: '🎯' },
    questions: { name: 'Questions', icon: '❓' },
    results: { name: 'Results', icon: '📊' },
    capture: { name: 'Lead Capture', icon: '📥' },
    publish: { name: 'Publish', icon: '🚀' }
  };

  const handleQuizSetup = async (setupData: QuizConfig) => {
    const quiz = await generateQuiz(setupData);
    if (quiz) {
      setQuizData(quiz);
      setCurrentView('questions');
    }
  };

  const handleQuestionsUpdate = async (questions: QuizQuestion[]) => {
    setQuizData(prev => prev ? ({ ...prev, questions }) : null);
    setCurrentView('results');
  };

  const handleResultsUpdate = async (results: QuizResult[]) => {
    setQuizData(prev => prev ? ({ ...prev, results }) : null);
    setCurrentView('capture');
  };

  const handleLeadCaptureSetup = async (captureSettings: any) => {
    setQuizData(prev => prev ? ({ ...prev, leadCapture: captureSettings }) : null);
    setCurrentView('publish');
  };

  const getProgressWidth = () => {
    const currentIndex = Object.keys(views).indexOf(currentView);
    return (currentIndex / (Object.keys(views).length - 1)) * 100;
  };

  const renderContent = () => {
    switch(currentView) {
      case 'setup':
        return <QuizSetup onSubmit={handleQuizSetup} isLoading={isLoading} />;
      case 'questions':
        return quizData && <QuestionDesigner quiz={quizData} onUpdate={handleQuestionsUpdate} onBack={() => setCurrentView('setup')} />;
      case 'results':
        return quizData && <ResultsBuilder quiz={quizData} onUpdate={handleResultsUpdate} onBack={() => setCurrentView('questions')} />;
      case 'capture':
        return quizData && <LeadCapture quiz={quizData} onUpdate={handleLeadCaptureSetup} onBack={() => setCurrentView('results')} />;
      case 'publish':
        return quizData && <PreviewPublisher quiz={quizData} onBack={() => setCurrentView('capture')} />;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
        <div className="text-center">
            <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">🧩 {module.name}</h2>
            <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
        </div>

        <div className="w-full px-4 sm:px-0">
          <div className="flex items-center">
            {Object.entries(views).map(([key, view], index) => (
              <React.Fragment key={key}>
                <div className="flex flex-col items-center text-center w-20">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors duration-300 ${currentView === key || Object.keys(views).indexOf(currentView) > index ? 'bg-brand-primary text-white' : 'bg-base-300 dark:bg-d-base-300 text-text-secondary dark:text-d-text-secondary'}`}>
                    {view.icon}
                  </div>
                  <p className={`mt-2 text-xs font-semibold ${currentView === key ? 'text-brand-primary' : 'text-text-secondary dark:text-d-text-secondary'}`}>{view.name}</p>
                </div>
                {index < Object.keys(views).length - 1 && (
                  <div className={`flex-1 h-1 transition-colors duration-300 -mt-8 mx-2 ${Object.keys(views).indexOf(currentView) > index ? 'bg-brand-primary' : 'bg-base-300 dark:bg-d-base-300'}`}></div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
        
        {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}

        <div className="bg-base-200/50 dark:bg-d-base-200/50 p-6 rounded-xl border border-base-300 dark:border-d-base-300 min-h-[300px]">
            {renderContent()}
        </div>
    </div>
  );
};

export default AIQuizCreatorView;