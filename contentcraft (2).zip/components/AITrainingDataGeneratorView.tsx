import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import { Type } from '@google/genai';
import CopyIcon from './icons/CopyIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

const trainingDataSchema = {
    type: Type.OBJECT,
    properties: {
        qa_pairs: {
            type: Type.ARRAY,
            description: "Array of question-answer pairs. Only populate if dataType is 'qa_pairs'.",
            items: {
                type: Type.OBJECT,
                properties: {
                    question: { type: Type.STRING },
                    answer: { type: Type.STRING },
                    variations: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ['question', 'answer']
            }
        },
        conversation_flows: {
            type: Type.ARRAY,
            description: "Array of multi-turn conversation flows. Only populate if dataType is 'conversation_flows'.",
            items: {
                type: Type.OBJECT,
                properties: {
                    scenario: { type: Type.STRING },
                    messages: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                role: { type: Type.STRING, description: "'user' or 'bot'" },
                                content: { type: Type.STRING }
                            },
                            required: ['role', 'content']
                        }
                    }
                },
                required: ['scenario', 'messages']
            }
        },
        intent_training: {
            type: Type.ARRAY,
            description: "Array of intents with training phrases. Only populate if dataType is 'intent_training'.",
            items: {
                type: Type.OBJECT,
                properties: {
                    intent: { type: Type.STRING },
                    phrases: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ['intent', 'phrases']
            }
        }
    }
};

type DataType = 'qa_pairs' | 'conversation_flows' | 'intent_training';

const AITrainingDataGeneratorView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [topic, setTopic] = useState('');
    const [dataType, setDataType] = useState<DataType>('qa_pairs');
    const [industry, setIndustry] = useState('ecommerce');
    const [sampleCount, setSampleCount] = useState(10);
    const [persona, setPersona] = useState('');
    const [complexity, setComplexity] = useState('medium');

    const [parsedOutput, setParsedOutput] = useState<any | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [copySuccess, setCopySuccess] = useState<string | null>(null);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && topic.trim();

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = `You are an expert AI training data specialist. Your task is to generate high-quality training data for a chatbot based on the user's specifications.
        
        **SPECIFICATIONS:**
        - Topic/Domain: ${topic}
        - Industry: ${industry}
        - Persona for the chatbot: ${persona || 'A helpful assistant'}
        - Data Type to Generate: ${dataType}
        - Number of Samples: ${sampleCount}
        - Conversation Complexity: ${complexity}

        **INSTRUCTIONS:**
        1. Generate exactly ${sampleCount} samples of the specified "Data Type".
        2. If generating 'qa_pairs', include 2-3 common variations for each question to improve NLU robustness.
        3. If generating 'conversation_flows', create realistic multi-turn dialogues. Each conversation should have a clear goal or scenario.
        4. If generating 'intent_training', create a relevant intent name and provide diverse user phrases that map to it.
        5. Ensure the generated content aligns with the specified industry, persona, and complexity.
        6. Your response MUST be a valid JSON object conforming to the provided schema. Populate ONLY the field corresponding to the requested "Data Type". For example, if "Data Type" is 'qa_pairs', only the 'qa_pairs' field in the JSON should contain data.`;

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: trainingDataSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: `Topic: ${topic}, Type: ${dataType}`,
                    output: JSON.stringify(parsed, null, 2),
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, topic, industry, dataType, sampleCount, persona, complexity, module, userId, usesLeft, decrementUse]);
    
    const handleCopy = (content: any, id: string) => {
        navigator.clipboard.writeText(JSON.stringify(content, null, 2)).then(() => {
            setCopySuccess(id);
            setTimeout(() => setCopySuccess(null), 2000);
        });
    };

    const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>

            <div className="p-6 bg-base-200 dark:bg-d-base-200 rounded-xl space-y-6">
                <div>
                    <label htmlFor="topic" className={commonLabelClasses}>Core Topic / Domain</label>
                    <textarea id="topic" value={topic} onChange={e => setTopic(e.target.value)} placeholder="e.g., Returns policy for an online clothing store" className={`${commonInputClasses} min-h-[100px]`} />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="industry" className={commonLabelClasses}>Industry</label>
                        <select id="industry" value={industry} onChange={e => setIndustry(e.target.value)} className={commonInputClasses}>
                            <option value="ecommerce">E-commerce</option>
                            <option value="healthcare">Healthcare</option>
                            <option value="finance">Finance</option>
                            <option value="travel">Travel</option>
                            <option value="customer_service">Customer Service</option>
                        </select>
                    </div>
                    <div>
                        <label htmlFor="persona" className={commonLabelClasses}>Chatbot Persona (Optional)</label>
                        <input id="persona" value={persona} onChange={e => setPersona(e.target.value)} placeholder="e.g., a friendly and helpful guide" className={commonInputClasses} />
                    </div>
                </div>

                <div>
                    <label className={commonLabelClasses}>Data Type</label>
                    <div className="grid grid-cols-3 gap-2 bg-base-100 dark:bg-d-base-100 p-1 rounded-lg">
                        {(['qa_pairs', 'conversation_flows', 'intent_training'] as DataType[]).map(type => (
                            <button key={type} onClick={() => setDataType(type)} className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors ${dataType === type ? 'bg-brand-primary text-white shadow' : 'text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-200'}`}>
                                {type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                            </button>
                        ))}
                    </div>
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="sampleCount" className={commonLabelClasses}>Number of Samples ({sampleCount})</label>
                        <input id="sampleCount" type="range" min="5" max="50" step="5" value={sampleCount} onChange={e => setSampleCount(Number(e.target.value))} className="w-full h-2 bg-base-300 dark:bg-d-base-300 rounded-lg appearance-none cursor-pointer" />
                    </div>
                     <div>
                        <label htmlFor="complexity" className={commonLabelClasses}>Complexity</label>
                         <select id="complexity" value={complexity} onChange={e => setComplexity(e.target.value)} className={commonInputClasses}>
                            <option value="simple">Simple</option>
                            <option value="medium">Medium</option>
                            <option value="complex">Complex</option>
                        </select>
                    </div>
                </div>
                
                <button
                    onClick={handleGenerate}
                    disabled={isLoading || !canGenerate}
                    className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed transition-all"
                >
                    {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : '🧠 Generate Training Data'}
                </button>
            </div>
            
            {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
            {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
            
            {isLoading && !parsedOutput && (
                <div className="text-center p-8">
                     <svg className="animate-spin mx-auto h-12 w-12 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                    <h3 className="text-xl font-bold font-heading mt-4">Generating data...</h3>
                </div>
            )}
            
            {parsedOutput && (
                <div className="space-y-6 animate-fade-in">
                    <h3 className="text-2xl font-bold font-heading text-center">Generated Training Data</h3>
                    {dataType === 'qa_pairs' && parsedOutput.qa_pairs?.map((item: any, index: number) => (
                        <div key={index} className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg relative group">
                            <p className="font-semibold text-text-primary dark:text-d-text-primary">Q: {item.question}</p>
                            <p className="mt-2 text-text-secondary dark:text-d-text-secondary">A: {item.answer}</p>
                            {item.variations?.length > 0 && <p className="text-xs text-text-secondary dark:text-d-text-secondary mt-2 italic">Variations: {item.variations.join(', ')}</p>}
                            <button onClick={() => handleCopy(item, `qa-${index}`)} className="absolute top-2 right-2 p-2 rounded-lg bg-base-300 dark:bg-d-base-300 opacity-0 group-hover:opacity-100 transition-opacity">
                                <CopyIcon className="h-4 w-4"/>
                            </button>
                            {copySuccess === `qa-${index}` && <span className="absolute top-3 right-12 text-xs bg-success text-white px-2 py-0.5 rounded-full">Copied!</span>}
                        </div>
                    ))}
                     {dataType === 'conversation_flows' && parsedOutput.conversation_flows?.map((item: any, index: number) => (
                        <div key={index} className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg relative group">
                            <h4 className="font-bold text-text-primary dark:text-d-text-primary mb-2">Scenario: {item.scenario}</h4>
                            <div className="space-y-2">
                                {item.messages.map((msg: any, msgIndex: number) => (
                                    <div key={msgIndex} className={`flex ${msg.role === 'bot' ? 'justify-start' : 'justify-end'}`}>
                                        <div className={`px-3 py-2 rounded-lg max-w-[80%] ${msg.role === 'bot' ? 'bg-base-300 dark:bg-d-base-300' : 'bg-brand-primary text-white'}`}>
                                            <p className="text-sm">{msg.content}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <button onClick={() => handleCopy(item, `conv-${index}`)} className="absolute top-2 right-2 p-2 rounded-lg bg-base-300 dark:bg-d-base-300 opacity-0 group-hover:opacity-100 transition-opacity">
                                <CopyIcon className="h-4 w-4"/>
                            </button>
                            {copySuccess === `conv-${index}` && <span className="absolute top-3 right-12 text-xs bg-success text-white px-2 py-0.5 rounded-full">Copied!</span>}
                        </div>
                    ))}
                     {dataType === 'intent_training' && parsedOutput.intent_training?.map((item: any, index: number) => (
                        <div key={index} className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg relative group">
                            <h4 className="font-bold text-text-primary dark:text-d-text-primary mb-2">Intent: <span className="font-mono bg-base-300 dark:bg-d-base-300 px-2 py-1 rounded">{item.intent}</span></h4>
                            <ul className="list-disc list-inside space-y-1 text-sm text-text-secondary dark:text-d-text-secondary">
                                {item.phrases.map((phrase: string, pIndex: number) => <li key={pIndex}>{phrase}</li>)}
                            </ul>
                            <button onClick={() => handleCopy(item, `intent-${index}`)} className="absolute top-2 right-2 p-2 rounded-lg bg-base-300 dark:bg-d-base-300 opacity-0 group-hover:opacity-100 transition-opacity">
                                <CopyIcon className="h-4 w-4"/>
                            </button>
                             {copySuccess === `intent-${index}` && <span className="absolute top-3 right-12 text-xs bg-success text-white px-2 py-0.5 rounded-full">Copied!</span>}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default AITrainingDataGeneratorView;
