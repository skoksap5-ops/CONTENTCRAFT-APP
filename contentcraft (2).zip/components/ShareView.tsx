import React, { useState, useCallback, useEffect } from 'react';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import GiftIcon from './icons/GiftIcon';
import ShareIcon from './icons/ShareIcon';
import CopyIcon from './icons/CopyIcon';
import FacebookIcon from './icons/social/FacebookIcon';
import TwitterIcon from './icons/social/TwitterIcon';
import LinkedInIcon from './icons/social/LinkedInIcon';
import PinterestIcon from './icons/social/PinterestIcon';
import RedditIcon from './icons/social/RedditIcon';
import TelegramIcon from './icons/social/TelegramIcon';
import WhatsAppIcon from './icons/social/WhatsAppIcon';
import MessengerIcon from './icons/social/MessengerIcon';
import EmailIcon from './icons/social/EmailIcon';
import SkypeIcon from './icons/social/SkypeIcon';
import TumblrIcon from './icons/social/TumblrIcon';
import BufferIcon from './icons/social/BufferIcon';
import QuoraIcon from './icons/social/QuoraIcon';
import MediumIcon from './icons/social/MediumIcon';
import TikTokIcon from './icons/social/TikTokIcon';
import InstagramIcon from './icons/social/InstagramIcon';
import YouTubeIcon from './icons/social/YouTubeIcon';
import DiscordIcon from './icons/social/DiscordIcon';

const SHARE_TEXT = "Check out ContentCraft - AI-powered content creation with emotional intelligence! Transform your writing with advanced tone control and 60+ modules.";
const SHARE_TITLE = "ContentCraft AI";
const SHARE_URL = typeof window !== 'undefined' ? window.location.origin : 'https://contentcraft.ai';
const FULL_SHARE_TEXT = `${SHARE_TEXT} ${SHARE_URL}`;

interface ShareViewProps {
    onClose: () => void;
    addUses: (amount: number) => Promise<void>;
}

const ShareView: React.FC<ShareViewProps> = ({ onClose, addUses }) => {
    const [notification, setNotification] = useState<string | null>(null);
    const [rewardsGivenToday, setRewardsGivenToday] = useState(0);

    useEffect(() => {
        const today = new Date().toISOString().split('T')[0];
        const lastRewardDate = localStorage.getItem('lastShareRewardDate');
        if (lastRewardDate === today) {
            const rewardsCount = parseInt(localStorage.getItem('shareRewardsToday') || '0', 10);
            setRewardsGivenToday(rewardsCount);
        } else {
            // It's a new day, reset.
            localStorage.setItem('lastShareRewardDate', today);
            localStorage.setItem('shareRewardsToday', '0');
            setRewardsGivenToday(0);
        }
    }, []);

    const showNotification = useCallback((message: string, duration: number = 3000) => {
        setNotification(message);
        setTimeout(() => {
            setNotification(null);
        }, duration);
    }, []);

    const grantReward = useCallback(() => {
        if (rewardsGivenToday < 2) {
            addUses(1);
            const newCount = rewardsGivenToday + 1;
            const today = new Date().toISOString().split('T')[0];
            localStorage.setItem('lastShareRewardDate', today);
            localStorage.setItem('shareRewardsToday', newCount.toString());
            setRewardsGivenToday(newCount);
            showNotification(`🎉 +1 credit added! (${newCount}/2 for today)`, 4000);
        }
    }, [rewardsGivenToday, addUses, showNotification]);

    const handleShareToTikTok = useCallback(() => {
        if (navigator.share) {
            navigator.share({
                title: SHARE_TITLE,
                text: SHARE_TEXT,
                url: SHARE_URL,
            }).then(() => {
                grantReward();
            }).catch(err => {
                if (err.name !== 'AbortError') console.error("Share failed", err);
            });
        } else {
            navigator.clipboard.writeText(FULL_SHARE_TEXT).then(() => {
                const userAction = confirm('Link copied to clipboard! Would you like to open TikTok now?');
                if (userAction) window.location.href = 'tiktok://';
            }).catch(() => showNotification("Failed to copy link."));
        }
    }, [showNotification, grantReward]);

    const handleShareToInstagram = useCallback(() => {
        navigator.clipboard.writeText(FULL_SHARE_TEXT).then(() => {
            const message = 'Caption copied! Paste it in your new post.\n\nWould you like to open Instagram now?';
            if (window.confirm(message)) {
                window.open('https://www.instagram.com', '_blank', 'noopener,noreferrer');
            }
        }).catch(() => showNotification("Failed to copy caption."));
    }, [showNotification]);

    const handleShareToYouTube = useCallback(() => {
        navigator.clipboard.writeText(FULL_SHARE_TEXT).then(() => {
            showNotification("Text copied! You can paste it in a YouTube comment or description.");
            window.open('https://www.youtube.com', '_blank', 'noopener,noreferrer');
        }).catch(() => showNotification("Failed to copy text."));
    }, [showNotification]);

    const handleShareToDiscord = useCallback(() => {
        navigator.clipboard.writeText(FULL_SHARE_TEXT).then(() => {
            showNotification('Link copied! Opening Discord...');
            setTimeout(() => {
                window.open('https://discord.com/channels/@me', '_blank', 'noopener,noreferrer');
            }, 500);
        }).catch(() => showNotification('Could not copy text.'));
    }, [showNotification]);

    const handleShareApp = useCallback(async () => {
        if (navigator.share) {
            try {
                await navigator.share({
                    title: SHARE_TITLE,
                    text: SHARE_TEXT,
                    url: SHARE_URL,
                });
                grantReward();
            } catch (error) {
                if ((error as DOMException).name !== 'AbortError') {
                    console.error('Error sharing:', error);
                }
            }
        } else {
            showNotification('Web Share not supported. Please use another option.');
        }
    }, [showNotification, grantReward]);

    const handleCopyText = useCallback(() => {
        navigator.clipboard.writeText(FULL_SHARE_TEXT).then(() => {
            showNotification("Copied to clipboard!");
        });
    }, [showNotification]);

    const handleGenericShare = (url: string) => {
        if (rewardsGivenToday >= 2) {
            window.open(url, '_blank', 'noopener,noreferrer');
            return;
        }

        const handleVisibilityChange = () => {
            if (document.visibilityState === 'visible' && sessionStorage.getItem('awaitingShareReward') === 'true') {
                grantReward();
                sessionStorage.removeItem('awaitingShareReward');
                window.removeEventListener('visibilitychange', handleVisibilityChange);
            }
        };
        
        window.addEventListener('visibilitychange', handleVisibilityChange);
        sessionStorage.setItem('awaitingShareReward', 'true');
        window.open(url, '_blank', 'noopener,noreferrer');
    };

    const handleShareToMessenger = useCallback(() => {
        if (navigator.share) {
            navigator.share({ title: SHARE_TITLE, text: SHARE_TEXT, url: SHARE_URL })
            .then(() => grantReward())
            .catch(err => { if (err.name !== 'AbortError') console.error("Web Share failed:", err); });
        } else {
            navigator.clipboard.writeText(FULL_SHARE_TEXT).then(() => {
                showNotification('Copied for Messenger! Paste it in a new message.');
                window.open('https://www.messenger.com/', '_blank', 'noopener,noreferrer');
            }).catch(() => showNotification("Failed to copy link."));
        }
    }, [showNotification, grantReward]);

    const socialPlatforms = [
        { name: 'Facebook', icon: <FacebookIcon className="h-10 w-10 text-white" />, color: 'bg-blue-600', onClick: () => handleGenericShare(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(SHARE_URL)}`) },
        { name: 'X (Twitter)', icon: <TwitterIcon className="h-8 w-8 text-white" />, color: 'bg-black', onClick: () => handleGenericShare(`https://twitter.com/intent/tweet?url=${encodeURIComponent(SHARE_URL)}&text=${encodeURIComponent(SHARE_TEXT)}`) },
        { name: 'LinkedIn', icon: <LinkedInIcon className="h-8 w-8 text-white" />, color: 'bg-sky-700', onClick: () => handleGenericShare(`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(SHARE_URL)}&title=${encodeURIComponent(SHARE_TITLE)}&summary=${encodeURIComponent(SHARE_TEXT)}`) },
        { name: 'Pinterest', icon: <PinterestIcon className="h-8 w-8 text-white" />, color: 'bg-red-600', onClick: () => handleGenericShare(`https://pinterest.com/pin/create/button/?url=${encodeURIComponent(SHARE_URL)}&description=${encodeURIComponent(SHARE_TEXT)}`) },
        { name: 'Reddit', icon: <RedditIcon className="h-9 w-9 text-white" />, color: 'bg-orange-500', onClick: () => handleGenericShare(`https://www.reddit.com/submit?url=${encodeURIComponent(SHARE_URL)}&title=${encodeURIComponent(SHARE_TITLE)}`) },
        { name: 'Telegram', icon: <TelegramIcon className="h-8 w-8 text-white" />, color: 'bg-sky-500', onClick: () => handleGenericShare(`https://t.me/share/url?url=${encodeURIComponent(SHARE_URL)}&text=${encodeURIComponent(SHARE_TEXT)}`) },
        { name: 'WhatsApp', icon: <WhatsAppIcon className="h-9 w-9 text-white" />, color: 'bg-green-500', onClick: () => handleGenericShare(`https://api.whatsapp.com/send?text=${encodeURIComponent(SHARE_TEXT)}%20${encodeURIComponent(SHARE_URL)}`) },
        { name: 'Email', icon: <EmailIcon className="h-8 w-8 text-white" />, color: 'bg-red-500', onClick: () => handleGenericShare(`mailto:?subject=${encodeURIComponent(SHARE_TITLE)}&body=${FULL_SHARE_TEXT}`) },
        { name: 'Skype', icon: <SkypeIcon className="h-8 w-8 text-white" />, color: 'bg-sky-400', onClick: () => handleGenericShare(`https://web.skype.com/share?url=${encodeURIComponent(SHARE_URL)}&text=${encodeURIComponent(SHARE_TEXT)}`) },
        { name: 'Tumblr', icon: <TumblrIcon className="h-8 w-8 text-white" />, color: 'bg-slate-800', onClick: () => handleGenericShare(`https://www.tumblr.com/widgets/share/tool?canonicalUrl=${encodeURIComponent(SHARE_URL)}&title=${encodeURIComponent(SHARE_TITLE)}&caption=${encodeURIComponent(SHARE_TEXT)}`) },
        { name: 'Buffer', icon: <BufferIcon className="h-8 w-8 text-white" />, color: 'bg-gray-800', onClick: () => handleGenericShare(`https://buffer.com/add?url=${encodeURIComponent(SHARE_URL)}&text=${encodeURIComponent(SHARE_TEXT)}`) },
        { name: 'Quora', icon: <QuoraIcon className="h-9 w-9 text-white" />, color: 'bg-red-700', onClick: () => handleGenericShare(`https://www.quora.com/share?url=${encodeURIComponent(SHARE_URL)}`) },
        { name: 'Messenger', icon: <MessengerIcon className="h-8 w-8 text-white" />, color: 'bg-gradient-to-br from-blue-500 to-purple-500', onClick: handleShareToMessenger },
        { name: 'Medium', icon: <MediumIcon className="h-9 w-9 text-white" />, color: 'bg-black', onClick: () => handleGenericShare(`https://medium.com/p/new?text=${encodeURIComponent(FULL_SHARE_TEXT)}`) },
        { name: 'TikTok', icon: <TikTokIcon className="h-9 w-9" />, color: 'bg-gradient-to-br from-cyan-400 via-pink-500 to-red-500', onClick: handleShareToTikTok },
        { name: 'Instagram', icon: <InstagramIcon className="h-9 w-9 text-white" />, color: 'bg-gradient-to-br from-[#833ab4] via-[#fd1d1d] to-[#fcb045]', onClick: handleShareToInstagram },
        { name: 'YouTube', icon: <YouTubeIcon className="h-8 w-8 text-white" />, color: 'bg-red-600', onClick: handleShareToYouTube },
        { name: 'Discord', icon: <DiscordIcon className="h-8 w-8 text-white" />, color: 'bg-indigo-600', onClick: handleShareToDiscord },
    ];

    const rewardGiven = rewardsGivenToday >= 2;

    interface SocialPlatformCardProps {
        platform: typeof socialPlatforms[0];
        rewardGiven: boolean;
    }
    
    const SocialPlatformCard: React.FC<SocialPlatformCardProps> = ({ platform, rewardGiven }) => {
        return (
            <button onClick={platform.onClick} className={`relative flex flex-col items-center justify-center p-6 rounded-2xl text-white font-bold text-center h-32 ${platform.color} transition-transform transform hover:-translate-y-1`}>
                {!rewardGiven && <div className="absolute top-2 right-2 bg-white/20 text-white text-xs font-bold px-2 py-0.5 rounded-full">+1</div>}
                {platform.icon}
                <span className="mt-2 text-sm">{platform.name}</span>
                {!rewardGiven && <span className="text-xs opacity-80">Earn a credit!</span>}
            </button>
        );
    };

    return (
        <div className="fixed inset-0 bg-base-100 dark:bg-d-base-100 z-50 animate-fade-in-up overflow-y-auto" role="dialog" aria-modal="true">
            <header className="sticky top-0 bg-base-100/80 dark:bg-d-base-100/80 backdrop-blur-sm z-10 border-b border-base-300 dark:border-d-base-300">
                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-16 gap-4">
                    <button
                        onClick={onClose}
                        className="p-2 rounded-full text-text-secondary dark:text-d-text-secondary hover:bg-base-200 dark:hover:bg-d-base-200"
                        aria-label="Back to main menu"
                    >
                        <ArrowLeftIcon className="h-6 w-6" />
                    </button>
                    <h1 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Share ContentCraft</h1>
                </div>
            </header>
            <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
                <section className="my-6 p-4 bg-green-100 dark:bg-green-500/20 rounded-xl flex items-start">
                    <GiftIcon className="h-8 w-8 text-green-600 dark:text-green-400 flex-shrink-0 mt-1" />
                    <div className="ml-4">
                        <h2 className="font-bold text-green-800 dark:text-green-300">Earn Free Credits!</h2>
                        {rewardGiven ? (
                            <p className="text-sm text-green-700 dark:text-green-400 mt-2">
                                You've earned your share credits for today! Thanks for sharing. Come back tomorrow for more rewards.
                            </p>
                        ) : (
                            <>
                                <p className="text-sm text-green-700 dark:text-green-400 mt-2">
                                    You can earn up to <strong>2 free credits</strong> every day for sharing Content Craft. You've earned {rewardsGivenToday} so far today.
                                </p>
                                <div className="text-sm text-green-700 dark:text-green-400 mt-3">
                                    <p className="font-semibold">How it works:</p>
                                    <ol className="list-decimal list-inside mt-1 space-y-1">
                                        <li>Click a share button below.</li>
                                        <li>Share our page with your followers.</li>
                                        <li>Your free credit will be added automatically! (Up to 2 per day)</li>
                                    </ol>
                                </div>
                            </>
                        )}
                    </div>
                </section>
                
                <section className="my-8">
                    <h2 className="text-lg font-bold text-text-primary dark:text-d-text-primary mb-4">Quick Actions</h2>
                    <div className="grid grid-cols-2 gap-4">
                        <button onClick={handleShareApp} className="flex items-center justify-center p-4 bg-gradient-to-r from-purple-500 to-indigo-500 text-white rounded-xl font-bold transition-transform transform hover:scale-105">
                            <ShareIcon className="h-6 w-6 mr-2" /> Share App
                        </button>
                         <button onClick={handleCopyText} className="relative flex items-center justify-center p-4 bg-green-500 text-white rounded-xl font-bold transition-transform transform hover:scale-105">
                            <CopyIcon className="h-6 w-6 mr-2" /> Copy Text
                        </button>
                    </div>
                </section>

                <section className="my-8">
                    <h2 className="text-lg font-bold text-text-primary dark:text-d-text-primary mb-4">Social Platforms</h2>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                        {socialPlatforms.map(platform => <SocialPlatformCard key={platform.name} platform={platform} rewardGiven={rewardGiven} />)}
                    </div>
                </section>

                <section className="my-8">
                    <h2 className="text-lg font-bold text-text-primary dark:text-d-text-primary mb-4">Share Preview</h2>
                    <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-xl">
                        <p className="text-text-secondary dark:text-d-text-secondary">{FULL_SHARE_TEXT}</p>
                    </div>
                </section>
            </main>
            {notification && (
                <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-gray-900/80 dark:bg-gray-100/80 text-white dark:text-black px-4 py-2 rounded-lg shadow-lg text-sm animate-fade-in-up z-50">
                    {notification}
                </div>
            )}
        </div>
    );
};

export default ShareView;