import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type Audience = 'Beginners' | 'Intermediate' | 'Advanced' | 'General Public';
type Goal = 'Drive Traffic' | 'Increase Engagement' | 'Build Authority' | 'Generate Leads';

interface BlogIdea {
    title: string;
    angle: string;
    keywords: string[];
    metrics: {
        trafficPotential: number;
        engagementPotential: number;
        authorityBuilding: number;
    }
}

interface ParsedOutput extends Array<BlogIdea> {}

const BLOG_IDEAS_PROMPT = `
You are an expert content strategist specializing in creating viral blog post ideas that drive traffic, engagement, and authority. Based on the user's input, generate 5 distinct and strategic blog post ideas.

**INPUT:**
- Main Topic: {MAIN_TOPIC}
- Target Audience: {TARGET_AUDIENCE}
- Primary Goal: {PRIMARY_GOAL}
- Desired Tones: {TONES}

**INSTRUCTIONS:**
1.  For each idea, provide a click-worthy title, a unique angle, a list of 3-5 relevant keywords, and performance metrics.
2.  Diversify the ideas by using different content frameworks and angles. Consider frameworks like:
    *   **How-To Guides:** "The Ultimate Guide to..."
    *   **List Posts:** "10 Tips for..."
    *   **Problem-Solution:** "Why You're Struggling With... And How to Fix It"
    *   **Case Studies:** "How I Achieved X..."
    *   **Trend Analysis:** "The Future of..."
3.  Tailor the angle to the specified audience (e.g., beginner-focused, expert-level, myth-busting).
4.  For the \`metrics\`, score each idea from 1-10 on Traffic Potential, Engagement Potential, and Authority Building potential.
5.  Your response must be a valid JSON object conforming to the provided schema.
`;

const responseSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      title: { type: Type.STRING, description: 'A click-worthy and SEO-optimized headline for the blog post.' },
      angle: { type: Type.STRING, description: 'A unique perspective or approach for the blog post.' },
      keywords: { type: Type.ARRAY, items: { type: Type.STRING }, description: 'A list of 3-5 primary and secondary keywords for SEO.' },
      metrics: {
        type: Type.OBJECT,
        properties: {
          trafficPotential: { type: Type.NUMBER, description: 'Score (1-10) for traffic potential based on search volume and shareability.' },
          engagementPotential: { type: Type.NUMBER, description: 'Score (1-10) for potential to generate comments and discussion.' },
          authorityBuilding: { type: Type.NUMBER, description: 'Score (1-10) for potential to build authority and trust.' }
        },
        required: ['trafficPotential', 'engagementPotential', 'authorityBuilding']
      }
    },
    required: ['title', 'angle', 'keywords', 'metrics'],
  },
};

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};

const ScoreBar: React.FC<{ score: number; label: string }> = ({ score, label }) => (
  <div>
    <div className="flex justify-between items-center mb-1">
      <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">{label}</span>
      <span className="text-sm font-bold text-text-primary dark:text-d-text-primary">{score}/10</span>
    </div>
    <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2">
      <div className="bg-brand-primary h-2 rounded-full transition-all duration-500" style={{ width: `${score * 10}%` }}></div>
    </div>
  </div>
);

const BlogIdeasGeneratorView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [audience, setAudience] = useState<Audience>('General Public');
    const [goal, setGoal] = useState<Goal>('Drive Traffic');
    const [tones, setTones] = useState<string[]>([]);
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();
    
    const getPrompt = useCallback(() => {
        return BLOG_IDEAS_PROMPT
            .replace('{MAIN_TOPIC}', input)
            .replace('{TARGET_AUDIENCE}', audience)
            .replace('{PRIMARY_GOAL}', goal)
            .replace('{TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [input, audience, goal, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId && parsed?.[0]?.title) {
                const outputToSave = parsed.map((idea: BlogIdea) => `Title: ${idea.title}\nAngle: ${idea.angle}`).join('\n\n');
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: outputToSave,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse content: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);

    const IdeaCard: React.FC<{idea: BlogIdea}> = ({ idea }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            navigator.clipboard.writeText(idea.title).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        return (
            <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg shadow-sm relative">
                <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary pr-10">{idea.title}</h4>
                <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-1 mb-3">{idea.angle}</p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                    {idea.keywords.map((kw, i) => (
                        <span key={i} className="bg-base-200 dark:bg-d-base-200 px-2 py-1 text-xs font-semibold text-brand-primary rounded-md">{kw}</span>
                    ))}
                </div>

                <Accordion title="Performance Metrics">
                    <div className="space-y-3 p-2">
                        <ScoreBar score={idea.metrics.trafficPotential} label="Traffic Potential" />
                        <ScoreBar score={idea.metrics.engagementPotential} label="Engagement Potential" />
                        <ScoreBar score={idea.metrics.authorityBuilding} label="Authority Building" />
                    </div>
                </Accordion>

                <button onClick={handleCopy} className="absolute top-3 right-3 p-2 rounded-lg bg-base-200 dark:bg-d-base-200 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label="Copy title">
                    <CopyIcon className="h-5 w-5" />
                </button>
                {copySuccess && <div className="absolute top-12 right-3 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        )
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter your main topic or keywords..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Content Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Target Audience</label>
                                <select value={audience} onChange={e => setAudience(e.target.value as Audience)} className={commonInputClasses}>
                                    <option>General Public</option><option>Beginners</option><option>Intermediate</option><option>Advanced</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Primary Goal</label>
                                <select value={goal} onChange={e => setGoal(e.target.value as Goal)} className={commonInputClasses}>
                                    <option>Drive Traffic</option><option>Increase Engagement</option><option>Build Authority</option><option>Generate Leads</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Generating Ideas...' : (isQueued ? 'Request Queued' : 'Generate Blog Ideas')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please enter a topic to generate ideas.</p>}
                </div>

                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Brainstorming brilliant blog ideas...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your strategic blog ideas will appear here.</p>}
                    {parsedOutput && (
                        <div className="space-y-4">
                             <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Generated Blog Ideas</h3>
                             {parsedOutput.map((idea, i) => <IdeaCard key={i} idea={idea} />)}
                        </div>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default BlogIdeasGeneratorView;
