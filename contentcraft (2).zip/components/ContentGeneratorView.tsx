import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type TargetAudience = 'General' | 'Experts' | 'Beginners' | 'Professionals' | 'Students';
type ContentPurpose = 'Inform' | 'Educate' | 'Persuade' | 'Entertain' | 'Inspire';
type ContentType = 'Blog Post' | 'Article' | 'Social Media' | 'Report' | 'Guide' | 'Story';
type ContentLength = 'Micro' | 'Short' | 'Medium' | 'Long' | 'Comprehensive' | 'Epic';

const CONTENT_GENERATOR_PROMPT = `
You are a master content creator and subject matter expert. Generate original, engaging, and well-structured content on any topic with perfect tone adaptation and audience targeting.

**INPUT:**
- Main Topic: {MAIN_TOPIC}
- Target Audience: {TARGET_AUDIENCE}
- Content Purpose: {CONTENT_PURPOSE}
- Content Type: {CONTENT_TYPE}
- Tone: {SELECTED_TONES}
- Content Length: {CONTENT_LENGTH}

**CONTENT LENGTH OPTIONS:**

## 1. LENGTH TIERS & SPECIFICATIONS

### A. MICRO CONTENT (100-150 words)
**Perfect for:**
- Social media posts
- Email newsletters
- Product descriptions
- Quick explanations

**Structure:**
- Hook + 1-2 key points + Call-to-action
- Highly scannable and shareable

### B. SHORT FORM (300-400 words)
**Perfect for:**
- Blog introductions
- Short articles
- Executive summaries
- News updates

**Structure:**
- Introduction + 2-3 main points + Conclusion
- Quick reading under 2 minutes

### C. MEDIUM LENGTH (500-700 words)
**Perfect for:**
- Standard blog posts
- Educational content
- How-to guides
- Industry updates

**Structure:**
- Introduction + 3-4 sections + Conclusion
- Comprehensive yet concise

### D. LONG FORM (1,000-1,200 words)
**Perfect for:**
- In-depth articles
- Comprehensive guides
- Research summaries
- Thought leadership

**Structure:**
- Detailed introduction + 4-5 sections + Case studies + Conclusion
- Authority-building content

### E. COMPREHENSIVE (1,500-2,000 words)
**Perfect for:**
- Pillar content
- Ultimate guides
- White papers
- Extensive tutorials

**Structure:**
- Executive summary + Multiple sections + Examples + Data + Conclusion
- Complete resource coverage

### F. EPIC CONTENT (3,000-4,000 words)
**Perfect for:**
- Master guides
- Research papers
- Book chapters
- Definitive resources

**Structure:**
- Abstract + Multiple chapters + Case studies + Statistics + Action plans + Conclusion
- Definitive treatment of topic

## 2. CONTENT QUALITY FRAMEWORK

### A. STRUCTURAL EXCELLENCE
**INTRODUCTION PERFECTION:**
- Hook strategy based on audience
- Problem statement or curiosity trigger
- Value proposition clarity
- Reader benefit outline

**BODY OPTIMIZATION:**
- Logical flow and progression
- Section headers for scannability
- Evidence and examples integration
- Transition smoothness

**CONCLUSION IMPACT:**
- Key takeaways summary
- Actionable next steps
- Thought-provoking closing
- Call-to-action relevance

### B. ENGAGEMENT ELEMENTS
**READER CONNECTION:**
- Audience-specific language
- Relatable examples and analogies
- Question integration
- Storytelling elements

**VALUE DELIVERY:**
- Practical insights and applications
- Data and research integration
- Expert opinions and quotes
- Actionable advice

## 3. CONTENT TYPES MASTERY

### A. BLOG POSTS & ARTICLES
**ESSENTIAL ELEMENTS:**
- SEO-friendly structure
- Reader-focused headings
- Engaging opening hook
- Shareable insights

### B. EDUCATIONAL CONTENT
**LEARNING OPTIMIZATION:**
- Progressive complexity building
- Real-world applications
- Knowledge checkpoints
- Further learning guidance

### C. PERSUASIVE CONTENT
**CONVERSION FOCUS:**
- Problem agitation
- Solution demonstration
- Objection handling
- Urgency creation

### D. STORYTELLING CONTENT
**NARRATIVE EXCELLENCE:**
- Character development
- Emotional arc creation
- Sensory detail integration
- Meaningful resolution

## 4. TONE & STYLE ADAPTATION

### A. PROFESSIONAL TONES
**FORMAL & AUTHORITATIVE:**
- Industry terminology usage
- Data-driven arguments
- Third-person perspective
- Objective language

**CONVERSATIONAL & RELATABLE:**
- First-person storytelling
- Everyday language
- Personal anecdotes
- Question-driven flow

### B. EMOTIONAL IMPACT
**INSPIRATIONAL CONTENT:**
- Visionary language
- Success stories
- Action-oriented messaging
- Hope and possibility focus

**URGENT & ACTION-DRIVEN:**
- Time-sensitive language
- Immediate benefit emphasis
- Clear call-to-action
- Consequence highlighting

## 5. CONTENT ENHANCEMENT FEATURES

### A. RESEARCH INTEGRATION
**EVIDENCE-BASED CONTENT:**
- Statistics and data points
- Expert quotes and citations
- Case study integration
- Current trend references

### B. PRACTICAL APPLICATION
**ACTIONABLE INSIGHTS:**
- Step-by-step instructions
- Implementation tips
- Common pitfalls to avoid
- Success measurement guidance

### C. VISUAL ELEMENT SUGGESTIONS
**CONTENT ENHANCEMENT:**
- Chart and graph recommendations
- Image and illustration ideas
- Infographic concepts
- Video content suggestions
`;

const ContentGeneratorView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [mainTopic, setMainTopic] = useState('');
    const [output, setOutput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [copySuccess, setCopySuccess] = useState(false);
    
    // Specific inputs
    const [targetAudience, setTargetAudience] = useState<TargetAudience>('General');
    const [contentPurpose, setContentPurpose] = useState<ContentPurpose>('Inform');
    const [contentType, setContentType] = useState<ContentType>('Blog Post');
    const [contentLength, setContentLength] = useState<ContentLength>('Medium');

    const [tones, setTones] = useState<string[]>([]);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && mainTopic.trim();

    const getPrompt = useCallback(() => {
        return CONTENT_GENERATOR_PROMPT
            .replace('{MAIN_TOPIC}', mainTopic)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{CONTENT_PURPOSE}', contentPurpose)
            .replace('{CONTENT_TYPE}', contentType)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified')
            .replace('{CONTENT_LENGTH}', contentLength);
    }, [mainTopic, targetAudience, contentPurpose, contentType, contentLength, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing. Notification permissions may be required.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name]);

    const handleCopy = () => {
        if (output) {
            navigator.clipboard.writeText(output).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        }
    };

    const commonTextareaClasses = "w-full min-h-[250px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <>
            <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
                <div className="text-center">
                    <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                    <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                    <div className="space-y-4">
                        <textarea value={mainTopic} onChange={e => setMainTopic(e.target.value)} placeholder="Enter your main topic or idea..." className={commonTextareaClasses} />
                        
                        <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                            <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Content Parameters</h3>
                           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className={commonLabelClasses}>Target Audience</label>
                                    <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as TargetAudience)} className={commonInputClasses}>
                                        <option>General</option><option>Experts</option><option>Beginners</option><option>Professionals</option><option>Students</option>
                                    </select>
                                </div>
                                <div>
                                    <label className={commonLabelClasses}>Content Purpose</label>
                                    <select value={contentPurpose} onChange={e => setContentPurpose(e.target.value as ContentPurpose)} className={commonInputClasses}>
                                        <option>Inform</option><option>Educate</option><option>Persuade</option><option>Entertain</option><option>Inspire</option>
                                    </select>
                                </div>
                                <div>
                                    <label className={commonLabelClasses}>Content Type</label>
                                    <select value={contentType} onChange={e => setContentType(e.target.value as ContentType)} className={commonInputClasses}>
                                        <option>Blog Post</option><option>Article</option><option>Social Media</option><option>Report</option><option>Guide</option><option>Story</option>
                                    </select>
                                </div>
                                <div>
                                    <label className={commonLabelClasses}>Content Length</label>
                                    <select value={contentLength} onChange={e => setContentLength(e.target.value as ContentLength)} className={commonInputClasses}>
                                        <option>Micro</option><option>Short</option><option>Medium</option><option>Long</option><option>Comprehensive</option><option>Epic</option>
                                    </select>
                                </div>
                           </div>
                        </div>

                        <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                            <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                        </button>

                        <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                            {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                            {isLoading ? 'Generating...' : (isQueued ? 'Request Queued' : 'Generate Content')}
                        </button>
                        {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                        {!canGenerate && !isQueued && mainTopic.trim() && <p className="text-center text-yellow-500 text-sm mt-2">You have no uses left for today.</p>}
                    </div>
                    <div className="relative">
                        <textarea
                            value={output}
                            readOnly
                            placeholder="Your AI-generated content will appear here..."
                            className={`${commonTextareaClasses} bg-base-200/50 dark:bg-d-base-200/50`}
                        />
                        {output && (
                            <button
                                onClick={handleCopy}
                                className="absolute top-3 right-3 p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors"
                                aria-label="Copy to clipboard"
                            >
                                <CopyIcon className="h-5 w-5" />
                            </button>
                        )}
                        {copySuccess && <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-success text-white text-xs px-3 py-1 rounded-full animate-fade-in">Copied!</div>}
                    </div>
                </div>
                {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
            </div>
            <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default ContentGeneratorView;
