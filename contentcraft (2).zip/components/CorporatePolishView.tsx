import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type CorporateContext = 'Executive' | 'C-Suite' | 'Board' | 'Investors' | 'External' | 'Internal';
type Industry = 'Technology' | 'Finance' | 'Healthcare' | 'Manufacturing' | 'Consulting' | 'Other';
type Purpose = 'Strategic Update' | 'Decision Request' | 'Performance Report' | 'Stakeholder Communication';
type AudienceLevel = 'C-Suite' | 'VPs' | 'Directors' | 'Board' | 'General Corporate';
type PolishingLevel = 'Professional' | 'Executive' | 'Board-Level' | 'Investor-Grade';

const CORPORATE_POLISH_PROMPT = `
You are an elite corporate communications expert and executive writing specialist. Transform any text into Fortune 500-level professional communication that demonstrates executive presence, strategic thinking, and business sophistication.

**INPUT:**
- Original Text: {ORIGINAL_TEXT}
- Corporate Context: {CORPORATE_CONTEXT}
- Industry: {INDUSTRY}
- Communication Purpose: {PURPOSE}
- Audience Level: {AUDIENCE_LEVEL}
- Polishing Intensity: {POLISHING_LEVEL}

**TASK:**
First, generate four distinct polished versions based on the polishing level and context. For each version, provide a "Polish Analysis" and "Key Enhancements" breakdown.
Second, provide the comprehensive analysis sections ("Corporate Polish Effectiveness," "Executive Presence Development," "Advanced Polishing Techniques Applied," and "Industry-Specific Examples") as a detailed breakdown of your work. The output MUST follow this structure exactly:

🏢 **CORPORATE-POLISHED VERSIONS:**
---
## 💼 **EXECUTIVE-LEVEL POLISH**
"[Polished text]"

**Polish Analysis:**
- Professionalism: [Score]/10 → [New Score]/10
- Strategic Focus: [Score]/10 → [New Score]/10
- Executive Presence: [Score]/10 → [New Score]/10
- Data Integration: [Score]/10 → [New Score]/10

**Key Enhancements:**
• "[Change 1]" → "[New Phrase]" ([Reason])
• "[Change 2]" → "[New Phrase]" ([Reason])
---
## 🎯 **BOARD-LEVEL POLISH**
"[Polished text]"

**Polish Analysis:**
(same structure as above)
**Key Enhancements:**
(same structure as above)
---
## 📈 **INVESTOR-GRADE POLISH**
"[Polished text]"

**Polish Analysis:**
(same structure as above)
**Key Enhancements:**
(same structure as above)
---
## 🤝 **INTERNAL EXECUTIVE COMMUNICATION**
"[Polished text]"

**Polish Analysis:**
(same structure as above)
**Key Enhancements:**
(same structure as above)
---

📊 **CORPORATE POLISH EFFECTIVENESS:**
**Overall Success Score: [Score]/10**
- Professional Standards: [Score]/10
- Strategic Sophistication: [Score]/10
- Executive Impact: [Score]/10
- Audience Alignment: [Score]/10

🎯 **EXECUTIVE PRESENCE DEVELOPMENT:**
**Original Text Leadership Gaps:**
- [Gap 1]
- [Gap 2]
**Polished Text Leadership Strengths:**
- [Strength 1]
- [Strength 2]

🔧 **ADVANCED POLISHING TECHNIQUES APPLIED:**
• [Technique 1]: [Brief explanation]
• [Technique 2]: [Brief explanation]
• [Technique 3]: [Brief explanation]

💡 **INDUSTRY-SPECIFIC POLISHING EXAMPLES:**
**Technology Industry Polish:**
**Original:** "[Original Text]"
**Polished:** "[Polished Text]"
**Financial Services Polish:**
**Original:** "[Original Text]"
**Polished:** "[Polished Text]"
**Healthcare Polish:**
**Original:** "[Original Text]"
**Polished:** "[Polished Text]"
`;


interface Version {
    title: string;
    content: string;
    analysis: string;
    enhancements: string;
}
interface ParsedOutput {
    versions: Version[];
    effectiveness: string;
    presence: string;
    techniques: string;
    examples: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const CorporatePolishView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const [corporateContext, setCorporateContext] = useState<CorporateContext>('Executive');
    const [industry, setIndustry] = useState<Industry>('Technology');
    const [purpose, setPurpose] = useState<Purpose>('Strategic Update');
    const [audienceLevel, setAudienceLevel] = useState<AudienceLevel>('C-Suite');
    const [polishingLevel, setPolishingLevel] = useState<PolishingLevel>('Executive');
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();

    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string, source = text) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = source.match(regex);
                return match ? match[1].trim() : '';
            };

            const versionsText = getSection('🏢 \\*\\*CORPORATE-POLISHED VERSIONS:\\*\\*', '📊 \\*\\*CORPORATE POLISH EFFECTIVENESS:\\*\\*');
            const versionBlocks = versionsText.split('---').filter(b => b.trim());

            const versions: Version[] = versionBlocks.map(block => {
                const titleMatch = block.match(/## (.*?)\n/);
                const title = titleMatch ? titleMatch[1].replace(/[💼🎯📈🤝*]/g, '').trim() : 'Polished Version';
                const contentMatch = block.match(/"([\s\S]*?)"/);
                const content = contentMatch ? contentMatch[1] : '';
                const analysis = getSection('\\*\\*Polish Analysis:\\*\\*', '\\*\\*Key Enhancements:\\*\\*', block);
                const enhancements = getSection('\\*\\*Key Enhancements:\\*\\*', '$', block);

                return { title, content, analysis, enhancements };
            });

            if (versions.length === 0 || versions.every(v => !v.content)) {
                return null;
            }

            return {
                versions,
                effectiveness: getSection('📊 \\*\\*CORPORATE POLISH EFFECTIVENESS:\\*\\*', '🎯 \\*\\*EXECUTIVE PRESENCE DEVELOPMENT:\\*\\*'),
                presence: getSection('🎯 \\*\\*EXECUTIVE PRESENCE DEVELOPMENT:\\*\\*', '🔧 \\*\\*ADVANCED POLISHING TECHNIQUES APPLIED:\\*\\*'),
                techniques: getSection('🔧 \\*\\*ADVANCED POLISHING TECHNIQUES APPLIED:\\*\\*', '💡 \\*\\*INDUSTRY-SPECIFIC POLISHING EXAMPLES:\\*\\*'),
                examples: getSection('💡 \\*\\*INDUSTRY-SPECIFIC POLISHING EXAMPLES:\\*\\*', '$'),
            };
        } catch (e) {
            console.error("Failed to parse Corporate Polish output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return CORPORATE_POLISH_PROMPT
            .replace('{ORIGINAL_TEXT}', input)
            .replace('{CORPORATE_CONTEXT}', corporateContext)
            .replace('{INDUSTRY}', industry)
            .replace('{PURPOSE}', purpose)
            .replace('{AUDIENCE_LEVEL}', audienceLevel)
            .replace('{POLISHING_LEVEL}', polishingLevel);
    }, [input, corporateContext, industry, purpose, audienceLevel, polishingLevel]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/^- (.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };

    const VersionCard: React.FC<{ version: Version }> = ({ version }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!version.content) return;
            navigator.clipboard.writeText(version.content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!version.content) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative space-y-4">
                <div className="flex justify-between items-start">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{version.title}</h4>
                    <button onClick={handleCopy} className="p-2 rounded-lg bg-base-300 dark:bg-d-base-300 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label={`Copy ${version.title}`}>
                        {copySuccess ? 'Copied!' : <CopyIcon className="h-5 w-5" />}
                    </button>
                </div>
                <p className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed">{version.content}</p>
                <Accordion title="Analysis & Enhancements">
                    <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(`**Polish Analysis:**\n${version.analysis}\n\n**Key Enhancements:**\n${version.enhancements}`)} />
                </Accordion>
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[200px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter text to polish..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Polishing Parameters</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Corporate Context</label>
                                <select value={corporateContext} onChange={e => setCorporateContext(e.target.value as CorporateContext)} className={commonInputClasses}>
                                    <option>Executive</option><option>C-Suite</option><option>Board</option><option>Investors</option><option>External</option><option>Internal</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Industry</label>
                                <select value={industry} onChange={e => setIndustry(e.target.value as Industry)} className={commonInputClasses}>
                                    <option>Technology</option><option>Finance</option><option>Healthcare</option><option>Manufacturing</option><option>Consulting</option><option>Other</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Purpose</label>
                                <select value={purpose} onChange={e => setPurpose(e.target.value as Purpose)} className={commonInputClasses}>
                                    <option>Strategic Update</option><option>Decision Request</option><option>Performance Report</option><option>Stakeholder Communication</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Audience Level</label>
                                <select value={audienceLevel} onChange={e => setAudienceLevel(e.target.value as AudienceLevel)} className={commonInputClasses}>
                                    <option>C-Suite</option><option>VPs</option><option>Directors</option><option>Board</option><option>General Corporate</option>
                                </select>
                            </div>
                             <div className="md:col-span-2">
                                <label className={commonLabelClasses}>Polishing Intensity</label>
                                <select value={polishingLevel} onChange={e => setPolishingLevel(e.target.value as PolishingLevel)} className={commonInputClasses}>
                                    <option>Professional</option><option>Executive</option><option>Board-Level</option><option>Investor-Grade</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Polishing...' : (isQueued ? 'Request Queued' : 'Polish Text')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please provide text to polish.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Applying corporate polish...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your polished versions and analysis will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-6">
                            <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Corporate-Polished Versions</h3>
                                {parsedOutput.versions.map((version, index) => <VersionCard key={index} version={version} />)}
                            </div>
                            <div className="space-y-2 pt-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Analysis & Insights</h3>
                                <Accordion title="Effectiveness" defaultOpen={true}><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.effectiveness)}/></Accordion>
                                <Accordion title="Executive Presence"><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.presence)}/></Accordion>
                                <Accordion title="Techniques Applied"><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.techniques)}/></Accordion>
                                <Accordion title="Industry Examples"><div className="whitespace-pre-wrap" dangerouslySetInnerHTML={formatContent(parsedOutput.examples)}/></Accordion>
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
    );
};

export default CorporatePolishView;