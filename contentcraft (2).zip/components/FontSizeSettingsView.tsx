import React from 'react';
import { useFontSize, FontSize } from '../hooks/useFontSize';
import { useLanguage } from '../hooks/useLanguage';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import CheckIcon from './icons/CheckIcon';

interface FontSizeSettingsViewProps {
  onClose: () => void;
}

const FontSizeSettingsView: React.FC<FontSizeSettingsViewProps> = ({ onClose }) => {
  const { fontSize, setFontSize } = useFontSize();
  const { t } = useLanguage();

  const options: { id: FontSize; nameKey: string; previewClass: string }[] = [
    { id: 'sm', nameKey: 'small', previewClass: 'text-sm' },
    { id: 'md', nameKey: 'medium', previewClass: 'text-base' },
    { id: 'lg', nameKey: 'large', previewClass: 'text-lg' },
  ];

  return (
    <div className="fixed inset-0 bg-base-100 dark:bg-d-base-100 z-50 animate-fade-in-up flex flex-col" role="dialog" aria-modal="true">
      <header className="sticky top-0 bg-brand-primary/95 backdrop-blur-sm z-10 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center h-16 gap-4">
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10"
            aria-label="Back to settings"
          >
            <ArrowLeftIcon className="h-6 w-6" />
          </button>
          <h1 className="text-xl font-bold">{t('fontSizeSettings')}</h1>
        </div>
      </header>
      
      <main className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="text-center mb-8">
                 <div className="w-20 h-20 mx-auto bg-brand-primary/10 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-10 h-10 text-brand-primary">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-12.75 5.25h12.75" />
                    </svg>
                </div>
                <h2 className="text-3xl font-bold font-heading text-text-primary dark:text-d-text-primary">{t('fontSize')}</h2>
                <p className="mt-2 text-text-secondary dark:text-d-text-secondary">
                    {t('fontSizeDescription')}
                </p>
            </div>
            
            <div className="bg-base-200 dark:bg-d-base-200 rounded-xl p-6 mb-8 text-center">
                <p className="text-4xl text-text-primary dark:text-d-text-primary" style={{ fontSize: `calc(3rem * var(--font-scale))` }}>Aa</p>
                <p className="text-lg text-text-secondary dark:text-d-text-secondary" style={{ fontSize: `calc(1.125rem * var(--font-scale))` }}>
                    {t('fontSizePreview')}
                </p>
            </div>

            <div className="space-y-3">
                {options.map(opt => {
                    const isSelected = fontSize === opt.id;
                    return (
                        <button 
                            key={opt.id}
                            onClick={() => setFontSize(opt.id)}
                            className={`w-full text-left bg-base-200 dark:bg-d-base-200 rounded-xl p-4 flex items-center justify-between border-2 transition-all duration-200 ${isSelected ? 'border-brand-primary' : 'border-transparent hover:border-brand-primary/50'}`}
                        >
                            <div className="flex items-center">
                                <span className={`mr-4 font-bold ${opt.previewClass}`}>Aa</span>
                                <div>
                                    <p className="font-bold text-lg text-text-primary dark:text-d-text-primary">{t(opt.nameKey)}</p>
                                </div>
                            </div>
                            {isSelected && (
                                <div className="w-6 h-6 bg-brand-primary rounded-full flex items-center justify-center text-white">
                                    <CheckIcon className="h-4 w-4" />
                                </div>
                            )}
                        </button>
                    )
                })}
            </div>
        </div>
      </main>
    </div>
  );
};

export default FontSizeSettingsView;
