import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ToneSelector from './ToneSelector';
import Rating from './Rating';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type Audience = 'Beginners' | 'Enthusiasts' | 'Professionals' | 'General';
type Purpose = 'Purchase Decision' | 'Comparison' | 'Experience Sharing' | 'Warning';
type Category = 'Electronics' | 'Software' | 'Home' | 'Beauty' | 'Fashion' | 'Food' | 'Other';

const PRODUCT_REVIEW_PROMPT = `
You are an expert product reviewer and consumer advocate with deep knowledge of product analysis, consumer psychology, and persuasive writing. Create comprehensive, authentic, and highly persuasive product reviews that help consumers make informed decisions.

**INPUT:**
- Product Name: {PRODUCT_NAME}
- Product Category: {PRODUCT_CATEGORY}
- Personal Experience: {PERSONAL_EXPERIENCE}
- Overall Rating: {OVERALL_RATING} (out of 5 stars)
- Target Audience: {TARGET_AUDIENCE}
- Review Purpose: {REVIEW_PURPOSE}
- Tone: {SELECTED_TONES}

**COMPREHENSIVE REVIEW CREATION:**

## 1. REVIEW STRUCTURE MASTERY

### A. EXECUTIVE SUMMARY (First Impression)
**COMPONENTS:**
- Quick overall verdict (1-2 sentences)
- Key strengths highlight
- Main limitations mention
- Target user identification
- Star rating upfront

### B. DETAILED EXPERIENCE BREAKDOWN

**PROS SECTION (Strengths):**
- 3-5 major advantages with specific examples
- Performance metrics and data where applicable
- Comparison to competitors or expectations
- Real-world usage benefits

**CONS SECTION (Limitations):**
- 2-4 honest drawbacks with context
- Severity assessment (Minor/Major/Dealbreaker)
- Workarounds or solutions if available
- Impact on user experience

### C. KEY FEATURES ANALYSIS
**FEATURE PERFORMANCE:**
- Core functionality evaluation
- Ease of use and learning curve
- Reliability and consistency
- Value for money assessment

### D. TARGET AUDIENCE MATCH
**PERFECT FOR:**
- Specific user types who will love it
- Use cases where it excels
- Scenarios where it provides maximum value

**NOT IDEAL FOR:**
- User types who should avoid it
- Situations where it underperforms
- Alternative recommendations

## 2. RATING SYSTEM BREAKDOWN

### COMPREHENSIVE SCORING (1-10 scale):
**PERFORMANCE: [X]/10**
- Speed, efficiency, capability
- Benchmark comparisons
- Real-world testing results

**DESIGN & BUILD: [X]/10**
- Aesthetics and ergonomics
- Material quality and durability
- Attention to detail

**VALUE FOR MONEY: [X]/10**
- Price justification
- Competitive positioning
- Long-term cost analysis

**EASE OF USE: [X]/10**
- Learning curve assessment
- Intuitiveness of interface
- Documentation and support

**OVERALL: [X]/10**
- Weighted average with justification

## 3. FINAL VERDICT & RECOMMENDATION
A concluding paragraph summarizing the review and giving a clear buy/don't buy recommendation for the target audience.
`;

interface ParsedOutput {
    executiveSummary: string;
    pros: string;
    cons: string;
    featuresAnalysis: string;
    targetAudienceMatch: string;
    ratingBreakdown: string;
    finalVerdict: string;
    overallRatingText: string;
}

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};


const ProductReviewView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [productName, setProductName] = useState('');
    const [productCategory, setProductCategory] = useState<Category>('Electronics');
    const [personalExperience, setPersonalExperience] = useState('');
    const [overallRating, setOverallRating] = useState(4);
    const [targetAudience, setTargetAudience] = useState<Audience>('General');
    const [reviewPurpose, setReviewPurpose] = useState<Purpose>('Purchase Decision');
    const [tones, setTones] = useState<string[]>([]);
    
    const [output, setOutput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && productName.trim() && personalExperience.trim();
    
    const parseOutput = useCallback((text: string): ParsedOutput | null => {
        try {
            const getSection = (start: string, end: string) => {
                const regex = new RegExp(`${start}([\\s\\S]*?)(?=${end}|$)`, 'im');
                const match = text.match(regex);
                return match ? match[1].trim() : 'Could not parse this section.';
            };
            const overallRatingMatch = text.match(/\*\*OVERALL:\s*\[?([\d\.]+\/10)\]?\*\*/i);
            
            return {
                executiveSummary: getSection('### A. EXECUTIVE SUMMARY', '### B. DETAILED EXPERIENCE BREAKDOWN'),
                pros: getSection('**PROS SECTION', '**CONS SECTION'),
                cons: getSection('**CONS SECTION', '### C. KEY FEATURES ANALYSIS'),
                featuresAnalysis: getSection('### C. KEY FEATURES ANALYSIS', '### D. TARGET AUDIENCE MATCH'),
                targetAudienceMatch: getSection('### D. TARGET AUDIENCE MATCH', '## 2. RATING SYSTEM BREAKDOWN'),
                ratingBreakdown: getSection('## 2. RATING SYSTEM BREAKDOWN', '## 3. FINAL VERDICT & RECOMMENDATION'),
                finalVerdict: getSection('## 3. FINAL VERDICT & RECOMMENDATION', '$'),
                overallRatingText: overallRatingMatch ? overallRatingMatch[1] : 'N/A',
            };
        } catch (e) {
            console.error("Failed to parse Product Review output:", e);
            return null;
        }
    }, []);

    const getPrompt = useCallback(() => {
        return PRODUCT_REVIEW_PROMPT
            .replace('{PRODUCT_NAME}', productName)
            .replace('{PRODUCT_CATEGORY}', productCategory)
            .replace('{PERSONAL_EXPERIENCE}', personalExperience)
            .replace('{OVERALL_RATING}', `${overallRating}/5`)
            .replace('{TARGET_AUDIENCE}', targetAudience)
            .replace('{REVIEW_PURPOSE}', reviewPurpose)
            .replace('{SELECTED_TONES}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [productName, productCategory, personalExperience, overallRating, targetAudience, reviewPurpose, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setOutput('');
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt);
            setOutput(result);
            setParsedOutput(parseOutput(result));
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, parseOutput]);

    const formatContent = (text: string): { __html: string } => {
        if (!text) return { __html: '' };
        return { __html: text
            .replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-text-primary dark:text-d-text-primary">$1</strong>')
            .replace(/•\s*(.*$)/gm, '<li class="ml-4 list-disc">$1</li>')
            .replace(/\n/g, '<br />')
            .replace(/<br \/>\s*<li/g, '<li')
        };
    };

    const ProsConsCard: React.FC<{ title: string; content: string; isPro: boolean }> = ({ title, content, isPro }) => {
        const icon = isPro ? '👍' : '👎';
        if (!content || content.toLowerCase().includes('could not parse')) return null;
        return (
            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300">
                <h4 className={`font-bold text-lg mb-2 flex items-center gap-2 ${isPro ? 'text-success' : 'text-error'}`}>
                    <span>{icon}</span> {title}
                </h4>
                <div className="text-text-primary dark:text-d-text-primary text-sm space-y-2" dangerouslySetInnerHTML={formatContent(content)} />
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className={commonLabelClasses}>Product Name</label>
                            <input value={productName} onChange={e => setProductName(e.target.value)} placeholder="e.g., Quantum Headphones X1" className={commonInputClasses} />
                        </div>
                        <div>
                            <label className={commonLabelClasses}>Product Category</label>
                            <select value={productCategory} onChange={e => setProductCategory(e.target.value as Category)} className={commonInputClasses}>
                                <option>Electronics</option><option>Software</option><option>Home</option><option>Beauty</option><option>Fashion</option><option>Food</option><option>Other</option>
                            </select>
                        </div>
                    </div>
                    
                    <textarea value={personalExperience} onChange={e => setPersonalExperience(e.target.value)} placeholder="Describe your personal experience, usage notes, duration of use..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                            <div>
                                <label className={commonLabelClasses}>Overall Rating</label>
                                <Rating rating={overallRating} onRatingChange={setOverallRating} />
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Review Purpose</label>
                                <select value={reviewPurpose} onChange={e => setReviewPurpose(e.target.value as Purpose)} className={commonInputClasses}>
                                    <option>Purchase Decision</option><option>Comparison</option><option>Experience Sharing</option><option>Warning</option>
                                </select>
                            </div>
                            <div className="md:col-span-2">
                                <label className={commonLabelClasses}>Target Audience</label>
                                <select value={targetAudience} onChange={e => setTargetAudience(e.target.value as Audience)} className={commonInputClasses}>
                                    <option>General</option><option>Beginners</option><option>Enthusiasts</option><option>Professionals</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>

                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                        {isLoading ? 'Writing Review...' : (isQueued ? 'Request Queued' : 'Create Review')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && (productName.trim() || personalExperience.trim()) && <p className="text-center text-yellow-500 text-sm mt-2">Please fill in Product Name and Personal Experience.</p>}
                </div>
                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Crafting your expert review...</p>}
                    {!isLoading && !output && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your comprehensive product review will appear here.</p>}
                    {parsedOutput ? (
                        <div className="space-y-6">
                            <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300">
                                <h3 className="font-bold text-lg text-text-primary dark:text-d-text-primary">Executive Summary</h3>
                                <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-2" dangerouslySetInnerHTML={formatContent(parsedOutput.executiveSummary)} />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                               <ProsConsCard title="Pros (Strengths)" content={parsedOutput.pros} isPro={true} />
                               <ProsConsCard title="Cons (Limitations)" content={parsedOutput.cons} isPro={false} />
                            </div>
                            <div className="space-y-2 pt-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading mb-2">Detailed Analysis</h3>
                                <Accordion title={<>⚙️ <span className="ml-2">Key Features Analysis</span></>} defaultOpen={true}><div dangerouslySetInnerHTML={formatContent(parsedOutput.featuresAnalysis)}/></Accordion>
                                <Accordion title={<>🎯 <span className="ml-2">Target Audience Match</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.targetAudienceMatch)}/></Accordion>
                                <Accordion title={<>📊 <span className="ml-2">Rating System Breakdown</span></>}><div dangerouslySetInnerHTML={formatContent(parsedOutput.ratingBreakdown)}/></Accordion>
                            </div>
                             <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-lg border border-base-300 dark:border-d-base-300">
                                <h3 className="font-bold text-lg text-text-primary dark:text-d-text-primary">Final Verdict & Recommendation</h3>
                                <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-2" dangerouslySetInnerHTML={formatContent(parsedOutput.finalVerdict)} />
                            </div>
                        </div>
                    ) : ( !isLoading && output && <div className="p-2"><h3 className="text-lg font-semibold text-error mb-2">Could not parse AI response.</h3><p className="text-sm text-text-secondary dark:text-d-text-secondary mb-4">Displaying raw output:</p><pre className="whitespace-pre-wrap text-xs">{output}</pre></div> )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default ProductReviewView;