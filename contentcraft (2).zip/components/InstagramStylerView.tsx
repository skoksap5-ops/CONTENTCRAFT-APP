import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type PostType = "Single Photo/Video" | "Carousel" | "Reels";
type Audience = "General" | "Existing Followers" | "New Customers";
type Goal = "Engagement" | "Sales" | "Brand Awareness";

interface ParsedOutput {
    captionVariations: {
        title: string;
        content: string;
        analysis: string;
    }[];
    hashtagStrategy: {
        hashtags: { tag: string; tier: string }[];
        analysis: string;
    };
    performancePrediction: {
        engagementScore: number;
        reachScore: number;
        conversionScore: number;
    };
}

const INSTAGRAM_STYLER_PROMPT = `
You are an expert Instagram content strategist. Your goal is to transform a user's basic idea into multiple high-performing Instagram captions, complete with a strategic hashtag set and performance analysis.

**CONSTRAINTS:**
- Captions must be under 2,200 characters. Aim for the main message within the first 150 characters.
- Use line breaks for readability.
- Hashtag sets must be under 30 total hashtags.

**INPUT:**
- User Message: {USER_MESSAGE}
- Post Type: {POST_TYPE}
- Primary Goal: {GOAL}
- Target Audience: {AUDIENCE}
- Desired Tone: {TONE}

**TASK:**
Generate a complete, valid JSON object that conforms to the provided schema.

**Instructions for JSON fields:**
1.  **captionVariations**: Create three distinct caption versions. Each should have a unique angle (e.g., "Storytelling Angle", "Direct & Punchy", "Question-Based"). For each, provide a brief analysis of the strategy used.
2.  **hashtagStrategy**: Generate a strategic set of 5-15 hashtags based on a 4-Tier Strategy (Broad, Niche, Targeted, Personal/Branded). Provide an analysis explaining why these hashtags were chosen.
3.  **performancePrediction**: Score the potential of the generated content on a scale of 1-10 for Engagement, Reach, and Conversion.
`;

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        captionVariations: {
            type: Type.ARRAY,
            description: "Three distinct caption variations, each with a title, content, and analysis.",
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "A creative title for the caption's strategic angle (e.g., 'The Storyteller')." },
                    content: { type: Type.STRING, description: "The full caption content, including emojis and line breaks (use \\n). No hashtags here." },
                    analysis: { type: Type.STRING, description: "A brief explanation of the strategy behind this caption version." }
                },
                required: ['title', 'content', 'analysis']
            }
        },
        hashtagStrategy: {
            type: Type.OBJECT,
            properties: {
                hashtags: {
                    type: Type.ARRAY,
                    description: "A strategic list of hashtags.",
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            tag: { type: Type.STRING, description: "The hashtag, including the '#' symbol." },
                            tier: { type: Type.STRING, description: "The strategic tier: Broad, Niche, Targeted, or Branded." }
                        },
                        required: ['tag', 'tier']
                    }
                },
                analysis: { type: Type.STRING, description: "An explanation of the hashtag strategy and why these tags were chosen." }
            },
            required: ['hashtags', 'analysis']
        },
        performancePrediction: {
            type: Type.OBJECT,
            properties: {
                engagementScore: { type: Type.NUMBER, description: "Predicted engagement score (1-10)." },
                reachScore: { type: Type.NUMBER, description: "Predicted reach score (1-10)." },
                conversionScore: { type: Type.NUMBER, description: "Predicted conversion score (1-10), relevant to the goal." }
            },
            required: ['engagementScore', 'reachScore', 'conversionScore']
        }
    },
    required: ['captionVariations', 'hashtagStrategy', 'performancePrediction']
};

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-200 dark:bg-d-base-200 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-300/50 dark:hover:bg-d-base-300/50 transition-colors"
        aria-expanded={isOpen}
      >
        <h3 className="font-semibold text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</h3>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 text-text-secondary dark:text-d-text-secondary leading-relaxed animate-fade-in text-sm">
          {children}
        </div>
      )}
    </div>
  );
};

const ScoreBar: React.FC<{ score: number; label: string }> = ({ score, label }) => (
  <div>
    <div className="flex justify-between items-center mb-1">
      <span className="text-sm font-medium text-text-secondary dark:text-d-text-secondary">{label}</span>
      <span className="text-sm font-bold text-text-primary dark:text-d-text-primary">{score}/10</span>
    </div>
    <div className="w-full bg-base-300 dark:bg-d-base-300 rounded-full h-2">
      <div className="bg-brand-primary h-2 rounded-full transition-all duration-500" style={{ width: `${score * 10}%` }}></div>
    </div>
  </div>
);

const InstagramStylerView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [postType, setPostType] = useState<PostType>('Single Photo/Video');
    const [audience, setAudience] = useState<Audience>('General');
    const [goal, setGoal] = useState<Goal>('Engagement');
    const [tones, setTones] = useState<string[]>([]);
    
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();
    
    const getPrompt = useCallback(() => {
        return INSTAGRAM_STYLER_PROMPT
            .replace('{USER_MESSAGE}', input)
            .replace('{POST_TYPE}', postType)
            .replace('{AUDIENCE}', audience)
            .replace('{GOAL}', goal)
            .replace('{TONE}', tones.length > 0 ? tones.join(', ') : 'Not specified');
    }, [input, postType, audience, goal, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId && parsed.captionVariations?.[0]?.content) {
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: parsed.captionVariations[0].content,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse content: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);

    const CaptionCard: React.FC<{variation: ParsedOutput['captionVariations'][0]}> = ({ variation }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            const fullPost = `${variation.content}\n\n${parsedOutput?.hashtagStrategy.hashtags.map(h => h.tag).join(' ')}`;
            navigator.clipboard.writeText(fullPost).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        return (
            <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg shadow-sm relative">
                <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary">{variation.title}</h4>
                <p className="text-xs text-text-secondary dark:text-d-text-secondary mb-3">{variation.analysis}</p>
                <pre className="text-text-primary dark:text-d-text-primary whitespace-pre-wrap font-sans text-sm leading-relaxed">{variation.content}</pre>
                <button onClick={handleCopy} className="absolute top-3 right-3 p-2 rounded-lg bg-base-200 dark:bg-d-base-200 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors" aria-label="Copy post content">
                    <CopyIcon className="h-5 w-5" />
                </button>
                {copySuccess && <div className="absolute bottom-2 right-2 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        )
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";
    
    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter your core message, idea, or description..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Post Parameters</h3>
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label className={commonLabelClasses}>Post Type</label>
                                <select value={postType} onChange={e => setPostType(e.target.value as PostType)} className={commonInputClasses}>
                                    <option>Single Photo/Video</option><option>Carousel</option><option>Reels</option>
                                </select>
                            </div>
                            <div>
                                <label className={commonLabelClasses}>Audience</label>
                                <select value={audience} onChange={e => setAudience(e.target.value as Audience)} className={commonInputClasses}>
                                    <option>General</option><option>Existing Followers</option><option>New Customers</option>
                                </select>
                            </div>
                             <div>
                                <label className={commonLabelClasses}>Goal</label>
                                <select value={goal} onChange={e => setGoal(e.target.value as Goal)} className={commonInputClasses}>
                                    <option>Engagement</option><option>Sales</option><option>Brand Awareness</option>
                                </select>
                            </div>
                       </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Crafting Post...' : (isQueued ? 'Request Queued' : 'Generate Instagram Post')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please enter a message to generate a post.</p>}
                </div>

                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Crafting your professional post...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your expert-crafted Instagram post and analysis will appear here.</p>}
                    {parsedOutput && (
                        <div className="space-y-6">
                             <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Caption Variations</h3>
                                {parsedOutput.captionVariations.map((v, i) => <CaptionCard key={i} variation={v} />)}
                            </div>
                            
                            <div className="space-y-2">
                                <Accordion title="🚀 Hashtag Performance & Strategy" defaultOpen={true}>
                                    <div className="space-y-4 p-2">
                                         <p className="text-xs text-text-secondary dark:text-d-text-secondary">{parsedOutput.hashtagStrategy.analysis}</p>
                                         <div className="pt-2">
                                            <h4 className="text-sm font-semibold text-text-primary dark:text-d-text-primary mb-2">Recommended Hashtags:</h4>
                                            <div className="flex flex-wrap gap-2">
                                                {parsedOutput.hashtagStrategy.hashtags.map((h, i) => (
                                                    <div key={i} className="bg-base-300 dark:bg-d-base-300 px-2 py-1 rounded-md text-xs">
                                                        <span className="font-semibold text-text-primary dark:text-d-text-primary">{h.tag}</span>
                                                        <span className="text-text-secondary dark:text-d-text-secondary ml-1.5">({h.tier})</span>
                                                    </div>
                                                ))}
                                            </div>
                                         </div>
                                    </div>
                                </Accordion>
                                <Accordion title="📊 Performance Prediction" defaultOpen={true}>
                                    <div className="space-y-4 p-2">
                                        <ScoreBar score={parsedOutput.performancePrediction.engagementScore} label="Engagement Potential" />
                                        <ScoreBar score={parsedOutput.performancePrediction.reachScore} label="Reach Potential" />
                                        <ScoreBar score={parsedOutput.performancePrediction.conversionScore} label="Conversion Potential" />
                                    </div>
                                </Accordion>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default InstagramStylerView;