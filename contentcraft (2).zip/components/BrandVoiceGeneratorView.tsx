import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { saveGeneration } from '../services/historyService';
import { addToQueue } from '../services/offlineService';
import { useFeedback } from '../hooks/useFeedback';
import { Type } from '@google/genai';
import SparklesIcon from './icons/settings/SparklesIcon';
import MicrophoneIcon from './icons/ai_power/MicrophoneIcon';
import EyeIcon from './icons/settings/EyeIcon';
import BriefcaseIcon from './icons/professional/BriefcaseIcon';
import SmileIcon from './icons/professional/SmileIcon';
import LightbulbIcon from './icons/professional/LightbulbIcon';
import GraduationCapIcon from './icons/professional/GraduationCapIcon';
import GamepadIcon from './icons/professional/GamepadIcon';
import GemIcon from './icons/professional/GemIcon';
import SaveIcon from './icons/SaveIcon';
import PaintBrushIcon from './icons/PaintBrushIcon';

interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface GeneratedData {
    brand_profile: { tagline: string; };
    sample_content: { instagram: string; email: string; blog: string; };
    voice_analysis: {
        metrics: { consistency: number; clarity: number; engagement: number; uniqueness: number; };
        guidelines: { dos: string[]; donts: string[]; };
    };
    transformed_example: { before: string; after: string; };
}

const brandVoiceSchema = {
    type: Type.OBJECT,
    properties: {
        brand_profile: {
            type: Type.OBJECT,
            properties: { tagline: { type: Type.STRING } },
            required: ['tagline']
        },
        sample_content: {
            type: Type.OBJECT,
            properties: {
                instagram: { type: Type.STRING },
                email: { type: Type.STRING },
                blog: { type: Type.STRING }
            },
            required: ['instagram', 'email', 'blog']
        },
        voice_analysis: {
            type: Type.OBJECT,
            properties: {
                metrics: {
                    type: Type.OBJECT,
                    properties: {
                        consistency: { type: Type.NUMBER },
                        clarity: { type: Type.NUMBER },
                        engagement: { type: Type.NUMBER },
                        uniqueness: { type: Type.NUMBER }
                    },
                    required: ['consistency', 'clarity', 'engagement', 'uniqueness']
                },
                guidelines: {
                    type: Type.OBJECT,
                    properties: {
                        dos: { type: Type.ARRAY, items: { type: Type.STRING } },
                        donts: { type: Type.ARRAY, items: { type: Type.STRING } }
                    },
                    required: ['dos', 'donts']
                }
            },
            required: ['metrics', 'guidelines']
        },
        transformed_example: {
            type: Type.OBJECT,
            properties: {
                before: { type: Type.STRING },
                after: { type: Type.STRING }
            },
            required: ['before', 'after']
        }
    },
    required: ['brand_profile', 'sample_content', 'voice_analysis', 'transformed_example']
};


const BrandVoiceGeneratorView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const { playClick, playSuccess } = useFeedback();

    // Input State
    const [brandName, setBrandName] = useState('');
    const [brandDescription, setBrandDescription] = useState('');
    const [targetAudience, setTargetAudience] = useState('');
    const [selectedAttributes, setSelectedAttributes] = useState<string[]>(['professional']);
    const [toneSettings, setToneSettings] = useState({ formal: 50, serious: 50, enthusiastic: 50, modern: 50 });
    const [brandKeywords, setBrandKeywords] = useState('');
    const [contentExamples, setContentExamples] = useState('');

    // Output State
    const [generatedData, setGeneratedData] = useState<GeneratedData | null>(null);
    const [activeTab, setActiveTab] = useState('preview');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && brandName.trim();

    const handleAttributeClick = (attribute: string) => {
        playClick();
        setSelectedAttributes(prev => 
            prev.includes(attribute) 
            ? prev.filter(a => a !== attribute) 
            : [...prev, attribute]
        );
    };

    const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { id, value } = e.target;
        const type = id.replace('-slider', '');
        setToneSettings(prev => ({ ...prev, [type]: parseInt(value) }));
    };
    
    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        playClick();
        setIsLoading(true);
        setError(null);
        
        const prompt = `You are an expert brand strategist and copywriter. Based on the user's input, generate a complete brand voice profile.

        **INPUT:**
        - Brand Name: ${brandName}
        - Brand Description: ${brandDescription}
        - Target Audience: ${targetAudience}
        - Brand Voice Attributes: ${selectedAttributes.join(', ')}
        - Tone Adjustments: Formal: ${toneSettings.formal}%, Serious: ${toneSettings.serious}%, Enthusiastic: ${toneSettings.enthusiastic}%, Modern: ${toneSettings.modern}%
        - Brand Keywords: ${brandKeywords}
        - Example Content to Transform: ${contentExamples}

        **INSTRUCTIONS:**
        Your response must be a valid JSON object conforming to the provided schema.
        1.  **brand_profile**: Create a concise brand tagline.
        2.  **sample_content**: Generate short, brand-consistent content snippets for Instagram, a Marketing Email, and a Blog Introduction.
        3.  **voice_analysis**: Provide percentage scores (0-100) for Consistency, Clarity, Engagement, and Uniqueness. Also, create a list of "Do"s and "Don't"s for the brand voice.
        4.  **transformed_example**: Take the user's example content and provide a rewritten "after" version that matches the defined brand voice. If multiple examples are provided in the input, transform the first one. If no example is provided, create a generic one.
        
        Ensure all generated content reflects the specified attributes and tone settings.`;

        try {
            const result = await generateContent(prompt, {
                responseMimeType: 'application/json',
                responseSchema: brandVoiceSchema as any,
            });
            const parsed: GeneratedData = JSON.parse(result);
            setGeneratedData(parsed);
            setActiveTab('profile');
            playSuccess();
            
            if (userId) {
                saveGeneration(userId, {
                    moduleId: module.id, moduleName: module.name,
                    inputs: `Brand: ${brandName}, Description: ${brandDescription.substring(0, 50)}...`,
                    output: `Generated brand voice profile for ${brandName}.`
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();

        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, brandName, brandDescription, targetAudience, selectedAttributes, toneSettings, brandKeywords, contentExamples, playClick, playSuccess, module, userId, usesLeft, decrementUse]);

    const attributeCards = [
        { id: 'professional', name: 'Professional', icon: <BriefcaseIcon className="h-8 w-8"/>, desc: 'Formal, authoritative tone' },
        { id: 'friendly', name: 'Friendly', icon: <SmileIcon className="h-8 w-8"/>, desc: 'Warm, approachable style' },
        { id: 'innovative', name: 'Innovative', icon: <LightbulbIcon className="h-8 w-8"/>, desc: 'Forward-thinking, creative' },
        { id: 'authoritative', name: 'Authoritative', icon: <GraduationCapIcon className="h-8 w-8"/>, desc: 'Expert, knowledgeable tone' },
        { id: 'playful', name: 'Playful', icon: <GamepadIcon className="h-8 w-8"/>, desc: 'Fun, energetic style' },
        { id: 'luxury', name: 'Luxury', icon: <GemIcon className="h-8 w-8"/>, desc: 'Elegant, premium tone' },
    ];

    return (
        <div className="brand-voice-generator-module max-w-7xl mx-auto flex flex-col gap-8">
            <header className="text-center">
                <h1 className="text-4xl font-bold font-heading">{module.name}</h1>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                <section className="creation-section bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-6">
                    <div className="section-title flex items-center gap-4">
                        <div className="section-icon w-12 h-12 flex items-center justify-center rounded-xl text-white"><MicrophoneIcon className="w-6 h-6"/></div>
                        <h2 className="text-2xl font-bold font-heading">Define Your Brand Voice</h2>
                    </div>
                    <input type="text" value={brandName} onChange={e => setBrandName(e.target.value)} placeholder="Brand Name" className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                    <textarea value={brandDescription} onChange={e => setBrandDescription(e.target.value)} placeholder="Describe what your brand does..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[100px]"></textarea>
                    <input type="text" value={targetAudience} onChange={e => setTargetAudience(e.target.value)} placeholder="Describe your ideal customers" className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                    
                    <div>
                        <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">Brand Voice Attributes</label>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                           {attributeCards.map(card => (
                                <button key={card.id} onClick={() => handleAttributeClick(card.id)} className={`attribute-card p-3 rounded-lg border-2 text-center transition-all duration-200 bg-base-100 dark:bg-d-base-100 ${selectedAttributes.includes(card.id) ? 'selected' : 'border-transparent'}`}>
                                    <div className="attribute-icon text-3xl mx-auto">{card.icon}</div>
                                    <div className="text-sm font-semibold">{card.name}</div>
                                </button>
                           ))}
                        </div>
                    </div>
                    
                    <div>
                        <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-2">Tone Adjustments</label>
                        <div className="space-y-3">
                            {Object.keys(toneSettings).map(key => (
                                <div key={key}>
                                    <div className="flex justify-between items-center text-sm">
                                        <span className="capitalize font-medium">{key}</span>
                                        <span className="font-semibold text-brand-purple">{toneSettings[key as keyof typeof toneSettings]}%</span>
                                    </div>
                                    <input type="range" min="0" max="100" value={toneSettings[key as keyof typeof toneSettings]} id={`${key}-slider`} onChange={handleSliderChange} className="w-full h-2 bg-base-300 rounded-lg appearance-none cursor-pointer slider"/>
                                </div>
                            ))}
                        </div>
                    </div>

                    <textarea value={brandKeywords} onChange={e => setBrandKeywords(e.target.value)} placeholder="Brand Keywords & Phrases (comma separated)..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[80px]"></textarea>
                    <textarea value={contentExamples} onChange={e => setContentExamples(e.target.value)} placeholder="Paste existing content to transform with your brand voice..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[80px]"></textarea>

                     <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full btn-primary flex items-center justify-center p-4 rounded-xl text-white font-bold text-lg gap-2">
                        {isLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/50 border-t-white rounded-full"></span> : <SparklesIcon className="h-6 w-6" />}
                        {isLoading ? 'Generating...' : 'Generate Brand Voice'}
                    </button>
                    {error && <div className="text-center bg-error/20 text-error p-2 rounded-lg text-sm">{error}</div>}
                </section>

                <section className="preview-section bg-base-200 dark:bg-d-base-200 p-6 rounded-xl flex flex-col">
                    <div className="section-title flex items-center gap-4">
                        <div className="section-icon w-12 h-12 flex items-center justify-center rounded-xl text-white"><EyeIcon className="w-6 h-6"/></div>
                        <h2 className="text-2xl font-bold font-heading">Brand Voice Preview</h2>
                    </div>
                     <div className="preview-tabs flex border-b border-base-300 dark:border-d-base-300 mt-4">
                        <button className={`tab px-4 py-2 ${activeTab === 'preview' && 'active'}`} onClick={() => setActiveTab('preview')}>Content Preview</button>
                        <button className={`tab px-4 py-2 ${activeTab === 'profile' && 'active'}`} onClick={() => setActiveTab('profile')}>Voice Profile</button>
                        <button className={`tab px-4 py-2 ${activeTab === 'examples' && 'active'}`} onClick={() => setActiveTab('examples')}>Transformed</button>
                    </div>

                    <div className="flex-1 preview-container bg-base-100 dark:bg-d-base-100 border-t-0 rounded-t-none">
                        <div className={`tab-content ${activeTab === 'preview' && 'active'}`}>
                            <div className="brand-profile">
                                <div className="brand-name">{brandName || "Your Brand"}</div>
                                <div className="brand-tagline">{generatedData?.brand_profile.tagline || "Consistent voice across all content"}</div>
                            </div>
                             <div className="space-y-4">
                                <div><h4 className="font-bold mb-2">Social Media Post</h4><div className="preview-content">{generatedData?.sample_content.instagram || "..."}</div></div>
                                <div><h4 className="font-bold mb-2">Email Newsletter</h4><div className="preview-content">{generatedData?.sample_content.email || "..."}</div></div>
                                <div><h4 className="font-bold mb-2">Blog Introduction</h4><div className="preview-content">{generatedData?.sample_content.blog || "..."}</div></div>
                            </div>
                        </div>
                        <div className={`tab-content ${activeTab === 'profile' && 'active'}`}>
                             <h4>Brand Voice Analysis</h4>
                            <div className="grid grid-cols-2 gap-4 my-4">
                                <div className="metric-card"><div className="metric-value">{generatedData?.voice_analysis.metrics.consistency || 0}%</div><div className="metric-label">Consistency</div></div>
                                <div className="metric-card"><div className="metric-value">{generatedData?.voice_analysis.metrics.clarity || 0}%</div><div className="metric-label">Clarity</div></div>
                                <div className="metric-card"><div className="metric-value">{generatedData?.voice_analysis.metrics.engagement || 0}%</div><div className="metric-label">Engagement</div></div>
                                <div className="metric-card"><div className="metric-value">{generatedData?.voice_analysis.metrics.uniqueness || 0}%</div><div className="metric-label">Uniqueness</div></div>
                            </div>
                             <h4>Voice Guidelines</h4>
                            <div className="grid grid-cols-2 gap-4">
                                <div><h5 className="font-semibold text-green-600">Do:</h5><ul className="list-disc list-inside text-sm">{generatedData?.voice_analysis.guidelines.dos.map((d,i)=><li key={i}>{d}</li>)}</ul></div>
                                <div><h5 className="font-semibold text-red-600">Don't:</h5><ul className="list-disc list-inside text-sm">{generatedData?.voice_analysis.guidelines.donts.map((d,i)=><li key={i}>{d}</li>)}</ul></div>
                            </div>
                        </div>
                         <div className={`tab-content ${activeTab === 'examples' && 'active'}`}>
                             <h4>Before & After Examples</h4>
                            <div className="example-item">
                                <div className="font-semibold text-xs uppercase text-text-secondary dark:text-d-text-secondary">BEFORE:</div>
                                <div className="italic">{generatedData?.transformed_example.before || "Your 'before' text will appear here."}</div>
                                <div className="font-semibold text-xs uppercase text-text-secondary dark:text-d-text-secondary mt-2">AFTER:</div>
                                <div className="font-semibold text-brand-purple">{generatedData?.transformed_example.after || "Your transformed text will appear here."}</div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
};

export default BrandVoiceGeneratorView;
