import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import ToneSelector from './ToneSelector';
import CopyIcon from './icons/CopyIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import { Type } from '@google/genai';
import TwitterIcon from './icons/social/TwitterIcon';
import LinkedInIcon from './icons/social/LinkedInIcon';
import InstagramIcon from './icons/social/InstagramIcon';
import BlogIcon from './icons/social/BlogIcon';
import EmailIcon from './icons/social/EmailIcon';
import YouTubeIcon from './icons/social/YouTubeIcon';
import TikTokIcon from './icons/social/TikTokIcon';


interface ModuleViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface RepurposedContent {
    platform: string;
    title: string;
    content: string;
    strategyTips: string[];
}

type ParsedOutput = RepurposedContent[];

const repurposingSchema = {
    type: Type.ARRAY,
    description: "An array of repurposed content pieces for various platforms.",
    items: {
        type: Type.OBJECT,
        properties: {
            platform: { type: Type.STRING, description: "The target platform (e.g., 'Twitter Thread', 'LinkedIn Post')." },
            title: { type: Type.STRING, description: "A catchy title or hook for the content piece." },
            content: { type: Type.STRING, description: "The main body of the repurposed content, formatted with markdown for line breaks." },
            strategyTips: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of 2-3 actionable tips for posting this content." }
        },
        required: ['platform', 'title', 'content', 'strategyTips']
    }
};

const Accordion: React.FC<{ title: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-100 dark:bg-d-base-100 rounded-lg border border-base-300 dark:border-d-base-300 overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-4 text-left hover:bg-base-200/50 dark:hover:bg-d-base-200/50 transition-colors"
        aria-expanded={isOpen}
      >
        <div className="font-bold text-lg text-text-primary dark:text-d-text-primary flex items-center gap-3">{title}</div>
        <ChevronDownIcon className={`h-5 w-5 text-text-secondary dark:text-d-text-secondary transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-4 border-t border-base-300 dark:border-d-base-300 space-y-4 animate-fade-in">
          {children}
        </div>
      )}
    </div>
  );
};


const AIContentRepurposingView: React.FC<ModuleViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const [sourceContent, setSourceContent] = useState('');
    const [targetFormats, setTargetFormats] = useState<string[]>(['Twitter Thread', 'LinkedIn Post']);
    const [tones, setTones] = useState<string[]>([]);
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    const [isToneSelectorOpen, setIsToneSelectorOpen] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && sourceContent.trim() && targetFormats.length > 0;

    const availableFormats = [
        { id: 'Twitter Thread', name: 'Twitter Thread', icon: <TwitterIcon className="h-6 w-6" /> },
        { id: 'LinkedIn Post', name: 'LinkedIn Post', icon: <LinkedInIcon className="h-6 w-6" /> },
        { id: 'Instagram Carousel', name: 'Instagram Carousel', icon: <InstagramIcon className="h-6 w-6" /> },
        { id: 'TikTok Script', name: 'TikTok Script', icon: <TikTokIcon className="h-6 w-6 text-black dark:text-white" /> },
        { id: 'YouTube Script', name: 'YouTube Script', icon: <YouTubeIcon className="h-6 w-6" /> },
        { id: 'Blog Post Outline', name: 'Blog Outline', icon: <BlogIcon className="h-6 w-6" /> },
        { id: 'Email Newsletter', name: 'Email Newsletter', icon: <EmailIcon className="h-6 w-6" /> },
    ];

    const getPrompt = useCallback(() => {
        return `You are an expert content strategist specializing in repurposing content for multiple platforms. Transform the following source content into engaging pieces for the specified target formats.

**SOURCE CONTENT:**
---
${sourceContent}
---

**TARGET FORMATS:**
${targetFormats.join(', ')}

**DESIRED TONE:**
${tones.length > 0 ? tones.join(', ') : 'Match the original tone'}

**INSTRUCTIONS:**
1.  For each target format, create a compelling piece of content that is natively suited to that platform.
2.  Include a catchy title or hook for each piece.
3.  Provide 2-3 actionable strategy tips for publishing each piece of content.
4.  Your response MUST be a valid JSON object conforming to the provided schema. Ensure 'content' fields use markdown for line breaks (\\n).
`;
    }, [sourceContent, targetFormats, tones]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: repurposingSchema,
            });
            const parsed = JSON.parse(result);
            setParsedOutput(parsed);
            
            if(userId) {
                const outputToSave = parsed.map((p: RepurposedContent) => `Platform: ${p.platform}\nTitle: ${p.title}\n${p.content}`).join('\n\n---\n\n');
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: prompt,
                    output: outputToSave,
                });
            }
            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate or parse content: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name, userId]);

    const handleFormatToggle = (formatId: string) => {
        setTargetFormats(prev => 
            prev.includes(formatId) 
            ? prev.filter(id => id !== formatId)
            : [...prev, formatId]
        );
    };

    const commonTextareaClasses = "w-full min-h-[250px] p-4 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    
    return (
        <>
        <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                <div className="space-y-4">
                    <textarea value={sourceContent} onChange={e => setSourceContent(e.target.value)} placeholder="Paste your blog post, article, or transcript here..." className={commonTextareaClasses} />
                    
                    <div className="bg-base-200 dark:bg-d-base-200 p-4 rounded-xl space-y-3">
                        <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Select Formats to Generate</h3>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                           {availableFormats.map(format => (
                                <button
                                    key={format.id}
                                    onClick={() => handleFormatToggle(format.id)}
                                    className={`flex flex-col items-center justify-center p-3 rounded-lg border-2 transition-colors text-center ${targetFormats.includes(format.id) ? 'bg-brand-primary/10 border-brand-primary text-brand-primary' : 'bg-base-100 dark:bg-d-base-100 border-base-300 dark:border-d-base-300'}`}
                                >
                                    {format.icon}
                                    <span className="text-xs font-semibold mt-1">{format.name}</span>
                                </button>
                           ))}
                        </div>
                    </div>

                    <button onClick={() => setIsToneSelectorOpen(true)} className="bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg p-4 w-full text-left hover:border-brand-primary/50 transition-colors">
                        <div className="flex justify-between items-center"><div className="flex items-center gap-2"><span role="img" aria-label="palette emoji" className="text-xl">🎨</span><h3 className="font-semibold text-text-primary dark:text-d-text-primary">Tone Control</h3></div><div className="text-sm font-medium bg-base-300 dark:bg-d-base-300 px-3 py-1.5 rounded-full text-text-secondary dark:text-d-text-secondary"><span className="font-bold text-text-primary dark:text-d-text-primary">{tones.length}</span> / 3</div></div>
                    </button>
                    
                    <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                        {isLoading && <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>}
                        {isLoading ? 'Repurposing...' : (isQueued ? 'Request Queued' : 'Repurpose Content')}
                    </button>
                    {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                    {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please provide content and select at least one format.</p>}
                </div>

                <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                    {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Repurposing your content...</p>}
                    {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your repurposed content will appear here.</p>}
                    {parsedOutput && (
                        <div className="space-y-4">
                            <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Generated Content</h3>
                            {parsedOutput.map((item, i) => (
                                <Accordion key={i} title={item.platform} defaultOpen={i === 0}>
                                    <div className="relative group">
                                         <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary mb-2">{item.title}</h4>
                                         <pre className="text-sm text-text-primary dark:text-d-text-primary whitespace-pre-wrap font-sans mt-2">{item.content}</pre>
                                         <div className="mt-4">
                                            <h5 className="font-semibold text-xs uppercase tracking-wider text-text-secondary dark:text-d-text-secondary mb-2">Strategy Tips</h5>
                                            <ul className="list-disc list-inside space-y-1 text-xs text-text-secondary dark:text-d-text-secondary">
                                                {item.strategyTips.map((tip, j) => <li key={j}>{tip}</li>)}
                                            </ul>
                                         </div>
                                         <button onClick={() => navigator.clipboard.writeText(`${item.title}\n\n${item.content}`)} className="absolute top-0 right-0 p-2 rounded-lg bg-base-200 dark:bg-d-base-200 opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Copy content">
                                            <CopyIcon className="h-5 w-5" />
                                        </button>
                                    </div>
                                </Accordion>
                            ))}
                        </div>
                    )}
                </div>
            </div>
            {error && <div className="max-w-7xl mx-auto mt-6 text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
        </div>
        <ToneSelector isOpen={isToneSelectorOpen} onClose={() => setIsToneSelectorOpen(false)} selectedTones={tones} onTonesChange={setTones} />
        </>
    );
};

export default AIContentRepurposingView;
