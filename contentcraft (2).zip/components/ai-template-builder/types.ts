export interface PurposeData {
  platform: string;
  contentType: string;
  industry: string;
  primaryGoal: string;
  targetAudience: string;
  brandVoice: string;
  productType: string;
  productName?: string;
  productDescription?: string;
}

export interface AIAnalysisData {
  patterns: string[];
  optimalStructure: { type: string; description: string }[];
  estimatedEngagement: string;
  viralPotential: string;
}

export interface TemplateData {
  name: string;
  platform: string;
  contentType: string;
  structure: {
    type: string;
    purpose: string;
    content: string;
    examples?: string[];
  }[];
}


export interface TemplateVariation {
  variationTitle: string;
  approach: string;
  template: TemplateData;
  predictedPerformance: {
    engagement: string;
    bestFor: string;
  };
  optimizationTips: string[];
}

export interface GenerationResponse {
    variations: TemplateVariation[];
}