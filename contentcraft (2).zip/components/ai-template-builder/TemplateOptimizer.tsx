

import React, { useState } from 'react';
import type { TemplateData } from './types';

interface TemplateOptimizerProps {
  template: TemplateData | null;
  onOptimize: (goals: { length: string; tone: string; }) => void;
  isLoading: boolean;
}

export const TemplateOptimizer: React.FC<TemplateOptimizerProps> = ({ template, onOptimize, isLoading }) => {
    const [goals, setGoals] = useState({ length: 'balanced', tone: 'as-is' });

    const handleOptimize = () => {
        onOptimize(goals);
    };

    if (isLoading) {
     return (
      <div className="text-center p-8 animate-fade-in">
        <svg className="animate-spin mx-auto h-12 w-12 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <h3 className="text-xl font-bold font-heading mt-4">AI is optimizing your template...</h3>
        <p className="text-text-secondary dark:text-d-text-secondary mt-2">Refining the structure based on your goals.</p>
      </div>
    );
    }

    return (
      <div className="p-8 bg-base-200 dark:bg-d-base-200 rounded-lg animate-fade-in">
        <h3 className="text-2xl font-bold font-heading mb-4 text-text-primary dark:text-d-text-primary text-center">Template Optimizer</h3>
        <p className="text-text-secondary dark:text-d-text-secondary mb-6 text-center">Refine your template for specific needs before personalizing.</p>
        
        <div className="bg-base-100 dark:bg-d-base-100 p-4 my-4 rounded-md text-left shadow-inner">
            <p className="text-sm text-text-secondary dark:text-d-text-secondary">Current Template: <strong>{template?.name}</strong></p>
        </div>

        <div className="space-y-4 my-6">
            <div>
                <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1 text-left">Length</label>
                <select value={goals.length} onChange={e => setGoals(g => ({...g, length: e.target.value}))} className="w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg">
                    <option value="balanced">Balanced</option>
                    <option value="concise">More Concise</option>
                    <option value="detailed">More Detailed</option>
                </select>
            </div>
            <div>
                <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1 text-left">Tone Shift</label>
                 <select value={goals.tone} onChange={e => setGoals(g => ({...g, tone: e.target.value}))} className="w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg">
                    <option value="as-is">Keep As Is</option>
                    <option value="more-formal">More Formal</option>
                    <option value="more-casual">More Casual</option>
                </select>
            </div>
        </div>

        <button onClick={handleOptimize} disabled={isLoading} className="w-full max-w-xs mx-auto flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-gray-400">
          {isLoading ? 'Optimizing...' : 'Next: Personalize ✨'}
        </button>
      </div>
    );
};