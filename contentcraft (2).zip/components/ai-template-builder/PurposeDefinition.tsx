import React, { useState } from 'react';
import type { PurposeData } from './types';

interface PurposeDefinitionProps {
  onSubmit: (data: PurposeData) => void;
  isLoading: boolean;
}

const commonInputClasses = "w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";


const PurposeDefinition: React.FC<PurposeDefinitionProps> = ({ onSubmit, isLoading }) => {
  const [purpose, setPurpose] = useState<PurposeData>({
    platform: '',
    contentType: '',
    industry: '',
    primaryGoal: '',
    targetAudience: '',
    brandVoice: 'professional',
    productType: 'saas-platform',
    productName: '',
    productDescription: '',
  });

  const platforms = ['LinkedIn', 'Twitter', 'Instagram', 'Email', 'Blog', 'YouTube'];
  const contentTypes = ['Thought Leadership', 'Educational', 'Promotional', 'Entertainment', 'News'];
  const industries = ['Technology', 'Marketing', 'Healthcare', 'Finance', 'Education', 'E-commerce'];
  const productTypes = ['SaaS Platform', 'Digital Service', 'Physical Product', 'E-commerce Store', 'Consulting Service'];


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(purpose);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPurpose(prev => ({ ...prev, [name]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="platform" className={commonLabelClasses}>Platform</label>
          <select id="platform" name="platform" value={purpose.platform} onChange={handleInputChange} required className={commonInputClasses}>
            <option value="">Select Platform</option>
            {platforms.map(p => (<option key={p} value={p.toLowerCase()}>{p}</option>))}
          </select>
        </div>

        <div>
          <label htmlFor="contentType" className={commonLabelClasses}>Content Type</label>
          <select id="contentType" name="contentType" value={purpose.contentType} onChange={handleInputChange} required className={commonInputClasses}>
            <option value="">Select Content Type</option>
            {contentTypes.map(type => (<option key={type} value={type.toLowerCase()}>{type}</option>))}
          </select>
        </div>

        <div>
          <label htmlFor="industry" className={commonLabelClasses}>Industry</label>
          <select id="industry" name="industry" value={purpose.industry} onChange={handleInputChange} required className={commonInputClasses}>
            <option value="">Select Industry</option>
            {industries.map(i => (<option key={i} value={i.toLowerCase()}>{i}</option>))}
          </select>
        </div>

        <div>
          <label htmlFor="productType" className={commonLabelClasses}>Product Type</label>
          <select id="productType" name="productType" value={purpose.productType} onChange={handleInputChange} required className={commonInputClasses}>
            {productTypes.map(pt => (<option key={pt} value={pt.toLowerCase().replace(' ', '-')}>{pt}</option>))}
          </select>
        </div>
        
         <div>
          <label htmlFor="brandVoice" className={commonLabelClasses}>Brand Voice</label>
          <select id="brandVoice" name="brandVoice" value={purpose.brandVoice} onChange={handleInputChange} className={commonInputClasses}>
            <option value="professional">Professional</option>
            <option value="casual">Casual</option>
            <option value="authoritative">Authoritative</option>
            <option value="friendly">Friendly</option>
            <option value="innovative">Innovative</option>
          </select>
        </div>
         <div>
          <label htmlFor="primaryGoal" className={commonLabelClasses}>Primary Goal</label>
          <input id="primaryGoal" name="primaryGoal" type="text" placeholder="e.g., Lead generation" value={purpose.primaryGoal} onChange={handleInputChange} required className={commonInputClasses}/>
        </div>
      </div>
       <div className="grid grid-cols-1">
            <div>
              <label htmlFor="targetAudience" className={commonLabelClasses}>Target Audience</label>
              <input id="targetAudience" name="targetAudience" type="text" placeholder="e.g., Startup founders, marketing managers" value={purpose.targetAudience} onChange={handleInputChange} required className={commonInputClasses}/>
            </div>
       </div>
      
       <div className="p-4 bg-base-100/50 dark:bg-d-base-100/50 rounded-lg border border-dashed border-base-300 dark:border-d-base-300 space-y-4">
            <h4 className="font-semibold text-text-primary dark:text-d-text-primary">Personalization (Optional)</h4>
            <p className="text-xs text-text-secondary dark:text-d-text-secondary -mt-2">Provide product details for a more tailored template.</p>
            <div className="grid grid-cols-1 gap-6">
                <div>
                  <label htmlFor="productName" className={commonLabelClasses}>Product/Service Name</label>
                  <input id="productName" name="productName" type="text" placeholder="e.g., ContentCraft AI" value={purpose.productName} onChange={handleInputChange} className={commonInputClasses}/>
                </div>
                <div>
                  <label htmlFor="productDescription" className={commonLabelClasses}>Short Product/Service Description</label>
                  <textarea id="productDescription" name="productDescription" placeholder="Describe what your product does in a sentence or two." value={purpose.productDescription} onChange={handleInputChange} className={`${commonInputClasses} min-h-[60px]`}/>
                </div>
            </div>
        </div>

      <button type="submit" disabled={isLoading} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary disabled:bg-base-300 dark:disabled:bg-d-base-300 transition-all duration-300">
        {isLoading ? 'Analyzing...' : 'Analyze with AI 🚀'}
      </button>
    </form>
  );
};

export default PurposeDefinition;