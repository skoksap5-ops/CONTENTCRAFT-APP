

import React, { useState } from 'react';
import type { GenerationResponse, TemplateData } from './types';

interface TemplateGeneratorProps {
  generationResponse: GenerationResponse | null;
  onSelectTemplate: (template: TemplateData) => void;
  isLoading: boolean;
}

const TemplateGenerator: React.FC<TemplateGeneratorProps> = ({ generationResponse, onSelectTemplate, isLoading }) => {
  const [activeTab, setActiveTab] = useState(0);

  if (isLoading || !generationResponse) {
     return (
      <div className="text-center p-8 animate-fade-in">
        <svg className="animate-spin mx-auto h-12 w-12 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <h3 className="text-xl font-bold font-heading mt-4">AI is generating your template variations...</h3>
        <p className="text-text-secondary dark:text-d-text-secondary mt-2">Crafting multiple strategic approaches based on millions of data points.</p>
      </div>
    );
  }
  
  const activeVariation = generationResponse.variations[activeTab];
  if (!activeVariation) return <p className="text-center text-error">Could not load template variations.</p>

  return (
    <div className="space-y-6 animate-fade-in">
        <div className="text-center">
            <h3 className="text-2xl font-bold font-heading text-text-primary dark:text-d-text-primary">Select a Template Variation</h3>
            <p className="text-text-secondary dark:text-d-text-secondary mt-1">AI has generated three unique approaches. Choose the one that best fits your needs to optimize and personalize it.</p>
        </div>

        <div className="border-b border-base-300 dark:border-d-base-300 flex items-center justify-center">
            {generationResponse.variations.map((variation, index) => (
                <button 
                    key={index}
                    onClick={() => setActiveTab(index)}
                    className={`px-4 py-3 font-semibold transition-colors duration-200 border-b-2 -mb-px ${activeTab === index ? 'border-brand-primary text-brand-primary' : 'border-transparent text-text-secondary dark:text-d-text-secondary hover:text-text-primary dark:hover:text-d-text-primary'}`}
                >
                    {variation.variationTitle}
                </button>
            ))}
        </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-base-100 dark:bg-d-base-100 p-6 rounded-lg space-y-4">
            <h4 className="font-bold text-xl text-text-primary dark:text-d-text-primary">{activeVariation.template.name}</h4>
             {activeVariation.template.structure.map((section, index) => (
                <div key={index} className="bg-base-200 dark:bg-d-base-200 p-4 rounded-md">
                    <div className="flex justify-between items-center">
                        <span className="font-bold text-text-primary dark:text-d-text-primary">{section.type}</span>
                        <span className="text-xs text-text-secondary dark:text-d-text-secondary">{section.purpose}</span>
                    </div>
                    <p className="text-sm text-text-secondary dark:text-d-text-secondary mt-2">{section.content}</p>
                </div>
            ))}
        </div>
        <div className="space-y-4">
            <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg">
                <h5 className="font-bold mb-2">Strategic Approach</h5>
                <p className="text-sm text-text-secondary dark:text-d-text-secondary">{activeVariation.approach}</p>
            </div>
             <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg">
                <h5 className="font-bold mb-2">Performance Prediction</h5>
                <p className="text-sm"><strong className="text-brand-primary">Engagement:</strong> {activeVariation.predictedPerformance.engagement}</p>
                <p className="text-sm"><strong className="text-brand-primary">Best For:</strong> {activeVariation.predictedPerformance.bestFor}</p>
            </div>
             <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg">
                <h5 className="font-bold mb-2">Optimization Tips</h5>
                 <ul className="space-y-1 list-disc list-inside text-sm text-text-secondary dark:text-d-text-secondary">
                    {activeVariation.optimizationTips.map((tip, i) => <li key={i}>{tip}</li>)}
                </ul>
            </div>
        </div>
      </div>


       <button onClick={() => onSelectTemplate(activeVariation.template)} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary transition-all duration-300">
        Select & Continue to Optimize 🔧
      </button>
    </div>
  );
};

export default TemplateGenerator;
