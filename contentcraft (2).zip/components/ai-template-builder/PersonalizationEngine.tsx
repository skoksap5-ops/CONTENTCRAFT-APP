
import React, { useState, useCallback } from 'react';
import type { TemplateData } from './types';
import CheckCircleIcon from '../icons/CheckCircleIcon';

interface PersonalizationEngineProps {
  template: TemplateData | null;
  onPersonalize: (persona: string) => Promise<void>;
  isLoading: boolean;
}

export const PersonalizationEngine: React.FC<PersonalizationEngineProps> = ({ template, onPersonalize, isLoading }) => {
  const [persona, setPersona] = useState('');
  const [isPersonalized, setIsPersonalized] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  const handlePersonalize = async () => {
    await onPersonalize(persona);
    setIsPersonalized(true);
  };
  
  const formatTemplateForDownload = useCallback((templateData: TemplateData): string => {
    let content = `# Template: ${templateData.name}\n\n`;
    content += `**Platform:** ${templateData.platform}\n`;
    content += `**Content Type:** ${templateData.contentType}\n\n`;
    content += '---\n\n';
    content += '## Template Structure\n\n';

    templateData.structure.forEach((section, index) => {
      content += `### ${index + 1}. ${section.type} (${section.purpose})\n\n`;
      content += `**Instruction:** ${section.content}\n\n`;
      if (section.examples && section.examples.length > 0) {
        content += '**Examples:**\n';
        section.examples.forEach(ex => {
          content += `- ${ex}\n`;
        });
        content += '\n';
      }
      content += '---\n\n';
    });

    return content;
  }, []);

  const handleDownload = useCallback(() => {
    if (!template) return;

    const content = formatTemplateForDownload(template);
    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    const filename = `${template.name.toLowerCase().replace(/[\s/]/g, '-')}.md`;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 3000);
  }, [template, formatTemplateForDownload]);

  if (!isPersonalized) {
      return (
          <div className="p-8 bg-base-200 dark:bg-d-base-200 rounded-lg animate-fade-in">
            <h3 className="text-2xl font-bold font-heading mb-4 text-text-primary dark:text-d-text-primary text-center">Personalization Engine</h3>
            <p className="text-text-secondary dark:text-d-text-secondary mb-6 text-center">Adapt your template for a specific audience segment or individual.</p>
            
            <div className="bg-base-100 dark:bg-d-base-100 p-4 my-4 rounded-md text-left shadow-inner">
                <p className="text-sm text-text-secondary dark:text-d-text-secondary">Current Template: <strong>{template?.name}</strong></p>
            </div>

            <div className="my-6">
                <label className="block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1 text-left">Target Persona (Optional)</label>
                <input 
                    value={persona} 
                    onChange={e => setPersona(e.target.value)} 
                    placeholder="e.g., Early-stage startup CEOs, busy parents" 
                    className="w-full p-3 bg-base-100 dark:bg-d-base-100 border border-base-300 dark:border-d-base-300 rounded-lg"
                />
            </div>

            <button onClick={handlePersonalize} disabled={isLoading} className="w-full max-w-xs mx-auto flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-gray-400">
              {isLoading ? 'Personalizing...' : 'Personalize & Finish ✅'}
            </button>
          </div>
      );
  }

  return (
    <div className="text-center p-8 bg-base-200 dark:bg-d-base-200 rounded-lg animate-fade-in">
      <CheckCircleIcon className="h-16 w-16 text-brand-secondary mx-auto" />
      <h3 className="text-2xl font-bold font-heading mt-4 text-text-primary dark:text-d-text-primary">Your Template is Ready!</h3>
      <p className="text-text-secondary dark:text-d-text-secondary my-4">Your AI-generated, optimized, and personalized template is complete.</p>
      
      <div className="bg-base-100 dark:bg-d-base-100 p-4 my-6 rounded-md text-left shadow-inner">
          <p className="text-sm text-text-secondary dark:text-d-text-secondary">Final Template:</p>
          <p className="font-bold text-text-primary dark:text-d-text-primary"><strong>{template?.name}</strong></p>
      </div>

      <button
        onClick={handleDownload}
        className="w-full max-w-xs mx-auto flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-secondary hover:bg-green-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary transition-all duration-300"
      >
        {downloaded ? 'Downloaded!' : 'Download Final Template'}
      </button>
    </div>
  );
};
