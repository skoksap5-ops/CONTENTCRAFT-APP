import React from 'react';
import type { AIAnalysisData } from './types';

interface AIAnalysisProps {
  analysis: AIAnalysisData | null;
  onGenerate: () => void;
  isLoading: boolean;
}

const AIAnalysis: React.FC<AIAnalysisProps> = ({ analysis, onGenerate, isLoading }) => {
  if (isLoading || !analysis) {
    return (
      <div className="text-center p-8 animate-fade-in">
        <svg className="animate-spin mx-auto h-12 w-12 text-brand-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <h3 className="text-xl font-bold font-heading mt-4">AI is analyzing successful patterns...</h3>
        <p className="text-text-secondary dark:text-d-text-secondary mt-2">Examining thousands of high-performing templates in your niche.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-base-200 dark:bg-d-base-200 p-6 rounded-lg">
          <h4 className="font-bold text-lg mb-3">📊 Success Patterns Found</h4>
          <ul className="space-y-2 text-sm list-disc list-inside text-text-secondary dark:text-d-text-secondary">
            {analysis.patterns.map((pattern, index) => (<li key={index}>{pattern}</li>))}
          </ul>
        </div>

        <div className="bg-base-200 dark:bg-d-base-200 p-6 rounded-lg">
          <h4 className="font-bold text-lg mb-3">🎯 Optimal Structure</h4>
          <div className="space-y-3">
            {analysis.optimalStructure.map((section, index) => (
              <div key={index} className="text-sm">
                <strong className="block text-text-primary dark:text-d-text-primary">{section.type}</strong>
                <p className="text-text-secondary dark:text-d-text-secondary">{section.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-base-200 dark:bg-d-base-200 p-6 rounded-lg text-center flex flex-col justify-center">
            <h4 className="font-bold text-lg mb-4">📈 Performance Insights</h4>
            <div className="space-y-4">
                <div>
                    <span className="text-4xl font-bold text-brand-primary">{analysis.estimatedEngagement}%</span>
                    <span className="block text-sm text-text-secondary dark:text-d-text-secondary mt-1">Estimated Engagement</span>
                </div>
                 <div>
                    <span className="text-4xl font-bold text-brand-secondary">{analysis.viralPotential}</span>
                    <span className="block text-sm text-text-secondary dark:text-d-text-secondary mt-1">Viral Potential</span>
                </div>
            </div>
        </div>
      </div>

      <button onClick={onGenerate} disabled={isLoading} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-base-100 dark:focus:ring-offset-d-base-100 focus:ring-brand-primary disabled:bg-base-300 dark:disabled:bg-d-base-300 transition-all duration-300">
        {isLoading ? 'Generating...' : 'Generate Template 🎨'}
      </button>
    </div>
  );
};

export default AIAnalysis;
