import React, { useState, useRef, useEffect, useMemo } from 'react';
import { generateContent } from '../services/geminiService';
import { MODULES } from '../constants';
import type { Content } from '@google/genai';
import CloseIcon from './icons/CloseIcon';

interface Message {
    id: number;
    type: 'user' | 'bot';
    content: string;
}

const moduleDatabase: { [key: string]: any } = {};
MODULES.forEach(m => {
    moduleDatabase[m.id] = {
        name: m.name,
        category: m.group,
        description: m.description,
        mainTask: m.prompt('input', ['tone1', 'tone2']).split('.')[0],
    };
});

const additionalKnowledge = `

**GENERAL INFORMATION (PRICING & TRIAL):**
- **Trial Period:** After selecting a desired plan (monthly, annual, or lifetime), there is a 3-day trial period.
- **Pricing Plans:**
  - **Monthly Plan:** $9.99 per month.
  - **Annual Plan:** $99.99 per year (Saves 17%).
  - **Lifetime Plan:** $299.99 as a one-time payment.
- All Pro plans offer unlimited generations and access to all features. The free version has daily usage limits.

**TONE ENGINE EXPLANATION:**
- **What is the Tone Engine?** The "Tone Control" is a powerful feature in most ContentCraft modules that allows you to precisely control the emotional and stylistic tone of your generated content. It's not a separate module but an integrated part of the content creation process.
- **How many tones are there?** The Tone Engine offers over 30 distinct tones across 6 categories (Standard, Emotional, Inspirational, Neutral, Serious, Professional).
- **Can I combine tones?** Yes! You can select and blend up to 3 different tones to create a unique and nuanced voice. For example, you could combine 'Professional', 'Enthusiastic', and 'Convincing' for a powerful sales email.
- **Which modules have it?** The Tone Control feature is available in nearly all modules that generate or modify text, including the Content Generator, Email Craft, Social Stylers, and many more. It's a core part of making your content unique.
- **Available Tones:** The tones include Formal, Assertive, Informative, Convincing, Urgent, Appreciative, Enthusiastic, Awestruck, Joyful, Passionate, Humorous, Thoughtful, Empathetic, Sympathetic, Inspirational, Encouraging, Optimistic, Earnest, Neutral, Casual, Candid, Humble, Serious, Compassionate, Cautionary, Critical, Worried, Angry, Skeptical, Professional, Authoritative, and Collaborative.

**FINANCIAL BENEFITS & MONETIZATION IDEAS:**
Here are over 100 ways you can leverage ContentCraft modules to earn money:

**🤖 AI POWER SUITE**
- **AI Prompt Generator:** Offer prompt engineering services to businesses or sell specialized prompt packs for different AI models (like Midjourney or ChatGPT).
- **AI Template Builder:** Design and sell high-quality, reusable content templates for specific industries (e.g., real estate, SaaS) on platforms like Etsy or Gumroad.
- **AI Ebook Creator:** Write and self-publish eBooks on Amazon KDP or other platforms. Become a ghostwriter for clients.
- **Brand Voice Generator:** Offer brand voice consulting services. Help new businesses define their tone and create a style guide.
- **AI Trend Spotter:** Create and sell niche-specific trend reports to marketing agencies or businesses.
- **AI Content Repurposing Engine:** Offer a service to creators and brands where you turn one piece of content (like a blog post) into a full social media campaign.
- **AI Chatbot Training Data Generator:** Generate and sell specialized datasets to companies developing AI chatbots.
- **AI SEO Opportunity Finder:** Offer SEO audit services to businesses, identifying keyword gaps and content opportunities they can rank for.
- **AI Search Optimizer (GEO):** Charge clients to optimize their websites and local business listings for AI search engines like Perplexity and Google AI Overviews.
- **AI Content Performance Predictor:** Offer content analysis as a service to help brands predict engagement before they publish.
- **AI Comment Response Generator:** Work as a freelance community manager, using the tool to create authentic responses for clients' social media.
- **AI Competitor & Gap Analyzer:** Sell detailed competitor analysis reports to businesses in any niche.
- **AI Social Media Calendar Planner:** Create and sell ready-to-use social media content calendars for busy entrepreneurs.
- **AI Quiz & Assessment Creator:** Design lead-generation quizzes for businesses and charge for the setup and content.

**🔧 CORE MODULES**
- **SEO Optimizer:** Offer freelance SEO content writing and optimization services for blogs and websites.
- **Meta Description Generator:** Get paid to write compelling meta descriptions for e-commerce sites or blogs.
- **FAQ Schema Generator:** Provide a technical SEO service to implement FAQ schema on clients' websites to improve their search visibility.
- **Human Warmth / Corporate Polish / Empathetic Tone / Narrative Softener / Tone Harmonizer:** Offer copy-editing and tone-of-voice services.
- **Clarity Enhancer:** Offer services to simplify technical or academic writing.
- **Summary Synthesizer:** Create executive summaries of long reports for busy professionals.
- **Grammar & Style Proofer:** Start a freelance proofreading and editing business.
- **Text Craft:** Offer versatile freelance writing services, quickly expanding or shortening text as per client needs.
- **Paragraph Generator:** Speed up your freelance writing workflow by quickly generating paragraphs on any topic.
- **Plagiarism Checker:** Offer content auditing services to ensure originality and provide rewriting suggestions.
- **Clean Paste:** Charge clients to "humanize" their existing AI-generated content to make it undetectable.
- **Global Translator:** Offer high-quality freelance translation and localization services for websites and documents.

**📱 SOCIAL SUITE**
- **Social Stylers (LinkedIn, Instagram, Twitter, etc.):** Become a freelance social media manager for multiple clients.
- **Hashtag Generator:** Sell hashtag research and strategy packages to influencers and brands.
- **Blog Ideas Generator:** Offer a "blog topic ideation" service to companies with content marketing needs.
- **YouTube Video to Blog Article:** Offer a service to YouTubers to repurpose their video content into blog posts.
- **Quora Answer Assistant:** Manage a Quora marketing strategy for clients, driving traffic and establishing them as experts.

**💼 PROFESSIONAL & CONTENT**
- **Startup Pitch:** Offer pitch deck writing and refinement services to new startups.
- **Personal Bio Generator:** Get paid to write professional bios for executives' LinkedIn, Twitter, and company websites.
- **Resume Generator:** Start a resume and cover letter writing service for job seekers.
- **Email Craft:** Write cold outreach sequences or marketing email campaigns for businesses.
- **ASO Optimizer:** Offer App Store Optimization (ASO) services to mobile app developers.
- **Create Product Review:** Become an affiliate marketer by quickly generating detailed reviews for products and earning commissions on sales.
- **Press Release:** Offer PR writing services to companies announcing new products or milestones.
- **Case Study Creator:** Write compelling case studies for B2B companies to use in their sales funnels.
- **Whitepaper Writer:** Position yourself as a B2B writer and create lead-generating whitepapers for tech and corporate clients.
- **Proposal Generator:** Offer a service to create persuasive business proposals for other freelancers or agencies.
- **AI-Powered Video Scriptwriter:** Offer scriptwriting services for YouTubers, course creators, and corporate training videos.

**🎯 MARKETING & CONVERSION**
- **Headline Generator:** Offer A/B testing headline packages to bloggers and media companies.
- **Slogan Generator:** Offer branding packages for new businesses that include slogan creation.
- **E-commerce Product Description:** Write product descriptions for Shopify or Amazon stores on a freelance basis.
- **Create Google Ad / Facebook Ad:** Offer ad copywriting services to digital marketing agencies or small businesses.
- **Landing Page Copy:** Specialize in writing high-converting landing page copy for clients.
- **Newsletter Builder:** Offer a "done-for-you" newsletter service for creators and businesses.

**CLEAN PASTE MODULE - In-Depth Explanation**
- **What it does:** Transforms AI-generated content into natural, human-sounding text by removing statistical patterns, predictable grammar, and generic phrases.
- **How it works:** It analyzes for "AI fingerprints," then "humanizes" the text by varying sentence structure, introducing colloquialisms, and personalizing the tone, while preserving the original meaning.
- **Why it's useful:**
  - **SEO Optimization:** Humanized content performs better with Google's E-E-A-T criteria, leading to better rankings.
  - **Increased Engagement:** Natural-sounding text keeps readers on the page longer and encourages more shares and comments.
  - **Professional Applications:** Ideal for marketing agencies, bloggers, and businesses to improve the authenticity of their AI-assisted content.
- **Key Value:** It combines the efficiency of AI with the authenticity of human writing. You can offer "AI content humanization" as a freelance service.
`;

const serbianKnowledgeBase = `
---
### **DETAILED MODULE DOCUMENTATION (SERBIAN)**
---

🔍 CLEAN PASTE MODUL - Detaljan Opis

🎯 ŠTA JE CLEAN PASTE?

Clean Paste je moćan modul koji transformiše veštački generisan sadržaj u prirodan, ljudski tekst. Zamislite ga kao "čarobni štapić" koji uzme tekst koji je očigledno napisan od strane AI-a i pretvori ga u nešto što zvuči kao da ga je napisao čovek.

🔧 KAKO RADI PO PRINCIPU?

1. ANALIZA AI "OTISAKA"

Modul prvo pažljivo analizira tekst i tragi specifične znake koji otkrivaju da je sadržaj AI-generisan:

· Statističke šablone - AI koristi predvidive kombinacije reči
· Savršenu gramatiku - Previše bezgrešnih rečenica
· Uniforman ritam - Sve rečenice slične dužine i strukture
· Generički izrazi - Nedostatak ličnog, specifičnog jezika

2. PROCES HUMANIZACIJE

Nakon analize, modul primenjuje više tehnika da učini tekst prirodnijim:

· Menja strukturu rečenica - Pravi varijacije u dužini
· Uvodi kolokvijalne izraze - Dodaje svakodnevni jezik
· Dodaje "ljudske nesavršenosti" - Prirodne greške i varijacije
· Personalizuje ton - Čini ga ličnijim i autentičnijim

3. PROVERA KVALITETA

Na kraju, modul proverava da li transformisani tekst:

· Zadržava originalno značenje
· Zvuči prirodno ljudski
· Ima dobar protok i čitljivost

💼 ZA ŠTA SE KORISTI?

1. OPTIMIZACIJA ZA GOOGLE

Iako Google tvrdi da ne kažnjava AI sadržaj, humanizovani tekst:

· Bolje prolazi E-E-A-T kriterijume (iskustvo, stručnost, autoritet, poverenje)
· Dobija bolji ranking jer korisnici duže ostaju na stranici
· Ima veću šansu za featured snippet pozicije

2. POVEĆANJE ANGAŽOVANJA

Kada ljudi čitaju tekst koji zvuči ljudski:

· Duže ostaju na stranici
· Više dele sadržaj
· Ostavljaju više komentara
· Veruju više informacijama

3. PROFESIONALNE PRIMENE

· Marketing agencije - Humanizacija klijentskog sadržaja
· Bloggeri - Poboljšanje autentičnosti članaka
· Edukatori - Prirodniji nastavni materijal
· Preduzeća - Bolji korisnički sadržaj

🚀 ZAŠTO JE KORISAN?

1. KOMERCIJALNA ISPLATIVOST

Možete naplatiti usluge humanizacije:

· $50-200 po blog postu
· $500-1500 za eBook transformaciju
· Mesečne pretplate za redovne klijente

2. VREMENSKA EFIKASNOST

Umesto da:

· Ručno prepravljate AI tekst (satima)
· Tražite ljudske pisce (danima)
· Riskirate loš kvalitet

Clean Paste daje kvalitetne rezultate za 2-5 minuta

3. KONKURENTSKA PREDNOST

Dok drugi koriste očigledno AI-generisan sadržaj:

· Vi nudite "ljudski" kvalitet
· Bolji Google ranking
· Veće poverenje čitalaca
· Profesionalniji imidž

📊 REALNI REZULTATI

Pre Clean Paste:

"Veštačka inteligencija revolucionizuje digitalni marketing 
kroz automatizaciju procesa i personalizaciju korisničkih iskustava."

Posle Clean Paste:

"Kao neko ko radi u digitalnom marketingu već godinama, 
mogu vam reći da AI zaista menja pravila igre. Umesto da 
samo automatizujem dosadne zadatke, sada mogu da stvorim 
iskustva koja se zaista povezuju sa mojom publikom."

🛡️ BEZBEDNOST I POVERENJE

Modul je dizajniran da:

· Ne čuva vaše podatke - tekst se briše nakon procesiranja
· Održava privatnost - niko ne vidi vaš sadržaj
· Čuva značenje - ne menja suštinu poruke

💡 KO BI TREBALO DA KORISTI?

Idealni korisnici:

· ✅ Freelanceri koji žele da nude bolje usluge
· ✅ Marketing timovi koji žele bolje rezultate
· ✅ Content kreatori koji žele autentičnost
· ✅ SEO stručnjaci koji žele bolji ranking
· ✅ Preduzetnici koji žele da štede vreme

Nije za:

· ❌ Potpuno zamenu ljudskog pisanja - i dalje treba ljudska kontrola
· ❌ Prevaru ili plagijat - moralno korišćenje je ključno

🌟 ZAKLJUČAK

Clean Paste je kao imati profesionalnog editora koji specijalno prepravlja AI tekst da zvuči potpuno ljudski.

To nije samo alat - to je strategka prednost u svetu gde svi koriste AI, ali malo ko zna kako da ga učini zaista ubedljivim i efektivnim.

Ključna vrednost: Omogućava vam da iskoristite efikasnost AI-a + autentičnost ljudskog pisanja = najbolji mogući rezultat 🚀

### **OPŠTE INFORMACIJE (CENE I PROBNI PERIOD):**
- **Probni period:** Nakon odabira željenog plana (mesečni, godišnji ili doživotni), postoji probni period od 3 dana.
- **Cenovni planovi:**
  - **Mesečni plan:** $9.99 mesečno.
  - **Godišnji plan:** $99.99 godišnje (Ušteda 17%).
  - **Doživotni plan:** $299.99 jednokratno.
- Svi Pro planovi nude neograničeno generisanje i pristup svim funkcijama. Besplatna verzija ima dnevna ograničenja korišćenja.

### **OBJAŠNJENJE TONE ENGINE-A:**
- **Šta je Tone Engine?** "Kontrola tona" je moćna funkcija u većini ContentCraft modula koja vam omogućava da precizno kontrolišete emocionalni i stilski ton vašeg generisanog sadržaja. To nije poseban modul, već integrisani deo procesa kreiranja sadržaja.
- **Koliko tonova postoji?** Tone Engine nudi preko 30 različitih tonova u 6 kategorija (Standardni, Emotivni, Inspirativni, Neutralni, Ozbiljni, Profesionalni).
- **Mogu li da kombinujem tonove?** Da! Možete izabrati i kombinovati do 3 različita tona da biste stvorili jedinstven i nijansiran glas. Na primer, možete kombinovati 'Profesionalni', 'Entuzijastičan' i 'Ubedljiv' za moćan prodajni email.
- **Koji moduli ga imaju?** Funkcija kontrole tona dostupna je u skoro svim modulima koji generišu ili modifikuju tekst, uključujući Content Generator, Email Craft, Social Stylers i mnoge druge. To je suštinski deo činjenja vašeg sadržaja jedinstvenim.
- **Dostupni tonovi:** Tonovi uključuju Formalan, Asertivan, Informativan, Ubedljiv, Hitno, Zahvalan, Entuzijastičan, Zadivljen, Radostan, Strastven, Duhovit, Pažljiv, Empatičan, Saosećajan, Inspirativan, Ohrabrujući, Optimističan, Iskren, Neutralan, Opušten, Iskren, Skroman, Ozbiljan, Saosećajan, Oprezan, Kritičan, Zabrinut, Ljut, Skeptičan, Profesionalan, Autoritativan i Kolaborativan.

### **FINANSIJSKE KORISTI I IDEJE ZA MONETIZACIJU:**
Evo preko 100 načina na koje možete iskoristiti ContentCraft module da zaradite novac:

**🤖 AI POWER SUITE**
- **AI Prompt Generator:** Ponudite usluge prompt inženjeringa ili prodajte specijalizovane pakete promptova.
- **AI Template Builder:** Dizajnirajte i prodajte šablone za sadržaj na Etsy-ju ili Gumroad-u.
- **AI Ebook Creator:** Pišite i samostalno objavljujte e-knjige na Amazon KDP.
- **Brand Voice Generator:** Ponudite konsultantske usluge za definisanje glasa brenda.
- **AI Trend Spotter:** Kreirajte i prodajte izveštaje o trendovima u specifičnim nišama.
- **AI Content Repurposing Engine:** Ponudite uslugu pretvaranja jednog sadržaja (npr. blog posta) u celu kampanju za društvene mreže.
- **AI Chatbot Training Data Generator:** Generišite i prodajte setove podataka za obuku AI čet-botova.
- **AI SEO Opportunity Finder:** Ponudite SEO analizu, identifikujući ključne reči i prilike za sadržaj.
- **AI Search Optimizer (GEO):** Optimizujte veb-sajtove za AI pretraživače kao što su Perplexity i Google AI Overviews.
- **AI Content Performance Predictor:** Ponudite analizu sadržaja kako biste predvideli angažovanje pre objavljivanja.
- **AI Comment Response Generator:** Radite kao frilens menadžer zajednice, koristeći alat za kreiranje autentičnih odgovora.
- **AI Competitor & Gap Analyzer:** Prodajte detaljne izveštaje o analizi konkurencije.
- **AI Social Media Calendar Planner:** Kreirajte i prodajte gotove kalendare sadržaja za društvene mreže.
- **AI Quiz & Assessment Creator:** Dizajnirajte kvizove za generisanje lidova i naplatite podešavanje.

**🔧 OSNOVNI MODULI**
- **SEO Optimizer:** Ponudite frilens pisanje i optimizaciju SEO sadržaja.
- **Meta Description Generator:** Naplatite pisanje ubedljivih meta opisa za veb-sajtove.
- **FAQ Schema Generator:** Pružite tehničku SEO uslugu implementacije FAQ šeme.
- **Human Warmth / Corporate Polish / Empathetic Tone / Narrative Softener / Tone Harmonizer:** Ponudite usluge uređivanja teksta i prilagođavanja tona glasa.
- **Clarity Enhancer:** Ponudite usluge pojednostavljivanja tehničkog ili akademskog pisanja.
- **Summary Synthesizer:** Kreirajte izvršne sažetke dugih izveštaja.
- **Grammar & Style Proofer:** Započnite frilens posao lektorisanja i redigovanja.
- **Text Craft:** Ponudite svestrane usluge pisanja, brzo proširujući ili skraćujući tekst po potrebi klijenta.
- **Paragraph Generator:** Ubrzajte svoj radni proces brzim generisanjem pasusa na bilo koju temu.
- **Plagiarism Checker:** Ponudite usluge provere originalnosti sadržaja.
- **Clean Paste:** Naplatite klijentima da "humanizuju" njihov postojeći AI-generisani sadržaj.
- **Global Translator:** Ponudite visokokvalitetne usluge prevođenja i lokalizacije.

**📱 DRUŠTVENE MREŽE**
- **Social Stylers (LinkedIn, Instagram, Twitter, itd.):** Postanite frilens menadžer društvenih mreža.
- **Hashtag Generator:** Prodajte pakete za istraživanje i strategiju hashtagova.
- **Blog Ideas Generator:** Ponudite uslugu "ideacije tema za blog".
- **YouTube Video to Blog Article:** Ponudite uslugu pretvaranja video sadržaja u blog postove.
- **Quora Answer Assistant:** Upravljajte Quora marketing strategijom za klijente.

**💼 PROFESIONALNI SADRŽAJ**
- **Startup Pitch:** Ponudite usluge pisanja i dorade pitch deck-ova za startape.
- **Personal Bio Generator:** Naplatite pisanje profesionalnih biografija za rukovodioce.
- **Resume Generator:** Započnite uslugu pisanja CV-ja i propratnih pisama.
- **Email Craft:** Pišite email kampanje za biznise.
- **ASO Optimizer:** Ponudite usluge optimizacije za prodavnice aplikacija (ASO).
- **Create Product Review:** Postanite affiliate marketer brzim generisanjem detaljnih recenzija proizvoda.
- **Press Release:** Ponudite usluge pisanja PR saopštenja.
- **Case Study Creator:** Pišite ubedljive studije slučaja za B2B kompanije.
- **Whitepaper Writer:** Kreirajte "bele papire" (whitepapers) za generisanje lidova.
- **Proposal Generator:** Ponudite uslugu kreiranja ubedljivih poslovnih predloga.
- **AI-Powered Video Scriptwriter:** Ponudite usluge pisanja scenarija za video sadržaj.

**🎯 MARKETING I KONVERZIJA**
- **Headline Generator:** Ponudite pakete A/B testiranja naslova.
- **Slogan Generator:** Ponudite pakete brendiranja za nove biznise.
- **E-commerce Product Description:** Pišite opise proizvoda za online prodavnice.
- **Create Google Ad / Facebook Ad:** Ponudite usluge pisanja reklamnih tekstova.
- **Landing Page Copy:** Specijalizujte se za pisanje visoko konvertujućih tekstova za landing stranice.
- **Newsletter Builder:** Ponudite uslugu "ključ u ruke" za pisanje newsletter-a.
`;

const systemInstruction = `You are a helpful and friendly multilingual assistant for the "ContentCraft AI" application. Your sole purpose is to explain what each module in the application does and how to use it. You MUST automatically detect the language of the user's message and respond ONLY in that same language. If the user switches language during the conversation, you MUST switch your response language to match. Be concise and clear, using markdown for formatting like **bold** text and lists.

Here is all the information about the available modules. Use this information to answer user questions:
\n\n--- DETAILED MODULE DOCUMENTATION (ENGLISH) ---\n` + Object.entries(moduleDatabase).map(([id, data]) => `
---
Module ID: '${id}'
Name: '${data.name}'
Description: ${data.description}
Main Task: ${data.mainTask}
---
`).join('\n\n') + additionalKnowledge + serbianKnowledgeBase;

const FloatingChatbot: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<Message[]>([
        { id: 1, type: 'bot', content: 'Zdravo! Ja sam vaš Content Craft asistent. Pitajte me bilo šta o našim modulima, planovima, ili kako da započnete. Na primer: "Šta je AI Prompt Generator?" ili "Kako mogu da zaradim novac sa ovom aplikacijom?"' }
    ]);
    const nextId = useRef(2);

    const [inputMessage, setInputMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<null | HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages, isLoading]);

    const handleSendMessage = async () => {
        if (!inputMessage.trim() || isLoading) return;

        const userMessage: Message = { id: nextId.current++, type: 'user', content: inputMessage };
        const newMessages = [...messages, userMessage];
        setMessages(newMessages);
        setInputMessage('');
        setIsLoading(true);

        const history: Content[] = newMessages.map(msg => ({
            role: msg.type === 'user' ? 'user' : 'model',
            parts: [{ text: msg.content }]
        }));

        try {
            const result = await generateContent(history, { systemInstruction });
            const botMessage: Message = { id: nextId.current++, type: 'bot', content: result };
            setMessages(prev => [...prev, botMessage]);
        } catch (err) {
            const errorMessage: Message = {
                id: nextId.current++,
                type: 'bot',
                content: 'Došlo je do greške. Proverite konekciju i pokušajte ponovo.'
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    const renderMessageContent = (content: string) => {
        const html = content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // Bold
            .replace(/\*(.*?)\*/g, '<em>$1</em>')     // Italic
            .replace(/• (.*)/g, '<li class="ml-4 list-disc">$1</li>') // List items
            .replace(/· (.*)/g, '<li class="ml-4 list-disc">$1</li>') // List items with different bullet
            .replace(/✅/g, '✅ ')
            .replace(/❌/g, '❌ ')
            .replace(/\n/g, '<br />');
        return { __html: html };
    };


    return (
        <div className="floating-chatbot-container">
            <div className={`chat-widget ${isOpen ? 'open' : ''}`}>
                <div className="chat-widget-header">
                    <h3 className="chat-widget-title">Content<span>Craft</span> Asistent</h3>
                    <button onClick={() => setIsOpen(false)} className="p-2 rounded-full hover:bg-base-200 dark:hover:bg-d-base-300">
                        <CloseIcon className="h-5 w-5" />
                    </button>
                </div>
                <div className="chat-widget-messages">
                    {messages.map(message => (
                        <div key={message.id} className={`message ${message.type}-message`} dangerouslySetInnerHTML={renderMessageContent(message.content)}></div>
                    ))}
                     {isLoading && (
                        <div className="message bot-message">
                            <div className="typing-indicator"><span></span><span></span><span></span></div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
                <div className="chat-widget-input-container">
                    <textarea
                        className="chat-widget-input"
                        placeholder="Postavite pitanje..."
                        value={inputMessage}
                        onChange={e => setInputMessage(e.target.value)}
                        onKeyPress={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSendMessage();
                            }
                        }}
                    />
                    <button className="chat-widget-send-btn" onClick={handleSendMessage} disabled={isLoading || !inputMessage.trim()}>
                        <i className="fas fa-paper-plane"></i>
                    </button>
                </div>
            </div>

            <button className="chat-fab" onClick={() => setIsOpen(!isOpen)} aria-label="Open Chatbot">
                <div className="perspective-1000">
                    <div className="relative w-12 h-12 animate-rotate-3d small-cube" style={{ transformStyle: 'preserve-3d' }}>
                        <div className="small-cube-face" style={{ transform: 'rotateY(0deg) translateZ(24px)' }}><span className="small-cube-face-text">CONTENT<br/>CRAFT</span></div>
                        <div className="small-cube-face" style={{ transform: 'rotateY(90deg) translateZ(24px)' }}></div>
                        <div className="small-cube-face" style={{ transform: 'rotateY(180deg) translateZ(24px)' }}><span className="small-cube-face-text">CONTENT<br/>CRAFT</span></div>
                        <div className="small-cube-face" style={{ transform: 'rotateY(-90deg) translateZ(24px)' }}></div>
                        <div className="small-cube-face" style={{ transform: 'rotateX(90deg) translateZ(24px)' }}></div>
                        <div className="small-cube-face" style={{ transform: 'rotateX(-90deg) translateZ(24px)' }}></div>
                    </div>
                </div>
            </button>
        </div>
    );
};

export default FloatingChatbot;