import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import CopyIcon from './icons/CopyIcon';
import { Type } from '@google/genai';

interface ModuleViewProps {
  module: Module;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

type AssertivenessLevel = 'Mildly Direct' | 'Moderately Assertive' | 'Highly Confrontational';
type Relationship = 'Manager-Employee' | 'Colleagues' | 'Client-Vendor' | 'Team Members';
type SofteningLevel = 'Subtle' | 'Moderate' | 'Substantial' | 'Transformative';

// NEW, more reliable JSON schema
const softenedVersionsSchema = {
    type: Type.OBJECT,
    properties: {
        softened_versions: {
            type: Type.ARRAY,
            description: "An array of 3-4 distinct softened versions of the text.",
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "A title for the variation, e.g., 'More Collaborative Version'." },
                    content: { type: Type.STRING, description: "The rewritten, softened text." },
                    analysis: { type: Type.STRING, description: "A brief, one-sentence analysis of the approach taken for this version." }
                },
                required: ['title', 'content', 'analysis']
            }
        }
    },
    required: ['softened_versions']
};

// NEW, simpler prompt focusing on the core task
const NARRATIVE_SOFTENER_PROMPT = `
You are a master of diplomatic communication. Your task is to transform the user's text into several softened, more collaborative versions.

**INPUT:**
- Original Text: {ORIGINAL_TEXT}
- Assertiveness Level of Original Text: {ASSERTIVENESS_LEVEL}
- Relationship Context: {RELATIONSHIP}
- Desired Softening Intensity: {SOFTENING_LEVEL}

**INSTRUCTIONS:**
1.  Generate 3-4 distinct softened versions of the original text.
2.  Each version should have a unique strategic focus (e.g., 'More Collaborative', 'Question-Based', 'Benefit-Oriented').
3.  Preserve the core message and intent of the original text.
4.  Your response MUST be a valid JSON object conforming to the provided schema.
`;

interface Version {
    title: string;
    content: string;
    analysis: string;
}
interface ParsedOutput {
    softened_versions: Version[];
}

const NarrativeSoftenerView: React.FC<ModuleViewProps> = ({ module, usesLeft, decrementUse }) => {
    const [input, setInput] = useState('');
    const [parsedOutput, setParsedOutput] = useState<ParsedOutput | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const [assertivenessLevel, setAssertivenessLevel] = useState<AssertivenessLevel>('Moderately Assertive');
    const [relationship, setRelationship] = useState<Relationship>('Colleagues');
    const [softeningLevel, setSofteningLevel] = useState<SofteningLevel>('Moderate');
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && input.trim();

    const getPrompt = useCallback(() => {
        return NARRATIVE_SOFTENER_PROMPT
            .replace('{ORIGINAL_TEXT}', input)
            .replace('{ASSERTIVENESS_LEVEL}', assertivenessLevel)
            .replace('{RELATIONSHIP}', relationship)
            .replace('{SOFTENING_LEVEL}', softeningLevel);
    }, [input, assertivenessLevel, relationship, softeningLevel]);

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) return;
        setIsLoading(true);
        setError(null);
        setParsedOutput(null);
        setIsQueued(false);

        const prompt = getPrompt();

        if (!navigator.onLine) {
            try {
                if (Notification.permission !== 'granted') await Notification.requestPermission();
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }

        try {
            const result = await generateContent(prompt, {
                responseMimeType: "application/json",
                responseSchema: softenedVersionsSchema,
            });
            const parsed: ParsedOutput = JSON.parse(result);
            setParsedOutput(parsed);

            if (usesLeft !== 'Unlimited') decrementUse();
        } catch (err) {
            setError(err instanceof Error ? `Failed to get a valid response from the AI. Please try again. Error: ${err.message}` : 'An unknown error occurred');
        } finally {
            setIsLoading(false);
        }
    }, [canGenerate, getPrompt, decrementUse, usesLeft, module.name]);

    const VersionCard: React.FC<{ version: Version }> = ({ version }) => {
        const [copySuccess, setCopySuccess] = useState(false);
        const handleCopy = () => {
            if (!version.content) return;
            navigator.clipboard.writeText(version.content).then(() => {
                setCopySuccess(true);
                setTimeout(() => setCopySuccess(false), 2000);
            });
        };

        if (!version.content) return null;
        return (
            <div className="bg-base-100 dark:bg-d-base-100 p-4 rounded-lg border border-base-300 dark:border-d-base-300 relative space-y-2 group">
                <div className="flex justify-between items-start">
                    <h4 className="font-bold text-lg text-text-primary dark:text-d-text-primary pr-10">{version.title}</h4>
                    <button onClick={handleCopy} className="p-2 rounded-lg bg-base-200 dark:bg-d-base-200 hover:bg-brand-primary text-text-secondary dark:text-d-text-secondary hover:text-white transition-colors opacity-0 group-hover:opacity-100" aria-label={`Copy ${version.title}`}>
                        <CopyIcon className="h-5 w-5" />
                    </button>
                </div>
                <p className="text-xs text-text-secondary dark:text-d-text-secondary italic">"{version.analysis}"</p>
                <p className="text-text-primary dark:text-d-text-primary mt-2 text-base leading-relaxed whitespace-pre-wrap">{version.content}</p>
                {copySuccess && <div className="absolute top-3 right-14 bg-success text-white text-xs px-2 py-0.5 rounded-full animate-fade-in">Copied!</div>}
            </div>
        );
    };

    const commonTextareaClasses = "w-full min-h-[150px] p-4 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonInputClasses = "w-full p-2 bg-base-200 dark:bg-d-base-200 border border-base-300 dark:border-d-base-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-primary text-text-primary dark:text-d-text-primary transition-colors";
    const commonLabelClasses = "block text-sm font-medium text-text-secondary dark:text-d-text-secondary mb-1";

    return (
        <>
            <div className="max-w-7xl mx-auto flex flex-col gap-8 animate-fade-in">
                <div className="text-center">
                    <h2 className="text-3xl font-bold text-text-primary dark:text-d-text-primary font-heading">{module.name}</h2>
                    <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
                    <div className="space-y-4">
                        <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Enter the assertive or direct text to soften..." className={commonTextareaClasses} />
                        
                        <div className="bg-base-200/50 dark:bg-d-base-200/50 p-4 rounded-lg space-y-4 border border-base-300 dark:border-d-base-300">
                            <h3 className="font-semibold text-text-primary dark:text-d-text-primary">Softening Parameters</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className={commonLabelClasses}>Assertiveness Level</label>
                                    <select value={assertivenessLevel} onChange={e => setAssertivenessLevel(e.target.value as AssertivenessLevel)} className={commonInputClasses}>
                                        <option>Mildly Direct</option><option>Moderately Assertive</option><option>Highly Confrontational</option>
                                    </select>
                                </div>
                                <div>
                                    <label className={commonLabelClasses}>Relationship Context</label>
                                    <select value={relationship} onChange={e => setRelationship(e.target.value as Relationship)} className={commonInputClasses}>
                                        <option>Colleagues</option><option>Manager-Employee</option><option>Client-Vendor</option><option>Team Members</option>
                                    </select>
                                </div>
                                <div className="md:col-span-2">
                                    <label className={commonLabelClasses}>Softening Intensity</label>
                                    <select value={softeningLevel} onChange={e => setSofteningLevel(e.target.value as SofteningLevel)} className={commonInputClasses}>
                                        <option>Subtle</option><option>Moderate</option><option>Substantial</option><option>Transformative</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full flex justify-center items-center px-6 py-3 border border-transparent text-base font-medium rounded-xl shadow-sm text-white bg-brand-primary hover:bg-gradient-to-r hover:from-brand-primary hover:to-accent disabled:bg-base-300 dark:disabled:bg-d-base-300 disabled:cursor-not-allowed disabled:text-text-secondary dark:disabled:text-d-text-secondary transition-all duration-300">
                            {isLoading ? <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : null}
                            {isLoading ? 'Softening...' : (isQueued ? 'Request Queued' : 'Soften Narrative')}
                        </button>
                        {isQueued && <p className="text-center text-accent text-sm mt-2">You're offline. Request will be processed when you reconnect.</p>}
                        {!canGenerate && !isQueued && <p className="text-center text-yellow-500 text-sm mt-2">Please provide text to soften.</p>}
                    </div>
                    <div className="bg-base-200/50 dark:bg-d-base-200/50 rounded-lg p-4 min-h-[500px] overflow-y-auto">
                        {isLoading && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Applying diplomatic filters...</p>}
                        {!isLoading && !parsedOutput && <p className="text-text-secondary dark:text-d-text-secondary text-center p-8">Your softened versions will appear here.</p>}
                        {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg">{error}</div>}
                        {parsedOutput && (
                             <div className="space-y-4">
                                <h3 className="text-xl font-bold text-text-primary dark:text-d-text-primary font-heading">Narrative-Softened Versions</h3>
                                {parsedOutput.softened_versions.map((version, index) => <VersionCard key={index} version={version} />)}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
};

export default NarrativeSoftenerView;