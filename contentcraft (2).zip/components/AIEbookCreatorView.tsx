import React, { useState, useCallback } from 'react';
import type { Module } from '../types';
import { generateContent } from '../services/geminiService';
import { addToQueue } from '../services/offlineService';
import { saveGeneration } from '../services/historyService';
import { Type } from '@google/genai';
import { useFeedback } from '../hooks/useFeedback';
import CopyIcon from './icons/CopyIcon';
import DownloadIcon from './icons/settings/DownloadIcon';
import SparklesIcon from './icons/settings/SparklesIcon';

interface AIEbookCreatorViewProps {
  module: Module;
  userId: string | null;
  usesLeft: number | 'Unlimited';
  decrementUse: () => void;
  isPremium: boolean;
}

interface EbookData {
    title: string;
    author: string;
    introduction: string;
    table_of_contents: string[];
    chapters: { title: string; content: string }[];
    conclusion: string;
}

const ebookSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING },
        author: { type: Type.STRING },
        introduction: { type: Type.STRING },
        table_of_contents: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
        },
        chapters: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    content: { type: Type.STRING }
                },
                required: ['title', 'content']
            }
        },
        conclusion: { type: Type.STRING }
    },
    required: ['title', 'author', 'introduction', 'table_of_contents', 'chapters', 'conclusion']
};

const AIEbookCreatorView: React.FC<AIEbookCreatorViewProps> = ({ module, userId, usesLeft, decrementUse }) => {
    const { playClick, playSuccess } = useFeedback();

    // Form state
    const [title, setTitle] = useState('');
    const [author, setAuthor] = useState('');
    const [topic, setTopic] = useState('');
    const [numChapters, setNumChapters] = useState('7');
    const [keywords, setKeywords] = useState('');
    const [template, setTemplate] = useState('professional');

    // API state
    const [ebookData, setEbookData] = useState<EbookData | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isQueued, setIsQueued] = useState(false);
    
    const canGenerate = (usesLeft === 'Unlimited' || usesLeft > 0) && title.trim() && author.trim() && topic.trim();

    const handleGenerate = useCallback(async () => {
        if (!canGenerate) {
            alert('Please fill in all required fields: Title, Author, and Topic.');
            return;
        }
        playClick();
        setIsLoading(true);
        setError(null);
        setEbookData(null);
        setIsQueued(false);

        const prompt = `You are an expert author and content strategist. Generate a complete eBook based on the following specifications. The response must be a valid JSON object conforming to the schema.

        **SPECIFICATIONS:**
        - Title: ${title}
        - Author: ${author}
        - Topic/Subject: ${topic}
        - Number of Chapters: ${numChapters}
        - Key Topics/Keywords: ${keywords}
        - Template Style: ${template} (This should influence the tone and structure, e.g., 'Professional', 'Creative', 'Minimal', 'Modern')
        
        **INSTRUCTIONS:**
        1.  Create a compelling introduction.
        2.  Generate a table of contents with ${numChapters} chapter titles.
        3.  Write the content for each of the ${numChapters} chapters. Each chapter should be substantive and well-structured.
        4.  Write a concluding summary.
        5.  Ensure the entire output is a single, valid JSON object that matches the provided schema.`;

        if (!navigator.onLine) {
            try {
                await addToQueue({ prompt, moduleName: module.name });
                setIsQueued(true);
            } catch (queueError) {
                setError("Could not save request for offline processing.");
            } finally {
                setIsLoading(false);
            }
            return;
        }
        
        try {
            const result = await generateContent(prompt, {
                responseMimeType: 'application/json',
                responseSchema: ebookSchema as any,
            });
            const parsed = JSON.parse(result);
            setEbookData(parsed);
            
            if (userId) {
                const outputSummary = `Generated eBook "${parsed.title}" with ${parsed.chapters.length} chapters.`;
                saveGeneration(userId, {
                    moduleId: module.id,
                    moduleName: module.name,
                    inputs: `Topic: ${topic}, Chapters: ${numChapters}`,
                    output: outputSummary,
                });
            }

            if (usesLeft !== 'Unlimited') {
                decrementUse();
            }
            playSuccess();
        } catch (err) {
            setError(err instanceof Error ? `Failed to generate eBook: ${err.message}` : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }

    }, [canGenerate, title, author, topic, numChapters, keywords, template, playClick, playSuccess, module, userId, usesLeft, decrementUse]);

    const handleExport = () => {
        if (!ebookData) return;
        let markdown = `# ${ebookData.title}\n\n`;
        markdown += `**By ${ebookData.author}**\n\n`;
        markdown += `## Introduction\n\n${ebookData.introduction}\n\n`;
        markdown += `## Table of Contents\n\n`;
        ebookData.table_of_contents.forEach((chapTitle, i) => {
            markdown += `${i + 1}. ${chapTitle}\n`;
        });
        markdown += '\n';
        ebookData.chapters.forEach(chapter => {
            markdown += `## ${chapter.title}\n\n${chapter.content}\n\n`;
        });
        markdown += `## Conclusion\n\n${ebookData.conclusion}\n`;

        const blob = new Blob([markdown], { type: 'text/markdown' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${title.replace(/\s/g, '_')}.md`;
        a.click();
        URL.revokeObjectURL(url);
    };

    const templates = [
        { id: 'professional', name: 'Professional', icon: ' briefcase' },
        { id: 'creative', name: 'Creative', icon: 'palette' },
        { id: 'minimal', name: 'Minimal', icon: 'leaf' },
        { id: 'modern', name: 'Modern', icon: 'rocket' },
    ];

    return (
        <div className="ebook-creator-module max-w-7xl mx-auto flex flex-col gap-8">
            <div className="text-center">
                <h1 className="text-3xl font-bold font-heading">{module.name}</h1>
                <p className="text-md text-text-secondary dark:text-d-text-secondary mt-2">{module.description}</p>
            </div>

            <div className="flex flex-col lg:flex-row gap-6">
                <section className="flex-1 lg:flex-2 bg-base-200 dark:bg-d-base-200 p-6 rounded-xl space-y-4">
                    <h2 className="text-2xl font-bold mb-4">Create Your eBook</h2>
                    <div className="space-y-4">
                        <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="eBook Title" className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                        <input type="text" value={author} onChange={e => setAuthor(e.target.value)} placeholder="Author Name" className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                        <input type="text" value={topic} onChange={e => setTopic(e.target.value)} placeholder="eBook Topic/Subject" className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100" />
                        <div>
                            <label className="text-sm font-medium">Number of Chapters</label>
                            <select value={numChapters} onChange={e => setNumChapters(e.target.value)} className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 mt-1">
                                <option value="5">5 Chapters</option>
                                <option value="7">7 Chapters</option>
                                <option value="10">10 Chapters</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-sm font-medium">Select Template</label>
                            <div className="grid grid-cols-2 gap-2 mt-1">
                                {templates.map(t => (
                                    <button key={t.id} onClick={() => setTemplate(t.id)} className={`p-3 rounded-lg border-2 text-center ${template === t.id ? 'border-brand-primary bg-brand-primary/10' : 'bg-base-100 dark:bg-d-base-100 border-transparent'}`}>
                                        <div className="font-semibold">{t.name}</div>
                                    </button>
                                ))}
                            </div>
                        </div>
                        <textarea value={keywords} onChange={e => setKeywords(e.target.value)} placeholder="Key Topics/Keywords (comma separated)..." className="w-full p-3 rounded-lg border border-base-300 dark:border-d-base-300 bg-base-100 dark:bg-d-base-100 min-h-[100px]"></textarea>
                    </div>
                     <button onClick={handleGenerate} disabled={isLoading || !canGenerate} className="w-full btn-primary flex items-center justify-center p-4 rounded-xl text-white font-bold text-lg gap-2">
                        {isLoading ? <span className="animate-spin h-5 w-5 border-2 border-white/50 border-t-white rounded-full"></span> : <SparklesIcon className="h-6 w-6" />}
                        {isLoading ? 'Generating...' : 'Generate eBook Content'}
                    </button>
                </section>
                
                <section className="flex-1 lg:flex-1 bg-base-200 dark:bg-d-base-200 p-6 rounded-xl flex flex-col">
                    <h2 className="text-2xl font-bold mb-4">eBook Preview</h2>
                    <div className="flex-1 bg-base-100 dark:bg-d-base-100 p-4 rounded-lg overflow-y-auto border border-base-300 dark:border-d-base-300">
                        {ebookData ? (
                            <div>
                                <div className="ebook-cover-preview h-48 rounded-lg flex items-center justify-center text-white text-2xl font-bold text-center p-4 mb-4">{ebookData.title}</div>
                                <h1 className="ebook-title-preview text-2xl font-bold text-center">{ebookData.title}</h1>
                                <p className="ebook-author-preview text-center text-text-secondary dark:text-d-text-secondary mb-4">by {ebookData.author}</p>
                                <div className="prose prose-sm dark:prose-invert max-w-none">
                                    <h3 className="chapter-title">Introduction</h3>
                                    <p>{ebookData.introduction}</p>
                                    <h3 className="chapter-title">Table of Contents</h3>
                                    <ul className="list-disc pl-5">
                                        {ebookData.table_of_contents.map((item, index) => <li key={index}>{item}</li>)}
                                    </ul>
                                    {ebookData.chapters.map((chapter, index) => (
                                        <div key={index}>
                                            <h3 className="chapter-title">{chapter.title}</h3>
                                            <p>{chapter.content}</p>
                                        </div>
                                    ))}
                                    <h3 className="chapter-title">Conclusion</h3>
                                    <p>{ebookData.conclusion}</p>
                                </div>
                            </div>
                        ) : (
                             <div>
                                <div className="ebook-cover-preview h-48 rounded-lg flex items-center justify-center text-white text-2xl font-bold text-center p-4 mb-4">{title || 'Your eBook Cover'}</div>
                                <h1 className="ebook-title-preview text-2xl font-bold text-center">{title || 'eBook Title'}</h1>
                                <p className="ebook-author-preview text-center text-text-secondary dark:text-d-text-secondary mb-4">by {author || 'Author Name'}</p>
                                <div className="prose prose-sm dark:prose-invert max-w-none">
                                    <h3 className="chapter-title">Introduction</h3>
                                    <p>Your eBook content will appear here once generated.</p>
                                </div>
                            </div>
                        )}
                    </div>
                     <div className="flex gap-4 mt-4">
                        <button onClick={handleExport} disabled={!ebookData} className="flex-1 flex items-center justify-center gap-2 p-3 bg-brand-secondary text-white font-semibold rounded-lg disabled:bg-gray-400">
                            <DownloadIcon className="h-5 w-5"/> Export
                        </button>
                    </div>
                </section>
            </div>
             {error && <div className="text-center bg-error/20 text-error p-4 rounded-lg mt-4">{error}</div>}
        </div>
    );
};

export default AIEbookCreatorView;