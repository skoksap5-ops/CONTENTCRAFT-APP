export interface Language {
  code: string;
  name: string;
  nativeName: string;
  country: string;
  flag: string;
}

export const LANGUAGES: Language[] = [
  { code: 'en', name: 'English', nativeName: 'English', country: 'United States', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', country: 'Spain', flag: '🇪🇸' },
  { code: 'fr', name: 'French', nativeName: 'Français', country: 'France', flag: '🇫🇷' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', country: 'Germany', flag: '🇩🇪' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', country: 'Italy', flag: '🇮🇹' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', country: 'Portugal', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', country: 'Russia', flag: '🇷🇺' },
  { code: 'zh', name: 'Chinese', nativeName: '中文', country: 'China', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', country: 'Japan', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', country: 'South Korea', flag: '🇰🇷' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', country: 'Saudi Arabia', flag: '🇸🇦' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', country: 'India', flag: '🇮🇳' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', country: 'Turkey', flag: '🇹🇷' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', country: 'Netherlands', flag: '🇳🇱' },
  { code: 'sv', name: 'Swedish', nativeName: 'Svenska', country: 'Sweden', flag: '🇸🇪' },
  { code: 'sr', name: 'Serbian', nativeName: 'Српски', country: 'Serbia', flag: '🇷🇸' },
];