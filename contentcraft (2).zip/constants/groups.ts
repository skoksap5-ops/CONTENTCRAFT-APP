export const MODULE_GROUPS_MAP = {
  AI_POWER: { id: 'ai-power-suite', nameKey: 'group_ai_power' },
  CORE: { id: 'core-modules', nameKey: 'group_core' },
  SOCIAL: { id: 'social-suite', nameKey: 'group_social' },
  PROFESSIONAL: { id: 'professional-content', nameKey: 'group_professional' },
  MARKETING: { id: 'marketing-conversion', nameKey: 'group_marketing' },
};

export const MODULE_GROUPS = {
  AI_POWER: 'group_ai_power',
  CORE: 'group_core',
  SOCIAL: 'group_social',
  PROFESSIONAL: 'group_professional',
  MARKETING: 'group_marketing',
};
