import type { Module } from '../types';
import { MODULE_GROUPS } from './groups';

const createPrompt = (task: string, input: string, tones: string[]) => {
  const formatTones = (tones: string[]): string => {
    if (tones.length === 0) return 'neutral';
    if (tones.length === 1) return `'${tones[0]}'`;
    const lastTone = tones[tones.length - 1];
    const initialTones = tones.slice(0, -1);
    return `${initialTones.map(t => `'${t}'`).join(', ')} and '${lastTone}'`;
  };
  
  const toneInstruction = `The desired ${tones.length > 1 ? 'tones are' : 'tone is'} strictly ${formatTones(tones)}.`;

  return `As an expert content creator, ${task}. ${toneInstruction} Here is the text to work with:\n\n---\n\n${input}\n\n---\n\nProduce only the transformed text as a direct response, without any introductory phrases, explanations, or conversational filler.`;
}

export const MODULES: Module[] = [
  {
    id: 'earn-with-content-craft-365',
    name: 'Earn with ContentCraft',
    description: 'Discover hundreds of ways to monetize your content creation skills using AI.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input) => `This is a complex module handled by EarnWithContentCraftView.tsx. Details: ${input}`,
  },
  // AI Power Suite
  {
    id: 'ai-prompt-generator',
    name: 'AI Prompt Generator & Optimizer',
    description: 'Craft and refine powerful prompts to get the best results from any AI.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as a prompt engineering expert. Based on the user\'s goal, generate and optimize a detailed prompt. The goal is: ', input, tones),
  },
  {
    id: 'ai-template-builder',
    name: 'AI Template Builder',
    description: 'Create dynamic, reusable content templates for any purpose.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as an expert template designer. Based on the following request, create a detailed, reusable content template. The request is: ', input, tones),
  },
  {
    id: 'ai-ebook-creator',
    name: 'AI Ebook Creator',
    description: 'Generate complete eBooks with structured chapters, content, and formatting from a simple topic.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => `This is a complex module. The prompt is handled by AIEbookCreatorView.tsx. Topic: ${input}`,
  },
  {
    id: 'brand-voice-generator',
    name: 'Brand Voice Generator',
    description: 'Define and maintain a consistent brand identity across all your content.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input) => `This is a complex module handled by BrandVoiceGeneratorView.tsx. Details: ${input}`,
  },
  {
    id: 'ai-trend-spotter',
    name: 'AI Trend Spotter',
    description: 'Analyze topics to find emerging trends, keywords, and content opportunities.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as a market trend analyst. For the topic provided, identify emerging trends, related keywords, and new content opportunities. The topic is: ', input, tones),
  },
  {
    id: 'ai-content-repurposing',
    name: 'AI Content Repurposing Engine',
    description: 'Transform existing content into multiple new formats (e.g., blog to tweets).',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as a content repurposing strategist. Transform the following content into various new formats suitable for different platforms. The content is: ', input, tones),
  },
  {
    id: 'ai-chatbot-training',
    name: 'AI Chatbot Training Data Generator',
    description: 'Create conversational data to train and improve AI chatbots.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as an AI training data specialist. Based on the following topic, generate a set of question/answer pairs to train a chatbot. The topic is: ', input, tones),
  },
  {
    id: 'ai-seo-opportunity-finder',
    name: 'AI SEO Opportunity Finder',
    description: 'Discover untapped keywords and content gaps your competitors are missing.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as an SEO expert. Analyze the given topic to discover untapped keywords and content gap opportunities. The topic is: ', input, tones),
  },
    {
    id: 'ai-search-optimizer',
    name: 'AI Search Optimizer (GEO)',
    description: 'Optimize your website for AI search engines like Perplexity & Google AI Overviews.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input) => `This is a complex module handled by AISearchOptimizerView.tsx. Details: ${input}`,
  },
  {
    id: 'ai-performance-predictor',
    name: 'AI Content Performance Predictor',
    description: 'Forecast the potential engagement and reach of your content before publishing.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as a data scientist. Based on the following content, predict its performance in terms of engagement, reach, and virality score. The content is: ', input, tones),
  },
  {
    id: 'ai-comment-response-generator',
    name: 'AI Comment Response Generator',
    description: 'Generate authentic, on-brand replies to social media comments.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as a community manager. Generate several on-brand responses to the following user comment. The comment is: ', input, tones),
  },
  {
    id: 'ai-competitor-analyzer',
    name: 'AI Competitor & Gap Analyzer',
    description: 'Analyze competitor content to identify strengths, weaknesses, and opportunities.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as a competitive analyst. Based on the competitor content or website provided, analyze its strengths, weaknesses, and identify content gaps. The competitor info is: ', input, tones),
  },
   {
    id: 'social-campaign-planner', 
    name: 'AI Social Media Calendar Planner',
    description: 'Generate a complete social media content calendar with post ideas, copy, visuals, and hashtags.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => `Generate a social media campaign plan based on these details: ${input}`,
  },
  {
    id: 'ai-quiz-creator',
    name: 'AI Quiz & Assessment Creator',
    description: 'Generate engaging quizzes and assessments to capture leads and educate your audience.',
    group: MODULE_GROUPS.AI_POWER,
    prompt: (input, tones) => createPrompt('act as an instructional designer. Create an engaging quiz or assessment based on the provided topic. The topic is: ', input, tones),
  },

  // Group A: Core Modules
  {
    id: 'seo-optimizer', name: 'SEO Optimizer', description: 'Enhance text for search engine visibility.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('rewrite the following text to be highly optimized for search engines, focusing on relevant keywords, readability, and user intent', input, tones),
  },
  {
    id: 'meta-description-generator',
    name: 'Meta Description Generator',
    description: 'Boost Your SEO with Perfect Snippets for Google search results.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => `This is a complex module. The prompt is handled by MetaDescriptionGeneratorView.tsx`,
  },
  {
    id: 'faq-schema-generator',
    name: 'FAQ Schema Generator',
    description: 'Boost SEO by creating structured data for your FAQ pages.',
    group: MODULE_GROUPS.CORE,
    prompt: (input) => `This is a complex module handled by FAQSchemaGeneratorView.tsx. Details: ${input}`,
  },
  {
    id: 'human-warmth', name: 'Human Warmth', description: 'Add a natural, conversational, and friendly touch.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('infuse the following text with a natural, warm, and conversational human touch, making it more relatable', input, tones),
  },
  {
    id: 'corporate-polish', name: 'Corporate Polish', description: 'Refine text to Fortune 500 standards.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('polish the following text to meet the highest corporate communication standards, ensuring it sounds professional, clear, and authoritative', input, tones),
  },
  {
    id: 'empathetic-tone', name: 'Empathetic Tone', description: 'Rewrite with a supportive and emotionally aware voice, tailored to specific contexts and emotional needs.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('rewrite the following text to be more empathetic, supportive, and emotionally aware', input, tones),
  },
  {
    id: 'clarity-enhancer', name: 'Clarity Enhancer', description: 'Simplify language and remove jargon.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('simplify the following text to improve clarity, removing jargon and complex sentence structures to make it easily understandable', input, tones),
  },
  {
    id: 'summary-synthesizer', name: 'Summary Synthesizer', description: 'Create a concise summary of the text.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('generate a concise summary of the following text', input, tones),
  },
   {
    id: 'narrative-softener', name: 'Narrative Softener', description: 'Make assertive or direct text more gentle and diplomatic.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('soften the narrative of the following text, making it more gentle, diplomatic, and less confrontational without losing the core message', input, tones),
  },
  {
    id: 'tone-harmonizer', name: 'Tone Harmonizer', description: 'Adjust text to perfectly match the selected tone.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt(`rewrite the following text to perfectly embody the selected tone(s), ensuring consistency throughout`, input, tones),
  },
  {
    id: 'grammar-proofer', name: 'Grammar Proofer', description: 'Correct grammar, spelling, and style with detailed analysis.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('proofread and correct all grammar and spelling mistakes in the following text', input, tones),
  },
  {
    id: 'style-proofer', name: 'Style Proofer', description: 'Improve sentence structure, flow, and vocabulary.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('proofread and enhance the style of the following text, improving sentence structure, flow, word choice, and overall readability', input, tones),
  },
   {
    id: 'text-craft', name: 'Text Craft', description: 'Transform text with comprehensive refinement, stylistic elevation, and creative enhancement.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('analyze the following instruction and text, then expand, shorten, or rephrase it accordingly. For example: "Make this longer: [text]"', input, tones),
  },
  {
    id: 'paragraph-generator', name: 'Paragraph Generator', description: 'Expand on a topic to create a full paragraph.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt(`based on the topic or keywords provided, generate a well-structured and coherent paragraph`, input, tones),
  },
  {
    id: 'plagiarism-checker', 
    name: 'Plagiarism Checker', 
    description: 'Get a comprehensive originality report with similarity detection, intelligent rewriting, and citation guidance.',
    group: MODULE_GROUPS.CORE,
    // The complex prompt is handled by PlagiarismCheckerView.tsx, this is a fallback.
    prompt: (input, tones) => createPrompt('analyze the following text for potential plagiarism. Identify sentences that seem unoriginal and suggest rephrasing for them. This is a conceptual check, not a database lookup.', input, tones),
  },
  {
    id: 'clean-paste',
    name: 'Clean Paste',
    description: 'Remove AI watermarks & make content human-like.',
    group: MODULE_GROUPS.CORE,
    prompt: (input) => `This is a complex module handled by CleanPasteView.tsx. Details: ${input}`,
  },
  {
    id: 'translation-master', 
    name: 'Global Translator', 
    description: 'Translate text between languages and adapt to regional dialects.',
    group: MODULE_GROUPS.CORE,
    prompt: (input, tones) => createPrompt('translate the following text. The input should specify the target language and dialect, e.g., "Translate to Serbian (Cyrillic): [text]". If not specified, detect the language and translate to English, while also considering cultural nuances.', input, tones),
  },

  // Group B: Social Suite
  {
    id: 'linkedin-styler', name: 'LinkedIn Styler', description: 'Craft professional posts and articles.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('transform the following idea into a compelling LinkedIn post, suitable for a professional audience', input, tones),
  },
  {
    id: 'instagram-styler', name: 'Instagram Styler', description: 'Write engaging captions for visuals.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('generate an engaging Instagram caption based on the following description. Include relevant emojis and suggest hashtags', input, tones),
  },
  {
    id: 'twitter-styler', name: 'Twitter Styler', description: 'Create punchy, character-limited posts.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('craft a concise and punchy tweet (under 280 characters) from the following text', input, tones),
  },
  {
    id: 'facebook-styler', name: 'Facebook Styler', description: 'Write engaging and shareable Facebook posts.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('transform the following idea into an engaging Facebook post designed for high shareability. Use a friendly tone and consider adding a question to boost engagement.', input, tones),
  },
  {
    id: 'youtube-styler', name: 'YouTube Styler', description: 'Create optimized titles and descriptions for videos.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('generate an optimized YouTube video title and description based on the following video topic. Include relevant keywords for search.', input, tones),
  },
  {
    id: 'tiktok-styler', name: 'TikTok Styler', description: 'Generate catchy video ideas and captions.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('generate a catchy TikTok video idea, caption, and trending hashtag suggestions based on the following topic', input, tones),
  },
  {
    id: 'hashtag-generator', name: 'Hashtag Generator', description: 'Find optimized hashtags for your content.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('generate a list of relevant and trending hashtags for a social media post about the following topic', input, tones),
  },
  {
    id: 'pinterest-styler', name: 'Pinterest Styler', description: 'Create compelling Pin titles and descriptions.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('write a compelling Pinterest Pin title and description for an image related to the following topic. Focus on keywords and inspiring action.', input, tones),
  },
  {
    id: 'blog-ideas-generator', name: 'Blog Ideas Generator', description: 'Generate topics and angles for blog posts.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('generate a list of 5 creative blog post ideas and angles based on the following topic or keyword', input, tones),
  },
  {
    id: 'youtube-to-blog', name: 'YouTube Video to Blog Article', description: 'Convert a video transcript into a blog post.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('transform the following YouTube video transcript into a well-structured and readable blog article. Add headings and format it for clarity.', input, tones),
  },
  {
    id: 'quora-answer', name: 'Quora Answer Assistant', description: 'Draft helpful and authoritative answers.',
    group: MODULE_GROUPS.SOCIAL,
    prompt: (input, tones) => createPrompt('draft a helpful and authoritative Quora answer based on the following question and key points. Start with a direct answer and then elaborate.', input, tones),
  },

  // Group C: Professional & Content
  {
    id: 'startup-pitch', name: 'Startup Pitch', description: 'Create an investor-ready elevator pitch.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input, tones) => createPrompt('craft a compelling and concise startup elevator pitch from the following business idea', input, tones),
  },
  {
    id: 'personal-bio-generator',
    name: 'Personal Bio Generator',
    description: 'Craft your perfect professional identity for LinkedIn, Twitter, and more.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input, tones) => `This is a complex module handled by PersonalBioGeneratorView.tsx. Details: ${input}`,
  },
  {
    id: 'resume-generator',
    name: 'Resume Generator',
    description: 'Create professional resumes that get noticed with AI-powered enhancements.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input) => `This is a complex module handled by ResumeGeneratorView.tsx. Details: ${input}`,
  },
  {
    id: 'email-craft', name: 'Email Craft', description: 'Compose professional and effective emails.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input, tones) => createPrompt('write a professional email based on the following key points and objective', input, tones),
  },
  {
    id: 'aso-optimizer', name: 'ASO Optimizer', description: 'Optimize app store names, subtitles, and descriptions.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input, tones) => createPrompt('generate an optimized App Store or Google Play Store title, subtitle, and description based on the following app idea and keywords.', input, tones),
  },
  {
    id: 'content-generator', name: 'Content Generator', description: 'Create original content on any topic.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input, tones) => createPrompt('generate a short piece of original content based on the following topic or prompt', input, tones),
  },
  {
    id: 'product-review', name: 'Create Product Review', description: 'Write a structured and persuasive product review.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input, tones) => createPrompt('write a structured and persuasive product review based on the following product name and key features', input, tones),
  },
  {
    id: 'press-release', name: 'Press Release', description: 'Craft compelling, newsworthy press releases with strategic analysis and media-specific angles.',
    group: MODULE_GROUPS.PROFESSIONAL,
    // The complex prompt is handled by PressReleaseView.tsx, this is a fallback.
    prompt: (input, tones) => createPrompt('write a professional press release based on the following announcement details. Follow standard press release format.', input, tones),
  },
  {
    id: 'case-study-creator', name: 'Case Study Creator', description: 'Generate a compelling case study structure.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input, tones) => createPrompt('create a structured case study outline (Problem, Solution, Result) based on the following customer success story details.', input, tones),
  },
  {
    id: 'whitepaper-writer', name: 'Whitepaper Writer', description: 'Generate comprehensive, data-driven whitepapers with detailed outlines, research methodologies, and content strategy.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input, tones) => createPrompt('generate a detailed outline and an introductory paragraph for a whitepaper on the following topic.', input, tones),
  },
  {
    id: 'proposal-generator', name: 'Proposal Generator', description: 'Draft a comprehensive, persuasive business proposal tailored to your client.',
    group: MODULE_GROUPS.PROFESSIONAL,
    prompt: (input, tones) => createPrompt('draft a professional business proposal based on the following client needs and services offered. Include sections for Introduction, Scope, and Pricing.', input, tones),
  },
  {
    id: 'video-script-writer',
    name: 'AI-Powered Video Scriptwriter',
    description: 'Generate engaging, structured video scripts for platforms like YouTube, TikTok, and Reels.',
    group: MODULE_GROUPS.PROFESSIONAL,
    // Complex prompt handled by VideoScriptWriterView.tsx
    prompt: (input, tones) => `Generate a video script about ${input}.`,
  },

  // Group D: Marketing & Conversion
  {
    id: 'headline-generator', name: 'Headline Generator', description: 'Create click-worthy titles for your content.',
    group: MODULE_GROUPS.MARKETING,
    prompt: (input, tones) => createPrompt('generate 5 catchy and click-worthy headlines for an article or ad about the following topic', input, tones),
  },
  {
    id: 'slogan-generator',
    name: 'Slogan Generator',
    description: 'Create memorable brand messages that convert.',
    group: MODULE_GROUPS.MARKETING,
    prompt: (input) => `This is a complex module handled by SloganGeneratorView.tsx. Details: ${input}`,
  },
  {
    id: 'ecommerce-description', name: 'e-Commerce Product Description', description: 'Write persuasive copy for product pages.',
    group: MODULE_GROUPS.MARKETING,
    prompt: (input, tones) => createPrompt('write a persuasive e-commerce product description for a product with the following features', input, tones),
  },
  {
    id: 'google-ad', name: 'Create Google Ad', description: 'Create high-converting, keyword-optimized Google Search Ads with targeting, budget, and performance predictions.',
    group: MODULE_GROUPS.MARKETING,
    prompt: (input, tones) => createPrompt('create compelling ad copy for a Google Ads campaign based on the following product and keywords. Provide 3 headlines and 2 descriptions', input, tones),
  },
  {
    id: 'facebook-ad', name: 'Create Facebook Ad', description: 'Craft engaging copy for social media ads.',
    group: MODULE_GROUPS.MARKETING,
    prompt: (input, tones) => createPrompt('create compelling ad copy for a Facebook ad campaign. Provide a primary text, a headline, and a description based on the following product and target audience.', input, tones),
  },
  {
    id: 'landing-page-copy', name: 'Landing Page Copy', description: 'Generate conversion-optimized web copy.',
    group: MODULE_GROUPS.MARKETING,
    prompt: (input, tones) => createPrompt('write conversion-focused copy for a landing page for the following product or service. Include a headline, a sub-headline, and 3 key benefit points', input, tones),
  },
  {
    id: 'newsletter-builder', name: 'Newsletter Builder', description: 'Draft engaging email newsletter content.',
    group: MODULE_GROUPS.MARKETING,
    prompt: (input, tones) => createPrompt('draft an engaging email newsletter based on the following topic and key points. Include a catchy subject line and a call-to-action.', input, tones),
  },
];