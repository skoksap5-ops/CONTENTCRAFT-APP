import type { Generation } from '../types';

const STORAGE_KEY = 'contentCraftHistory';
const MAX_ITEMS = 30;
const EXCLUDED_MODULE = 'Module Explanation Assistant';

const getHistory = (): Generation[] => {
    try {
        const historyJSON = localStorage.getItem(STORAGE_KEY);
        return historyJSON ? JSON.parse(historyJSON) : [];
    } catch (e) {
        console.error("Failed to read history from localStorage", e);
        return [];
    }
};

const setHistory = (history: Generation[]) => {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch (e) {
        console.error("Failed to save history to localStorage", e);
    }
};

export const saveGeneration = async (
    userId: string | null, // userId is not used for localStorage but kept for compatibility
    data: { moduleName: string; inputs: string; output: string; moduleId: string }
): Promise<void> => {
    if (data.moduleName === EXCLUDED_MODULE) {
        return;
    }

    const history = getHistory();
    const newItem: Generation = {
        id: Date.now(),
        moduleName: data.moduleName,
        output: data.output,
        inputs: data.inputs,
        timestamp: new Date().toLocaleString('en-US', {
            year: 'numeric', month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit'
        }),
    };

    history.unshift(newItem);

    if (history.length > MAX_ITEMS) {
        history.splice(MAX_ITEMS);
    }

    setHistory(history);
};

export const getGenerationsForUser = async (userId: string | null): Promise<Generation[]> => {
    // userId is ignored for localStorage implementation
    return Promise.resolve(getHistory());
};

export const deleteGeneration = async (generationId: number): Promise<void> => {
    const history = getHistory();
    const filteredHistory = history.filter(item => item.id !== generationId);
    setHistory(filteredHistory);
    return Promise.resolve();
};

export const clearAllGenerationsForUser = async (userId: string | null): Promise<void> => {
    // userId is ignored for localStorage implementation
    setHistory([]);
    return Promise.resolve();
};
