import { generateContent } from './geminiService';

interface QueuedRequestPayload {
  prompt: string;
  moduleName: string;
}

interface QueuedRequest {
  id?: number;
  timestamp: number;
  payload: QueuedRequestPayload;
}

const DB_NAME = 'contentcraft-offline-db';
const STORE_NAME = 'request-queue';
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

function getDb(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        return reject('IndexedDB not supported');
      }

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
        }
      };
    });
  }
  return dbPromise;
}

export async function addToQueue(payload: QueuedRequestPayload): Promise<void> {
  const db = await getDb();
  const tx = db.transaction(STORE_NAME, 'readwrite');
  const store = tx.objectStore(STORE_NAME);
  
  const request: QueuedRequest = {
    timestamp: Date.now(),
    payload,
  };

  store.add(request);

  return new Promise((resolve, reject) => {
    tx.oncomplete = () => {
        console.log(`Request for "${payload.moduleName}" queued successfully.`);
        resolve();
    };
    tx.onerror = () => reject(tx.error);
  });
}

export async function processQueue(decrementUse: () => void): Promise<void> {
  if (!navigator.onLine) {
    console.log("Offline. Cannot process queue.");
    return;
  }
  
  const db = await getDb();
  const tx = db.transaction(STORE_NAME, 'readwrite');
  const store = tx.objectStore(STORE_NAME);
  
  const allRequests = await new Promise<QueuedRequest[]>((resolve, reject) => {
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

  if (allRequests.length === 0) {
    return;
  }

  console.log(`Processing ${allRequests.length} offline request(s).`);
  
  // Clear queue before processing to avoid race conditions
  await new Promise<void>((resolve, reject) => {
    const clearReq = store.clear();
    clearReq.onsuccess = () => resolve();
    clearReq.onerror = () => reject(clearReq.error);
  });

  for (const request of allRequests) {
    try {
      // We don't display the content, just generate it and notify.
      // A more advanced implementation could store results in another DB.
      await generateContent(request.payload.prompt);
      
      // Since a use was consumed, we call the passed-in function
      decrementUse();

      if (Notification.permission === 'granted') {
        new Notification('ContentCraft AI: Content Ready!', {
          body: `Your queued content for "${request.payload.moduleName}" has been generated.`,
          icon: '/icon.svg',
        });
      }
    } catch (error) {
      console.error("Failed to process queued request:", request, error);
      // Optional: Add request back to the queue for a retry.
      // For simplicity, we currently do not.
      new Notification('ContentCraft AI: Generation Failed', {
          body: `We couldn't generate content for "${request.payload.moduleName}". Please try again.`,
          icon: '/icon.svg'
      });
    }
  }
}
