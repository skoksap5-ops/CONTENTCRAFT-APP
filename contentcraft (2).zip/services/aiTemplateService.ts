

import { Type } from "@google/genai";
import { generateContent } from './geminiService';
import type { AIAnalysisData, TemplateData, PurposeData, GenerationResponse } from '../components/ai-template-builder/types';

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        patterns: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 3-5 successful content patterns for this niche."
        },
        optimalStructure: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    type: { type: Type.STRING, description: "The name of the structure section (e.g., 'Hook', 'Problem')." },
                    description: { type: Type.STRING, description: "A brief description of this section's purpose." }
                },
                required: ['type', 'description']
            },
            description: "An array of objects representing the optimal content structure."
        },
        estimatedEngagement: { type: Type.STRING, description: "An estimated engagement percentage, as a string (e.g., '85%')." },
        viralPotential: { type: Type.STRING, description: "A qualitative assessment of viral potential (e.g., 'High', 'Medium', 'Low')." }
    },
    required: ['patterns', 'optimalStructure', 'estimatedEngagement', 'viralPotential']
};

const singleTemplateSchema = {
    type: Type.OBJECT,
    properties: {
        name: { type: Type.STRING },
        platform: { type: Type.STRING },
        contentType: { type: Type.STRING },
        structure: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    type: { type: Type.STRING },
                    purpose: { type: Type.STRING },
                    content: { type: Type.STRING, description: "AI-generated example content for this section, with placeholders in [square brackets] for further user customization." },
                    examples: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ['type', 'purpose', 'content']
            }
        }
    },
    required: ['name', 'platform', 'contentType', 'structure']
};


const generationResponseSchema = {
    type: Type.OBJECT,
    properties: {
        variations: {
            type: Type.ARRAY,
            description: "An array of 3 distinct template variations.",
            items: {
                type: Type.OBJECT,
                properties: {
                    variationTitle: { type: Type.STRING, description: "The strategic name of this variation (e.g., 'Problem-Solution Focus')." },
                    approach: { type: Type.STRING, description: "A brief description of this variation's strategic approach." },
                    template: singleTemplateSchema,
                    predictedPerformance: {
                        type: Type.OBJECT,
                        properties: {
                            engagement: { type: Type.STRING, description: "Predicted engagement score or percentage (e.g., '4.2%')." },
                            bestFor: { type: Type.STRING, description: "The ideal audience or scenario for this variation." }
                        },
                        required: ['engagement', 'bestFor']
                    },
                    optimizationTips: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                        description: "A list of 2-3 actionable optimization tips."
                    }
                },
                required: ['variationTitle', 'approach', 'template', 'predictedPerformance', 'optimizationTips']
            }
        }
    },
    required: ['variations']
};

const aiTemplateService = {
  analyzePurpose: async (purposeData: PurposeData): Promise<AIAnalysisData> => {
    const prompt = `You are a world-class content strategist. Based on the following purpose definition, analyze successful content patterns and optimal structures.

Purpose Definition:
- Platform: ${purposeData.platform}
- Content Type: ${purposeData.contentType}
- Industry: ${purposeData.industry}
- Product Type: ${purposeData.productType}
- Primary Goal: ${purposeData.primaryGoal}
- Target Audience: ${purposeData.targetAudience}
- Brand Voice: ${purposeData.brandVoice}
${purposeData.productName ? `- Product Name: ${purposeData.productName}` : ''}
${purposeData.productDescription ? `- Product Description: ${purposeData.productDescription}` : ''}

Your response must be a valid JSON object conforming to the provided schema.`;

    const responseText = await generateContent(prompt, {
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
    });

    try {
        const result = JSON.parse(responseText);
        return result as AIAnalysisData;
    } catch (e) {
        console.error("Failed to parse analysis JSON:", responseText, e);
        throw new Error("The AI returned an unexpected format for analysis.");
    }
  },

  generateTemplate: async (userInput: {purpose: PurposeData, analysis: AIAnalysisData}): Promise<GenerationResponse> => {
    const prompt = `You are an expert template designer. Based on the provided purpose definition and AI analysis, generate a detailed, reusable content template package with 3 distinct variations.

Purpose Definition:
- Platform: ${userInput.purpose.platform}
- Content Type: ${userInput.purpose.contentType}
- Industry: ${userInput.purpose.industry}
- Product Type: ${userInput.purpose.productType}
- Primary Goal: ${userInput.purpose.primaryGoal}
- Target Audience: ${userInput.purpose.targetAudience}
- Brand Voice: ${userInput.purpose.brandVoice}
${userInput.purpose.productName ? `- Product Name: ${userInput.purpose.productName}` : ''}
${userInput.purpose.productDescription ? `- Product Description: ${userInput.purpose.productDescription}` : ''}

AI Analysis of Successful Content:
- Patterns: ${userInput.analysis.patterns.join(', ')}
- Optimal Structure: ${userInput.analysis.optimalStructure.map(s => `${s.type}: ${s.description}`).join('; ')}

**Instructions:**
1.  Create three distinct template variations:
    *   **Variation 1: Problem-Solution Focus:** Start with pain points, then present the solution.
    *   **Variation 2: Benefit-Driven Approach:** Lead with aspirational benefits and outcomes.
    *   **Variation 3: Social-Proof Centered:** Focus on testimonials, results, and success stories.
2.  For each variation, create a full template structure.
3.  **Auto-fill the 'content' field** of each structure section with realistic, industry-specific examples. Use [square brackets] for parts the user absolutely must customize. If a product name or description is provided, integrate them naturally into the example content.
4.  Provide a predicted performance analysis and actionable optimization tips for each variation.

Your response must be a valid JSON object conforming to the provided schema.`;

    const responseText = await generateContent(prompt, {
        responseMimeType: "application/json",
        responseSchema: generationResponseSchema,
    });

    try {
        const result = JSON.parse(responseText);
        return result as GenerationResponse;
    } catch (e) {
        console.error("Failed to parse template JSON:", responseText, e);
        throw new Error("The AI returned an unexpected format for the template.");
    }
  },
  
  optimizeTemplate: async (template: TemplateData, goals: { length: string; tone: string; }): Promise<TemplateData> => {
    const prompt = `You are a content optimization expert. Refine the provided template to better achieve the specified optimization goals.

Original Template JSON:
${JSON.stringify(template, null, 2)}

Optimization Goals:
- Desired Length: ${goals.length}
- Desired Tone Shift: ${goals.tone}

Your response must be a valid JSON object of the refined template, conforming to the same schema as the original template. The name should be updated to reflect that it is an optimized version (e.g., "AI-Optimized...").`;

    const responseText = await generateContent(prompt, {
        responseMimeType: "application/json",
        responseSchema: singleTemplateSchema,
    });

     try {
        const result = JSON.parse(responseText);
        return result as TemplateData;
    } catch (e) {
        console.error("Failed to parse optimized template JSON:", responseText, e);
        throw new Error("The AI returned an unexpected format for the optimized template.");
    }
  },
  
  personalizeTemplate: async (template: TemplateData, userInput: { persona: string }): Promise<TemplateData> => {
    const prompt = `You are a content personalization expert. Adapt the provided template for a specific audience segment or individual.

Original Template JSON:
${JSON.stringify(template, null, 2)}

Personalization Input:
- Target Persona: ${userInput.persona || 'Not specified'}

Your response must be a valid JSON object of the personalized template, conforming to the same schema as the original template. The name should be updated to reflect that it is a personalized version (e.g., "AI-Personalized..."). If no persona is specified, make minimal changes and just update the name.`;
    
    const responseText = await generateContent(prompt, {
        responseMimeType: "application/json",
        responseSchema: singleTemplateSchema,
    });

     try {
        const result = JSON.parse(responseText);
        return result as TemplateData;
    } catch (e) {
        console.error("Failed to parse personalized template JSON:", responseText, e);
        throw new Error("The AI returned an unexpected format for the personalized template.");
    }
  }
};

export { aiTemplateService };
