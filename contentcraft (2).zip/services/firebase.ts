import { initializeApp, type FirebaseApp } from 'firebase/app';
import { 
  getAuth, 
  onAuthStateChanged, 
  type Auth, 
  type User,
  signInWithPopup,
  GoogleAuthProvider,
  FacebookAuthProvider,
  GithubAuthProvider,
  OAuthProvider,
  signOut as firebaseSignOut,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendEmailVerification,
  updateProfile,
  sendPasswordResetEmail,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
} from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getAnalytics, type Analytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY,
  authDomain: process.env.FIREBASE_AUTH_DOMAIN,
  projectId: process.env.FIREBASE_PROJECT_ID,
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID,
};

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;
let analytics: Analytics | null = null;
let firebaseInitialized = false;

// Comprehensive check for all necessary Firebase config values
const requiredConfigKeys: (keyof typeof firebaseConfig)[] = [
  'apiKey',
  'authDomain',
  'projectId',
];
const missingKeys = requiredConfigKeys.filter(key => !firebaseConfig[key]);

if (missingKeys.length === 0) {
    try {
        app = initializeApp(firebaseConfig);
        auth = getAuth(app);
        db = getFirestore(app);
        if (firebaseConfig.appId) {
            analytics = getAnalytics(app);
        }
        firebaseInitialized = true;
    } catch (error) {
        console.error("Firebase initialization failed despite having keys. Ensure your Firebase environment variables are set correctly.", error);
        const errorMessage = `Firebase initialization failed. Check console for details.
        
Greška pri inicijalizaciji Firebase-a. Proverite konzolu za detalje.`;
        alert(errorMessage);
    }
} else {
    const errorTitle = "Firebase configuration is incomplete.";
    const errorSR = "Firebase konfiguracija je nepotpuna.";
    const errorMessage = `${errorTitle} Authentication and database features will be disabled. Please set the following environment variables: ${missingKeys.join(', ')}.

${errorSR} Funkcije za autentifikaciju i bazu podataka će biti onemogućene. Molimo vas da postavite sledeće varijable okruženja: ${missingKeys.join(', ')}.`;
    
    console.warn(errorMessage);
    // We can also throw an error to halt the app, which is better for development.
    // In a production app, we might just disable features, but for this context, failing fast is better.
    // For the purpose of this tool, we will show an alert and continue in a degraded mode.
    // alert(errorMessage);
}


const onAuthUserChanged = (callback: (user: User | null) => void) => {
    if (!auth) {
        callback(null);
        return () => {};
    }
    return onAuthStateChanged(auth, callback);
};

const authNotConfiguredError = `Firebase authentication is not configured. Please ensure your Firebase environment variables are set correctly.

Firebase autentifikacija nije konfigurisana. Molimo vas da proverite da li su vaše Firebase varijable okruženja ispravno postavljene.`;

export const signInWithGoogle = () => {
  if (!auth) return Promise.reject(new Error(authNotConfiguredError));
  const provider = new GoogleAuthProvider();
  return signInWithPopup(auth, provider);
};

export const signInWithFacebook = () => {
  if (!auth) return Promise.reject(new Error(authNotConfiguredError));
  const provider = new FacebookAuthProvider();
  return signInWithPopup(auth, provider);
};

export const signInWithGithub = () => {
  if (!auth) return Promise.reject(new Error(authNotConfiguredError));
  const provider = new GithubAuthProvider();
  return signInWithPopup(auth, provider);
};

export const signInWithMicrosoft = () => {
  if (!auth) return Promise.reject(new Error(authNotConfiguredError));
  const provider = new OAuthProvider('microsoft.com');
  return signInWithPopup(auth, provider);
};

export const signUpWithEmail = async (name: string, email: string, password: string): Promise<User> => {
  if (!auth) throw new Error(authNotConfiguredError);
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  if (userCredential.user) {
    await updateProfile(userCredential.user, { displayName: name });
    await sendEmailVerification(userCredential.user);
  }
  return userCredential.user;
};

export const signInWithEmail = (email: string, password: string, stayLoggedIn: boolean) => {
  if (!auth) return Promise.reject(new Error(authNotConfiguredError));
  const persistence = stayLoggedIn ? browserLocalPersistence : browserSessionPersistence;
  return setPersistence(auth, persistence).then(() => {
    return signInWithEmailAndPassword(auth, email, password);
  });
};

export const sendPasswordReset = (email: string) => {
  if (!auth) return Promise.reject(new Error(authNotConfiguredError));
  return sendPasswordResetEmail(auth, email);
};


export const signOut = () => {
  if (!auth) return Promise.reject(new Error(authNotConfiguredError));
  return firebaseSignOut(auth);
};


export { auth, db, analytics, onAuthUserChanged, firebaseInitialized };