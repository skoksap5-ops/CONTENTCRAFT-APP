import { GoogleGenAI, GenerateContentParameters, Content } from "@google/genai";

export const generateContent = async (
  contents: string | Content[],
  config?: GenerateContentParameters['config']
): Promise<string> => {
  if (!process.env.API_KEY) {
      const errorMessage = `Gemini API key is not configured. Please set the API_KEY environment variable.
      
Greška sa API ključem: Gemini API ključ nije konfigurisan. Molimo vas da postavite API_KEY varijablu okruženja.`;
      throw new Error(errorMessage);
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents,
      config: {
        temperature: 0.7,
        topP: 0.95,
        ...config,
      }
    });
    
    return response.text;
  } catch (error: any) {
    console.error("Error generating content:", error);
    let errorMessage = "An unexpected error occurred while generating content.";
    
    const rawMessage = error?.message || (typeof error === 'object' ? JSON.stringify(error) : String(error));
    
    if (rawMessage.toLowerCase().includes('permission') || rawMessage.toLowerCase().includes('api key')) {
        errorMessage = `API Permission Error: The server denied the request. This is almost always due to an incorrectly configured API key. Please verify that the API_KEY environment variable is set correctly, is valid, and has the 'Generative Language API' enabled for your project.

Greška sa API ključem: Došlo je do greške u pristupu. Ovo se obično dešava kada API ključ nije ispravno konfigurisan. Molimo vas da proverite da li je API_KEY varijabla okruženja ispravno postavljena, važeća i da li je "Generative Language API" omogućen u vašem Google Cloud projektu.

Raw error: "${rawMessage}"`;
    } else {
        errorMessage = `An error occurred: ${rawMessage}. Please check your network connection.`;
    }

    throw new Error(errorMessage);
  }
};