import { generateContent } from './geminiService';
import { Type } from "@google/genai";
import type { CampaignDay, CampaignConfig, StrategyData } from '../components/social-campaign-planner/types';

const campaignSchema = {
    type: Type.ARRAY,
    description: "A social media campaign plan for the specified number of days.",
    items: {
      type: Type.OBJECT,
      properties: {
        day: { type: Type.NUMBER, description: "The day of the campaign (e.g., 1, 2, 3)." },
        theme: { type: Type.STRING, description: "The content theme or focus for this day." },
        posts: {
          type: Type.ARRAY,
          description: "A list of posts for this day, one for each selected platform.",
          items: {
            type: Type.OBJECT,
            properties: {
              platform: { type: Type.STRING, description: "The social media platform (e.g., 'Twitter', 'LinkedIn')." },
              postContent: { type: Type.STRING, description: "The full text content for the post, including emojis and line breaks." },
              visualSuggestion: { type: Type.STRING, description: "A brief description of a suggested visual (image or video)." },
              hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ['platform', 'postContent', 'visualSuggestion', 'hashtags'],
          }
        }
      },
      required: ['day', 'theme', 'posts'],
    }
  };


const generateContentCalendar = async (config: CampaignConfig & StrategyData): Promise<CampaignDay[]> => {
    const prompt = `You are an expert social media strategist. Based on the user's input, generate a comprehensive, day-by-day social media content calendar.

    **INPUT:**
    - Campaign Name: ${config.campaignName}
    - Campaign Duration: ${config.timeframe}
    - Content Pillars: ${config.contentPillars.join(', ')}
    - Target Audience: ${config.targetAudience}
    - Campaign Goals: ${config.goals.join(', ')}
    - Target Platforms: ${config.platforms.join(', ')}
    - Posting Frequency: ${config.postingFrequency}
    - Content Mix: ${config.contentMix}
    - Hashtag Strategy: ${config.hashtagStrategy}
    
    **INSTRUCTIONS:**
    1.  Create a content plan for the specified duration (e.g., for '7d', generate 7 days of content).
    2.  For each day, provide a clear content theme based on the content pillars.
    3.  For each day, generate a specific post for each selected platform.
    4.  Each post must include:
        *   Engaging text content formatted for the platform.
        *   A creative suggestion for a visual element (image or video) if requested.
        *   A set of 3-5 strategic hashtags.
    5.  Your response MUST be a valid JSON object conforming to the provided schema. Ensure 'postContent' uses markdown for line breaks (\\n).
    `;

    const responseText = await generateContent(prompt, {
        responseMimeType: "application/json",
        responseSchema: campaignSchema,
    });

    try {
        const parsedResponse = JSON.parse(responseText);
        if (!Array.isArray(parsedResponse)) {
            throw new Error("AI response is not an array.");
        }
        return parsedResponse;
    } catch (e) {
        console.error("Failed to parse calendar JSON:", responseText, e);
        throw new Error("The AI returned an unexpected format for the calendar.");
    }
};

const optimizePostingSchedule = async (calendar: CampaignDay[], config: any): Promise<CampaignDay[]> => {
    // This is a placeholder for a potential future feature.
    console.log("Optimizing schedule for:", config.platforms);
    return Promise.resolve(calendar);
}

export const calendarService = {
    generateContentCalendar,
    optimizePostingSchedule
};
